﻿namespace DrectSoft.Core.IEMMainPageZY
{
    partial class UCIemDiagnose
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UCIemDiagnose));
            this.btnNewOutDiag = new DevExpress.XtraEditors.SimpleButton();
            this.labelControl117 = new DevExpress.XtraEditors.LabelControl();
            this.gridControl1 = new DevExpress.XtraGrid.GridControl();
            this.gridViewDiagnose = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn5 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn3 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn4 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridView2 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.barManager1 = new DevExpress.XtraBars.BarManager(this.components);
            this.barDockControlTop = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlBottom = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlLeft = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlRight = new DevExpress.XtraBars.BarDockControl();
            this.btn_del_diag = new DevExpress.XtraBars.BarButtonItem();
            this.popupMenu1 = new DevExpress.XtraBars.PopupMenu(this.components);
            this.labelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.gridControl2 = new DevExpress.XtraGrid.GridControl();
            this.gridViewDiagnose2 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn9 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn10 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn11 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn12 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn13 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridView3 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.btn_up = new DrectSoft.Common.Ctrs.OTHER.DevButtonUp(this.components);
            this.btn_down = new DrectSoft.Common.Ctrs.OTHER.DevButtonDown(this.components);
            this.btnEditOutDiag = new DrectSoft.Common.Ctrs.OTHER.DevButtonEdit(this.components);
            this.btn_del = new DrectSoft.Common.Ctrs.OTHER.DevButtonDelete(this.components);
            this.btn_up2 = new DrectSoft.Common.Ctrs.OTHER.DevButtonUp(this.components);
            this.btn_down2 = new DrectSoft.Common.Ctrs.OTHER.DevButtonDown(this.components);
            this.btnEditOutDiagCHn = new DrectSoft.Common.Ctrs.OTHER.DevButtonEdit(this.components);
            this.btn_del2 = new DrectSoft.Common.Ctrs.OTHER.DevButtonDelete(this.components);
            this.panelControl1 = new DevExpress.XtraEditors.PanelControl();
            this.btn_Close = new DrectSoft.Common.Ctrs.OTHER.DevButtonClose(this.components);
            this.btn_OK = new DrectSoft.Common.Ctrs.OTHER.DevButtonSave(this.components);
            this.txtSuccessCS = new DrectSoft.Common.Ctrs.OTHER.DSTextBox();
            this.labelControl12 = new DevExpress.XtraEditors.LabelControl();
            this.txtQJCS = new DrectSoft.Common.Ctrs.OTHER.DSTextBox();
            this.labelControl11 = new DevExpress.XtraEditors.LabelControl();
            this.chkInpLY5 = new DevExpress.XtraEditors.CheckEdit();
            this.chkInpLY4 = new DevExpress.XtraEditors.CheckEdit();
            this.chkInpLY3 = new DevExpress.XtraEditors.CheckEdit();
            this.chkInpLY2 = new DevExpress.XtraEditors.CheckEdit();
            this.chkInpLY1 = new DevExpress.XtraEditors.CheckEdit();
            this.labelControl10 = new DevExpress.XtraEditors.LabelControl();
            this.ChkFSYBL3 = new DevExpress.XtraEditors.CheckEdit();
            this.chkFSYBL2 = new DevExpress.XtraEditors.CheckEdit();
            this.chkFSYBL1 = new DevExpress.XtraEditors.CheckEdit();
            this.chkFSYBL0 = new DevExpress.XtraEditors.CheckEdit();
            this.labelControl9 = new DevExpress.XtraEditors.LabelControl();
            this.chkLCYBL3 = new DevExpress.XtraEditors.CheckEdit();
            this.chkLCYBL2 = new DevExpress.XtraEditors.CheckEdit();
            this.chkLCYBL1 = new DevExpress.XtraEditors.CheckEdit();
            this.chkLCYBL0 = new DevExpress.XtraEditors.CheckEdit();
            this.labelControl8 = new DevExpress.XtraEditors.LabelControl();
            this.chkRYYCY3 = new DevExpress.XtraEditors.CheckEdit();
            this.chkRYYCY2 = new DevExpress.XtraEditors.CheckEdit();
            this.chkRYYCY1 = new DevExpress.XtraEditors.CheckEdit();
            this.chkRYYCY0 = new DevExpress.XtraEditors.CheckEdit();
            this.labelControl7 = new DevExpress.XtraEditors.LabelControl();
            this.chkMZYCY3 = new DevExpress.XtraEditors.CheckEdit();
            this.chkMZYCY2 = new DevExpress.XtraEditors.CheckEdit();
            this.chkMZYCY1 = new DevExpress.XtraEditors.CheckEdit();
            this.chkMZYCY0 = new DevExpress.XtraEditors.CheckEdit();
            this.labelControl6 = new DevExpress.XtraEditors.LabelControl();
            this.chkYNZZF = new DevExpress.XtraEditors.CheckEdit();
            this.chkYNZZS = new DevExpress.XtraEditors.CheckEdit();
            this.labelControl5 = new DevExpress.XtraEditors.LabelControl();
            this.chkOutOthers = new DevExpress.XtraEditors.CheckEdit();
            this.chkOutDead = new DevExpress.XtraEditors.CheckEdit();
            this.chkOutWY = new DevExpress.XtraEditors.CheckEdit();
            this.chkOutHZ = new DevExpress.XtraEditors.CheckEdit();
            this.chkOutZY = new DevExpress.XtraEditors.CheckEdit();
            this.labelControl4 = new DevExpress.XtraEditors.LabelControl();
            this.lookUpEditPathologyName = new DrectSoft.Common.Library.LookUpEditor();
            this.deZkDate = new DrectSoft.Common.Ctrs.OTHER.DSDateEdit(this.components);
            this.lueHurt_Toxicosis_Ele = new DrectSoft.Common.Library.LookUpEditor();
            this.chkMedicalQuality3 = new DevExpress.XtraEditors.CheckEdit();
            this.chkMedicalQuality2 = new DevExpress.XtraEditors.CheckEdit();
            this.chkMedicalQuality1 = new DevExpress.XtraEditors.CheckEdit();
            this.lueZkys = new DrectSoft.Common.Library.LookUpEditor();
            this.labelControl56 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl55 = new DevExpress.XtraEditors.LabelControl();
            this.lueZkhs = new DrectSoft.Common.Library.LookUpEditor();
            this.labelControl53 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl16 = new DevExpress.XtraEditors.LabelControl();
            this.lueBmy = new DrectSoft.Common.Library.LookUpEditor();
            this.labelControl49 = new DevExpress.XtraEditors.LabelControl();
            this.lueSxys = new DrectSoft.Common.Library.LookUpEditor();
            this.labelControl50 = new DevExpress.XtraEditors.LabelControl();
            this.luejxys = new DrectSoft.Common.Library.LookUpEditor();
            this.labelControl51 = new DevExpress.XtraEditors.LabelControl();
            this.lueDuty_Nurse = new DrectSoft.Common.Library.LookUpEditor();
            this.labelControl52 = new DevExpress.XtraEditors.LabelControl();
            this.lueZyys = new DrectSoft.Common.Library.LookUpEditor();
            this.labelControl47 = new DevExpress.XtraEditors.LabelControl();
            this.lueZzys = new DrectSoft.Common.Library.LookUpEditor();
            this.labelControl48 = new DevExpress.XtraEditors.LabelControl();
            this.lueZrys = new DrectSoft.Common.Library.LookUpEditor();
            this.labelControl46 = new DevExpress.XtraEditors.LabelControl();
            this.lueKszr = new DrectSoft.Common.Library.LookUpEditor();
            this.labelControl45 = new DevExpress.XtraEditors.LabelControl();
            this.chkBlood6 = new DevExpress.XtraEditors.CheckEdit();
            this.chkBlood4 = new DevExpress.XtraEditors.CheckEdit();
            this.chkBlood5 = new DevExpress.XtraEditors.CheckEdit();
            this.chkBlood3 = new DevExpress.XtraEditors.CheckEdit();
            this.chkBlood2 = new DevExpress.XtraEditors.CheckEdit();
            this.chkBlood1 = new DevExpress.XtraEditors.CheckEdit();
            this.chkRH4 = new DevExpress.XtraEditors.CheckEdit();
            this.chkRH3 = new DevExpress.XtraEditors.CheckEdit();
            this.chkAutopsy2 = new DevExpress.XtraEditors.CheckEdit();
            this.chkAllergic2 = new DevExpress.XtraEditors.CheckEdit();
            this.chkRH2 = new DevExpress.XtraEditors.CheckEdit();
            this.chkRH1 = new DevExpress.XtraEditors.CheckEdit();
            this.chkAutopsy1 = new DevExpress.XtraEditors.CheckEdit();
            this.chkAllergic1 = new DevExpress.XtraEditors.CheckEdit();
            this.labelControl3 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl18 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl14 = new DevExpress.XtraEditors.LabelControl();
            this.txtAllergicDrug = new DrectSoft.Common.Ctrs.OTHER.DSTextBox();
            this.labelControl17 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl122 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl118 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.txtPathologyID = new DrectSoft.Common.Ctrs.OTHER.DSTextBox();
            this.labelControl119 = new DevExpress.XtraEditors.LabelControl();
            this.txtPathologySn = new DrectSoft.Common.Ctrs.OTHER.DSTextBox();
            this.labelControl121 = new DevExpress.XtraEditors.LabelControl();
            this.DevTextEdit1 = new DrectSoft.Common.Ctrs.OTHER.DevTextEdit();
            ((System.ComponentModel.ISupportInitialize)(this.gridControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewDiagnose)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.barManager1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.popupMenu1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridControl2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewDiagnose2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).BeginInit();
            this.panelControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtSuccessCS.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtQJCS.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkInpLY5.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkInpLY4.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkInpLY3.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkInpLY2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkInpLY1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ChkFSYBL3.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkFSYBL2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkFSYBL1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkFSYBL0.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkLCYBL3.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkLCYBL2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkLCYBL1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkLCYBL0.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkRYYCY3.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkRYYCY2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkRYYCY1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkRYYCY0.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkMZYCY3.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkMZYCY2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkMZYCY1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkMZYCY0.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkYNZZF.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkYNZZS.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkOutOthers.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkOutDead.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkOutWY.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkOutHZ.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkOutZY.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookUpEditPathologyName)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.deZkDate.Properties.VistaTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.deZkDate.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueHurt_Toxicosis_Ele)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkMedicalQuality3.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkMedicalQuality2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkMedicalQuality1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueZkys)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueZkhs)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueBmy)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueSxys)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.luejxys)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueDuty_Nurse)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueZyys)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueZzys)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueZrys)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueKszr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkBlood6.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkBlood4.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkBlood5.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkBlood3.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkBlood2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkBlood1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkRH4.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkRH3.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkAutopsy2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkAllergic2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkRH2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkRH1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkAutopsy1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkAllergic1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtAllergicDrug.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPathologyID.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPathologySn.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DevTextEdit1.Properties)).BeginInit();
            this.SuspendLayout();
            // 
            // btnNewOutDiag
            // 
            this.btnNewOutDiag.Location = new System.Drawing.Point(89, 10);
            this.btnNewOutDiag.Name = "btnNewOutDiag";
            this.btnNewOutDiag.Size = new System.Drawing.Size(102, 23);
            this.btnNewOutDiag.TabIndex = 0;
            this.btnNewOutDiag.Text = "新增出院诊断";
            this.btnNewOutDiag.Click += new System.EventHandler(this.btnNewOutDiag_Click);
            // 
            // labelControl117
            // 
            this.labelControl117.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl117.Location = new System.Drawing.Point(13, 13);
            this.labelControl117.Name = "labelControl117";
            this.labelControl117.Size = new System.Drawing.Size(60, 14);
            this.labelControl117.TabIndex = 115;
            this.labelControl117.Text = "出院诊断：";
            // 
            // gridControl1
            // 
            this.gridControl1.AllowDrop = true;
            this.gridControl1.Location = new System.Drawing.Point(0, 40);
            this.gridControl1.MainView = this.gridViewDiagnose;
            this.gridControl1.Name = "gridControl1";
            this.gridControl1.Size = new System.Drawing.Size(587, 101);
            this.gridControl1.TabIndex = 9;
            this.gridControl1.TabStop = false;
            this.gridControl1.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridViewDiagnose,
            this.gridView2});
            this.gridControl1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.gridControl1_MouseUp);
            // 
            // gridViewDiagnose
            // 
            this.gridViewDiagnose.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn1,
            this.gridColumn5,
            this.gridColumn3,
            this.gridColumn2,
            this.gridColumn4});
            this.gridViewDiagnose.GridControl = this.gridControl1;
            this.gridViewDiagnose.Name = "gridViewDiagnose";
            this.gridViewDiagnose.OptionsBehavior.AutoExpandAllGroups = true;
            this.gridViewDiagnose.OptionsBehavior.Editable = false;
            this.gridViewDiagnose.OptionsBehavior.ReadOnly = true;
            this.gridViewDiagnose.OptionsCustomization.AllowColumnMoving = false;
            this.gridViewDiagnose.OptionsCustomization.AllowFilter = false;
            this.gridViewDiagnose.OptionsCustomization.AllowSort = false;
            this.gridViewDiagnose.OptionsFilter.AllowColumnMRUFilterList = false;
            this.gridViewDiagnose.OptionsFilter.AllowFilterEditor = false;
            this.gridViewDiagnose.OptionsFilter.AllowMRUFilterList = false;
            this.gridViewDiagnose.OptionsMenu.EnableColumnMenu = false;
            this.gridViewDiagnose.OptionsMenu.EnableFooterMenu = false;
            this.gridViewDiagnose.OptionsMenu.EnableGroupPanelMenu = false;
            this.gridViewDiagnose.OptionsMenu.ShowAutoFilterRowItem = false;
            this.gridViewDiagnose.OptionsMenu.ShowDateTimeGroupIntervalItems = false;
            this.gridViewDiagnose.OptionsMenu.ShowGroupSortSummaryItems = false;
            this.gridViewDiagnose.OptionsView.ShowGroupPanel = false;
            this.gridViewDiagnose.OptionsView.ShowIndicator = false;
            // 
            // gridColumn1
            // 
            this.gridColumn1.Caption = "出院西医诊断";
            this.gridColumn1.FieldName = "Diagnosis_Name";
            this.gridColumn1.Name = "gridColumn1";
            this.gridColumn1.OptionsColumn.AllowEdit = false;
            this.gridColumn1.Visible = true;
            this.gridColumn1.VisibleIndex = 0;
            // 
            // gridColumn5
            // 
            this.gridColumn5.Caption = "诊断结果ID";
            this.gridColumn5.FieldName = "Status_Id";
            this.gridColumn5.Name = "gridColumn5";
            // 
            // gridColumn3
            // 
            this.gridColumn3.Caption = "ICD-10编码";
            this.gridColumn3.FieldName = "Diagnosis_Code";
            this.gridColumn3.Name = "gridColumn3";
            this.gridColumn3.OptionsColumn.AllowEdit = false;
            this.gridColumn3.Visible = true;
            this.gridColumn3.VisibleIndex = 1;
            // 
            // gridColumn2
            // 
            this.gridColumn2.Caption = "入院病情";
            this.gridColumn2.FieldName = "Status_Name";
            this.gridColumn2.Name = "gridColumn2";
            this.gridColumn2.OptionsColumn.AllowEdit = false;
            this.gridColumn2.Visible = true;
            this.gridColumn2.VisibleIndex = 2;
            // 
            // gridColumn4
            // 
            this.gridColumn4.Caption = "是否主诊断";
            this.gridColumn4.Name = "gridColumn4";
            this.gridColumn4.OptionsColumn.AllowEdit = false;
            // 
            // gridView2
            // 
            this.gridView2.GridControl = this.gridControl1;
            this.gridView2.Name = "gridView2";
            // 
            // barManager1
            // 
            this.barManager1.DockControls.Add(this.barDockControlTop);
            this.barManager1.DockControls.Add(this.barDockControlBottom);
            this.barManager1.DockControls.Add(this.barDockControlLeft);
            this.barManager1.DockControls.Add(this.barDockControlRight);
            this.barManager1.Form = this;
            this.barManager1.Items.AddRange(new DevExpress.XtraBars.BarItem[] {
            this.btn_del_diag});
            this.barManager1.MaxItemId = 1;
            this.barManager1.QueryShowPopupMenu += new DevExpress.XtraBars.QueryShowPopupMenuEventHandler(this.barManager1_QueryShowPopupMenu);
            // 
            // barDockControlTop
            // 
            this.barDockControlTop.CausesValidation = false;
            this.barDockControlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.barDockControlTop.Location = new System.Drawing.Point(0, 0);
            this.barDockControlTop.Size = new System.Drawing.Size(700, 0);
            // 
            // barDockControlBottom
            // 
            this.barDockControlBottom.CausesValidation = false;
            this.barDockControlBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.barDockControlBottom.Location = new System.Drawing.Point(0, 710);
            this.barDockControlBottom.Size = new System.Drawing.Size(700, 0);
            // 
            // barDockControlLeft
            // 
            this.barDockControlLeft.CausesValidation = false;
            this.barDockControlLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.barDockControlLeft.Location = new System.Drawing.Point(0, 0);
            this.barDockControlLeft.Size = new System.Drawing.Size(0, 710);
            // 
            // barDockControlRight
            // 
            this.barDockControlRight.CausesValidation = false;
            this.barDockControlRight.Dock = System.Windows.Forms.DockStyle.Right;
            this.barDockControlRight.Location = new System.Drawing.Point(700, 0);
            this.barDockControlRight.Size = new System.Drawing.Size(0, 710);
            // 
            // btn_del_diag
            // 
            this.btn_del_diag.Caption = "删除";
            this.btn_del_diag.Id = 0;
            this.btn_del_diag.Name = "btn_del_diag";
            this.btn_del_diag.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btn_del_diag_ItemClick);
            // 
            // popupMenu1
            // 
            this.popupMenu1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.btn_del_diag)});
            this.popupMenu1.Manager = this.barManager1;
            this.popupMenu1.Name = "popupMenu1";
            // 
            // labelControl2
            // 
            this.labelControl2.Appearance.ForeColor = System.Drawing.Color.Red;
            this.labelControl2.Location = new System.Drawing.Point(392, 13);
            this.labelControl2.Name = "labelControl2";
            this.labelControl2.Size = new System.Drawing.Size(190, 14);
            this.labelControl2.TabIndex = 115;
            this.labelControl2.Text = "(中西医诊断的第一条记录为主诊断)";
            // 
            // gridControl2
            // 
            this.gridControl2.AllowDrop = true;
            this.gridControl2.Location = new System.Drawing.Point(0, 147);
            this.gridControl2.MainView = this.gridViewDiagnose2;
            this.gridControl2.Name = "gridControl2";
            this.gridControl2.Size = new System.Drawing.Size(587, 98);
            this.gridControl2.TabIndex = 195;
            this.gridControl2.TabStop = false;
            this.gridControl2.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridViewDiagnose2,
            this.gridView3});
            // 
            // gridViewDiagnose2
            // 
            this.gridViewDiagnose2.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn9,
            this.gridColumn10,
            this.gridColumn11,
            this.gridColumn12,
            this.gridColumn13});
            this.gridViewDiagnose2.GridControl = this.gridControl2;
            this.gridViewDiagnose2.Name = "gridViewDiagnose2";
            this.gridViewDiagnose2.OptionsBehavior.AutoExpandAllGroups = true;
            this.gridViewDiagnose2.OptionsBehavior.Editable = false;
            this.gridViewDiagnose2.OptionsBehavior.ReadOnly = true;
            this.gridViewDiagnose2.OptionsCustomization.AllowColumnMoving = false;
            this.gridViewDiagnose2.OptionsCustomization.AllowFilter = false;
            this.gridViewDiagnose2.OptionsCustomization.AllowSort = false;
            this.gridViewDiagnose2.OptionsFilter.AllowColumnMRUFilterList = false;
            this.gridViewDiagnose2.OptionsFilter.AllowFilterEditor = false;
            this.gridViewDiagnose2.OptionsFilter.AllowMRUFilterList = false;
            this.gridViewDiagnose2.OptionsMenu.EnableColumnMenu = false;
            this.gridViewDiagnose2.OptionsMenu.EnableFooterMenu = false;
            this.gridViewDiagnose2.OptionsMenu.EnableGroupPanelMenu = false;
            this.gridViewDiagnose2.OptionsMenu.ShowAutoFilterRowItem = false;
            this.gridViewDiagnose2.OptionsMenu.ShowDateTimeGroupIntervalItems = false;
            this.gridViewDiagnose2.OptionsMenu.ShowGroupSortSummaryItems = false;
            this.gridViewDiagnose2.OptionsView.ShowGroupPanel = false;
            this.gridViewDiagnose2.OptionsView.ShowIndicator = false;
            // 
            // gridColumn9
            // 
            this.gridColumn9.Caption = "出院中医诊断";
            this.gridColumn9.FieldName = "Diagnosis_Name";
            this.gridColumn9.Name = "gridColumn9";
            this.gridColumn9.OptionsColumn.AllowEdit = false;
            this.gridColumn9.Visible = true;
            this.gridColumn9.VisibleIndex = 0;
            // 
            // gridColumn10
            // 
            this.gridColumn10.Caption = "诊断结果ID";
            this.gridColumn10.FieldName = "Status_Id";
            this.gridColumn10.Name = "gridColumn10";
            // 
            // gridColumn11
            // 
            this.gridColumn11.Caption = "ICD-10编码";
            this.gridColumn11.FieldName = "Diagnosis_Code";
            this.gridColumn11.Name = "gridColumn11";
            this.gridColumn11.OptionsColumn.AllowEdit = false;
            this.gridColumn11.Visible = true;
            this.gridColumn11.VisibleIndex = 1;
            // 
            // gridColumn12
            // 
            this.gridColumn12.Caption = "入院病情";
            this.gridColumn12.FieldName = "Status_Name";
            this.gridColumn12.Name = "gridColumn12";
            this.gridColumn12.OptionsColumn.AllowEdit = false;
            this.gridColumn12.Visible = true;
            this.gridColumn12.VisibleIndex = 2;
            // 
            // gridColumn13
            // 
            this.gridColumn13.Caption = "是否主诊断";
            this.gridColumn13.Name = "gridColumn13";
            this.gridColumn13.OptionsColumn.AllowEdit = false;
            // 
            // gridView3
            // 
            this.gridView3.GridControl = this.gridControl2;
            this.gridView3.Name = "gridView3";
            // 
            // btn_up
            // 
            this.btn_up.Image = ((System.Drawing.Image)(resources.GetObject("btn_up.Image")));
            this.btn_up.Location = new System.Drawing.Point(604, 37);
            this.btn_up.Name = "btn_up";
            this.btn_up.Size = new System.Drawing.Size(80, 23);
            this.btn_up.TabIndex = 1;
            this.btn_up.Text = "上移(&N)";
            this.btn_up.Click += new System.EventHandler(this.btn_up_Click);
            // 
            // btn_down
            // 
            this.btn_down.Image = ((System.Drawing.Image)(resources.GetObject("btn_down.Image")));
            this.btn_down.Location = new System.Drawing.Point(604, 64);
            this.btn_down.Name = "btn_down";
            this.btn_down.Size = new System.Drawing.Size(80, 23);
            this.btn_down.TabIndex = 2;
            this.btn_down.Text = "下移(&X)";
            this.btn_down.Click += new System.EventHandler(this.btn_down_Click);
            // 
            // btnEditOutDiag
            // 
            this.btnEditOutDiag.Image = ((System.Drawing.Image)(resources.GetObject("btnEditOutDiag.Image")));
            this.btnEditOutDiag.Location = new System.Drawing.Point(604, 91);
            this.btnEditOutDiag.Name = "btnEditOutDiag";
            this.btnEditOutDiag.Size = new System.Drawing.Size(80, 23);
            this.btnEditOutDiag.TabIndex = 3;
            this.btnEditOutDiag.Text = "编辑(&E)";
            this.btnEditOutDiag.Click += new System.EventHandler(this.btnEditOutDiag_Click);
            // 
            // btn_del
            // 
            this.btn_del.Image = ((System.Drawing.Image)(resources.GetObject("btn_del.Image")));
            this.btn_del.Location = new System.Drawing.Point(604, 118);
            this.btn_del.Name = "btn_del";
            this.btn_del.Size = new System.Drawing.Size(80, 23);
            this.btn_del.TabIndex = 4;
            this.btn_del.Text = "删除(&D)";
            this.btn_del.Click += new System.EventHandler(this.btn_del_Click);
            // 
            // btn_up2
            // 
            this.btn_up2.Image = ((System.Drawing.Image)(resources.GetObject("btn_up2.Image")));
            this.btn_up2.Location = new System.Drawing.Point(604, 147);
            this.btn_up2.Name = "btn_up2";
            this.btn_up2.Size = new System.Drawing.Size(80, 23);
            this.btn_up2.TabIndex = 5;
            this.btn_up2.Text = "上移(&N)";
            this.btn_up2.Click += new System.EventHandler(this.btn_up2_Click);
            // 
            // btn_down2
            // 
            this.btn_down2.Image = ((System.Drawing.Image)(resources.GetObject("btn_down2.Image")));
            this.btn_down2.Location = new System.Drawing.Point(604, 173);
            this.btn_down2.Name = "btn_down2";
            this.btn_down2.Size = new System.Drawing.Size(80, 23);
            this.btn_down2.TabIndex = 6;
            this.btn_down2.Text = "下移(&X)";
            this.btn_down2.Click += new System.EventHandler(this.btn_down2_Click);
            // 
            // btnEditOutDiagCHn
            // 
            this.btnEditOutDiagCHn.Image = ((System.Drawing.Image)(resources.GetObject("btnEditOutDiagCHn.Image")));
            this.btnEditOutDiagCHn.Location = new System.Drawing.Point(604, 199);
            this.btnEditOutDiagCHn.Name = "btnEditOutDiagCHn";
            this.btnEditOutDiagCHn.Size = new System.Drawing.Size(80, 23);
            this.btnEditOutDiagCHn.TabIndex = 7;
            this.btnEditOutDiagCHn.Text = "编辑(&E)";
            this.btnEditOutDiagCHn.Click += new System.EventHandler(this.btnEditOutDiagCHn_Click);
            // 
            // btn_del2
            // 
            this.btn_del2.Image = ((System.Drawing.Image)(resources.GetObject("btn_del2.Image")));
            this.btn_del2.Location = new System.Drawing.Point(604, 225);
            this.btn_del2.Name = "btn_del2";
            this.btn_del2.Size = new System.Drawing.Size(80, 23);
            this.btn_del2.TabIndex = 8;
            this.btn_del2.Text = "删除(&D)";
            this.btn_del2.Click += new System.EventHandler(this.btn_del2_Click);
            // 
            // panelControl1
            // 
            this.panelControl1.Appearance.BackColor = System.Drawing.Color.White;
            this.panelControl1.Appearance.Options.UseBackColor = true;
            this.panelControl1.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.panelControl1.Controls.Add(this.btn_Close);
            this.panelControl1.Controls.Add(this.btn_OK);
            this.panelControl1.Controls.Add(this.txtSuccessCS);
            this.panelControl1.Controls.Add(this.labelControl12);
            this.panelControl1.Controls.Add(this.txtQJCS);
            this.panelControl1.Controls.Add(this.labelControl11);
            this.panelControl1.Controls.Add(this.chkInpLY5);
            this.panelControl1.Controls.Add(this.chkInpLY4);
            this.panelControl1.Controls.Add(this.chkInpLY3);
            this.panelControl1.Controls.Add(this.chkInpLY2);
            this.panelControl1.Controls.Add(this.chkInpLY1);
            this.panelControl1.Controls.Add(this.labelControl10);
            this.panelControl1.Controls.Add(this.ChkFSYBL3);
            this.panelControl1.Controls.Add(this.chkFSYBL2);
            this.panelControl1.Controls.Add(this.chkFSYBL1);
            this.panelControl1.Controls.Add(this.chkFSYBL0);
            this.panelControl1.Controls.Add(this.labelControl9);
            this.panelControl1.Controls.Add(this.chkLCYBL3);
            this.panelControl1.Controls.Add(this.chkLCYBL2);
            this.panelControl1.Controls.Add(this.chkLCYBL1);
            this.panelControl1.Controls.Add(this.chkLCYBL0);
            this.panelControl1.Controls.Add(this.labelControl8);
            this.panelControl1.Controls.Add(this.chkRYYCY3);
            this.panelControl1.Controls.Add(this.chkRYYCY2);
            this.panelControl1.Controls.Add(this.chkRYYCY1);
            this.panelControl1.Controls.Add(this.chkRYYCY0);
            this.panelControl1.Controls.Add(this.labelControl7);
            this.panelControl1.Controls.Add(this.chkMZYCY3);
            this.panelControl1.Controls.Add(this.chkMZYCY2);
            this.panelControl1.Controls.Add(this.chkMZYCY1);
            this.panelControl1.Controls.Add(this.chkMZYCY0);
            this.panelControl1.Controls.Add(this.labelControl6);
            this.panelControl1.Controls.Add(this.chkYNZZF);
            this.panelControl1.Controls.Add(this.chkYNZZS);
            this.panelControl1.Controls.Add(this.labelControl5);
            this.panelControl1.Controls.Add(this.chkOutOthers);
            this.panelControl1.Controls.Add(this.chkOutDead);
            this.panelControl1.Controls.Add(this.chkOutWY);
            this.panelControl1.Controls.Add(this.chkOutHZ);
            this.panelControl1.Controls.Add(this.chkOutZY);
            this.panelControl1.Controls.Add(this.labelControl4);
            this.panelControl1.Controls.Add(this.lookUpEditPathologyName);
            this.panelControl1.Controls.Add(this.deZkDate);
            this.panelControl1.Controls.Add(this.lueHurt_Toxicosis_Ele);
            this.panelControl1.Controls.Add(this.chkMedicalQuality3);
            this.panelControl1.Controls.Add(this.chkMedicalQuality2);
            this.panelControl1.Controls.Add(this.chkMedicalQuality1);
            this.panelControl1.Controls.Add(this.lueZkys);
            this.panelControl1.Controls.Add(this.labelControl56);
            this.panelControl1.Controls.Add(this.labelControl55);
            this.panelControl1.Controls.Add(this.lueZkhs);
            this.panelControl1.Controls.Add(this.labelControl53);
            this.panelControl1.Controls.Add(this.labelControl16);
            this.panelControl1.Controls.Add(this.lueBmy);
            this.panelControl1.Controls.Add(this.labelControl49);
            this.panelControl1.Controls.Add(this.lueSxys);
            this.panelControl1.Controls.Add(this.labelControl50);
            this.panelControl1.Controls.Add(this.luejxys);
            this.panelControl1.Controls.Add(this.labelControl51);
            this.panelControl1.Controls.Add(this.lueDuty_Nurse);
            this.panelControl1.Controls.Add(this.labelControl52);
            this.panelControl1.Controls.Add(this.lueZyys);
            this.panelControl1.Controls.Add(this.labelControl47);
            this.panelControl1.Controls.Add(this.lueZzys);
            this.panelControl1.Controls.Add(this.labelControl48);
            this.panelControl1.Controls.Add(this.lueZrys);
            this.panelControl1.Controls.Add(this.labelControl46);
            this.panelControl1.Controls.Add(this.lueKszr);
            this.panelControl1.Controls.Add(this.labelControl45);
            this.panelControl1.Controls.Add(this.chkBlood6);
            this.panelControl1.Controls.Add(this.chkBlood4);
            this.panelControl1.Controls.Add(this.chkBlood5);
            this.panelControl1.Controls.Add(this.chkBlood3);
            this.panelControl1.Controls.Add(this.chkBlood2);
            this.panelControl1.Controls.Add(this.chkBlood1);
            this.panelControl1.Controls.Add(this.chkRH4);
            this.panelControl1.Controls.Add(this.chkRH3);
            this.panelControl1.Controls.Add(this.chkAutopsy2);
            this.panelControl1.Controls.Add(this.chkAllergic2);
            this.panelControl1.Controls.Add(this.chkRH2);
            this.panelControl1.Controls.Add(this.chkRH1);
            this.panelControl1.Controls.Add(this.chkAutopsy1);
            this.panelControl1.Controls.Add(this.chkAllergic1);
            this.panelControl1.Controls.Add(this.labelControl3);
            this.panelControl1.Controls.Add(this.labelControl18);
            this.panelControl1.Controls.Add(this.labelControl14);
            this.panelControl1.Controls.Add(this.txtAllergicDrug);
            this.panelControl1.Controls.Add(this.labelControl17);
            this.panelControl1.Controls.Add(this.labelControl122);
            this.panelControl1.Controls.Add(this.labelControl118);
            this.panelControl1.Controls.Add(this.labelControl1);
            this.panelControl1.Controls.Add(this.txtPathologyID);
            this.panelControl1.Controls.Add(this.labelControl119);
            this.panelControl1.Controls.Add(this.txtPathologySn);
            this.panelControl1.Controls.Add(this.labelControl121);
            this.panelControl1.Location = new System.Drawing.Point(0, 253);
            this.panelControl1.Name = "panelControl1";
            this.panelControl1.Size = new System.Drawing.Size(700, 460);
            this.panelControl1.TabIndex = 0;
            // 
            // btn_Close
            // 
            this.btn_Close.Image = ((System.Drawing.Image)(resources.GetObject("btn_Close.Image")));
            this.btn_Close.Location = new System.Drawing.Point(530, 421);
            this.btn_Close.Name = "btn_Close";
            this.btn_Close.Size = new System.Drawing.Size(80, 23);
            this.btn_Close.TabIndex = 73;
            this.btn_Close.Text = "关闭(&T)";
            this.btn_Close.Click += new System.EventHandler(this.btn_Close_Click);
            // 
            // btn_OK
            // 
            this.btn_OK.Image = ((System.Drawing.Image)(resources.GetObject("btn_OK.Image")));
            this.btn_OK.Location = new System.Drawing.Point(439, 421);
            this.btn_OK.Name = "btn_OK";
            this.btn_OK.Size = new System.Drawing.Size(80, 23);
            this.btn_OK.TabIndex = 72;
            this.btn_OK.Text = "保存(&S)";
            this.btn_OK.Click += new System.EventHandler(this.btn_OK_Click);
            // 
            // txtSuccessCS
            // 
            this.txtSuccessCS.EnterMoveNextControl = true;
            this.txtSuccessCS.Location = new System.Drawing.Point(620, 222);
            this.txtSuccessCS.MenuManager = this.barManager1;
            this.txtSuccessCS.Name = "txtSuccessCS";
            this.txtSuccessCS.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtSuccessCS.Size = new System.Drawing.Size(64, 19);
            this.txtSuccessCS.TabIndex = 45;
            // 
            // labelControl12
            // 
            this.labelControl12.Appearance.ForeColor = System.Drawing.Color.Red;
            this.labelControl12.Location = new System.Drawing.Point(564, 224);
            this.labelControl12.Name = "labelControl12";
            this.labelControl12.Size = new System.Drawing.Size(60, 14);
            this.labelControl12.TabIndex = 312;
            this.labelControl12.Text = "成功次数：";
            // 
            // txtQJCS
            // 
            this.txtQJCS.EnterMoveNextControl = true;
            this.txtQJCS.Location = new System.Drawing.Point(477, 222);
            this.txtQJCS.MenuManager = this.barManager1;
            this.txtQJCS.Name = "txtQJCS";
            this.txtQJCS.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtQJCS.Properties.Appearance.Options.UseBackColor = true;
            this.txtQJCS.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtQJCS.Size = new System.Drawing.Size(63, 19);
            this.txtQJCS.TabIndex = 44;
            // 
            // labelControl11
            // 
            this.labelControl11.Appearance.ForeColor = System.Drawing.Color.Red;
            this.labelControl11.Location = new System.Drawing.Point(418, 224);
            this.labelControl11.Name = "labelControl11";
            this.labelControl11.Size = new System.Drawing.Size(60, 14);
            this.labelControl11.TabIndex = 310;
            this.labelControl11.Text = "抢救次数：";
            // 
            // chkInpLY5
            // 
            this.chkInpLY5.Location = new System.Drawing.Point(512, 197);
            this.chkInpLY5.Name = "chkInpLY5";
            this.chkInpLY5.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkInpLY5.Properties.Appearance.Options.UseForeColor = true;
            this.chkInpLY5.Properties.Caption = "5.国外";
            this.chkInpLY5.Properties.RadioGroupIndex = 6;
            this.chkInpLY5.Size = new System.Drawing.Size(104, 19);
            this.chkInpLY5.TabIndex = 39;
            this.chkInpLY5.TabStop = false;
            this.chkInpLY5.ToolTip = "回车键改变勾选状态或右键取消勾选";
            this.chkInpLY5.ToolTipIconType = DevExpress.Utils.ToolTipIconType.Information;
            this.chkInpLY5.Click += new System.EventHandler(this.chkMedicalQuality3_Click);
            this.chkInpLY5.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.chkAllergic1_KeyPress);
            // 
            // chkInpLY4
            // 
            this.chkInpLY4.Location = new System.Drawing.Point(397, 197);
            this.chkInpLY4.Name = "chkInpLY4";
            this.chkInpLY4.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkInpLY4.Properties.Appearance.Options.UseForeColor = true;
            this.chkInpLY4.Properties.Caption = "4.港澳台地区";
            this.chkInpLY4.Properties.RadioGroupIndex = 6;
            this.chkInpLY4.Size = new System.Drawing.Size(104, 19);
            this.chkInpLY4.TabIndex = 38;
            this.chkInpLY4.TabStop = false;
            this.chkInpLY4.ToolTip = "回车键改变勾选状态或右键取消勾选";
            this.chkInpLY4.ToolTipIconType = DevExpress.Utils.ToolTipIconType.Information;
            this.chkInpLY4.Click += new System.EventHandler(this.chkMedicalQuality3_Click);
            this.chkInpLY4.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.chkAllergic1_KeyPress);
            // 
            // chkInpLY3
            // 
            this.chkInpLY3.Location = new System.Drawing.Point(314, 197);
            this.chkInpLY3.Name = "chkInpLY3";
            this.chkInpLY3.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkInpLY3.Properties.Appearance.Options.UseForeColor = true;
            this.chkInpLY3.Properties.Caption = "3.外省";
            this.chkInpLY3.Properties.RadioGroupIndex = 6;
            this.chkInpLY3.Size = new System.Drawing.Size(62, 19);
            this.chkInpLY3.TabIndex = 37;
            this.chkInpLY3.TabStop = false;
            this.chkInpLY3.ToolTip = "回车键改变勾选状态或右键取消勾选";
            this.chkInpLY3.ToolTipIconType = DevExpress.Utils.ToolTipIconType.Information;
            this.chkInpLY3.Click += new System.EventHandler(this.chkMedicalQuality3_Click);
            this.chkInpLY3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.chkAllergic1_KeyPress);
            // 
            // chkInpLY2
            // 
            this.chkInpLY2.Location = new System.Drawing.Point(192, 196);
            this.chkInpLY2.Name = "chkInpLY2";
            this.chkInpLY2.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkInpLY2.Properties.Appearance.Options.UseForeColor = true;
            this.chkInpLY2.Properties.Caption = "2.本省其他县市";
            this.chkInpLY2.Properties.RadioGroupIndex = 6;
            this.chkInpLY2.Size = new System.Drawing.Size(113, 19);
            this.chkInpLY2.TabIndex = 36;
            this.chkInpLY2.TabStop = false;
            this.chkInpLY2.ToolTip = "回车键改变勾选状态或右键取消勾选";
            this.chkInpLY2.ToolTipIconType = DevExpress.Utils.ToolTipIconType.Information;
            this.chkInpLY2.Click += new System.EventHandler(this.chkMedicalQuality3_Click);
            this.chkInpLY2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.chkAllergic1_KeyPress);
            // 
            // chkInpLY1
            // 
            this.chkInpLY1.Location = new System.Drawing.Point(77, 196);
            this.chkInpLY1.Name = "chkInpLY1";
            this.chkInpLY1.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkInpLY1.Properties.Appearance.Options.UseForeColor = true;
            this.chkInpLY1.Properties.Caption = "1.本市区、县市";
            this.chkInpLY1.Properties.RadioGroupIndex = 6;
            this.chkInpLY1.Size = new System.Drawing.Size(110, 19);
            this.chkInpLY1.TabIndex = 35;
            this.chkInpLY1.TabStop = false;
            this.chkInpLY1.ToolTip = "回车键改变勾选状态或右键取消勾选";
            this.chkInpLY1.ToolTipIconType = DevExpress.Utils.ToolTipIconType.Information;
            this.chkInpLY1.Click += new System.EventHandler(this.chkMedicalQuality3_Click);
            this.chkInpLY1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.chkAllergic1_KeyPress);
            // 
            // labelControl10
            // 
            this.labelControl10.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl10.Location = new System.Drawing.Point(15, 200);
            this.labelControl10.Name = "labelControl10";
            this.labelControl10.Size = new System.Drawing.Size(60, 14);
            this.labelControl10.TabIndex = 304;
            this.labelControl10.Text = "病人来源：";
            // 
            // ChkFSYBL3
            // 
            this.ChkFSYBL3.Location = new System.Drawing.Point(314, 221);
            this.ChkFSYBL3.Name = "ChkFSYBL3";
            this.ChkFSYBL3.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.ChkFSYBL3.Properties.Appearance.Options.UseForeColor = true;
            this.ChkFSYBL3.Properties.Caption = "3.不肯定";
            this.ChkFSYBL3.Properties.RadioGroupIndex = 7;
            this.ChkFSYBL3.Size = new System.Drawing.Size(79, 19);
            this.ChkFSYBL3.TabIndex = 43;
            this.ChkFSYBL3.TabStop = false;
            this.ChkFSYBL3.ToolTip = "回车键改变勾选状态或右键取消";
            this.ChkFSYBL3.ToolTipIconType = DevExpress.Utils.ToolTipIconType.Information;
            this.ChkFSYBL3.Click += new System.EventHandler(this.chkMedicalQuality3_Click);
            this.ChkFSYBL3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.chkAllergic1_KeyPress);
            // 
            // chkFSYBL2
            // 
            this.chkFSYBL2.Location = new System.Drawing.Point(231, 221);
            this.chkFSYBL2.Name = "chkFSYBL2";
            this.chkFSYBL2.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkFSYBL2.Properties.Appearance.Options.UseForeColor = true;
            this.chkFSYBL2.Properties.Caption = "2.不符合";
            this.chkFSYBL2.Properties.RadioGroupIndex = 7;
            this.chkFSYBL2.Size = new System.Drawing.Size(77, 19);
            this.chkFSYBL2.TabIndex = 42;
            this.chkFSYBL2.TabStop = false;
            this.chkFSYBL2.ToolTip = "回车键改变勾选状态或右键取消";
            this.chkFSYBL2.ToolTipIconType = DevExpress.Utils.ToolTipIconType.Information;
            this.chkFSYBL2.Click += new System.EventHandler(this.chkMedicalQuality3_Click);
            this.chkFSYBL2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.chkAllergic1_KeyPress);
            // 
            // chkFSYBL1
            // 
            this.chkFSYBL1.Location = new System.Drawing.Point(146, 221);
            this.chkFSYBL1.Name = "chkFSYBL1";
            this.chkFSYBL1.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkFSYBL1.Properties.Appearance.Options.UseForeColor = true;
            this.chkFSYBL1.Properties.Caption = "1.符合";
            this.chkFSYBL1.Properties.RadioGroupIndex = 7;
            this.chkFSYBL1.Size = new System.Drawing.Size(58, 19);
            this.chkFSYBL1.TabIndex = 41;
            this.chkFSYBL1.TabStop = false;
            this.chkFSYBL1.ToolTip = "回车键改变勾选状态或右键取消";
            this.chkFSYBL1.ToolTipIconType = DevExpress.Utils.ToolTipIconType.Information;
            this.chkFSYBL1.Click += new System.EventHandler(this.chkMedicalQuality3_Click);
            this.chkFSYBL1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.chkAllergic1_KeyPress);
            // 
            // chkFSYBL0
            // 
            this.chkFSYBL0.Location = new System.Drawing.Point(77, 221);
            this.chkFSYBL0.Name = "chkFSYBL0";
            this.chkFSYBL0.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkFSYBL0.Properties.Appearance.Options.UseForeColor = true;
            this.chkFSYBL0.Properties.Caption = "0.未做";
            this.chkFSYBL0.Properties.RadioGroupIndex = 7;
            this.chkFSYBL0.Size = new System.Drawing.Size(58, 19);
            this.chkFSYBL0.TabIndex = 40;
            this.chkFSYBL0.TabStop = false;
            this.chkFSYBL0.ToolTip = "回车键改变勾选状态或右键取消";
            this.chkFSYBL0.ToolTipIconType = DevExpress.Utils.ToolTipIconType.Information;
            this.chkFSYBL0.Click += new System.EventHandler(this.chkMedicalQuality3_Click);
            this.chkFSYBL0.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.chkAllergic1_KeyPress);
            // 
            // labelControl9
            // 
            this.labelControl9.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl9.Location = new System.Drawing.Point(3, 224);
            this.labelControl9.Name = "labelControl9";
            this.labelControl9.Size = new System.Drawing.Size(72, 14);
            this.labelControl9.TabIndex = 299;
            this.labelControl9.Text = "放射与病理：";
            // 
            // chkLCYBL3
            // 
            this.chkLCYBL3.Location = new System.Drawing.Point(348, 298);
            this.chkLCYBL3.Name = "chkLCYBL3";
            this.chkLCYBL3.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkLCYBL3.Properties.Appearance.Options.UseForeColor = true;
            this.chkLCYBL3.Properties.Caption = "3.不肯定";
            this.chkLCYBL3.Properties.RadioGroupIndex = 10;
            this.chkLCYBL3.Size = new System.Drawing.Size(79, 19);
            this.chkLCYBL3.TabIndex = 57;
            this.chkLCYBL3.TabStop = false;
            this.chkLCYBL3.ToolTip = "回车键改变勾选状态或右键取消勾选";
            this.chkLCYBL3.ToolTipIconType = DevExpress.Utils.ToolTipIconType.Information;
            this.chkLCYBL3.Click += new System.EventHandler(this.chkMedicalQuality3_Click);
            this.chkLCYBL3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.chkAllergic1_KeyPress);
            // 
            // chkLCYBL2
            // 
            this.chkLCYBL2.Location = new System.Drawing.Point(251, 298);
            this.chkLCYBL2.Name = "chkLCYBL2";
            this.chkLCYBL2.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkLCYBL2.Properties.Appearance.Options.UseForeColor = true;
            this.chkLCYBL2.Properties.Caption = "2.不符合";
            this.chkLCYBL2.Properties.RadioGroupIndex = 10;
            this.chkLCYBL2.Size = new System.Drawing.Size(77, 19);
            this.chkLCYBL2.TabIndex = 56;
            this.chkLCYBL2.TabStop = false;
            this.chkLCYBL2.ToolTip = "回车键改变勾选状态或右键取消勾选";
            this.chkLCYBL2.ToolTipIconType = DevExpress.Utils.ToolTipIconType.Information;
            this.chkLCYBL2.Click += new System.EventHandler(this.chkMedicalQuality3_Click);
            this.chkLCYBL2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.chkAllergic1_KeyPress);
            // 
            // chkLCYBL1
            // 
            this.chkLCYBL1.Location = new System.Drawing.Point(159, 299);
            this.chkLCYBL1.Name = "chkLCYBL1";
            this.chkLCYBL1.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkLCYBL1.Properties.Appearance.Options.UseForeColor = true;
            this.chkLCYBL1.Properties.Caption = "1.符合";
            this.chkLCYBL1.Properties.RadioGroupIndex = 10;
            this.chkLCYBL1.Size = new System.Drawing.Size(58, 19);
            this.chkLCYBL1.TabIndex = 55;
            this.chkLCYBL1.TabStop = false;
            this.chkLCYBL1.ToolTip = "回车键改变勾选状态或右键取消勾选";
            this.chkLCYBL1.ToolTipIconType = DevExpress.Utils.ToolTipIconType.Information;
            this.chkLCYBL1.Click += new System.EventHandler(this.chkMedicalQuality3_Click);
            this.chkLCYBL1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.chkAllergic1_KeyPress);
            // 
            // chkLCYBL0
            // 
            this.chkLCYBL0.Location = new System.Drawing.Point(77, 300);
            this.chkLCYBL0.Name = "chkLCYBL0";
            this.chkLCYBL0.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkLCYBL0.Properties.Appearance.Options.UseForeColor = true;
            this.chkLCYBL0.Properties.Caption = "0.未做";
            this.chkLCYBL0.Properties.RadioGroupIndex = 10;
            this.chkLCYBL0.Size = new System.Drawing.Size(58, 19);
            this.chkLCYBL0.TabIndex = 54;
            this.chkLCYBL0.TabStop = false;
            this.chkLCYBL0.ToolTip = "回车键改变勾选状态或右键取消勾选";
            this.chkLCYBL0.ToolTipIconType = DevExpress.Utils.ToolTipIconType.Information;
            this.chkLCYBL0.Click += new System.EventHandler(this.chkMedicalQuality3_Click);
            this.chkLCYBL0.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.chkAllergic1_KeyPress);
            // 
            // labelControl8
            // 
            this.labelControl8.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl8.Location = new System.Drawing.Point(3, 303);
            this.labelControl8.Name = "labelControl8";
            this.labelControl8.Size = new System.Drawing.Size(72, 14);
            this.labelControl8.TabIndex = 294;
            this.labelControl8.Text = "临床与病理：";
            // 
            // chkRYYCY3
            // 
            this.chkRYYCY3.Location = new System.Drawing.Point(348, 273);
            this.chkRYYCY3.Name = "chkRYYCY3";
            this.chkRYYCY3.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkRYYCY3.Properties.Appearance.Options.UseForeColor = true;
            this.chkRYYCY3.Properties.Caption = "3.不肯定";
            this.chkRYYCY3.Properties.RadioGroupIndex = 9;
            this.chkRYYCY3.Size = new System.Drawing.Size(79, 19);
            this.chkRYYCY3.TabIndex = 53;
            this.chkRYYCY3.TabStop = false;
            this.chkRYYCY3.ToolTip = "回车键改变勾选状态或右键取消勾选";
            this.chkRYYCY3.ToolTipIconType = DevExpress.Utils.ToolTipIconType.Information;
            this.chkRYYCY3.Click += new System.EventHandler(this.chkMedicalQuality3_Click);
            this.chkRYYCY3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.chkAllergic1_KeyPress);
            // 
            // chkRYYCY2
            // 
            this.chkRYYCY2.Location = new System.Drawing.Point(251, 273);
            this.chkRYYCY2.Name = "chkRYYCY2";
            this.chkRYYCY2.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkRYYCY2.Properties.Appearance.Options.UseForeColor = true;
            this.chkRYYCY2.Properties.Caption = "2.不符合";
            this.chkRYYCY2.Properties.RadioGroupIndex = 9;
            this.chkRYYCY2.Size = new System.Drawing.Size(77, 19);
            this.chkRYYCY2.TabIndex = 52;
            this.chkRYYCY2.TabStop = false;
            this.chkRYYCY2.ToolTip = "回车键改变勾选状态或右键取消勾选";
            this.chkRYYCY2.ToolTipIconType = DevExpress.Utils.ToolTipIconType.Information;
            this.chkRYYCY2.Click += new System.EventHandler(this.chkMedicalQuality3_Click);
            this.chkRYYCY2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.chkAllergic1_KeyPress);
            // 
            // chkRYYCY1
            // 
            this.chkRYYCY1.Location = new System.Drawing.Point(159, 273);
            this.chkRYYCY1.Name = "chkRYYCY1";
            this.chkRYYCY1.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkRYYCY1.Properties.Appearance.Options.UseForeColor = true;
            this.chkRYYCY1.Properties.Caption = "1.符合";
            this.chkRYYCY1.Properties.RadioGroupIndex = 9;
            this.chkRYYCY1.Size = new System.Drawing.Size(58, 19);
            this.chkRYYCY1.TabIndex = 51;
            this.chkRYYCY1.TabStop = false;
            this.chkRYYCY1.ToolTip = "回车键改变勾选状态或右键取消勾选";
            this.chkRYYCY1.ToolTipIconType = DevExpress.Utils.ToolTipIconType.Information;
            this.chkRYYCY1.Click += new System.EventHandler(this.chkMedicalQuality3_Click);
            this.chkRYYCY1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.chkAllergic1_KeyPress);
            // 
            // chkRYYCY0
            // 
            this.chkRYYCY0.Location = new System.Drawing.Point(78, 272);
            this.chkRYYCY0.Name = "chkRYYCY0";
            this.chkRYYCY0.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkRYYCY0.Properties.Appearance.Options.UseForeColor = true;
            this.chkRYYCY0.Properties.Caption = "0.未做";
            this.chkRYYCY0.Properties.RadioGroupIndex = 9;
            this.chkRYYCY0.Size = new System.Drawing.Size(58, 19);
            this.chkRYYCY0.TabIndex = 50;
            this.chkRYYCY0.TabStop = false;
            this.chkRYYCY0.ToolTip = "回车键改变勾选状态或右键取消勾选";
            this.chkRYYCY0.ToolTipIconType = DevExpress.Utils.ToolTipIconType.Information;
            this.chkRYYCY0.Click += new System.EventHandler(this.chkMedicalQuality3_Click);
            this.chkRYYCY0.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.chkAllergic1_KeyPress);
            // 
            // labelControl7
            // 
            this.labelControl7.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl7.Location = new System.Drawing.Point(3, 276);
            this.labelControl7.Name = "labelControl7";
            this.labelControl7.Size = new System.Drawing.Size(72, 14);
            this.labelControl7.TabIndex = 289;
            this.labelControl7.Text = "入院与出院：";
            // 
            // chkMZYCY3
            // 
            this.chkMZYCY3.Location = new System.Drawing.Point(348, 248);
            this.chkMZYCY3.Name = "chkMZYCY3";
            this.chkMZYCY3.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkMZYCY3.Properties.Appearance.Options.UseForeColor = true;
            this.chkMZYCY3.Properties.Caption = "3.不肯定";
            this.chkMZYCY3.Properties.RadioGroupIndex = 8;
            this.chkMZYCY3.Size = new System.Drawing.Size(79, 19);
            this.chkMZYCY3.TabIndex = 49;
            this.chkMZYCY3.TabStop = false;
            this.chkMZYCY3.ToolTip = "回车键改变勾选状态或右键取消勾选";
            this.chkMZYCY3.ToolTipIconType = DevExpress.Utils.ToolTipIconType.Information;
            this.chkMZYCY3.Click += new System.EventHandler(this.chkMedicalQuality3_Click);
            this.chkMZYCY3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.chkAllergic1_KeyPress);
            // 
            // chkMZYCY2
            // 
            this.chkMZYCY2.Location = new System.Drawing.Point(251, 248);
            this.chkMZYCY2.Name = "chkMZYCY2";
            this.chkMZYCY2.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkMZYCY2.Properties.Appearance.Options.UseForeColor = true;
            this.chkMZYCY2.Properties.Caption = "2.不符合";
            this.chkMZYCY2.Properties.RadioGroupIndex = 8;
            this.chkMZYCY2.Size = new System.Drawing.Size(77, 19);
            this.chkMZYCY2.TabIndex = 48;
            this.chkMZYCY2.TabStop = false;
            this.chkMZYCY2.ToolTip = "回车键改变勾选状态或右键取消勾选";
            this.chkMZYCY2.ToolTipIconType = DevExpress.Utils.ToolTipIconType.Information;
            this.chkMZYCY2.Click += new System.EventHandler(this.chkMedicalQuality3_Click);
            this.chkMZYCY2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.chkAllergic1_KeyPress);
            // 
            // chkMZYCY1
            // 
            this.chkMZYCY1.Location = new System.Drawing.Point(159, 247);
            this.chkMZYCY1.Name = "chkMZYCY1";
            this.chkMZYCY1.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkMZYCY1.Properties.Appearance.Options.UseForeColor = true;
            this.chkMZYCY1.Properties.Caption = "1.符合";
            this.chkMZYCY1.Properties.RadioGroupIndex = 8;
            this.chkMZYCY1.Size = new System.Drawing.Size(58, 19);
            this.chkMZYCY1.TabIndex = 47;
            this.chkMZYCY1.TabStop = false;
            this.chkMZYCY1.ToolTip = "回车键改变勾选状态或右键取消勾选";
            this.chkMZYCY1.Click += new System.EventHandler(this.chkMedicalQuality3_Click);
            this.chkMZYCY1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.chkAllergic1_KeyPress);
            // 
            // chkMZYCY0
            // 
            this.chkMZYCY0.Location = new System.Drawing.Point(78, 246);
            this.chkMZYCY0.Name = "chkMZYCY0";
            this.chkMZYCY0.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkMZYCY0.Properties.Appearance.Options.UseForeColor = true;
            this.chkMZYCY0.Properties.Caption = "0.未做";
            this.chkMZYCY0.Properties.RadioGroupIndex = 8;
            this.chkMZYCY0.Size = new System.Drawing.Size(58, 19);
            this.chkMZYCY0.TabIndex = 46;
            this.chkMZYCY0.TabStop = false;
            this.chkMZYCY0.ToolTip = "回车键改变勾选状态或右键取消勾选";
            this.chkMZYCY0.ToolTipIconType = DevExpress.Utils.ToolTipIconType.Information;
            this.chkMZYCY0.Click += new System.EventHandler(this.chkMedicalQuality3_Click);
            this.chkMZYCY0.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.chkAllergic1_KeyPress);
            // 
            // labelControl6
            // 
            this.labelControl6.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl6.Location = new System.Drawing.Point(3, 249);
            this.labelControl6.Name = "labelControl6";
            this.labelControl6.Size = new System.Drawing.Size(72, 14);
            this.labelControl6.TabIndex = 284;
            this.labelControl6.Text = "门诊与出院：";
            // 
            // chkYNZZF
            // 
            this.chkYNZZF.Location = new System.Drawing.Point(152, 146);
            this.chkYNZZF.MenuManager = this.barManager1;
            this.chkYNZZF.Name = "chkYNZZF";
            this.chkYNZZF.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkYNZZF.Properties.Appearance.Options.UseForeColor = true;
            this.chkYNZZF.Properties.Caption = "0.不是";
            this.chkYNZZF.Properties.RadioGroupIndex = 2;
            this.chkYNZZF.Size = new System.Drawing.Size(75, 19);
            this.chkYNZZF.TabIndex = 24;
            this.chkYNZZF.TabStop = false;
            this.chkYNZZF.Click += new System.EventHandler(this.chkMedicalQuality3_Click);
            this.chkYNZZF.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.chkAllergic1_KeyPress);
            // 
            // chkYNZZS
            // 
            this.chkYNZZS.Location = new System.Drawing.Point(94, 148);
            this.chkYNZZS.MenuManager = this.barManager1;
            this.chkYNZZS.Name = "chkYNZZS";
            this.chkYNZZS.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkYNZZS.Properties.Appearance.Options.UseForeColor = true;
            this.chkYNZZS.Properties.Caption = "1.是";
            this.chkYNZZS.Properties.RadioGroupIndex = 2;
            this.chkYNZZS.Size = new System.Drawing.Size(52, 19);
            this.chkYNZZS.TabIndex = 23;
            this.chkYNZZS.TabStop = false;
            this.chkYNZZS.Click += new System.EventHandler(this.chkMedicalQuality3_Click);
            this.chkYNZZS.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.chkAllergic1_KeyPress);
            // 
            // labelControl5
            // 
            this.labelControl5.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl5.Location = new System.Drawing.Point(7, 149);
            this.labelControl5.Name = "labelControl5";
            this.labelControl5.Size = new System.Drawing.Size(84, 14);
            this.labelControl5.TabIndex = 281;
            this.labelControl5.Text = "疾病是否疑难：";
            // 
            // chkOutOthers
            // 
            this.chkOutOthers.Location = new System.Drawing.Point(609, 118);
            this.chkOutOthers.MenuManager = this.barManager1;
            this.chkOutOthers.Name = "chkOutOthers";
            this.chkOutOthers.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkOutOthers.Properties.Appearance.Options.UseForeColor = true;
            this.chkOutOthers.Properties.Caption = "4.其他";
            this.chkOutOthers.Properties.RadioGroupIndex = 1;
            this.chkOutOthers.Size = new System.Drawing.Size(75, 19);
            this.chkOutOthers.TabIndex = 22;
            this.chkOutOthers.TabStop = false;
            this.chkOutOthers.ToolTip = "回车键改变勾选状态或右键取消";
            this.chkOutOthers.ToolTipIconType = DevExpress.Utils.ToolTipIconType.Information;
            this.chkOutOthers.Click += new System.EventHandler(this.chkMedicalQuality3_Click);
            this.chkOutOthers.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.chkAllergic1_KeyPress);
            // 
            // chkOutDead
            // 
            this.chkOutDead.Location = new System.Drawing.Point(535, 118);
            this.chkOutDead.MenuManager = this.barManager1;
            this.chkOutDead.Name = "chkOutDead";
            this.chkOutDead.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkOutDead.Properties.Appearance.Options.UseForeColor = true;
            this.chkOutDead.Properties.Caption = "3.死亡";
            this.chkOutDead.Properties.RadioGroupIndex = 1;
            this.chkOutDead.Size = new System.Drawing.Size(75, 19);
            this.chkOutDead.TabIndex = 21;
            this.chkOutDead.TabStop = false;
            this.chkOutDead.ToolTip = "回车键改变勾选状态或右键取消";
            this.chkOutDead.ToolTipIconType = DevExpress.Utils.ToolTipIconType.Information;
            this.chkOutDead.Click += new System.EventHandler(this.chkMedicalQuality3_Click);
            this.chkOutDead.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.chkAllergic1_KeyPress);
            // 
            // chkOutWY
            // 
            this.chkOutWY.Location = new System.Drawing.Point(465, 118);
            this.chkOutWY.MenuManager = this.barManager1;
            this.chkOutWY.Name = "chkOutWY";
            this.chkOutWY.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkOutWY.Properties.Appearance.Options.UseForeColor = true;
            this.chkOutWY.Properties.Caption = "2.未愈";
            this.chkOutWY.Properties.RadioGroupIndex = 1;
            this.chkOutWY.Size = new System.Drawing.Size(75, 19);
            this.chkOutWY.TabIndex = 20;
            this.chkOutWY.TabStop = false;
            this.chkOutWY.ToolTip = "回车键改变勾选状态或右键取消";
            this.chkOutWY.ToolTipIconType = DevExpress.Utils.ToolTipIconType.Information;
            this.chkOutWY.Click += new System.EventHandler(this.chkMedicalQuality3_Click);
            this.chkOutWY.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.chkAllergic1_KeyPress);
            // 
            // chkOutHZ
            // 
            this.chkOutHZ.Location = new System.Drawing.Point(390, 118);
            this.chkOutHZ.MenuManager = this.barManager1;
            this.chkOutHZ.Name = "chkOutHZ";
            this.chkOutHZ.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkOutHZ.Properties.Appearance.Options.UseForeColor = true;
            this.chkOutHZ.Properties.Caption = "1.好转";
            this.chkOutHZ.Properties.RadioGroupIndex = 1;
            this.chkOutHZ.Size = new System.Drawing.Size(75, 19);
            this.chkOutHZ.TabIndex = 19;
            this.chkOutHZ.TabStop = false;
            this.chkOutHZ.ToolTip = "回车键改变勾选状态或右键取消";
            this.chkOutHZ.ToolTipIconType = DevExpress.Utils.ToolTipIconType.Information;
            this.chkOutHZ.Click += new System.EventHandler(this.chkMedicalQuality3_Click);
            this.chkOutHZ.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.chkAllergic1_KeyPress);
            // 
            // chkOutZY
            // 
            this.chkOutZY.Location = new System.Drawing.Point(314, 118);
            this.chkOutZY.MenuManager = this.barManager1;
            this.chkOutZY.Name = "chkOutZY";
            this.chkOutZY.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkOutZY.Properties.Appearance.Options.UseForeColor = true;
            this.chkOutZY.Properties.Caption = "0.治愈";
            this.chkOutZY.Properties.RadioGroupIndex = 1;
            this.chkOutZY.Size = new System.Drawing.Size(75, 19);
            this.chkOutZY.TabIndex = 18;
            this.chkOutZY.TabStop = false;
            this.chkOutZY.ToolTip = "回车键改变勾选状态或右键取消";
            this.chkOutZY.ToolTipIconType = DevExpress.Utils.ToolTipIconType.Information;
            this.chkOutZY.Click += new System.EventHandler(this.chkMedicalQuality3_Click);
            this.chkOutZY.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.chkAllergic1_KeyPress);
            // 
            // labelControl4
            // 
            this.labelControl4.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl4.Location = new System.Drawing.Point(221, 121);
            this.labelControl4.Name = "labelControl4";
            this.labelControl4.Size = new System.Drawing.Size(84, 14);
            this.labelControl4.TabIndex = 275;
            this.labelControl4.Text = "病人出院情况：";
            // 
            // lookUpEditPathologyName
            // 
            this.lookUpEditPathologyName.EnterMoveNextControl = true;
            this.lookUpEditPathologyName.IsNeedPaint = true;
            this.lookUpEditPathologyName.ListWindow = null;
            this.lookUpEditPathologyName.Location = new System.Drawing.Point(96, 43);
            this.lookUpEditPathologyName.MenuManager = this.barManager1;
            this.lookUpEditPathologyName.Name = "lookUpEditPathologyName";
            this.lookUpEditPathologyName.ShowSButton = true;
            this.lookUpEditPathologyName.Size = new System.Drawing.Size(259, 20);
            this.lookUpEditPathologyName.TabIndex = 10;
            this.lookUpEditPathologyName.CodeValueChanged += new System.EventHandler(this.lookUpEditPathologyName_CodeValueChanged);
            // 
            // deZkDate
            // 
            this.deZkDate.EditValue = null;
            this.deZkDate.EnterMoveNextControl = true;
            this.deZkDate.Location = new System.Drawing.Point(584, 393);
            this.deZkDate.MenuManager = this.barManager1;
            this.deZkDate.Name = "deZkDate";
            this.deZkDate.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.deZkDate.Properties.VistaTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.deZkDate.Size = new System.Drawing.Size(102, 21);
            this.deZkDate.TabIndex = 71;
            // 
            // lueHurt_Toxicosis_Ele
            // 
            this.lueHurt_Toxicosis_Ele.EnterMoveNextControl = true;
            this.lueHurt_Toxicosis_Ele.IsNeedPaint = true;
            this.lueHurt_Toxicosis_Ele.Kind = DrectSoft.Wordbook.WordbookKind.Sql;
            this.lueHurt_Toxicosis_Ele.ListWindow = null;
            this.lueHurt_Toxicosis_Ele.Location = new System.Drawing.Point(97, 17);
            this.lueHurt_Toxicosis_Ele.Name = "lueHurt_Toxicosis_Ele";
            this.lueHurt_Toxicosis_Ele.ShowSButton = true;
            this.lueHurt_Toxicosis_Ele.Size = new System.Drawing.Size(258, 20);
            this.lueHurt_Toxicosis_Ele.TabIndex = 9;
            // 
            // chkMedicalQuality3
            // 
            this.chkMedicalQuality3.Location = new System.Drawing.Point(148, 396);
            this.chkMedicalQuality3.Name = "chkMedicalQuality3";
            this.chkMedicalQuality3.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkMedicalQuality3.Properties.Appearance.Options.UseForeColor = true;
            this.chkMedicalQuality3.Properties.Caption = "3.丙";
            this.chkMedicalQuality3.Properties.RadioGroupIndex = 4;
            this.chkMedicalQuality3.Size = new System.Drawing.Size(47, 19);
            this.chkMedicalQuality3.TabIndex = 68;
            this.chkMedicalQuality3.TabStop = false;
            this.chkMedicalQuality3.ToolTip = "回车键改变勾选状态或右键取消";
            this.chkMedicalQuality3.Click += new System.EventHandler(this.chkMedicalQuality3_Click);
            this.chkMedicalQuality3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.chkAllergic1_KeyPress);
            // 
            // chkMedicalQuality2
            // 
            this.chkMedicalQuality2.Location = new System.Drawing.Point(106, 396);
            this.chkMedicalQuality2.Name = "chkMedicalQuality2";
            this.chkMedicalQuality2.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkMedicalQuality2.Properties.Appearance.Options.UseForeColor = true;
            this.chkMedicalQuality2.Properties.Caption = "2.乙";
            this.chkMedicalQuality2.Properties.RadioGroupIndex = 4;
            this.chkMedicalQuality2.Size = new System.Drawing.Size(52, 19);
            this.chkMedicalQuality2.TabIndex = 67;
            this.chkMedicalQuality2.TabStop = false;
            this.chkMedicalQuality2.ToolTip = "回车键改变勾选状态或右键取消";
            this.chkMedicalQuality2.Click += new System.EventHandler(this.chkMedicalQuality3_Click);
            this.chkMedicalQuality2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.chkAllergic1_KeyPress);
            // 
            // chkMedicalQuality1
            // 
            this.chkMedicalQuality1.Location = new System.Drawing.Point(62, 396);
            this.chkMedicalQuality1.Name = "chkMedicalQuality1";
            this.chkMedicalQuality1.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkMedicalQuality1.Properties.Appearance.Options.UseForeColor = true;
            this.chkMedicalQuality1.Properties.Caption = "1.甲";
            this.chkMedicalQuality1.Properties.RadioGroupIndex = 4;
            this.chkMedicalQuality1.Size = new System.Drawing.Size(49, 19);
            this.chkMedicalQuality1.TabIndex = 66;
            this.chkMedicalQuality1.TabStop = false;
            this.chkMedicalQuality1.ToolTip = "回车键改变勾选状态或右键取消";
            this.chkMedicalQuality1.Click += new System.EventHandler(this.chkMedicalQuality3_Click);
            this.chkMedicalQuality1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.chkAllergic1_KeyPress);
            // 
            // lueZkys
            // 
            this.lueZkys.EnterMoveNextControl = true;
            this.lueZkys.IsNeedPaint = true;
            this.lueZkys.Kind = DrectSoft.Wordbook.WordbookKind.Sql;
            this.lueZkys.ListWindow = null;
            this.lueZkys.Location = new System.Drawing.Point(262, 395);
            this.lueZkys.Name = "lueZkys";
            this.lueZkys.ShowSButton = true;
            this.lueZkys.Size = new System.Drawing.Size(102, 20);
            this.lueZkys.TabIndex = 69;
            // 
            // labelControl56
            // 
            this.labelControl56.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl56.Location = new System.Drawing.Point(204, 396);
            this.labelControl56.Name = "labelControl56";
            this.labelControl56.Size = new System.Drawing.Size(60, 14);
            this.labelControl56.TabIndex = 273;
            this.labelControl56.Text = "质控医师：";
            // 
            // labelControl55
            // 
            this.labelControl55.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl55.Location = new System.Drawing.Point(542, 396);
            this.labelControl55.Name = "labelControl55";
            this.labelControl55.Size = new System.Drawing.Size(36, 14);
            this.labelControl55.TabIndex = 272;
            this.labelControl55.Text = "日期：";
            // 
            // lueZkhs
            // 
            this.lueZkhs.EnterMoveNextControl = true;
            this.lueZkhs.IsNeedPaint = true;
            this.lueZkhs.Kind = DrectSoft.Wordbook.WordbookKind.Sql;
            this.lueZkhs.ListWindow = null;
            this.lueZkhs.Location = new System.Drawing.Point(427, 395);
            this.lueZkhs.Name = "lueZkhs";
            this.lueZkhs.ShowSButton = true;
            this.lueZkhs.Size = new System.Drawing.Size(107, 20);
            this.lueZkhs.TabIndex = 70;
            // 
            // labelControl53
            // 
            this.labelControl53.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl53.Location = new System.Drawing.Point(370, 396);
            this.labelControl53.Name = "labelControl53";
            this.labelControl53.Size = new System.Drawing.Size(60, 14);
            this.labelControl53.TabIndex = 271;
            this.labelControl53.Text = "质控护士：";
            // 
            // labelControl16
            // 
            this.labelControl16.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl16.Location = new System.Drawing.Point(8, 396);
            this.labelControl16.Name = "labelControl16";
            this.labelControl16.Size = new System.Drawing.Size(60, 14);
            this.labelControl16.TabIndex = 270;
            this.labelControl16.Text = "病案质量：";
            // 
            // lueBmy
            // 
            this.lueBmy.EnterMoveNextControl = true;
            this.lueBmy.IsNeedPaint = true;
            this.lueBmy.Kind = DrectSoft.Wordbook.WordbookKind.Sql;
            this.lueBmy.ListWindow = null;
            this.lueBmy.Location = new System.Drawing.Point(582, 363);
            this.lueBmy.Name = "lueBmy";
            this.lueBmy.ShowSButton = true;
            this.lueBmy.Size = new System.Drawing.Size(104, 20);
            this.lueBmy.TabIndex = 65;
            this.lueBmy.CodeValueChanged += new System.EventHandler(this.lueBmy_CodeValueChanged);
            // 
            // labelControl49
            // 
            this.labelControl49.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl49.Location = new System.Drawing.Point(538, 364);
            this.labelControl49.Name = "labelControl49";
            this.labelControl49.Size = new System.Drawing.Size(48, 14);
            this.labelControl49.TabIndex = 269;
            this.labelControl49.Text = "编码员：";
            this.labelControl49.Click += new System.EventHandler(this.labelControl49_Click);
            // 
            // lueSxys
            // 
            this.lueSxys.EnterMoveNextControl = true;
            this.lueSxys.IsNeedPaint = true;
            this.lueSxys.Kind = DrectSoft.Wordbook.WordbookKind.Sql;
            this.lueSxys.ListWindow = null;
            this.lueSxys.Location = new System.Drawing.Point(414, 363);
            this.lueSxys.Name = "lueSxys";
            this.lueSxys.ShowSButton = true;
            this.lueSxys.Size = new System.Drawing.Size(107, 20);
            this.lueSxys.TabIndex = 64;
            // 
            // labelControl50
            // 
            this.labelControl50.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl50.Location = new System.Drawing.Point(357, 364);
            this.labelControl50.Name = "labelControl50";
            this.labelControl50.Size = new System.Drawing.Size(60, 14);
            this.labelControl50.TabIndex = 268;
            this.labelControl50.Text = "实习医师：";
            // 
            // luejxys
            // 
            this.luejxys.EnterMoveNextControl = true;
            this.luejxys.IsNeedPaint = true;
            this.luejxys.Kind = DrectSoft.Wordbook.WordbookKind.Sql;
            this.luejxys.ListWindow = null;
            this.luejxys.Location = new System.Drawing.Point(248, 363);
            this.luejxys.Name = "luejxys";
            this.luejxys.ShowSButton = true;
            this.luejxys.Size = new System.Drawing.Size(102, 20);
            this.luejxys.TabIndex = 63;
            // 
            // labelControl51
            // 
            this.labelControl51.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl51.Location = new System.Drawing.Point(182, 364);
            this.labelControl51.Name = "labelControl51";
            this.labelControl51.Size = new System.Drawing.Size(60, 14);
            this.labelControl51.TabIndex = 267;
            this.labelControl51.Text = "进修医师：";
            // 
            // lueDuty_Nurse
            // 
            this.lueDuty_Nurse.EnterMoveNextControl = true;
            this.lueDuty_Nurse.IsNeedPaint = true;
            this.lueDuty_Nurse.Kind = DrectSoft.Wordbook.WordbookKind.Sql;
            this.lueDuty_Nurse.ListWindow = null;
            this.lueDuty_Nurse.Location = new System.Drawing.Point(73, 363);
            this.lueDuty_Nurse.Name = "lueDuty_Nurse";
            this.lueDuty_Nurse.ShowSButton = true;
            this.lueDuty_Nurse.Size = new System.Drawing.Size(102, 20);
            this.lueDuty_Nurse.TabIndex = 62;
            // 
            // labelControl52
            // 
            this.labelControl52.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl52.Location = new System.Drawing.Point(7, 364);
            this.labelControl52.Name = "labelControl52";
            this.labelControl52.Size = new System.Drawing.Size(60, 14);
            this.labelControl52.TabIndex = 266;
            this.labelControl52.Text = "责任护士：";
            // 
            // lueZyys
            // 
            this.lueZyys.EnterMoveNextControl = true;
            this.lueZyys.IsNeedPaint = true;
            this.lueZyys.Kind = DrectSoft.Wordbook.WordbookKind.Sql;
            this.lueZyys.ListWindow = null;
            this.lueZyys.Location = new System.Drawing.Point(582, 333);
            this.lueZyys.Name = "lueZyys";
            this.lueZyys.ShowSButton = true;
            this.lueZyys.Size = new System.Drawing.Size(104, 20);
            this.lueZyys.TabIndex = 61;
            // 
            // labelControl47
            // 
            this.labelControl47.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl47.Location = new System.Drawing.Point(527, 334);
            this.labelControl47.Name = "labelControl47";
            this.labelControl47.Size = new System.Drawing.Size(60, 14);
            this.labelControl47.TabIndex = 265;
            this.labelControl47.Text = "住院医师：";
            // 
            // lueZzys
            // 
            this.lueZzys.EnterMoveNextControl = true;
            this.lueZzys.IsNeedPaint = true;
            this.lueZzys.Kind = DrectSoft.Wordbook.WordbookKind.Sql;
            this.lueZzys.ListWindow = null;
            this.lueZzys.Location = new System.Drawing.Point(414, 333);
            this.lueZzys.Name = "lueZzys";
            this.lueZzys.ShowSButton = true;
            this.lueZzys.Size = new System.Drawing.Size(107, 20);
            this.lueZzys.TabIndex = 60;
            // 
            // labelControl48
            // 
            this.labelControl48.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl48.Location = new System.Drawing.Point(357, 334);
            this.labelControl48.Name = "labelControl48";
            this.labelControl48.Size = new System.Drawing.Size(60, 14);
            this.labelControl48.TabIndex = 264;
            this.labelControl48.Text = "主治医师：";
            // 
            // lueZrys
            // 
            this.lueZrys.EnterMoveNextControl = true;
            this.lueZrys.IsNeedPaint = true;
            this.lueZrys.Kind = DrectSoft.Wordbook.WordbookKind.Sql;
            this.lueZrys.ListWindow = null;
            this.lueZrys.Location = new System.Drawing.Point(250, 333);
            this.lueZrys.Name = "lueZrys";
            this.lueZrys.ShowSButton = true;
            this.lueZrys.Size = new System.Drawing.Size(100, 20);
            this.lueZrys.TabIndex = 59;
            // 
            // labelControl46
            // 
            this.labelControl46.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl46.Location = new System.Drawing.Point(161, 334);
            this.labelControl46.Name = "labelControl46";
            this.labelControl46.Size = new System.Drawing.Size(94, 14);
            this.labelControl46.TabIndex = 263;
            this.labelControl46.Text = "主(副主)任医师：";
            // 
            // lueKszr
            // 
            this.lueKszr.EnterMoveNextControl = true;
            this.lueKszr.IsNeedPaint = true;
            this.lueKszr.Kind = DrectSoft.Wordbook.WordbookKind.Sql;
            this.lueKszr.ListWindow = null;
            this.lueKszr.Location = new System.Drawing.Point(53, 333);
            this.lueKszr.Name = "lueKszr";
            this.lueKszr.ShowSButton = true;
            this.lueKszr.Size = new System.Drawing.Size(95, 20);
            this.lueKszr.TabIndex = 58;
            // 
            // labelControl45
            // 
            this.labelControl45.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl45.Location = new System.Drawing.Point(5, 334);
            this.labelControl45.Name = "labelControl45";
            this.labelControl45.Size = new System.Drawing.Size(48, 14);
            this.labelControl45.TabIndex = 262;
            this.labelControl45.Text = "科主任：";
            // 
            // chkBlood6
            // 
            this.chkBlood6.Location = new System.Drawing.Point(609, 146);
            this.chkBlood6.Name = "chkBlood6";
            this.chkBlood6.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkBlood6.Properties.Appearance.Options.UseForeColor = true;
            this.chkBlood6.Properties.Caption = "6.未查";
            this.chkBlood6.Properties.RadioGroupIndex = 3;
            this.chkBlood6.Size = new System.Drawing.Size(64, 19);
            this.chkBlood6.TabIndex = 30;
            this.chkBlood6.TabStop = false;
            this.chkBlood6.ToolTip = "回车键改变勾选状态或右键取消";
            this.chkBlood6.ToolTipIconType = DevExpress.Utils.ToolTipIconType.Information;
            this.chkBlood6.Click += new System.EventHandler(this.chkMedicalQuality3_Click);
            this.chkBlood6.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.chkAllergic1_KeyPress);
            // 
            // chkBlood4
            // 
            this.chkBlood4.Location = new System.Drawing.Point(465, 146);
            this.chkBlood4.Name = "chkBlood4";
            this.chkBlood4.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkBlood4.Properties.Appearance.Options.UseForeColor = true;
            this.chkBlood4.Properties.Caption = "4.AB";
            this.chkBlood4.Properties.RadioGroupIndex = 3;
            this.chkBlood4.Size = new System.Drawing.Size(51, 19);
            this.chkBlood4.TabIndex = 28;
            this.chkBlood4.TabStop = false;
            this.chkBlood4.ToolTip = "回车键改变勾选状态或右键取消";
            this.chkBlood4.ToolTipIconType = DevExpress.Utils.ToolTipIconType.Information;
            this.chkBlood4.Click += new System.EventHandler(this.chkMedicalQuality3_Click);
            this.chkBlood4.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.chkAllergic1_KeyPress);
            // 
            // chkBlood5
            // 
            this.chkBlood5.Location = new System.Drawing.Point(535, 146);
            this.chkBlood5.Name = "chkBlood5";
            this.chkBlood5.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkBlood5.Properties.Appearance.Options.UseForeColor = true;
            this.chkBlood5.Properties.Caption = "5.不详";
            this.chkBlood5.Properties.RadioGroupIndex = 3;
            this.chkBlood5.Size = new System.Drawing.Size(56, 19);
            this.chkBlood5.TabIndex = 29;
            this.chkBlood5.TabStop = false;
            this.chkBlood5.ToolTip = "回车键改变勾选状态或右键取消";
            this.chkBlood5.ToolTipIconType = DevExpress.Utils.ToolTipIconType.Information;
            this.chkBlood5.Click += new System.EventHandler(this.chkMedicalQuality3_Click);
            this.chkBlood5.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.chkAllergic1_KeyPress);
            // 
            // chkBlood3
            // 
            this.chkBlood3.Location = new System.Drawing.Point(410, 146);
            this.chkBlood3.Name = "chkBlood3";
            this.chkBlood3.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkBlood3.Properties.Appearance.Options.UseForeColor = true;
            this.chkBlood3.Properties.Caption = "3.O";
            this.chkBlood3.Properties.RadioGroupIndex = 3;
            this.chkBlood3.Size = new System.Drawing.Size(41, 19);
            this.chkBlood3.TabIndex = 27;
            this.chkBlood3.TabStop = false;
            this.chkBlood3.ToolTip = "回车键改变勾选状态或右键取消";
            this.chkBlood3.ToolTipIconType = DevExpress.Utils.ToolTipIconType.Information;
            this.chkBlood3.Click += new System.EventHandler(this.chkMedicalQuality3_Click);
            this.chkBlood3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.chkAllergic1_KeyPress);
            // 
            // chkBlood2
            // 
            this.chkBlood2.Location = new System.Drawing.Point(348, 146);
            this.chkBlood2.Name = "chkBlood2";
            this.chkBlood2.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkBlood2.Properties.Appearance.Options.UseForeColor = true;
            this.chkBlood2.Properties.Caption = "2.B";
            this.chkBlood2.Properties.RadioGroupIndex = 3;
            this.chkBlood2.Size = new System.Drawing.Size(41, 19);
            this.chkBlood2.TabIndex = 26;
            this.chkBlood2.TabStop = false;
            this.chkBlood2.ToolTip = "回车键改变勾选状态或右键取消";
            this.chkBlood2.ToolTipIconType = DevExpress.Utils.ToolTipIconType.Information;
            this.chkBlood2.Click += new System.EventHandler(this.chkMedicalQuality3_Click);
            this.chkBlood2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.chkAllergic1_KeyPress);
            // 
            // chkBlood1
            // 
            this.chkBlood1.Location = new System.Drawing.Point(286, 146);
            this.chkBlood1.Name = "chkBlood1";
            this.chkBlood1.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkBlood1.Properties.Appearance.Options.UseForeColor = true;
            this.chkBlood1.Properties.Caption = "1.A";
            this.chkBlood1.Properties.RadioGroupIndex = 3;
            this.chkBlood1.Size = new System.Drawing.Size(42, 19);
            this.chkBlood1.TabIndex = 25;
            this.chkBlood1.TabStop = false;
            this.chkBlood1.ToolTip = "回车键改变勾选状态或右键取消";
            this.chkBlood1.ToolTipIconType = DevExpress.Utils.ToolTipIconType.Information;
            this.chkBlood1.Click += new System.EventHandler(this.chkMedicalQuality3_Click);
            this.chkBlood1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.chkAllergic1_KeyPress);
            // 
            // chkRH4
            // 
            this.chkRH4.Location = new System.Drawing.Point(348, 172);
            this.chkRH4.Name = "chkRH4";
            this.chkRH4.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkRH4.Properties.Appearance.Options.UseForeColor = true;
            this.chkRH4.Properties.Caption = "4.未查";
            this.chkRH4.Properties.RadioGroupIndex = 4;
            this.chkRH4.Size = new System.Drawing.Size(66, 19);
            this.chkRH4.TabIndex = 34;
            this.chkRH4.TabStop = false;
            this.chkRH4.ToolTip = "回车键改变勾选状态或右键取消勾选";
            this.chkRH4.ToolTipIconType = DevExpress.Utils.ToolTipIconType.Information;
            this.chkRH4.Click += new System.EventHandler(this.chkMedicalQuality3_Click);
            this.chkRH4.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.chkAllergic1_KeyPress);
            // 
            // chkRH3
            // 
            this.chkRH3.Location = new System.Drawing.Point(251, 172);
            this.chkRH3.Name = "chkRH3";
            this.chkRH3.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkRH3.Properties.Appearance.Options.UseForeColor = true;
            this.chkRH3.Properties.Caption = "3.不详";
            this.chkRH3.Properties.RadioGroupIndex = 4;
            this.chkRH3.Size = new System.Drawing.Size(66, 19);
            this.chkRH3.TabIndex = 33;
            this.chkRH3.TabStop = false;
            this.chkRH3.ToolTip = "回车键改变勾选状态或右键取消勾选";
            this.chkRH3.ToolTipIconType = DevExpress.Utils.ToolTipIconType.Information;
            this.chkRH3.Click += new System.EventHandler(this.chkMedicalQuality3_Click);
            this.chkRH3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.chkAllergic1_KeyPress);
            // 
            // chkAutopsy2
            // 
            this.chkAutopsy2.Location = new System.Drawing.Point(152, 118);
            this.chkAutopsy2.Name = "chkAutopsy2";
            this.chkAutopsy2.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkAutopsy2.Properties.Appearance.Options.UseForeColor = true;
            this.chkAutopsy2.Properties.Caption = "2.否";
            this.chkAutopsy2.Properties.RadioGroupIndex = 5;
            this.chkAutopsy2.Size = new System.Drawing.Size(65, 19);
            this.chkAutopsy2.TabIndex = 17;
            this.chkAutopsy2.TabStop = false;
            this.chkAutopsy2.ToolTip = "回车键改变勾选状态或右键取消勾选";
            this.chkAutopsy2.ToolTipIconType = DevExpress.Utils.ToolTipIconType.Information;
            this.chkAutopsy2.Click += new System.EventHandler(this.chkMedicalQuality3_Click);
            this.chkAutopsy2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.chkAllergic1_KeyPress);
            // 
            // chkAllergic2
            // 
            this.chkAllergic2.Location = new System.Drawing.Point(152, 93);
            this.chkAllergic2.Name = "chkAllergic2";
            this.chkAllergic2.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkAllergic2.Properties.Appearance.Options.UseForeColor = true;
            this.chkAllergic2.Properties.Caption = "2.有";
            this.chkAllergic2.Properties.RadioGroupIndex = 0;
            this.chkAllergic2.Size = new System.Drawing.Size(57, 19);
            this.chkAllergic2.TabIndex = 14;
            this.chkAllergic2.TabStop = false;
            this.chkAllergic2.ToolTip = "回车键改变勾选状态或右键取消";
            this.chkAllergic2.ToolTipIconType = DevExpress.Utils.ToolTipIconType.Information;
            this.chkAllergic2.Click += new System.EventHandler(this.chkMedicalQuality3_Click);
            this.chkAllergic2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.chkAllergic1_KeyPress);
            // 
            // chkRH2
            // 
            this.chkRH2.Location = new System.Drawing.Point(158, 171);
            this.chkRH2.Name = "chkRH2";
            this.chkRH2.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkRH2.Properties.Appearance.Options.UseForeColor = true;
            this.chkRH2.Properties.Caption = "2.阳";
            this.chkRH2.Properties.RadioGroupIndex = 4;
            this.chkRH2.Size = new System.Drawing.Size(72, 19);
            this.chkRH2.TabIndex = 32;
            this.chkRH2.TabStop = false;
            this.chkRH2.ToolTip = "回车键改变勾选状态或右键取消勾选";
            this.chkRH2.ToolTipIconType = DevExpress.Utils.ToolTipIconType.Information;
            this.chkRH2.Click += new System.EventHandler(this.chkMedicalQuality3_Click);
            this.chkRH2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.chkAllergic1_KeyPress);
            // 
            // chkRH1
            // 
            this.chkRH1.Location = new System.Drawing.Point(78, 172);
            this.chkRH1.Name = "chkRH1";
            this.chkRH1.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkRH1.Properties.Appearance.Options.UseForeColor = true;
            this.chkRH1.Properties.Caption = "1.阴";
            this.chkRH1.Properties.RadioGroupIndex = 4;
            this.chkRH1.Size = new System.Drawing.Size(58, 19);
            this.chkRH1.TabIndex = 31;
            this.chkRH1.TabStop = false;
            this.chkRH1.ToolTip = "回车键改变勾选状态或右键取消勾选";
            this.chkRH1.ToolTipIconType = DevExpress.Utils.ToolTipIconType.Information;
            this.chkRH1.Click += new System.EventHandler(this.chkMedicalQuality3_Click);
            this.chkRH1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.chkAllergic1_KeyPress);
            // 
            // chkAutopsy1
            // 
            this.chkAutopsy1.Location = new System.Drawing.Point(88, 118);
            this.chkAutopsy1.Name = "chkAutopsy1";
            this.chkAutopsy1.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkAutopsy1.Properties.Appearance.Options.UseForeColor = true;
            this.chkAutopsy1.Properties.Caption = "1.是";
            this.chkAutopsy1.Properties.RadioGroupIndex = 5;
            this.chkAutopsy1.Size = new System.Drawing.Size(71, 19);
            this.chkAutopsy1.TabIndex = 16;
            this.chkAutopsy1.TabStop = false;
            this.chkAutopsy1.ToolTip = "回车键改变勾选状态或右键取消勾选";
            this.chkAutopsy1.ToolTipIconType = DevExpress.Utils.ToolTipIconType.Information;
            this.chkAutopsy1.Click += new System.EventHandler(this.chkMedicalQuality3_Click);
            this.chkAutopsy1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.chkAllergic1_KeyPress);
            // 
            // chkAllergic1
            // 
            this.chkAllergic1.Location = new System.Drawing.Point(88, 94);
            this.chkAllergic1.Name = "chkAllergic1";
            this.chkAllergic1.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkAllergic1.Properties.Appearance.Options.UseForeColor = true;
            this.chkAllergic1.Properties.Caption = "1.无";
            this.chkAllergic1.Properties.RadioGroupIndex = 0;
            this.chkAllergic1.Size = new System.Drawing.Size(53, 19);
            this.chkAllergic1.TabIndex = 13;
            this.chkAllergic1.TabStop = false;
            this.chkAllergic1.ToolTip = "回车键改变勾选状态或右键取消";
            this.chkAllergic1.ToolTipIconType = DevExpress.Utils.ToolTipIconType.Information;
            this.chkAllergic1.Click += new System.EventHandler(this.chkMedicalQuality3_Click);
            this.chkAllergic1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.chkAllergic1_KeyPress);
            // 
            // labelControl3
            // 
            this.labelControl3.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl3.Location = new System.Drawing.Point(248, 149);
            this.labelControl3.Name = "labelControl3";
            this.labelControl3.Size = new System.Drawing.Size(36, 14);
            this.labelControl3.TabIndex = 260;
            this.labelControl3.Text = "血型：";
            // 
            // labelControl18
            // 
            this.labelControl18.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl18.Location = new System.Drawing.Point(49, 177);
            this.labelControl18.Name = "labelControl18";
            this.labelControl18.Size = new System.Drawing.Size(26, 14);
            this.labelControl18.TabIndex = 261;
            this.labelControl18.Text = "Rh：";
            // 
            // labelControl14
            // 
            this.labelControl14.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl14.Location = new System.Drawing.Point(7, 16);
            this.labelControl14.Name = "labelControl14";
            this.labelControl14.Size = new System.Drawing.Size(84, 14);
            this.labelControl14.TabIndex = 255;
            this.labelControl14.Text = "损伤中毒因素：";
            // 
            // txtAllergicDrug
            // 
            this.txtAllergicDrug.EditValue = "";
            this.txtAllergicDrug.EnterMoveNextControl = true;
            this.txtAllergicDrug.Location = new System.Drawing.Point(493, 91);
            this.txtAllergicDrug.Name = "txtAllergicDrug";
            this.txtAllergicDrug.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtAllergicDrug.Size = new System.Drawing.Size(191, 19);
            this.txtAllergicDrug.TabIndex = 15;
            // 
            // labelControl17
            // 
            this.labelControl17.Appearance.ForeColor = System.Drawing.Color.Red;
            this.labelControl17.Location = new System.Drawing.Point(31, 96);
            this.labelControl17.Name = "labelControl17";
            this.labelControl17.Size = new System.Drawing.Size(60, 14);
            this.labelControl17.TabIndex = 259;
            this.labelControl17.Text = "过敏药物：";
            // 
            // labelControl122
            // 
            this.labelControl122.Appearance.ForeColor = System.Drawing.Color.Red;
            this.labelControl122.Location = new System.Drawing.Point(427, 94);
            this.labelControl122.Name = "labelControl122";
            this.labelControl122.Size = new System.Drawing.Size(60, 14);
            this.labelControl122.TabIndex = 258;
            this.labelControl122.Text = "过敏药物：";
            // 
            // labelControl118
            // 
            this.labelControl118.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl118.Location = new System.Drawing.Point(30, 44);
            this.labelControl118.Name = "labelControl118";
            this.labelControl118.Size = new System.Drawing.Size(60, 14);
            this.labelControl118.TabIndex = 256;
            this.labelControl118.Text = "病理诊断：";
            // 
            // labelControl1
            // 
            this.labelControl1.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl1.Location = new System.Drawing.Point(427, 44);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(60, 14);
            this.labelControl1.TabIndex = 253;
            this.labelControl1.Text = "疾病编码：";
            // 
            // txtPathologyID
            // 
            this.txtPathologyID.EditValue = "";
            this.txtPathologyID.EnterMoveNextControl = true;
            this.txtPathologyID.Location = new System.Drawing.Point(493, 42);
            this.txtPathologyID.Name = "txtPathologyID";
            this.txtPathologyID.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtPathologyID.Size = new System.Drawing.Size(191, 19);
            this.txtPathologyID.TabIndex = 11;
            // 
            // labelControl119
            // 
            this.labelControl119.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl119.Location = new System.Drawing.Point(43, 74);
            this.labelControl119.Name = "labelControl119";
            this.labelControl119.Size = new System.Drawing.Size(48, 14);
            this.labelControl119.TabIndex = 254;
            this.labelControl119.Text = "病理号：";
            // 
            // txtPathologySn
            // 
            this.txtPathologySn.EditValue = "";
            this.txtPathologySn.EnterMoveNextControl = true;
            this.txtPathologySn.Location = new System.Drawing.Point(97, 69);
            this.txtPathologySn.Name = "txtPathologySn";
            this.txtPathologySn.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtPathologySn.Size = new System.Drawing.Size(258, 19);
            this.txtPathologySn.TabIndex = 12;
            // 
            // labelControl121
            // 
            this.labelControl121.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl121.Location = new System.Drawing.Point(7, 121);
            this.labelControl121.Name = "labelControl121";
            this.labelControl121.Size = new System.Drawing.Size(84, 14);
            this.labelControl121.TabIndex = 257;
            this.labelControl121.Text = "死亡患者尸检：";
            this.labelControl121.ToolTip = "回车键改变勾选状态或右键取消勾选";
            this.labelControl121.ToolTipIconType = DevExpress.Utils.ToolTipIconType.Information;
            this.labelControl121.Click += new System.EventHandler(this.chkMedicalQuality3_Click);
            this.labelControl121.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.chkAllergic1_KeyPress);
            // 
            // DevTextEdit1
            // 
            this.DevTextEdit1.IsEnterChangeBgColor = false;
            this.DevTextEdit1.IsEnterKeyToNextControl = false;
            this.DevTextEdit1.IsNumber = false;
            this.DevTextEdit1.Location = new System.Drawing.Point(0, 0);
            this.DevTextEdit1.Name = "DevTextEdit1";
            this.DevTextEdit1.Size = new System.Drawing.Size(100, 21);
            this.DevTextEdit1.TabIndex = 0;
            // 
            // UCIemDiagnose
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.panelControl1);
            this.Controls.Add(this.btn_del2);
            this.Controls.Add(this.btnEditOutDiagCHn);
            this.Controls.Add(this.btn_down2);
            this.Controls.Add(this.btn_up2);
            this.Controls.Add(this.btn_del);
            this.Controls.Add(this.btnEditOutDiag);
            this.Controls.Add(this.btn_down);
            this.Controls.Add(this.btn_up);
            this.Controls.Add(this.gridControl2);
            this.Controls.Add(this.btnNewOutDiag);
            this.Controls.Add(this.gridControl1);
            this.Controls.Add(this.labelControl2);
            this.Controls.Add(this.labelControl117);
            this.Controls.Add(this.barDockControlLeft);
            this.Controls.Add(this.barDockControlRight);
            this.Controls.Add(this.barDockControlBottom);
            this.Controls.Add(this.barDockControlTop);
            this.Name = "UCIemDiagnose";
            this.Size = new System.Drawing.Size(700, 710);
            this.Load += new System.EventHandler(this.UCIemDiagnose_Load);
            ((System.ComponentModel.ISupportInitialize)(this.gridControl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewDiagnose)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.barManager1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.popupMenu1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridControl2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewDiagnose2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).EndInit();
            this.panelControl1.ResumeLayout(false);
            this.panelControl1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtSuccessCS.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtQJCS.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkInpLY5.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkInpLY4.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkInpLY3.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkInpLY2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkInpLY1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ChkFSYBL3.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkFSYBL2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkFSYBL1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkFSYBL0.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkLCYBL3.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkLCYBL2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkLCYBL1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkLCYBL0.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkRYYCY3.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkRYYCY2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkRYYCY1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkRYYCY0.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkMZYCY3.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkMZYCY2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkMZYCY1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkMZYCY0.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkYNZZF.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkYNZZS.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkOutOthers.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkOutDead.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkOutWY.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkOutHZ.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkOutZY.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookUpEditPathologyName)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.deZkDate.Properties.VistaTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.deZkDate.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueHurt_Toxicosis_Ele)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkMedicalQuality3.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkMedicalQuality2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkMedicalQuality1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueZkys)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueZkhs)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueBmy)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueSxys)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.luejxys)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueDuty_Nurse)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueZyys)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueZzys)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueZrys)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueKszr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkBlood6.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkBlood4.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkBlood5.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkBlood3.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkBlood2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkBlood1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkRH4.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkRH3.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkAutopsy2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkAllergic2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkRH2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkRH1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkAutopsy1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkAllergic1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtAllergicDrug.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPathologyID.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPathologySn.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DevTextEdit1.Properties)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevExpress.XtraEditors.LabelControl labelControl117;
        private DevExpress.XtraGrid.GridControl gridControl1;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewDiagnose;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView2;
        private DevExpress.XtraEditors.SimpleButton btnNewOutDiag;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn2;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn3;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn4;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn5;
        private DevExpress.XtraBars.BarManager barManager1;
        private DevExpress.XtraBars.BarDockControl barDockControlTop;
        private DevExpress.XtraBars.BarDockControl barDockControlBottom;
        private DevExpress.XtraBars.BarDockControl barDockControlLeft;
        private DevExpress.XtraBars.BarDockControl barDockControlRight;
        private DevExpress.XtraBars.BarButtonItem btn_del_diag;
        private DevExpress.XtraBars.PopupMenu popupMenu1;
        private DevExpress.XtraEditors.LabelControl labelControl2;
        private DevExpress.XtraGrid.GridControl gridControl2;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewDiagnose2;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn9;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn10;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn11;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn12;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn13;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView3;
        private DrectSoft.Common.Ctrs.OTHER.DevButtonDelete btn_del2;
        private DrectSoft.Common.Ctrs.OTHER.DevButtonEdit btnEditOutDiagCHn;
        private DrectSoft.Common.Ctrs.OTHER.DevButtonDown btn_down2;
        private DrectSoft.Common.Ctrs.OTHER.DevButtonUp btn_up2;
        private DrectSoft.Common.Ctrs.OTHER.DevButtonDelete btn_del;
        private DrectSoft.Common.Ctrs.OTHER.DevButtonEdit btnEditOutDiag;
        private DrectSoft.Common.Ctrs.OTHER.DevButtonDown btn_down;
        private DrectSoft.Common.Ctrs.OTHER.DevButtonUp btn_up;
        private DevExpress.XtraEditors.PanelControl panelControl1;
        private DrectSoft.Common.Ctrs.OTHER.DSTextBox txtSuccessCS;
        private DevExpress.XtraEditors.LabelControl labelControl12;
        private DrectSoft.Common.Ctrs.OTHER.DSTextBox txtQJCS;
        private DevExpress.XtraEditors.LabelControl labelControl11;
        private DevExpress.XtraEditors.CheckEdit chkInpLY5;
        private DevExpress.XtraEditors.CheckEdit chkInpLY4;
        private DevExpress.XtraEditors.CheckEdit chkInpLY3;
        private DevExpress.XtraEditors.CheckEdit chkInpLY2;
        private DevExpress.XtraEditors.CheckEdit chkInpLY1;
        private DevExpress.XtraEditors.LabelControl labelControl10;
        private DevExpress.XtraEditors.CheckEdit ChkFSYBL3;
        private DevExpress.XtraEditors.CheckEdit chkFSYBL2;
        private DevExpress.XtraEditors.CheckEdit chkFSYBL1;
        private DevExpress.XtraEditors.CheckEdit chkFSYBL0;
        private DevExpress.XtraEditors.LabelControl labelControl9;
        private DevExpress.XtraEditors.CheckEdit chkLCYBL3;
        private DevExpress.XtraEditors.CheckEdit chkLCYBL2;
        private DevExpress.XtraEditors.CheckEdit chkLCYBL1;
        private DevExpress.XtraEditors.CheckEdit chkLCYBL0;
        private DevExpress.XtraEditors.LabelControl labelControl8;
        private DevExpress.XtraEditors.CheckEdit chkRYYCY3;
        private DevExpress.XtraEditors.CheckEdit chkRYYCY2;
        private DevExpress.XtraEditors.CheckEdit chkRYYCY1;
        private DevExpress.XtraEditors.CheckEdit chkRYYCY0;
        private DevExpress.XtraEditors.LabelControl labelControl7;
        private DevExpress.XtraEditors.CheckEdit chkMZYCY3;
        private DevExpress.XtraEditors.CheckEdit chkMZYCY2;
        private DevExpress.XtraEditors.CheckEdit chkMZYCY1;
        private DevExpress.XtraEditors.CheckEdit chkMZYCY0;
        private DevExpress.XtraEditors.LabelControl labelControl6;
        private DevExpress.XtraEditors.CheckEdit chkYNZZF;
        private DevExpress.XtraEditors.CheckEdit chkYNZZS;
        private DevExpress.XtraEditors.LabelControl labelControl5;
        private DevExpress.XtraEditors.CheckEdit chkOutOthers;
        private DevExpress.XtraEditors.CheckEdit chkOutDead;
        private DevExpress.XtraEditors.CheckEdit chkOutWY;
        private DevExpress.XtraEditors.CheckEdit chkOutHZ;
        private DevExpress.XtraEditors.CheckEdit chkOutZY;
        private DevExpress.XtraEditors.LabelControl labelControl4;
        private Common.Library.LookUpEditor lookUpEditPathologyName;
        private DrectSoft.Common.Ctrs.OTHER.DSDateEdit deZkDate;
        private Common.Library.LookUpEditor lueHurt_Toxicosis_Ele;
        private DevExpress.XtraEditors.CheckEdit chkMedicalQuality3;
        private DevExpress.XtraEditors.CheckEdit chkMedicalQuality2;
        private DevExpress.XtraEditors.CheckEdit chkMedicalQuality1;
        private Common.Library.LookUpEditor lueZkys;
        private DevExpress.XtraEditors.LabelControl labelControl56;
        private DevExpress.XtraEditors.LabelControl labelControl55;
        private Common.Library.LookUpEditor lueZkhs;
        private DevExpress.XtraEditors.LabelControl labelControl53;
        private DevExpress.XtraEditors.LabelControl labelControl16;
        private Common.Library.LookUpEditor lueBmy;
        private DevExpress.XtraEditors.LabelControl labelControl49;
        private Common.Library.LookUpEditor lueSxys;
        private DevExpress.XtraEditors.LabelControl labelControl50;
        private Common.Library.LookUpEditor luejxys;
        private DevExpress.XtraEditors.LabelControl labelControl51;
        private Common.Library.LookUpEditor lueDuty_Nurse;
        private DevExpress.XtraEditors.LabelControl labelControl52;
        private Common.Library.LookUpEditor lueZyys;
        private DevExpress.XtraEditors.LabelControl labelControl47;
        private Common.Library.LookUpEditor lueZzys;
        private DevExpress.XtraEditors.LabelControl labelControl48;
        private Common.Library.LookUpEditor lueZrys;
        private DevExpress.XtraEditors.LabelControl labelControl46;
        private Common.Library.LookUpEditor lueKszr;
        private DevExpress.XtraEditors.LabelControl labelControl45;
        private DevExpress.XtraEditors.CheckEdit chkBlood6;
        private DevExpress.XtraEditors.CheckEdit chkBlood4;
        private DevExpress.XtraEditors.CheckEdit chkBlood5;
        private DevExpress.XtraEditors.CheckEdit chkBlood3;
        private DevExpress.XtraEditors.CheckEdit chkBlood2;
        private DevExpress.XtraEditors.CheckEdit chkBlood1;
        private DevExpress.XtraEditors.CheckEdit chkRH4;
        private DevExpress.XtraEditors.CheckEdit chkRH3;
        private DevExpress.XtraEditors.CheckEdit chkAutopsy2;
        private DevExpress.XtraEditors.CheckEdit chkAllergic2;
        private DevExpress.XtraEditors.CheckEdit chkRH2;
        private DevExpress.XtraEditors.CheckEdit chkRH1;
        private DevExpress.XtraEditors.CheckEdit chkAutopsy1;
        private DevExpress.XtraEditors.CheckEdit chkAllergic1;
        private DevExpress.XtraEditors.LabelControl labelControl3;
        private DevExpress.XtraEditors.LabelControl labelControl18;
        private DevExpress.XtraEditors.LabelControl labelControl14;
        private DrectSoft.Common.Ctrs.OTHER.DSTextBox txtAllergicDrug;
        private DevExpress.XtraEditors.LabelControl labelControl17;
        private DevExpress.XtraEditors.LabelControl labelControl122;
        private DevExpress.XtraEditors.LabelControl labelControl118;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private DrectSoft.Common.Ctrs.OTHER.DSTextBox txtPathologyID;
        private DevExpress.XtraEditors.LabelControl labelControl119;
        private DrectSoft.Common.Ctrs.OTHER.DSTextBox txtPathologySn;
        private DevExpress.XtraEditors.LabelControl labelControl121;
        private DrectSoft.Common.Ctrs.OTHER.DevButtonClose btn_Close;
        private DrectSoft.Common.Ctrs.OTHER.DevButtonSave btn_OK;
        private DrectSoft.Common.Ctrs.OTHER.DevTextEdit DevTextEdit1;
    }
}
