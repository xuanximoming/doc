﻿namespace DrectSoft.Core.IEMMainPage
{
    partial class UCOthers
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UCOthers));
            this.labelControl40 = new DevExpress.XtraEditors.LabelControl();
            this.txtTotal = new DevExpress.XtraEditors.TextEdit();
            this.labelControl42 = new DevExpress.XtraEditors.LabelControl();
            this.txtOwnFee = new DevExpress.XtraEditors.TextEdit();
            this.labelControl44 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl46 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl48 = new DevExpress.XtraEditors.LabelControl();
            this.txtYBYLFY = new DevExpress.XtraEditors.TextEdit();
            this.labelControl50 = new DevExpress.XtraEditors.LabelControl();
            this.txtYBZLFY = new DevExpress.XtraEditors.TextEdit();
            this.labelControl52 = new DevExpress.XtraEditors.LabelControl();
            this.txtCare = new DevExpress.XtraEditors.TextEdit();
            this.labelControl55 = new DevExpress.XtraEditors.LabelControl();
            this.txtZHQTFY = new DevExpress.XtraEditors.TextEdit();
            this.labelControl57 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl59 = new DevExpress.XtraEditors.LabelControl();
            this.txtBLZDF = new DevExpress.XtraEditors.TextEdit();
            this.labelControl61 = new DevExpress.XtraEditors.LabelControl();
            this.txtSYSZDF = new DevExpress.XtraEditors.TextEdit();
            this.labelControl63 = new DevExpress.XtraEditors.LabelControl();
            this.txtYXXZDF = new DevExpress.XtraEditors.TextEdit();
            this.labelControl65 = new DevExpress.XtraEditors.LabelControl();
            this.txtLCZDF = new DevExpress.XtraEditors.TextEdit();
            this.labelControl66 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl67 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl68 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl69 = new DevExpress.XtraEditors.LabelControl();
            this.txtFSSZLF = new DevExpress.XtraEditors.TextEdit();
            this.txtLCWLZLF = new DevExpress.XtraEditors.TextEdit();
            this.txtSSZLF = new DevExpress.XtraEditors.TextEdit();
            this.labelControl70 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl71 = new DevExpress.XtraEditors.LabelControl();
            this.txtMZF = new DevExpress.XtraEditors.TextEdit();
            this.labelControl72 = new DevExpress.XtraEditors.LabelControl();
            this.txtSSF = new DevExpress.XtraEditors.TextEdit();
            this.labelControl73 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl74 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl75 = new DevExpress.XtraEditors.LabelControl();
            this.txtKFF = new DevExpress.XtraEditors.TextEdit();
            this.labelControl76 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl77 = new DevExpress.XtraEditors.LabelControl();
            this.txtZYZLF = new DevExpress.XtraEditors.TextEdit();
            this.labelControl17 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl26 = new DevExpress.XtraEditors.LabelControl();
            this.txtXYF = new DevExpress.XtraEditors.TextEdit();
            this.labelControl28 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl29 = new DevExpress.XtraEditors.LabelControl();
            this.txtKJYWF = new DevExpress.XtraEditors.TextEdit();
            this.labelControl31 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl35 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl37 = new DevExpress.XtraEditors.LabelControl();
            this.txtCPMedical = new DevExpress.XtraEditors.TextEdit();
            this.txtCMedical = new DevExpress.XtraEditors.TextEdit();
            this.labelControl33 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl39 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl41 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl43 = new DevExpress.XtraEditors.LabelControl();
            this.txtBloodFee = new DevExpress.XtraEditors.TextEdit();
            this.txtXDBLZPF = new DevExpress.XtraEditors.TextEdit();
            this.txtQDBLZPF = new DevExpress.XtraEditors.TextEdit();
            this.labelControl45 = new DevExpress.XtraEditors.LabelControl();
            this.txtNXYZLZPF = new DevExpress.XtraEditors.TextEdit();
            this.labelControl47 = new DevExpress.XtraEditors.LabelControl();
            this.txtZLYYCXCLF = new DevExpress.XtraEditors.TextEdit();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl3 = new DevExpress.XtraEditors.LabelControl();
            this.txtOtherFee = new DevExpress.XtraEditors.TextEdit();
            this.labelControl4 = new DevExpress.XtraEditors.LabelControl();
            this.txtSSYYCXCLF = new DevExpress.XtraEditors.TextEdit();
            this.labelControl5 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl6 = new DevExpress.XtraEditors.LabelControl();
            this.txtJCYYCXCLF = new DevExpress.XtraEditors.TextEdit();
            this.txtXBYZLZPF = new DevExpress.XtraEditors.TextEdit();
            this.btnLoad = new DevExpress.XtraEditors.SimpleButton();
            this.btn_OK = new DrectSoft.Common.Ctrs.OTHER.DevButtonOK(this.components);
            this.btn_Close = new DrectSoft.Common.Ctrs.OTHER.DevButtonClose(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.txtTotal.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtOwnFee.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtYBYLFY.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtYBZLFY.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCare.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtZHQTFY.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtBLZDF.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSYSZDF.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtYXXZDF.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtLCZDF.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtFSSZLF.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtLCWLZLF.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSSZLF.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMZF.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSSF.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtKFF.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtZYZLF.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtXYF.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtKJYWF.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCPMedical.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCMedical.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtBloodFee.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtXDBLZPF.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtQDBLZPF.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtNXYZLZPF.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtZLYYCXCLF.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtOtherFee.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSSYYCXCLF.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtJCYYCXCLF.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtXBYZLZPF.Properties)).BeginInit();
            this.SuspendLayout();
            // 
            // labelControl40
            // 
            this.labelControl40.Appearance.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.labelControl40.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl40.Location = new System.Drawing.Point(14, 16);
            this.labelControl40.Name = "labelControl40";
            this.labelControl40.Size = new System.Drawing.Size(143, 14);
            this.labelControl40.TabIndex = 125;
            this.labelControl40.Text = "住院费用（元）：总费用";
            // 
            // txtTotal
            // 
            this.txtTotal.EditValue = "";
            this.txtTotal.Location = new System.Drawing.Point(160, 16);
            this.txtTotal.Name = "txtTotal";
            this.txtTotal.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtTotal.Size = new System.Drawing.Size(121, 19);
            this.txtTotal.TabIndex = 218;
            // 
            // labelControl42
            // 
            this.labelControl42.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl42.Location = new System.Drawing.Point(290, 16);
            this.labelControl42.Name = "labelControl42";
            this.labelControl42.Size = new System.Drawing.Size(72, 14);
            this.labelControl42.TabIndex = 125;
            this.labelControl42.Text = "（自付金额：";
            // 
            // txtOwnFee
            // 
            this.txtOwnFee.EditValue = "";
            this.txtOwnFee.Location = new System.Drawing.Point(358, 14);
            this.txtOwnFee.Name = "txtOwnFee";
            this.txtOwnFee.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtOwnFee.Size = new System.Drawing.Size(122, 19);
            this.txtOwnFee.TabIndex = 218;
            // 
            // labelControl44
            // 
            this.labelControl44.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl44.Location = new System.Drawing.Point(482, 14);
            this.labelControl44.Name = "labelControl44";
            this.labelControl44.Size = new System.Drawing.Size(12, 14);
            this.labelControl44.TabIndex = 125;
            this.labelControl44.Text = "）";
            // 
            // labelControl46
            // 
            this.labelControl46.Appearance.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.labelControl46.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl46.Location = new System.Drawing.Point(15, 38);
            this.labelControl46.Name = "labelControl46";
            this.labelControl46.Size = new System.Drawing.Size(116, 14);
            this.labelControl46.TabIndex = 125;
            this.labelControl46.Text = "1.综合医疗服务类：";
            // 
            // labelControl48
            // 
            this.labelControl48.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl48.Location = new System.Drawing.Point(133, 38);
            this.labelControl48.Name = "labelControl48";
            this.labelControl48.Size = new System.Drawing.Size(127, 14);
            this.labelControl48.TabIndex = 125;
            this.labelControl48.Text = "（1）一般医疗服务费：";
            // 
            // txtYBYLFY
            // 
            this.txtYBYLFY.EditValue = "";
            this.txtYBYLFY.Location = new System.Drawing.Point(252, 36);
            this.txtYBYLFY.Name = "txtYBYLFY";
            this.txtYBYLFY.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtYBYLFY.Size = new System.Drawing.Size(47, 19);
            this.txtYBYLFY.TabIndex = 218;
            // 
            // labelControl50
            // 
            this.labelControl50.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl50.Location = new System.Drawing.Point(297, 38);
            this.labelControl50.Name = "labelControl50";
            this.labelControl50.Size = new System.Drawing.Size(127, 14);
            this.labelControl50.TabIndex = 125;
            this.labelControl50.Text = "（2）一般治疗操作费：";
            // 
            // txtYBZLFY
            // 
            this.txtYBZLFY.EditValue = "";
            this.txtYBZLFY.Location = new System.Drawing.Point(421, 36);
            this.txtYBZLFY.Name = "txtYBZLFY";
            this.txtYBZLFY.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtYBZLFY.Size = new System.Drawing.Size(55, 19);
            this.txtYBZLFY.TabIndex = 218;
            // 
            // labelControl52
            // 
            this.labelControl52.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl52.Location = new System.Drawing.Point(477, 38);
            this.labelControl52.Name = "labelControl52";
            this.labelControl52.Size = new System.Drawing.Size(79, 14);
            this.labelControl52.TabIndex = 125;
            this.labelControl52.Text = "（3）护理费：";
            // 
            // txtCare
            // 
            this.txtCare.EditValue = "";
            this.txtCare.Location = new System.Drawing.Point(551, 36);
            this.txtCare.Name = "txtCare";
            this.txtCare.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtCare.Size = new System.Drawing.Size(47, 19);
            this.txtCare.TabIndex = 218;
            // 
            // labelControl55
            // 
            this.labelControl55.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl55.Location = new System.Drawing.Point(34, 60);
            this.labelControl55.Name = "labelControl55";
            this.labelControl55.Size = new System.Drawing.Size(91, 14);
            this.labelControl55.TabIndex = 125;
            this.labelControl55.Text = "（4）其他费用：";
            // 
            // txtZHQTFY
            // 
            this.txtZHQTFY.EditValue = "";
            this.txtZHQTFY.Location = new System.Drawing.Point(122, 58);
            this.txtZHQTFY.Name = "txtZHQTFY";
            this.txtZHQTFY.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtZHQTFY.Size = new System.Drawing.Size(83, 19);
            this.txtZHQTFY.TabIndex = 218;
            // 
            // labelControl57
            // 
            this.labelControl57.Appearance.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.labelControl57.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl57.Location = new System.Drawing.Point(15, 83);
            this.labelControl57.Name = "labelControl57";
            this.labelControl57.Size = new System.Drawing.Size(64, 14);
            this.labelControl57.TabIndex = 125;
            this.labelControl57.Text = "2.诊断类：";
            // 
            // labelControl59
            // 
            this.labelControl59.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl59.Location = new System.Drawing.Point(78, 83);
            this.labelControl59.Name = "labelControl59";
            this.labelControl59.Size = new System.Drawing.Size(103, 14);
            this.labelControl59.TabIndex = 125;
            this.labelControl59.Text = "（5）病理诊断费：";
            // 
            // txtBLZDF
            // 
            this.txtBLZDF.EditValue = "";
            this.txtBLZDF.Location = new System.Drawing.Point(177, 81);
            this.txtBLZDF.Name = "txtBLZDF";
            this.txtBLZDF.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtBLZDF.Size = new System.Drawing.Size(56, 19);
            this.txtBLZDF.TabIndex = 218;
            // 
            // labelControl61
            // 
            this.labelControl61.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl61.Location = new System.Drawing.Point(237, 83);
            this.labelControl61.Name = "labelControl61";
            this.labelControl61.Size = new System.Drawing.Size(115, 14);
            this.labelControl61.TabIndex = 125;
            this.labelControl61.Text = "（6）实验室诊断费：";
            // 
            // txtSYSZDF
            // 
            this.txtSYSZDF.EditValue = "";
            this.txtSYSZDF.Location = new System.Drawing.Point(347, 81);
            this.txtSYSZDF.Name = "txtSYSZDF";
            this.txtSYSZDF.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtSYSZDF.Size = new System.Drawing.Size(54, 19);
            this.txtSYSZDF.TabIndex = 218;
            // 
            // labelControl63
            // 
            this.labelControl63.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl63.Location = new System.Drawing.Point(407, 83);
            this.labelControl63.Name = "labelControl63";
            this.labelControl63.Size = new System.Drawing.Size(115, 14);
            this.labelControl63.TabIndex = 125;
            this.labelControl63.Text = "（7）影像学诊断费：";
            // 
            // txtYXXZDF
            // 
            this.txtYXXZDF.EditValue = "";
            this.txtYXXZDF.Location = new System.Drawing.Point(516, 81);
            this.txtYXXZDF.Name = "txtYXXZDF";
            this.txtYXXZDF.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtYXXZDF.Size = new System.Drawing.Size(55, 19);
            this.txtYXXZDF.TabIndex = 218;
            // 
            // labelControl65
            // 
            this.labelControl65.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl65.Location = new System.Drawing.Point(34, 105);
            this.labelControl65.Name = "labelControl65";
            this.labelControl65.Size = new System.Drawing.Size(127, 14);
            this.labelControl65.TabIndex = 125;
            this.labelControl65.Text = "（8）临床诊断项目费：";
            // 
            // txtLCZDF
            // 
            this.txtLCZDF.EditValue = "";
            this.txtLCZDF.Location = new System.Drawing.Point(155, 103);
            this.txtLCZDF.Name = "txtLCZDF";
            this.txtLCZDF.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtLCZDF.Size = new System.Drawing.Size(47, 19);
            this.txtLCZDF.TabIndex = 218;
            // 
            // labelControl66
            // 
            this.labelControl66.Appearance.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.labelControl66.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl66.Location = new System.Drawing.Point(15, 125);
            this.labelControl66.Name = "labelControl66";
            this.labelControl66.Size = new System.Drawing.Size(64, 14);
            this.labelControl66.TabIndex = 125;
            this.labelControl66.Text = "3.治疗类：";
            // 
            // labelControl67
            // 
            this.labelControl67.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl67.Location = new System.Drawing.Point(80, 125);
            this.labelControl67.Name = "labelControl67";
            this.labelControl67.Size = new System.Drawing.Size(139, 14);
            this.labelControl67.TabIndex = 125;
            this.labelControl67.Text = "（9）非手术治疗项目费：";
            // 
            // labelControl68
            // 
            this.labelControl68.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl68.Location = new System.Drawing.Point(295, 125);
            this.labelControl68.Name = "labelControl68";
            this.labelControl68.Size = new System.Drawing.Size(108, 14);
            this.labelControl68.TabIndex = 125;
            this.labelControl68.Text = "（临床物理治疗费：";
            // 
            // labelControl69
            // 
            this.labelControl69.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl69.Location = new System.Drawing.Point(34, 148);
            this.labelControl69.Name = "labelControl69";
            this.labelControl69.Size = new System.Drawing.Size(110, 14);
            this.labelControl69.TabIndex = 125;
            this.labelControl69.Text = "（10）手术治疗费：";
            // 
            // txtFSSZLF
            // 
            this.txtFSSZLF.EditValue = "";
            this.txtFSSZLF.Location = new System.Drawing.Point(216, 123);
            this.txtFSSZLF.Name = "txtFSSZLF";
            this.txtFSSZLF.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtFSSZLF.Size = new System.Drawing.Size(74, 19);
            this.txtFSSZLF.TabIndex = 218;
            // 
            // txtLCWLZLF
            // 
            this.txtLCWLZLF.EditValue = "";
            this.txtLCWLZLF.Location = new System.Drawing.Point(399, 123);
            this.txtLCWLZLF.Name = "txtLCWLZLF";
            this.txtLCWLZLF.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtLCWLZLF.Size = new System.Drawing.Size(71, 19);
            this.txtLCWLZLF.TabIndex = 218;
            // 
            // txtSSZLF
            // 
            this.txtSSZLF.EditValue = "";
            this.txtSSZLF.Location = new System.Drawing.Point(141, 146);
            this.txtSSZLF.Name = "txtSSZLF";
            this.txtSSZLF.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtSSZLF.Size = new System.Drawing.Size(57, 19);
            this.txtSSZLF.TabIndex = 218;
            // 
            // labelControl70
            // 
            this.labelControl70.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl70.Location = new System.Drawing.Point(476, 125);
            this.labelControl70.Name = "labelControl70";
            this.labelControl70.Size = new System.Drawing.Size(12, 14);
            this.labelControl70.TabIndex = 125;
            this.labelControl70.Text = "）";
            // 
            // labelControl71
            // 
            this.labelControl71.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl71.Location = new System.Drawing.Point(202, 148);
            this.labelControl71.Name = "labelControl71";
            this.labelControl71.Size = new System.Drawing.Size(60, 14);
            this.labelControl71.TabIndex = 125;
            this.labelControl71.Text = "（麻醉费：";
            // 
            // txtMZF
            // 
            this.txtMZF.EditValue = "";
            this.txtMZF.Location = new System.Drawing.Point(259, 146);
            this.txtMZF.Name = "txtMZF";
            this.txtMZF.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtMZF.Size = new System.Drawing.Size(64, 19);
            this.txtMZF.TabIndex = 218;
            // 
            // labelControl72
            // 
            this.labelControl72.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl72.Location = new System.Drawing.Point(329, 148);
            this.labelControl72.Name = "labelControl72";
            this.labelControl72.Size = new System.Drawing.Size(48, 14);
            this.labelControl72.TabIndex = 125;
            this.labelControl72.Text = "手术费：";
            // 
            // txtSSF
            // 
            this.txtSSF.EditValue = "";
            this.txtSSF.Location = new System.Drawing.Point(373, 146);
            this.txtSSF.Name = "txtSSF";
            this.txtSSF.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtSSF.Size = new System.Drawing.Size(64, 19);
            this.txtSSF.TabIndex = 218;
            // 
            // labelControl73
            // 
            this.labelControl73.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl73.Location = new System.Drawing.Point(436, 148);
            this.labelControl73.Name = "labelControl73";
            this.labelControl73.Size = new System.Drawing.Size(12, 14);
            this.labelControl73.TabIndex = 125;
            this.labelControl73.Text = "）";
            // 
            // labelControl74
            // 
            this.labelControl74.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl74.Location = new System.Drawing.Point(79, 168);
            this.labelControl74.Name = "labelControl74";
            this.labelControl74.Size = new System.Drawing.Size(86, 14);
            this.labelControl74.TabIndex = 125;
            this.labelControl74.Text = "（11）康复费：";
            // 
            // labelControl75
            // 
            this.labelControl75.Appearance.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.labelControl75.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl75.Location = new System.Drawing.Point(14, 168);
            this.labelControl75.Name = "labelControl75";
            this.labelControl75.Size = new System.Drawing.Size(64, 14);
            this.labelControl75.TabIndex = 125;
            this.labelControl75.Text = "4.康复类：";
            // 
            // txtKFF
            // 
            this.txtKFF.EditValue = "";
            this.txtKFF.Location = new System.Drawing.Point(162, 166);
            this.txtKFF.Name = "txtKFF";
            this.txtKFF.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtKFF.Size = new System.Drawing.Size(98, 19);
            this.txtKFF.TabIndex = 218;
            // 
            // labelControl76
            // 
            this.labelControl76.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl76.Location = new System.Drawing.Point(80, 190);
            this.labelControl76.Name = "labelControl76";
            this.labelControl76.Size = new System.Drawing.Size(110, 14);
            this.labelControl76.TabIndex = 125;
            this.labelControl76.Text = "（12）中医治疗费：";
            // 
            // labelControl77
            // 
            this.labelControl77.Appearance.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.labelControl77.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl77.Location = new System.Drawing.Point(15, 190);
            this.labelControl77.Name = "labelControl77";
            this.labelControl77.Size = new System.Drawing.Size(64, 14);
            this.labelControl77.TabIndex = 125;
            this.labelControl77.Text = "5.中医类：";
            // 
            // txtZYZLF
            // 
            this.txtZYZLF.EditValue = "";
            this.txtZYZLF.Location = new System.Drawing.Point(186, 188);
            this.txtZYZLF.Name = "txtZYZLF";
            this.txtZYZLF.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtZYZLF.Size = new System.Drawing.Size(74, 19);
            this.txtZYZLF.TabIndex = 218;
            // 
            // labelControl17
            // 
            this.labelControl17.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl17.Location = new System.Drawing.Point(80, 212);
            this.labelControl17.Name = "labelControl17";
            this.labelControl17.Size = new System.Drawing.Size(86, 14);
            this.labelControl17.TabIndex = 125;
            this.labelControl17.Text = "（13）西药费：";
            // 
            // labelControl26
            // 
            this.labelControl26.Appearance.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.labelControl26.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl26.Location = new System.Drawing.Point(15, 212);
            this.labelControl26.Name = "labelControl26";
            this.labelControl26.Size = new System.Drawing.Size(64, 14);
            this.labelControl26.TabIndex = 125;
            this.labelControl26.Text = "6.西药类：";
            // 
            // txtXYF
            // 
            this.txtXYF.EditValue = "";
            this.txtXYF.Location = new System.Drawing.Point(162, 210);
            this.txtXYF.Name = "txtXYF";
            this.txtXYF.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtXYF.Size = new System.Drawing.Size(110, 19);
            this.txtXYF.TabIndex = 218;
            // 
            // labelControl28
            // 
            this.labelControl28.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl28.Location = new System.Drawing.Point(425, 212);
            this.labelControl28.Name = "labelControl28";
            this.labelControl28.Size = new System.Drawing.Size(12, 14);
            this.labelControl28.TabIndex = 125;
            this.labelControl28.Text = "）";
            // 
            // labelControl29
            // 
            this.labelControl29.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl29.Location = new System.Drawing.Point(278, 212);
            this.labelControl29.Name = "labelControl29";
            this.labelControl29.Size = new System.Drawing.Size(96, 14);
            this.labelControl29.TabIndex = 125;
            this.labelControl29.Text = "（抗菌药物费用：";
            // 
            // txtKJYWF
            // 
            this.txtKJYWF.EditValue = "";
            this.txtKJYWF.Location = new System.Drawing.Point(372, 210);
            this.txtKJYWF.Name = "txtKJYWF";
            this.txtKJYWF.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtKJYWF.Size = new System.Drawing.Size(47, 19);
            this.txtKJYWF.TabIndex = 218;
            // 
            // labelControl31
            // 
            this.labelControl31.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl31.Location = new System.Drawing.Point(80, 232);
            this.labelControl31.Name = "labelControl31";
            this.labelControl31.Size = new System.Drawing.Size(98, 14);
            this.labelControl31.TabIndex = 125;
            this.labelControl31.Text = "（14）中成药费：";
            // 
            // labelControl35
            // 
            this.labelControl35.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl35.Location = new System.Drawing.Point(278, 232);
            this.labelControl35.Name = "labelControl35";
            this.labelControl35.Size = new System.Drawing.Size(98, 14);
            this.labelControl35.TabIndex = 125;
            this.labelControl35.Text = "（15）中草药费：";
            // 
            // labelControl37
            // 
            this.labelControl37.Appearance.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.labelControl37.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl37.Location = new System.Drawing.Point(15, 232);
            this.labelControl37.Name = "labelControl37";
            this.labelControl37.Size = new System.Drawing.Size(64, 14);
            this.labelControl37.TabIndex = 125;
            this.labelControl37.Text = "7.中药类：";
            // 
            // txtCPMedical
            // 
            this.txtCPMedical.EditValue = "";
            this.txtCPMedical.Location = new System.Drawing.Point(175, 230);
            this.txtCPMedical.Name = "txtCPMedical";
            this.txtCPMedical.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtCPMedical.Size = new System.Drawing.Size(97, 19);
            this.txtCPMedical.TabIndex = 218;
            // 
            // txtCMedical
            // 
            this.txtCMedical.EditValue = "";
            this.txtCMedical.Location = new System.Drawing.Point(372, 230);
            this.txtCMedical.Name = "txtCMedical";
            this.txtCMedical.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtCMedical.Size = new System.Drawing.Size(89, 19);
            this.txtCMedical.TabIndex = 218;
            // 
            // labelControl33
            // 
            this.labelControl33.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl33.Location = new System.Drawing.Point(150, 254);
            this.labelControl33.Name = "labelControl33";
            this.labelControl33.Size = new System.Drawing.Size(74, 14);
            this.labelControl33.TabIndex = 125;
            this.labelControl33.Text = "（16）血费：";
            // 
            // labelControl39
            // 
            this.labelControl39.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl39.Location = new System.Drawing.Point(283, 254);
            this.labelControl39.Name = "labelControl39";
            this.labelControl39.Size = new System.Drawing.Size(134, 14);
            this.labelControl39.TabIndex = 125;
            this.labelControl39.Text = "（17）白蛋白类制品费：";
            // 
            // labelControl41
            // 
            this.labelControl41.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl41.Location = new System.Drawing.Point(32, 274);
            this.labelControl41.Name = "labelControl41";
            this.labelControl41.Size = new System.Drawing.Size(134, 14);
            this.labelControl41.TabIndex = 125;
            this.labelControl41.Text = "（18）球蛋白类制品费：";
            // 
            // labelControl43
            // 
            this.labelControl43.Appearance.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.labelControl43.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl43.Location = new System.Drawing.Point(15, 254);
            this.labelControl43.Name = "labelControl43";
            this.labelControl43.Size = new System.Drawing.Size(129, 14);
            this.labelControl43.TabIndex = 125;
            this.labelControl43.Text = "8.血液和血液制品类：";
            // 
            // txtBloodFee
            // 
            this.txtBloodFee.EditValue = "";
            this.txtBloodFee.Location = new System.Drawing.Point(221, 252);
            this.txtBloodFee.Name = "txtBloodFee";
            this.txtBloodFee.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtBloodFee.Size = new System.Drawing.Size(63, 19);
            this.txtBloodFee.TabIndex = 218;
            // 
            // txtXDBLZPF
            // 
            this.txtXDBLZPF.EditValue = "";
            this.txtXDBLZPF.Location = new System.Drawing.Point(414, 254);
            this.txtXDBLZPF.Name = "txtXDBLZPF";
            this.txtXDBLZPF.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtXDBLZPF.Size = new System.Drawing.Size(74, 19);
            this.txtXDBLZPF.TabIndex = 218;
            // 
            // txtQDBLZPF
            // 
            this.txtQDBLZPF.EditValue = "";
            this.txtQDBLZPF.Location = new System.Drawing.Point(164, 272);
            this.txtQDBLZPF.Name = "txtQDBLZPF";
            this.txtQDBLZPF.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtQDBLZPF.Size = new System.Drawing.Size(60, 19);
            this.txtQDBLZPF.TabIndex = 218;
            // 
            // labelControl45
            // 
            this.labelControl45.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl45.Location = new System.Drawing.Point(225, 274);
            this.labelControl45.Name = "labelControl45";
            this.labelControl45.Size = new System.Drawing.Size(146, 14);
            this.labelControl45.TabIndex = 125;
            this.labelControl45.Text = "（19）凝血因子类制品费：";
            // 
            // txtNXYZLZPF
            // 
            this.txtNXYZLZPF.EditValue = "";
            this.txtNXYZLZPF.Location = new System.Drawing.Point(362, 272);
            this.txtNXYZLZPF.Name = "txtNXYZLZPF";
            this.txtNXYZLZPF.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtNXYZLZPF.Size = new System.Drawing.Size(59, 19);
            this.txtNXYZLZPF.TabIndex = 218;
            // 
            // labelControl47
            // 
            this.labelControl47.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl47.Location = new System.Drawing.Point(422, 274);
            this.labelControl47.Name = "labelControl47";
            this.labelControl47.Size = new System.Drawing.Size(146, 14);
            this.labelControl47.TabIndex = 125;
            this.labelControl47.Text = "（20）细胞因子类制品费：";
            // 
            // txtZLYYCXCLF
            // 
            this.txtZLYYCXCLF.EditValue = "";
            this.txtZLYYCXCLF.Location = new System.Drawing.Point(492, 295);
            this.txtZLYYCXCLF.Name = "txtZLYYCXCLF";
            this.txtZLYYCXCLF.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtZLYYCXCLF.Size = new System.Drawing.Size(66, 19);
            this.txtZLYYCXCLF.TabIndex = 218;
            // 
            // labelControl1
            // 
            this.labelControl1.Appearance.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.labelControl1.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl1.Location = new System.Drawing.Point(15, 297);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(64, 14);
            this.labelControl1.TabIndex = 125;
            this.labelControl1.Text = "9.耗材类：";
            // 
            // labelControl2
            // 
            this.labelControl2.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl2.Location = new System.Drawing.Point(87, 339);
            this.labelControl2.Name = "labelControl2";
            this.labelControl2.Size = new System.Drawing.Size(86, 14);
            this.labelControl2.TabIndex = 125;
            this.labelControl2.Text = "（24）其他费：";
            // 
            // labelControl3
            // 
            this.labelControl3.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl3.Location = new System.Drawing.Point(314, 297);
            this.labelControl3.Name = "labelControl3";
            this.labelControl3.Size = new System.Drawing.Size(182, 14);
            this.labelControl3.TabIndex = 125;
            this.labelControl3.Text = "（22）治疗用一次性医用材料费：";
            // 
            // txtOtherFee
            // 
            this.txtOtherFee.EditValue = "";
            this.txtOtherFee.Location = new System.Drawing.Point(162, 336);
            this.txtOtherFee.Name = "txtOtherFee";
            this.txtOtherFee.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtOtherFee.Size = new System.Drawing.Size(69, 19);
            this.txtOtherFee.TabIndex = 218;
            // 
            // labelControl4
            // 
            this.labelControl4.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl4.Location = new System.Drawing.Point(34, 319);
            this.labelControl4.Name = "labelControl4";
            this.labelControl4.Size = new System.Drawing.Size(182, 14);
            this.labelControl4.TabIndex = 125;
            this.labelControl4.Text = "（23）手术用一次性医用材料费：";
            // 
            // txtSSYYCXCLF
            // 
            this.txtSSYYCXCLF.EditValue = "";
            this.txtSSYYCXCLF.Location = new System.Drawing.Point(212, 317);
            this.txtSSYYCXCLF.Name = "txtSSYYCXCLF";
            this.txtSSYYCXCLF.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtSSYYCXCLF.Size = new System.Drawing.Size(60, 19);
            this.txtSSYYCXCLF.TabIndex = 218;
            // 
            // labelControl5
            // 
            this.labelControl5.Appearance.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.labelControl5.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl5.Location = new System.Drawing.Point(14, 339);
            this.labelControl5.Name = "labelControl5";
            this.labelControl5.Size = new System.Drawing.Size(72, 14);
            this.labelControl5.TabIndex = 125;
            this.labelControl5.Text = "10.其他类：";
            // 
            // labelControl6
            // 
            this.labelControl6.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl6.Location = new System.Drawing.Point(85, 297);
            this.labelControl6.Name = "labelControl6";
            this.labelControl6.Size = new System.Drawing.Size(182, 14);
            this.labelControl6.TabIndex = 125;
            this.labelControl6.Text = "（21）检查用一次性医用材料费：";
            // 
            // txtJCYYCXCLF
            // 
            this.txtJCYYCXCLF.EditValue = "";
            this.txtJCYYCXCLF.Location = new System.Drawing.Point(263, 295);
            this.txtJCYYCXCLF.Name = "txtJCYYCXCLF";
            this.txtJCYYCXCLF.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtJCYYCXCLF.Size = new System.Drawing.Size(47, 19);
            this.txtJCYYCXCLF.TabIndex = 218;
            // 
            // txtXBYZLZPF
            // 
            this.txtXBYZLZPF.EditValue = "";
            this.txtXBYZLZPF.Location = new System.Drawing.Point(562, 272);
            this.txtXBYZLZPF.Name = "txtXBYZLZPF";
            this.txtXBYZLZPF.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtXBYZLZPF.Size = new System.Drawing.Size(47, 19);
            this.txtXBYZLZPF.TabIndex = 219;
            // 
            // btnLoad
            // 
            this.btnLoad.Location = new System.Drawing.Point(278, 362);
            this.btnLoad.Name = "btnLoad";
            this.btnLoad.Size = new System.Drawing.Size(75, 27);
            this.btnLoad.TabIndex = 220;
            this.btnLoad.Text = "提取";
            this.btnLoad.ToolTip = "从his中提取费用信息";
            this.btnLoad.Click += new System.EventHandler(this.btnFee_Click);
            // 
            // btn_OK
            // 
            this.btn_OK.Image = ((System.Drawing.Image)(resources.GetObject("btn_OK.Image")));
            this.btn_OK.Location = new System.Drawing.Point(372, 362);
            this.btn_OK.Name = "btn_OK";
            this.btn_OK.Size = new System.Drawing.Size(75, 27);
            this.btn_OK.TabIndex = 185;
            this.btn_OK.Text = "确定(&Y)";
            this.btn_OK.Click += new System.EventHandler(this.btn_OK_Click);
            // 
            // btn_Close
            // 
            this.btn_Close.Image = ((System.Drawing.Image)(resources.GetObject("btn_Close.Image")));
            this.btn_Close.Location = new System.Drawing.Point(476, 362);
            this.btn_Close.Name = "btn_Close";
            this.btn_Close.Size = new System.Drawing.Size(75, 27);
            this.btn_Close.TabIndex = 186;
            this.btn_Close.Text = "关闭(&T)";
            this.btn_Close.Click += new System.EventHandler(this.btn_Close_Click);
            // 
            // UCOthers
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.btn_Close);
            this.Controls.Add(this.btn_OK);
            this.Controls.Add(this.btnLoad);
            this.Controls.Add(this.txtXBYZLZPF);
            this.Controls.Add(this.txtOwnFee);
            this.Controls.Add(this.txtCare);
            this.Controls.Add(this.txtZHQTFY);
            this.Controls.Add(this.txtYBZLFY);
            this.Controls.Add(this.txtLCZDF);
            this.Controls.Add(this.txtSSZLF);
            this.Controls.Add(this.txtSSYYCXCLF);
            this.Controls.Add(this.txtJCYYCXCLF);
            this.Controls.Add(this.txtZLYYCXCLF);
            this.Controls.Add(this.txtNXYZLZPF);
            this.Controls.Add(this.txtQDBLZPF);
            this.Controls.Add(this.txtYXXZDF);
            this.Controls.Add(this.txtCMedical);
            this.Controls.Add(this.txtKJYWF);
            this.Controls.Add(this.txtSSF);
            this.Controls.Add(this.txtMZF);
            this.Controls.Add(this.txtLCWLZLF);
            this.Controls.Add(this.txtXDBLZPF);
            this.Controls.Add(this.txtSYSZDF);
            this.Controls.Add(this.txtCPMedical);
            this.Controls.Add(this.txtXYF);
            this.Controls.Add(this.txtZYZLF);
            this.Controls.Add(this.txtKFF);
            this.Controls.Add(this.txtFSSZLF);
            this.Controls.Add(this.txtOtherFee);
            this.Controls.Add(this.txtBloodFee);
            this.Controls.Add(this.txtBLZDF);
            this.Controls.Add(this.txtYBYLFY);
            this.Controls.Add(this.txtTotal);
            this.Controls.Add(this.labelControl37);
            this.Controls.Add(this.labelControl26);
            this.Controls.Add(this.labelControl77);
            this.Controls.Add(this.labelControl75);
            this.Controls.Add(this.labelControl66);
            this.Controls.Add(this.labelControl5);
            this.Controls.Add(this.labelControl1);
            this.Controls.Add(this.labelControl43);
            this.Controls.Add(this.labelControl57);
            this.Controls.Add(this.labelControl46);
            this.Controls.Add(this.labelControl40);
            this.Controls.Add(this.labelControl44);
            this.Controls.Add(this.labelControl52);
            this.Controls.Add(this.labelControl48);
            this.Controls.Add(this.labelControl65);
            this.Controls.Add(this.labelControl47);
            this.Controls.Add(this.labelControl45);
            this.Controls.Add(this.labelControl41);
            this.Controls.Add(this.labelControl69);
            this.Controls.Add(this.labelControl63);
            this.Controls.Add(this.labelControl35);
            this.Controls.Add(this.labelControl70);
            this.Controls.Add(this.labelControl29);
            this.Controls.Add(this.labelControl28);
            this.Controls.Add(this.labelControl72);
            this.Controls.Add(this.labelControl31);
            this.Controls.Add(this.labelControl73);
            this.Controls.Add(this.labelControl17);
            this.Controls.Add(this.labelControl71);
            this.Controls.Add(this.labelControl76);
            this.Controls.Add(this.labelControl68);
            this.Controls.Add(this.labelControl4);
            this.Controls.Add(this.labelControl6);
            this.Controls.Add(this.labelControl3);
            this.Controls.Add(this.labelControl39);
            this.Controls.Add(this.labelControl74);
            this.Controls.Add(this.labelControl61);
            this.Controls.Add(this.labelControl2);
            this.Controls.Add(this.labelControl33);
            this.Controls.Add(this.labelControl67);
            this.Controls.Add(this.labelControl59);
            this.Controls.Add(this.labelControl55);
            this.Controls.Add(this.labelControl50);
            this.Controls.Add(this.labelControl42);
            this.Name = "UCOthers";
            this.Size = new System.Drawing.Size(620, 399);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.UCOthers_Paint);
            ((System.ComponentModel.ISupportInitialize)(this.txtTotal.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtOwnFee.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtYBYLFY.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtYBZLFY.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCare.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtZHQTFY.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtBLZDF.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSYSZDF.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtYXXZDF.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtLCZDF.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtFSSZLF.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtLCWLZLF.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSSZLF.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMZF.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSSF.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtKFF.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtZYZLF.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtXYF.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtKJYWF.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCPMedical.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCMedical.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtBloodFee.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtXDBLZPF.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtQDBLZPF.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtNXYZLZPF.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtZLYYCXCLF.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtOtherFee.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSSYYCXCLF.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtJCYYCXCLF.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtXBYZLZPF.Properties)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevExpress.XtraEditors.LabelControl labelControl40;
        private DevExpress.XtraEditors.TextEdit txtTotal;
        private DevExpress.XtraEditors.LabelControl labelControl42;
        private DevExpress.XtraEditors.TextEdit txtOwnFee;
        private DevExpress.XtraEditors.LabelControl labelControl44;
        private DevExpress.XtraEditors.LabelControl labelControl46;
        private DevExpress.XtraEditors.LabelControl labelControl48;
        private DevExpress.XtraEditors.TextEdit txtYBYLFY;
        private DevExpress.XtraEditors.LabelControl labelControl50;
        private DevExpress.XtraEditors.TextEdit txtYBZLFY;
        private DevExpress.XtraEditors.LabelControl labelControl52;
        private DevExpress.XtraEditors.TextEdit txtCare;
        private DevExpress.XtraEditors.LabelControl labelControl55;
        private DevExpress.XtraEditors.TextEdit txtZHQTFY;
        private DevExpress.XtraEditors.LabelControl labelControl57;
        private DevExpress.XtraEditors.LabelControl labelControl59;
        private DevExpress.XtraEditors.TextEdit txtBLZDF;
        private DevExpress.XtraEditors.LabelControl labelControl61;
        private DevExpress.XtraEditors.TextEdit txtSYSZDF;
        private DevExpress.XtraEditors.LabelControl labelControl63;
        private DevExpress.XtraEditors.TextEdit txtYXXZDF;
        private DevExpress.XtraEditors.LabelControl labelControl65;
        private DevExpress.XtraEditors.TextEdit txtLCZDF;
        private DevExpress.XtraEditors.LabelControl labelControl66;
        private DevExpress.XtraEditors.LabelControl labelControl67;
        private DevExpress.XtraEditors.LabelControl labelControl68;
        private DevExpress.XtraEditors.LabelControl labelControl69;
        private DevExpress.XtraEditors.TextEdit txtFSSZLF;
        private DevExpress.XtraEditors.TextEdit txtLCWLZLF;
        private DevExpress.XtraEditors.TextEdit txtSSZLF;
        private DevExpress.XtraEditors.LabelControl labelControl70;
        private DevExpress.XtraEditors.LabelControl labelControl71;
        private DevExpress.XtraEditors.TextEdit txtMZF;
        private DevExpress.XtraEditors.LabelControl labelControl72;
        private DevExpress.XtraEditors.TextEdit txtSSF;
        private DevExpress.XtraEditors.LabelControl labelControl73;
        private DevExpress.XtraEditors.LabelControl labelControl74;
        private DevExpress.XtraEditors.LabelControl labelControl75;
        private DevExpress.XtraEditors.TextEdit txtKFF;
        private DevExpress.XtraEditors.LabelControl labelControl76;
        private DevExpress.XtraEditors.LabelControl labelControl77;
        private DevExpress.XtraEditors.TextEdit txtZYZLF;
        private DevExpress.XtraEditors.LabelControl labelControl17;
        private DevExpress.XtraEditors.LabelControl labelControl26;
        private DevExpress.XtraEditors.TextEdit txtXYF;
        private DevExpress.XtraEditors.LabelControl labelControl28;
        private DevExpress.XtraEditors.LabelControl labelControl29;
        private DevExpress.XtraEditors.TextEdit txtKJYWF;
        private DevExpress.XtraEditors.LabelControl labelControl31;
        private DevExpress.XtraEditors.LabelControl labelControl35;
        private DevExpress.XtraEditors.LabelControl labelControl37;
        private DevExpress.XtraEditors.TextEdit txtCPMedical;
        private DevExpress.XtraEditors.TextEdit txtCMedical;
        private DevExpress.XtraEditors.LabelControl labelControl33;
        private DevExpress.XtraEditors.LabelControl labelControl39;
        private DevExpress.XtraEditors.LabelControl labelControl41;
        private DevExpress.XtraEditors.LabelControl labelControl43;
        private DevExpress.XtraEditors.TextEdit txtBloodFee;
        private DevExpress.XtraEditors.TextEdit txtXDBLZPF;
        private DevExpress.XtraEditors.TextEdit txtQDBLZPF;
        private DevExpress.XtraEditors.LabelControl labelControl45;
        private DevExpress.XtraEditors.TextEdit txtNXYZLZPF;
        private DevExpress.XtraEditors.LabelControl labelControl47;
        private DevExpress.XtraEditors.TextEdit txtZLYYCXCLF;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private DevExpress.XtraEditors.LabelControl labelControl2;
        private DevExpress.XtraEditors.LabelControl labelControl3;
        private DevExpress.XtraEditors.TextEdit txtOtherFee;
        private DevExpress.XtraEditors.LabelControl labelControl4;
        private DevExpress.XtraEditors.TextEdit txtSSYYCXCLF;
        private DevExpress.XtraEditors.LabelControl labelControl5;
        private DevExpress.XtraEditors.LabelControl labelControl6;
        private DevExpress.XtraEditors.TextEdit txtJCYYCXCLF;
        private DevExpress.XtraEditors.TextEdit txtXBYZLZPF;
        private DevExpress.XtraEditors.SimpleButton btnLoad;
        private DrectSoft.Common.Ctrs.OTHER.DevButtonOK btn_OK;
        private DrectSoft.Common.Ctrs.OTHER.DevButtonClose btn_Close;
    }
}
