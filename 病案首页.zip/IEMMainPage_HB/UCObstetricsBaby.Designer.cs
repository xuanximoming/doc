﻿namespace DrectSoft.Core.IEMMainPage
{
    partial class UCObstetricsBaby
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UCObstetricsBaby));
            this.labelControl17 = new DevExpress.XtraEditors.LabelControl();
            this.gridControlBabyInfo = new DevExpress.XtraGrid.GridControl();
            this.gridViewBabyInfo = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn3 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn4 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn5 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn6 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn7 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn8 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn9 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.errorProvider = new System.Windows.Forms.ErrorProvider();
            this.btn_OK = new DrectSoft.Common.Ctrs.OTHER.DevButtonOK();
            this.btn_Close = new DrectSoft.Common.Ctrs.OTHER.DevButtonClose();
            this.panelControl2 = new DevExpress.XtraEditors.PanelControl();
            this.btnEdit = new DevExpress.XtraEditors.SimpleButton();
            this.simpleButtonDeleteInfo = new DevExpress.XtraEditors.SimpleButton();
            this.simpleButtonAddInfo = new DevExpress.XtraEditors.SimpleButton();
            this.panelControl1 = new DevExpress.XtraEditors.PanelControl();
            this.labelControl21 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl20 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl19 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl18 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl16 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl14 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl13 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl12 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl10 = new DevExpress.XtraEditors.LabelControl();
            this.lpEdiMidwifery = new DrectSoft.Common.Library.LookUpEditor();
            this.chkCCQK1 = new DevExpress.XtraEditors.CheckEdit();
            this.labelControl23 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl33 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl30 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl27 = new DevExpress.XtraEditors.LabelControl();
            this.BithDayTime = new DevExpress.XtraEditors.TimeEdit();
            this.labelControl32 = new DevExpress.XtraEditors.LabelControl();
            this.BithDayDate = new DevExpress.XtraEditors.DateEdit();
            this.labelControl11 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl34 = new DevExpress.XtraEditors.LabelControl();
            this.chkCYQK3 = new DevExpress.XtraEditors.CheckEdit();
            this.labelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl29 = new DevExpress.XtraEditors.LabelControl();
            this.chkCCQK4 = new DevExpress.XtraEditors.CheckEdit();
            this.labelControl15 = new DevExpress.XtraEditors.LabelControl();
            this.chkCCQK3 = new DevExpress.XtraEditors.CheckEdit();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.chkFMFS6 = new DevExpress.XtraEditors.CheckEdit();
            this.txtheigh = new DevExpress.XtraEditors.TextEdit();
            this.chkFMFS3 = new DevExpress.XtraEditors.CheckEdit();
            this.txtAPJPF = new DevExpress.XtraEditors.TextEdit();
            this.txtweight = new DevExpress.XtraEditors.TextEdit();
            this.chkFMFS1 = new DevExpress.XtraEditors.CheckEdit();
            this.chkSex2 = new DevExpress.XtraEditors.CheckEdit();
            this.chkFMFS4 = new DevExpress.XtraEditors.CheckEdit();
            this.chkCYQK2 = new DevExpress.XtraEditors.CheckEdit();
            this.chkCYQK1 = new DevExpress.XtraEditors.CheckEdit();
            this.chkSex1 = new DevExpress.XtraEditors.CheckEdit();
            this.chkCCQK2 = new DevExpress.XtraEditors.CheckEdit();
            this.chkFMFS2 = new DevExpress.XtraEditors.CheckEdit();
            this.chkFMFS5 = new DevExpress.XtraEditors.CheckEdit();
            this.panelControl3 = new DevExpress.XtraEditors.PanelControl();
            this.labelControl5 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl4 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl3 = new DevExpress.XtraEditors.LabelControl();
            this.chkCC3 = new DevExpress.XtraEditors.CheckEdit();
            this.chkCFHYPLD3 = new DevExpress.XtraEditors.CheckEdit();
            this.chkTB3 = new DevExpress.XtraEditors.CheckEdit();
            this.chkTC3 = new DevExpress.XtraEditors.CheckEdit();
            this.chkCC2 = new DevExpress.XtraEditors.CheckEdit();
            this.chkCFHYPLD2 = new DevExpress.XtraEditors.CheckEdit();
            this.chkTB2 = new DevExpress.XtraEditors.CheckEdit();
            this.chkTC2 = new DevExpress.XtraEditors.CheckEdit();
            this.chkCC1 = new DevExpress.XtraEditors.CheckEdit();
            this.chkCFHYPLD1 = new DevExpress.XtraEditors.CheckEdit();
            this.chkTB1 = new DevExpress.XtraEditors.CheckEdit();
            this.chkTC1 = new DevExpress.XtraEditors.CheckEdit();
            this.labelControl9 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl35 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl8 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl7 = new DevExpress.XtraEditors.LabelControl();
            ((System.ComponentModel.ISupportInitialize)(this.gridControlBabyInfo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewBabyInfo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl2)).BeginInit();
            this.panelControl2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).BeginInit();
            this.panelControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lpEdiMidwifery)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCCQK1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BithDayTime.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BithDayDate.Properties.VistaTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BithDayDate.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCYQK3.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCCQK4.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCCQK3.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkFMFS6.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtheigh.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkFMFS3.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtAPJPF.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtweight.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkFMFS1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkSex2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkFMFS4.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCYQK2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCYQK1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkSex1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCCQK2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkFMFS2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkFMFS5.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl3)).BeginInit();
            this.panelControl3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chkCC3.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCFHYPLD3.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkTB3.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkTC3.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCC2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCFHYPLD2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkTB2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkTC2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCC1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCFHYPLD1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkTB1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkTC1.Properties)).BeginInit();
            this.SuspendLayout();
            // 
            // labelControl17
            // 
            this.labelControl17.Appearance.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold);
            this.labelControl17.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl17.Location = new System.Drawing.Point(151, 15);
            this.labelControl17.Name = "labelControl17";
            this.labelControl17.Size = new System.Drawing.Size(303, 33);
            this.labelControl17.TabIndex = 3;
            this.labelControl17.Text = "产 科 产 妇 婴 儿 情 况";
            // 
            // gridControlBabyInfo
            // 
            this.gridControlBabyInfo.Location = new System.Drawing.Point(25, 103);
            this.gridControlBabyInfo.MainView = this.gridViewBabyInfo;
            this.gridControlBabyInfo.Name = "gridControlBabyInfo";
            this.gridControlBabyInfo.Size = new System.Drawing.Size(604, 200);
            this.gridControlBabyInfo.TabIndex = 20;
            this.gridControlBabyInfo.TabStop = false;
            this.gridControlBabyInfo.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridViewBabyInfo});
            this.gridControlBabyInfo.Click += new System.EventHandler(this.gridControlBabyInfo_Click);
            // 
            // gridViewBabyInfo
            // 
            this.gridViewBabyInfo.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn1,
            this.gridColumn2,
            this.gridColumn3,
            this.gridColumn4,
            this.gridColumn5,
            this.gridColumn6,
            this.gridColumn7,
            this.gridColumn8,
            this.gridColumn9});
            this.gridViewBabyInfo.GridControl = this.gridControlBabyInfo;
            this.gridViewBabyInfo.Name = "gridViewBabyInfo";
            this.gridViewBabyInfo.OptionsCustomization.AllowColumnMoving = false;
            this.gridViewBabyInfo.OptionsCustomization.AllowColumnResizing = false;
            this.gridViewBabyInfo.OptionsCustomization.AllowFilter = false;
            this.gridViewBabyInfo.OptionsCustomization.AllowGroup = false;
            this.gridViewBabyInfo.OptionsCustomization.AllowQuickHideColumns = false;
            this.gridViewBabyInfo.OptionsCustomization.AllowSort = false;
            this.gridViewBabyInfo.OptionsFilter.AllowColumnMRUFilterList = false;
            this.gridViewBabyInfo.OptionsFilter.AllowFilterEditor = false;
            this.gridViewBabyInfo.OptionsFilter.AllowMRUFilterList = false;
            this.gridViewBabyInfo.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.gridViewBabyInfo.OptionsView.ShowGroupPanel = false;
            this.gridViewBabyInfo.OptionsView.ShowIndicator = false;
            // 
            // gridColumn1
            // 
            this.gridColumn1.Caption = "性别";
            this.gridColumn1.FieldName = "SEX";
            this.gridColumn1.Name = "gridColumn1";
            this.gridColumn1.OptionsColumn.AllowEdit = false;
            this.gridColumn1.Visible = true;
            this.gridColumn1.VisibleIndex = 0;
            // 
            // gridColumn2
            // 
            this.gridColumn2.Caption = "身长";
            this.gridColumn2.FieldName = "HEIGH";
            this.gridColumn2.Name = "gridColumn2";
            this.gridColumn2.OptionsColumn.AllowEdit = false;
            this.gridColumn2.Visible = true;
            this.gridColumn2.VisibleIndex = 1;
            // 
            // gridColumn3
            // 
            this.gridColumn3.Caption = "体重";
            this.gridColumn3.FieldName = "WEIGHT";
            this.gridColumn3.Name = "gridColumn3";
            this.gridColumn3.OptionsColumn.AllowEdit = false;
            this.gridColumn3.Visible = true;
            this.gridColumn3.VisibleIndex = 2;
            // 
            // gridColumn4
            // 
            this.gridColumn4.Caption = "出生时间";
            this.gridColumn4.FieldName = "BITHDAY";
            this.gridColumn4.Name = "gridColumn4";
            this.gridColumn4.OptionsColumn.AllowEdit = false;
            this.gridColumn4.Visible = true;
            this.gridColumn4.VisibleIndex = 3;
            // 
            // gridColumn5
            // 
            this.gridColumn5.Caption = "分娩方式";
            this.gridColumn5.FieldName = "FMFS";
            this.gridColumn5.Name = "gridColumn5";
            this.gridColumn5.OptionsColumn.AllowEdit = false;
            this.gridColumn5.Visible = true;
            this.gridColumn5.VisibleIndex = 4;
            // 
            // gridColumn6
            // 
            this.gridColumn6.Caption = "产出情况";
            this.gridColumn6.FieldName = "CCQK";
            this.gridColumn6.Name = "gridColumn6";
            this.gridColumn6.OptionsColumn.AllowEdit = false;
            this.gridColumn6.Visible = true;
            this.gridColumn6.VisibleIndex = 5;
            // 
            // gridColumn7
            // 
            this.gridColumn7.Caption = "阿帕加评分";
            this.gridColumn7.FieldName = "APJ";
            this.gridColumn7.Name = "gridColumn7";
            this.gridColumn7.OptionsColumn.AllowEdit = false;
            this.gridColumn7.Visible = true;
            this.gridColumn7.VisibleIndex = 6;
            // 
            // gridColumn8
            // 
            this.gridColumn8.Caption = "接产者";
            this.gridColumn8.FieldName = "MIDWIFERY";
            this.gridColumn8.Name = "gridColumn8";
            this.gridColumn8.OptionsColumn.AllowEdit = false;
            this.gridColumn8.Visible = true;
            this.gridColumn8.VisibleIndex = 7;
            // 
            // gridColumn9
            // 
            this.gridColumn9.Caption = "出院情况";
            this.gridColumn9.FieldName = "CYQK";
            this.gridColumn9.Name = "gridColumn9";
            this.gridColumn9.OptionsColumn.AllowEdit = false;
            this.gridColumn9.Visible = true;
            this.gridColumn9.VisibleIndex = 8;
            // 
            // errorProvider
            // 
            this.errorProvider.ContainerControl = this;
            // 
            // btn_OK
            // 
            this.btn_OK.Image = ((System.Drawing.Image)(resources.GetObject("btn_OK.Image")));
            this.btn_OK.Location = new System.Drawing.Point(463, 483);
            this.btn_OK.Name = "btn_OK";
            this.btn_OK.Size = new System.Drawing.Size(80, 27);
            this.btn_OK.TabIndex = 1;
            this.btn_OK.Text = "确定(&Y)";
            this.btn_OK.Click += new System.EventHandler(this.btn_OK_Click);
            // 
            // btn_Close
            // 
            this.btn_Close.Image = ((System.Drawing.Image)(resources.GetObject("btn_Close.Image")));
            this.btn_Close.Location = new System.Drawing.Point(549, 483);
            this.btn_Close.Name = "btn_Close";
            this.btn_Close.Size = new System.Drawing.Size(80, 27);
            this.btn_Close.TabIndex = 2;
            this.btn_Close.Text = "关闭(&T)";
            this.btn_Close.Click += new System.EventHandler(this.btn_Close_Click);
            // 
            // panelControl2
            // 
            this.panelControl2.Controls.Add(this.btnEdit);
            this.panelControl2.Controls.Add(this.simpleButtonDeleteInfo);
            this.panelControl2.Controls.Add(this.simpleButtonAddInfo);
            this.panelControl2.Location = new System.Drawing.Point(25, 439);
            this.panelControl2.Name = "panelControl2";
            this.panelControl2.Size = new System.Drawing.Size(604, 38);
            this.panelControl2.TabIndex = 39;
            // 
            // btnEdit
            // 
            this.btnEdit.Image = global::DrectSoft.Core.IEMMainPage_HB.Properties.Resources.编辑;
            this.btnEdit.Location = new System.Drawing.Point(393, 5);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(100, 23);
            this.btnEdit.TabIndex = 41;
            this.btnEdit.Text = "编辑婴儿(&E)";
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // simpleButtonDeleteInfo
            // 
            this.simpleButtonDeleteInfo.Image = global::DrectSoft.Core.IEMMainPage_HB.Properties.Resources.删除;
            this.simpleButtonDeleteInfo.Location = new System.Drawing.Point(501, 5);
            this.simpleButtonDeleteInfo.Name = "simpleButtonDeleteInfo";
            this.simpleButtonDeleteInfo.Size = new System.Drawing.Size(100, 23);
            this.simpleButtonDeleteInfo.TabIndex = 40;
            this.simpleButtonDeleteInfo.Text = "删除婴儿 (&D)";
            this.simpleButtonDeleteInfo.Click += new System.EventHandler(this.simpleButtonDeleteInfo_Click);
            // 
            // simpleButtonAddInfo
            // 
            this.simpleButtonAddInfo.Image = global::DrectSoft.Core.IEMMainPage_HB.Properties.Resources.新增;
            this.simpleButtonAddInfo.Location = new System.Drawing.Point(285, 5);
            this.simpleButtonAddInfo.Name = "simpleButtonAddInfo";
            this.simpleButtonAddInfo.Size = new System.Drawing.Size(100, 23);
            this.simpleButtonAddInfo.TabIndex = 39;
            this.simpleButtonAddInfo.Text = "添加婴儿 (&A)";
            this.simpleButtonAddInfo.Click += new System.EventHandler(this.simpleButtonAddInfo_Click);
            // 
            // panelControl1
            // 
            this.panelControl1.Controls.Add(this.labelControl21);
            this.panelControl1.Controls.Add(this.labelControl20);
            this.panelControl1.Controls.Add(this.labelControl19);
            this.panelControl1.Controls.Add(this.labelControl18);
            this.panelControl1.Controls.Add(this.labelControl16);
            this.panelControl1.Controls.Add(this.labelControl14);
            this.panelControl1.Controls.Add(this.labelControl13);
            this.panelControl1.Controls.Add(this.labelControl12);
            this.panelControl1.Controls.Add(this.labelControl10);
            this.panelControl1.Controls.Add(this.lpEdiMidwifery);
            this.panelControl1.Controls.Add(this.chkCCQK1);
            this.panelControl1.Controls.Add(this.labelControl23);
            this.panelControl1.Controls.Add(this.labelControl33);
            this.panelControl1.Controls.Add(this.labelControl30);
            this.panelControl1.Controls.Add(this.labelControl27);
            this.panelControl1.Controls.Add(this.BithDayTime);
            this.panelControl1.Controls.Add(this.labelControl32);
            this.panelControl1.Controls.Add(this.BithDayDate);
            this.panelControl1.Controls.Add(this.labelControl11);
            this.panelControl1.Controls.Add(this.labelControl34);
            this.panelControl1.Controls.Add(this.chkCYQK3);
            this.panelControl1.Controls.Add(this.labelControl2);
            this.panelControl1.Controls.Add(this.labelControl29);
            this.panelControl1.Controls.Add(this.chkCCQK4);
            this.panelControl1.Controls.Add(this.labelControl15);
            this.panelControl1.Controls.Add(this.chkCCQK3);
            this.panelControl1.Controls.Add(this.labelControl1);
            this.panelControl1.Controls.Add(this.chkFMFS6);
            this.panelControl1.Controls.Add(this.txtheigh);
            this.panelControl1.Controls.Add(this.chkFMFS3);
            this.panelControl1.Controls.Add(this.txtAPJPF);
            this.panelControl1.Controls.Add(this.txtweight);
            this.panelControl1.Controls.Add(this.chkFMFS1);
            this.panelControl1.Controls.Add(this.chkSex2);
            this.panelControl1.Controls.Add(this.chkFMFS4);
            this.panelControl1.Controls.Add(this.chkCYQK2);
            this.panelControl1.Controls.Add(this.chkCYQK1);
            this.panelControl1.Controls.Add(this.chkSex1);
            this.panelControl1.Controls.Add(this.chkCCQK2);
            this.panelControl1.Controls.Add(this.chkFMFS2);
            this.panelControl1.Controls.Add(this.chkFMFS5);
            this.panelControl1.Location = new System.Drawing.Point(25, 309);
            this.panelControl1.Name = "panelControl1";
            this.panelControl1.Size = new System.Drawing.Size(604, 128);
            this.panelControl1.TabIndex = 0;
            // 
            // labelControl21
            // 
            this.labelControl21.Appearance.ForeColor = System.Drawing.Color.Red;
            this.labelControl21.Location = new System.Drawing.Point(592, 89);
            this.labelControl21.Name = "labelControl21";
            this.labelControl21.Size = new System.Drawing.Size(7, 14);
            this.labelControl21.TabIndex = 49;
            this.labelControl21.Text = "*";
            // 
            // labelControl20
            // 
            this.labelControl20.Appearance.ForeColor = System.Drawing.Color.Red;
            this.labelControl20.Location = new System.Drawing.Point(493, 112);
            this.labelControl20.Name = "labelControl20";
            this.labelControl20.Size = new System.Drawing.Size(7, 14);
            this.labelControl20.TabIndex = 48;
            this.labelControl20.Text = "*";
            // 
            // labelControl19
            // 
            this.labelControl19.Appearance.ForeColor = System.Drawing.Color.Red;
            this.labelControl19.Location = new System.Drawing.Point(304, 89);
            this.labelControl19.Name = "labelControl19";
            this.labelControl19.Size = new System.Drawing.Size(7, 14);
            this.labelControl19.TabIndex = 47;
            this.labelControl19.Text = "*";
            // 
            // labelControl18
            // 
            this.labelControl18.Appearance.ForeColor = System.Drawing.Color.Red;
            this.labelControl18.Location = new System.Drawing.Point(592, 67);
            this.labelControl18.Name = "labelControl18";
            this.labelControl18.Size = new System.Drawing.Size(7, 14);
            this.labelControl18.TabIndex = 46;
            this.labelControl18.Text = "*";
            // 
            // labelControl16
            // 
            this.labelControl16.Appearance.ForeColor = System.Drawing.Color.Red;
            this.labelControl16.Location = new System.Drawing.Point(267, 65);
            this.labelControl16.Name = "labelControl16";
            this.labelControl16.Size = new System.Drawing.Size(7, 14);
            this.labelControl16.TabIndex = 45;
            this.labelControl16.Text = "*";
            // 
            // labelControl14
            // 
            this.labelControl14.Appearance.ForeColor = System.Drawing.Color.Red;
            this.labelControl14.Location = new System.Drawing.Point(525, 41);
            this.labelControl14.Name = "labelControl14";
            this.labelControl14.Size = new System.Drawing.Size(7, 14);
            this.labelControl14.TabIndex = 44;
            this.labelControl14.Text = "*";
            // 
            // labelControl13
            // 
            this.labelControl13.Appearance.ForeColor = System.Drawing.Color.Red;
            this.labelControl13.Location = new System.Drawing.Point(204, 41);
            this.labelControl13.Name = "labelControl13";
            this.labelControl13.Size = new System.Drawing.Size(7, 14);
            this.labelControl13.TabIndex = 43;
            this.labelControl13.Text = "*";
            // 
            // labelControl12
            // 
            this.labelControl12.Appearance.ForeColor = System.Drawing.Color.Red;
            this.labelControl12.Location = new System.Drawing.Point(592, 16);
            this.labelControl12.Name = "labelControl12";
            this.labelControl12.Size = new System.Drawing.Size(7, 14);
            this.labelControl12.TabIndex = 42;
            this.labelControl12.Text = "*";
            // 
            // labelControl10
            // 
            this.labelControl10.Appearance.ForeColor = System.Drawing.Color.Red;
            this.labelControl10.Location = new System.Drawing.Point(193, 16);
            this.labelControl10.Name = "labelControl10";
            this.labelControl10.Size = new System.Drawing.Size(7, 14);
            this.labelControl10.TabIndex = 41;
            this.labelControl10.Text = "*";
            // 
            // lpEdiMidwifery
            // 
            this.lpEdiMidwifery.ListWindow = null;
            this.lpEdiMidwifery.Location = new System.Drawing.Point(402, 61);
            this.lpEdiMidwifery.Name = "lpEdiMidwifery";
            this.lpEdiMidwifery.ShowSButton = true;
            this.lpEdiMidwifery.Size = new System.Drawing.Size(185, 20);
            this.lpEdiMidwifery.TabIndex = 34;
            // 
            // chkCCQK1
            // 
            this.chkCCQK1.Location = new System.Drawing.Point(74, 84);
            this.chkCCQK1.Name = "chkCCQK1";
            this.chkCCQK1.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkCCQK1.Properties.Appearance.Options.UseForeColor = true;
            this.chkCCQK1.Properties.Caption = "1.活产";
            this.chkCCQK1.Properties.RadioGroupIndex = 6;
            this.chkCCQK1.Size = new System.Drawing.Size(56, 19);
            this.chkCCQK1.TabIndex = 13;
            this.chkCCQK1.TabStop = false;
            this.chkCCQK1.Click += new System.EventHandler(this.chk_CheckedChanged);
            this.chkCCQK1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.chb_KeyPress);
            // 
            // labelControl23
            // 
            this.labelControl23.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl23.Location = new System.Drawing.Point(13, 38);
            this.labelControl23.Name = "labelControl23";
            this.labelControl23.Size = new System.Drawing.Size(52, 14);
            this.labelControl23.TabIndex = 1;
            this.labelControl23.Text = "身    长：";
            // 
            // labelControl33
            // 
            this.labelControl33.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl33.Location = new System.Drawing.Point(13, 62);
            this.labelControl33.Name = "labelControl33";
            this.labelControl33.Size = new System.Drawing.Size(60, 14);
            this.labelControl33.TabIndex = 7;
            this.labelControl33.Text = "出生时间：";
            // 
            // labelControl30
            // 
            this.labelControl30.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl30.Location = new System.Drawing.Point(343, 38);
            this.labelControl30.Name = "labelControl30";
            this.labelControl30.Size = new System.Drawing.Size(52, 14);
            this.labelControl30.TabIndex = 4;
            this.labelControl30.Text = "体    重：";
            // 
            // labelControl27
            // 
            this.labelControl27.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl27.Location = new System.Drawing.Point(182, 38);
            this.labelControl27.Name = "labelControl27";
            this.labelControl27.Size = new System.Drawing.Size(16, 14);
            this.labelControl27.TabIndex = 3;
            this.labelControl27.Text = "CM";
            // 
            // BithDayTime
            // 
            this.BithDayTime.EditValue = new System.DateTime(2011, 3, 5, 0, 0, 0, 0);
            this.BithDayTime.EnterMoveNextControl = true;
            this.BithDayTime.Location = new System.Drawing.Point(182, 60);
            this.BithDayTime.Name = "BithDayTime";
            this.BithDayTime.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.BithDayTime.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.BithDayTime.Properties.Mask.EditMask = "HH:mm";
            this.BithDayTime.Size = new System.Drawing.Size(79, 19);
            this.BithDayTime.TabIndex = 9;
            // 
            // labelControl32
            // 
            this.labelControl32.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl32.Location = new System.Drawing.Point(511, 38);
            this.labelControl32.Name = "labelControl32";
            this.labelControl32.Size = new System.Drawing.Size(8, 14);
            this.labelControl32.TabIndex = 6;
            this.labelControl32.Text = "G";
            // 
            // BithDayDate
            // 
            this.BithDayDate.EditValue = null;
            this.BithDayDate.EnterMoveNextControl = true;
            this.BithDayDate.Location = new System.Drawing.Point(76, 60);
            this.BithDayDate.Name = "BithDayDate";
            this.BithDayDate.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.BithDayDate.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.BithDayDate.Properties.VistaTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.BithDayDate.Size = new System.Drawing.Size(100, 21);
            this.BithDayDate.TabIndex = 8;
            this.BithDayDate.Validating += new System.ComponentModel.CancelEventHandler(this.BithDayDate_Validating);
            // 
            // labelControl11
            // 
            this.labelControl11.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl11.Location = new System.Drawing.Point(13, 14);
            this.labelControl11.Name = "labelControl11";
            this.labelControl11.Size = new System.Drawing.Size(52, 14);
            this.labelControl11.TabIndex = 30;
            this.labelControl11.Text = "性    别：";
            // 
            // labelControl34
            // 
            this.labelControl34.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl34.Location = new System.Drawing.Point(13, 87);
            this.labelControl34.Name = "labelControl34";
            this.labelControl34.Size = new System.Drawing.Size(60, 14);
            this.labelControl34.TabIndex = 12;
            this.labelControl34.Text = "产出情况：";
            // 
            // chkCYQK3
            // 
            this.chkCYQK3.Location = new System.Drawing.Point(505, 84);
            this.chkCYQK3.Name = "chkCYQK3";
            this.chkCYQK3.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkCYQK3.Properties.Appearance.Options.UseForeColor = true;
            this.chkCYQK3.Properties.Caption = "3.交叉感染";
            this.chkCYQK3.Properties.RadioGroupIndex = 7;
            this.chkCYQK3.Size = new System.Drawing.Size(82, 19);
            this.chkCYQK3.TabIndex = 20;
            this.chkCYQK3.TabStop = false;
            this.chkCYQK3.Click += new System.EventHandler(this.chk_CheckedChanged);
            this.chkCYQK3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.chb_KeyPress);
            // 
            // labelControl2
            // 
            this.labelControl2.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl2.Location = new System.Drawing.Point(13, 110);
            this.labelControl2.Name = "labelControl2";
            this.labelControl2.Size = new System.Drawing.Size(60, 14);
            this.labelControl2.TabIndex = 21;
            this.labelControl2.Text = "分娩方式：";
            // 
            // labelControl29
            // 
            this.labelControl29.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl29.Location = new System.Drawing.Point(321, 86);
            this.labelControl29.Name = "labelControl29";
            this.labelControl29.Size = new System.Drawing.Size(60, 14);
            this.labelControl29.TabIndex = 17;
            this.labelControl29.Text = "出院情况：";
            // 
            // chkCCQK4
            // 
            this.chkCCQK4.Location = new System.Drawing.Point(242, 84);
            this.chkCCQK4.Name = "chkCCQK4";
            this.chkCCQK4.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkCCQK4.Properties.Appearance.Options.UseForeColor = true;
            this.chkCCQK4.Properties.Caption = "4.畸形";
            this.chkCCQK4.Properties.RadioGroupIndex = 6;
            this.chkCCQK4.Size = new System.Drawing.Size(56, 19);
            this.chkCCQK4.TabIndex = 16;
            this.chkCCQK4.TabStop = false;
            this.chkCCQK4.Click += new System.EventHandler(this.chk_CheckedChanged);
            this.chkCCQK4.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.chb_KeyPress);
            // 
            // labelControl15
            // 
            this.labelControl15.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl15.Location = new System.Drawing.Point(323, 13);
            this.labelControl15.Name = "labelControl15";
            this.labelControl15.Size = new System.Drawing.Size(72, 14);
            this.labelControl15.TabIndex = 33;
            this.labelControl15.Text = "阿帕加评分：";
            // 
            // chkCCQK3
            // 
            this.chkCCQK3.Location = new System.Drawing.Point(186, 84);
            this.chkCCQK3.Name = "chkCCQK3";
            this.chkCCQK3.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkCCQK3.Properties.Appearance.Options.UseForeColor = true;
            this.chkCCQK3.Properties.Caption = "3.死胎";
            this.chkCCQK3.Properties.RadioGroupIndex = 6;
            this.chkCCQK3.Size = new System.Drawing.Size(56, 19);
            this.chkCCQK3.TabIndex = 15;
            this.chkCCQK3.TabStop = false;
            this.chkCCQK3.Click += new System.EventHandler(this.chk_CheckedChanged);
            this.chkCCQK3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.chb_KeyPress);
            // 
            // labelControl1
            // 
            this.labelControl1.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl1.Location = new System.Drawing.Point(347, 62);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(48, 14);
            this.labelControl1.TabIndex = 10;
            this.labelControl1.Text = "接产者：";
            // 
            // chkFMFS6
            // 
            this.chkFMFS6.Location = new System.Drawing.Point(430, 107);
            this.chkFMFS6.Name = "chkFMFS6";
            this.chkFMFS6.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkFMFS6.Properties.Appearance.Options.UseForeColor = true;
            this.chkFMFS6.Properties.Caption = "6.其他";
            this.chkFMFS6.Properties.RadioGroupIndex = 8;
            this.chkFMFS6.Size = new System.Drawing.Size(57, 19);
            this.chkFMFS6.TabIndex = 27;
            this.chkFMFS6.TabStop = false;
            this.chkFMFS6.Click += new System.EventHandler(this.chk_CheckedChanged);
            this.chkFMFS6.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.chb_KeyPress);
            // 
            // txtheigh
            // 
            this.txtheigh.EditValue = "";
            this.txtheigh.EnterMoveNextControl = true;
            this.txtheigh.Location = new System.Drawing.Point(76, 36);
            this.txtheigh.Name = "txtheigh";
            this.txtheigh.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtheigh.Properties.MaxLength = 10;
            this.txtheigh.Size = new System.Drawing.Size(100, 19);
            this.txtheigh.TabIndex = 2;
            this.txtheigh.Enter += new System.EventHandler(this.txt_Enter);
            // 
            // chkFMFS3
            // 
            this.chkFMFS3.Location = new System.Drawing.Point(219, 107);
            this.chkFMFS3.Name = "chkFMFS3";
            this.chkFMFS3.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkFMFS3.Properties.Appearance.Options.UseForeColor = true;
            this.chkFMFS3.Properties.Caption = "3.产钳";
            this.chkFMFS3.Properties.RadioGroupIndex = 8;
            this.chkFMFS3.Size = new System.Drawing.Size(57, 19);
            this.chkFMFS3.TabIndex = 24;
            this.chkFMFS3.TabStop = false;
            this.chkFMFS3.Click += new System.EventHandler(this.chk_CheckedChanged);
            this.chkFMFS3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.chb_KeyPress);
            // 
            // txtAPJPF
            // 
            this.txtAPJPF.EditValue = "";
            this.txtAPJPF.EnterMoveNextControl = true;
            this.txtAPJPF.Location = new System.Drawing.Point(402, 11);
            this.txtAPJPF.Name = "txtAPJPF";
            this.txtAPJPF.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtAPJPF.Properties.MaxLength = 10;
            this.txtAPJPF.Size = new System.Drawing.Size(185, 19);
            this.txtAPJPF.TabIndex = 0;
            this.txtAPJPF.Enter += new System.EventHandler(this.txt_Enter);
            // 
            // txtweight
            // 
            this.txtweight.EditValue = "";
            this.txtweight.EnterMoveNextControl = true;
            this.txtweight.Location = new System.Drawing.Point(402, 36);
            this.txtweight.Name = "txtweight";
            this.txtweight.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtweight.Properties.MaxLength = 10;
            this.txtweight.Size = new System.Drawing.Size(100, 19);
            this.txtweight.TabIndex = 5;
            this.txtweight.Enter += new System.EventHandler(this.txt_Enter);
            // 
            // chkFMFS1
            // 
            this.chkFMFS1.Location = new System.Drawing.Point(74, 107);
            this.chkFMFS1.Name = "chkFMFS1";
            this.chkFMFS1.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkFMFS1.Properties.Appearance.Options.UseForeColor = true;
            this.chkFMFS1.Properties.Caption = "1.自然";
            this.chkFMFS1.Properties.RadioGroupIndex = 8;
            this.chkFMFS1.Size = new System.Drawing.Size(67, 19);
            this.chkFMFS1.TabIndex = 22;
            this.chkFMFS1.TabStop = false;
            this.chkFMFS1.Click += new System.EventHandler(this.chk_CheckedChanged);
            this.chkFMFS1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.chb_KeyPress);
            // 
            // chkSex2
            // 
            this.chkSex2.Location = new System.Drawing.Point(141, 11);
            this.chkSex2.Name = "chkSex2";
            this.chkSex2.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkSex2.Properties.Appearance.Options.UseForeColor = true;
            this.chkSex2.Properties.Caption = "2.女";
            this.chkSex2.Properties.RadioGroupIndex = 5;
            this.chkSex2.Size = new System.Drawing.Size(49, 19);
            this.chkSex2.TabIndex = 32;
            this.chkSex2.TabStop = false;
            this.chkSex2.Click += new System.EventHandler(this.chk_CheckedChanged);
            this.chkSex2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.chb_KeyPress);
            // 
            // chkFMFS4
            // 
            this.chkFMFS4.Location = new System.Drawing.Point(282, 107);
            this.chkFMFS4.Name = "chkFMFS4";
            this.chkFMFS4.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkFMFS4.Properties.Appearance.Options.UseForeColor = true;
            this.chkFMFS4.Properties.Caption = "4.臂牵引";
            this.chkFMFS4.Properties.RadioGroupIndex = 8;
            this.chkFMFS4.Size = new System.Drawing.Size(67, 19);
            this.chkFMFS4.TabIndex = 25;
            this.chkFMFS4.TabStop = false;
            this.chkFMFS4.Click += new System.EventHandler(this.chk_CheckedChanged);
            this.chkFMFS4.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.chb_KeyPress);
            // 
            // chkCYQK2
            // 
            this.chkCYQK2.Location = new System.Drawing.Point(444, 84);
            this.chkCYQK2.Name = "chkCYQK2";
            this.chkCYQK2.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkCYQK2.Properties.Appearance.Options.UseForeColor = true;
            this.chkCYQK2.Properties.Caption = "2.有病";
            this.chkCYQK2.Properties.RadioGroupIndex = 7;
            this.chkCYQK2.Size = new System.Drawing.Size(61, 19);
            this.chkCYQK2.TabIndex = 19;
            this.chkCYQK2.TabStop = false;
            this.chkCYQK2.Click += new System.EventHandler(this.chk_CheckedChanged);
            this.chkCYQK2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.chb_KeyPress);
            // 
            // chkCYQK1
            // 
            this.chkCYQK1.Location = new System.Drawing.Point(383, 84);
            this.chkCYQK1.Name = "chkCYQK1";
            this.chkCYQK1.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkCYQK1.Properties.Appearance.Options.UseForeColor = true;
            this.chkCYQK1.Properties.Caption = "1.正常";
            this.chkCYQK1.Properties.RadioGroupIndex = 7;
            this.chkCYQK1.Size = new System.Drawing.Size(61, 19);
            this.chkCYQK1.TabIndex = 18;
            this.chkCYQK1.TabStop = false;
            this.chkCYQK1.Click += new System.EventHandler(this.chk_CheckedChanged);
            this.chkCYQK1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.chb_KeyPress);
            // 
            // chkSex1
            // 
            this.chkSex1.Location = new System.Drawing.Point(74, 11);
            this.chkSex1.Name = "chkSex1";
            this.chkSex1.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkSex1.Properties.Appearance.Options.UseForeColor = true;
            this.chkSex1.Properties.Caption = "1.男";
            this.chkSex1.Properties.RadioGroupIndex = 5;
            this.chkSex1.Size = new System.Drawing.Size(67, 19);
            this.chkSex1.TabIndex = 31;
            this.chkSex1.TabStop = false;
            this.chkSex1.Click += new System.EventHandler(this.chk_CheckedChanged);
            this.chkSex1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.chb_KeyPress);
            // 
            // chkCCQK2
            // 
            this.chkCCQK2.Location = new System.Drawing.Point(130, 84);
            this.chkCCQK2.Name = "chkCCQK2";
            this.chkCCQK2.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkCCQK2.Properties.Appearance.Options.UseForeColor = true;
            this.chkCCQK2.Properties.Caption = "2.死产";
            this.chkCCQK2.Properties.RadioGroupIndex = 6;
            this.chkCCQK2.Size = new System.Drawing.Size(56, 19);
            this.chkCCQK2.TabIndex = 14;
            this.chkCCQK2.TabStop = false;
            this.chkCCQK2.Click += new System.EventHandler(this.chk_CheckedChanged);
            this.chkCCQK2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.chb_KeyPress);
            // 
            // chkFMFS2
            // 
            this.chkFMFS2.Location = new System.Drawing.Point(141, 107);
            this.chkFMFS2.Name = "chkFMFS2";
            this.chkFMFS2.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkFMFS2.Properties.Appearance.Options.UseForeColor = true;
            this.chkFMFS2.Properties.Caption = "2.侧+吸";
            this.chkFMFS2.Properties.RadioGroupIndex = 8;
            this.chkFMFS2.Size = new System.Drawing.Size(72, 19);
            this.chkFMFS2.TabIndex = 23;
            this.chkFMFS2.TabStop = false;
            this.chkFMFS2.Click += new System.EventHandler(this.chk_CheckedChanged);
            this.chkFMFS2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.chb_KeyPress);
            // 
            // chkFMFS5
            // 
            this.chkFMFS5.Location = new System.Drawing.Point(361, 107);
            this.chkFMFS5.Name = "chkFMFS5";
            this.chkFMFS5.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkFMFS5.Properties.Appearance.Options.UseForeColor = true;
            this.chkFMFS5.Properties.Caption = "5.剖宫";
            this.chkFMFS5.Properties.RadioGroupIndex = 8;
            this.chkFMFS5.Size = new System.Drawing.Size(63, 19);
            this.chkFMFS5.TabIndex = 26;
            this.chkFMFS5.TabStop = false;
            this.chkFMFS5.Click += new System.EventHandler(this.chk_CheckedChanged);
            this.chkFMFS5.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.chb_KeyPress);
            // 
            // panelControl3
            // 
            this.panelControl3.Controls.Add(this.labelControl5);
            this.panelControl3.Controls.Add(this.labelControl4);
            this.panelControl3.Controls.Add(this.labelControl3);
            this.panelControl3.Controls.Add(this.chkCC3);
            this.panelControl3.Controls.Add(this.chkCFHYPLD3);
            this.panelControl3.Controls.Add(this.chkTB3);
            this.panelControl3.Controls.Add(this.chkTC3);
            this.panelControl3.Controls.Add(this.chkCC2);
            this.panelControl3.Controls.Add(this.chkCFHYPLD2);
            this.panelControl3.Controls.Add(this.chkTB2);
            this.panelControl3.Controls.Add(this.chkTC2);
            this.panelControl3.Controls.Add(this.chkCC1);
            this.panelControl3.Controls.Add(this.chkCFHYPLD1);
            this.panelControl3.Controls.Add(this.chkTB1);
            this.panelControl3.Controls.Add(this.chkTC1);
            this.panelControl3.Controls.Add(this.labelControl9);
            this.panelControl3.Controls.Add(this.labelControl35);
            this.panelControl3.Controls.Add(this.labelControl8);
            this.panelControl3.Controls.Add(this.labelControl7);
            this.panelControl3.Location = new System.Drawing.Point(25, 47);
            this.panelControl3.Name = "panelControl3";
            this.panelControl3.Size = new System.Drawing.Size(604, 50);
            this.panelControl3.TabIndex = 40;
            // 
            // labelControl5
            // 
            this.labelControl5.Appearance.ForeColor = System.Drawing.Color.Red;
            this.labelControl5.Location = new System.Drawing.Point(589, 11);
            this.labelControl5.Name = "labelControl5";
            this.labelControl5.Size = new System.Drawing.Size(7, 14);
            this.labelControl5.TabIndex = 44;
            this.labelControl5.Text = "*";
            // 
            // labelControl4
            // 
            this.labelControl4.Appearance.ForeColor = System.Drawing.Color.Red;
            this.labelControl4.Location = new System.Drawing.Point(266, 32);
            this.labelControl4.Name = "labelControl4";
            this.labelControl4.Size = new System.Drawing.Size(7, 14);
            this.labelControl4.TabIndex = 43;
            this.labelControl4.Text = "*";
            // 
            // labelControl3
            // 
            this.labelControl3.Appearance.ForeColor = System.Drawing.Color.Red;
            this.labelControl3.Location = new System.Drawing.Point(266, 11);
            this.labelControl3.Name = "labelControl3";
            this.labelControl3.Size = new System.Drawing.Size(7, 14);
            this.labelControl3.TabIndex = 42;
            this.labelControl3.Text = "*";
            // 
            // chkCC3
            // 
            this.chkCC3.Location = new System.Drawing.Point(539, 6);
            this.chkCC3.Name = "chkCC3";
            this.chkCC3.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkCC3.Properties.Appearance.Options.UseForeColor = true;
            this.chkCC3.Properties.Caption = "3.多";
            this.chkCC3.Properties.RadioGroupIndex = 2;
            this.chkCC3.Size = new System.Drawing.Size(44, 19);
            this.chkCC3.TabIndex = 27;
            this.chkCC3.TabStop = false;
            // 
            // chkCFHYPLD3
            // 
            this.chkCFHYPLD3.Location = new System.Drawing.Point(539, 27);
            this.chkCFHYPLD3.Name = "chkCFHYPLD3";
            this.chkCFHYPLD3.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkCFHYPLD3.Properties.Appearance.Options.UseForeColor = true;
            this.chkCFHYPLD3.Properties.Caption = "3.III";
            this.chkCFHYPLD3.Properties.RadioGroupIndex = 4;
            this.chkCFHYPLD3.Size = new System.Drawing.Size(44, 19);
            this.chkCFHYPLD3.TabIndex = 35;
            this.chkCFHYPLD3.TabStop = false;
            // 
            // chkTB3
            // 
            this.chkTB3.Location = new System.Drawing.Point(213, 27);
            this.chkTB3.Name = "chkTB3";
            this.chkTB3.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkTB3.Properties.Appearance.Options.UseForeColor = true;
            this.chkTB3.Properties.Caption = "3.多";
            this.chkTB3.Properties.RadioGroupIndex = 3;
            this.chkTB3.Size = new System.Drawing.Size(47, 19);
            this.chkTB3.TabIndex = 31;
            this.chkTB3.TabStop = false;
            // 
            // chkTC3
            // 
            this.chkTC3.Location = new System.Drawing.Point(213, 6);
            this.chkTC3.Name = "chkTC3";
            this.chkTC3.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkTC3.Properties.Appearance.Options.UseForeColor = true;
            this.chkTC3.Properties.Caption = "3.多";
            this.chkTC3.Properties.RadioGroupIndex = 1;
            this.chkTC3.Size = new System.Drawing.Size(47, 19);
            this.chkTC3.TabIndex = 23;
            this.chkTC3.TabStop = false;
            // 
            // chkCC2
            // 
            this.chkCC2.Location = new System.Drawing.Point(476, 6);
            this.chkCC2.Name = "chkCC2";
            this.chkCC2.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkCC2.Properties.Appearance.Options.UseForeColor = true;
            this.chkCC2.Properties.Caption = "2.双";
            this.chkCC2.Properties.RadioGroupIndex = 2;
            this.chkCC2.Size = new System.Drawing.Size(63, 19);
            this.chkCC2.TabIndex = 26;
            this.chkCC2.TabStop = false;
            // 
            // chkCFHYPLD2
            // 
            this.chkCFHYPLD2.Location = new System.Drawing.Point(476, 27);
            this.chkCFHYPLD2.Name = "chkCFHYPLD2";
            this.chkCFHYPLD2.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkCFHYPLD2.Properties.Appearance.Options.UseForeColor = true;
            this.chkCFHYPLD2.Properties.Caption = "2.II";
            this.chkCFHYPLD2.Properties.RadioGroupIndex = 4;
            this.chkCFHYPLD2.Size = new System.Drawing.Size(63, 19);
            this.chkCFHYPLD2.TabIndex = 34;
            this.chkCFHYPLD2.TabStop = false;
            // 
            // chkTB2
            // 
            this.chkTB2.Location = new System.Drawing.Point(150, 27);
            this.chkTB2.Name = "chkTB2";
            this.chkTB2.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkTB2.Properties.Appearance.Options.UseForeColor = true;
            this.chkTB2.Properties.Caption = "2.双";
            this.chkTB2.Properties.RadioGroupIndex = 3;
            this.chkTB2.Size = new System.Drawing.Size(63, 19);
            this.chkTB2.TabIndex = 30;
            this.chkTB2.TabStop = false;
            // 
            // chkTC2
            // 
            this.chkTC2.Location = new System.Drawing.Point(150, 6);
            this.chkTC2.Name = "chkTC2";
            this.chkTC2.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkTC2.Properties.Appearance.Options.UseForeColor = true;
            this.chkTC2.Properties.Caption = "2.双";
            this.chkTC2.Properties.RadioGroupIndex = 1;
            this.chkTC2.Size = new System.Drawing.Size(63, 19);
            this.chkTC2.TabIndex = 22;
            this.chkTC2.TabStop = false;
            // 
            // chkCC1
            // 
            this.chkCC1.Location = new System.Drawing.Point(409, 6);
            this.chkCC1.Name = "chkCC1";
            this.chkCC1.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkCC1.Properties.Appearance.Options.UseForeColor = true;
            this.chkCC1.Properties.Caption = "1.单";
            this.chkCC1.Properties.RadioGroupIndex = 2;
            this.chkCC1.Size = new System.Drawing.Size(67, 19);
            this.chkCC1.TabIndex = 25;
            this.chkCC1.TabStop = false;
            // 
            // chkCFHYPLD1
            // 
            this.chkCFHYPLD1.Location = new System.Drawing.Point(409, 27);
            this.chkCFHYPLD1.Name = "chkCFHYPLD1";
            this.chkCFHYPLD1.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkCFHYPLD1.Properties.Appearance.Options.UseForeColor = true;
            this.chkCFHYPLD1.Properties.Caption = "1.I";
            this.chkCFHYPLD1.Properties.RadioGroupIndex = 4;
            this.chkCFHYPLD1.Size = new System.Drawing.Size(67, 19);
            this.chkCFHYPLD1.TabIndex = 33;
            this.chkCFHYPLD1.TabStop = false;
            // 
            // chkTB1
            // 
            this.chkTB1.Location = new System.Drawing.Point(83, 27);
            this.chkTB1.Name = "chkTB1";
            this.chkTB1.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkTB1.Properties.Appearance.Options.UseForeColor = true;
            this.chkTB1.Properties.Caption = "1.单";
            this.chkTB1.Properties.RadioGroupIndex = 3;
            this.chkTB1.Size = new System.Drawing.Size(67, 19);
            this.chkTB1.TabIndex = 29;
            this.chkTB1.TabStop = false;
            // 
            // chkTC1
            // 
            this.chkTC1.Location = new System.Drawing.Point(83, 6);
            this.chkTC1.Name = "chkTC1";
            this.chkTC1.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkTC1.Properties.Appearance.Options.UseForeColor = true;
            this.chkTC1.Properties.Caption = "1.单";
            this.chkTC1.Properties.RadioGroupIndex = 1;
            this.chkTC1.Size = new System.Drawing.Size(67, 19);
            this.chkTC1.TabIndex = 21;
            this.chkTC1.TabStop = false;
            // 
            // labelControl9
            // 
            this.labelControl9.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl9.Location = new System.Drawing.Point(338, 28);
            this.labelControl9.Name = "labelControl9";
            this.labelControl9.Size = new System.Drawing.Size(72, 14);
            this.labelControl9.TabIndex = 32;
            this.labelControl9.Text = "会阴破裂度：";
            // 
            // labelControl35
            // 
            this.labelControl35.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl35.Location = new System.Drawing.Point(22, 30);
            this.labelControl35.Name = "labelControl35";
            this.labelControl35.Size = new System.Drawing.Size(52, 14);
            this.labelControl35.TabIndex = 28;
            this.labelControl35.Text = "胎    别：";
            // 
            // labelControl8
            // 
            this.labelControl8.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl8.Location = new System.Drawing.Point(348, 8);
            this.labelControl8.Name = "labelControl8";
            this.labelControl8.Size = new System.Drawing.Size(52, 14);
            this.labelControl8.TabIndex = 24;
            this.labelControl8.Text = "产    次：";
            // 
            // labelControl7
            // 
            this.labelControl7.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl7.Location = new System.Drawing.Point(22, 7);
            this.labelControl7.Name = "labelControl7";
            this.labelControl7.Size = new System.Drawing.Size(52, 14);
            this.labelControl7.TabIndex = 20;
            this.labelControl7.Text = "胎    次：";
            // 
            // UCObstetricsBaby
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.panelControl3);
            this.Controls.Add(this.panelControl2);
            this.Controls.Add(this.btn_Close);
            this.Controls.Add(this.btn_OK);
            this.Controls.Add(this.panelControl1);
            this.Controls.Add(this.gridControlBabyInfo);
            this.Controls.Add(this.labelControl17);
            this.ForeColor = System.Drawing.Color.Black;
            this.Name = "UCObstetricsBaby";
            this.Size = new System.Drawing.Size(651, 529);
            this.Load += new System.EventHandler(this.UCObstetricsBaby_Load);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.UCObstetricsBaby_Paint);
            ((System.ComponentModel.ISupportInitialize)(this.gridControlBabyInfo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewBabyInfo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl2)).EndInit();
            this.panelControl2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).EndInit();
            this.panelControl1.ResumeLayout(false);
            this.panelControl1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lpEdiMidwifery)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCCQK1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BithDayTime.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BithDayDate.Properties.VistaTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BithDayDate.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCYQK3.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCCQK4.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCCQK3.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkFMFS6.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtheigh.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkFMFS3.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtAPJPF.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtweight.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkFMFS1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkSex2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkFMFS4.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCYQK2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCYQK1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkSex1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCCQK2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkFMFS2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkFMFS5.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl3)).EndInit();
            this.panelControl3.ResumeLayout(false);
            this.panelControl3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chkCC3.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCFHYPLD3.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkTB3.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkTC3.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCC2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCFHYPLD2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkTB2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkTC2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCC1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCFHYPLD1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkTB1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkTC1.Properties)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevExpress.XtraEditors.LabelControl labelControl17;
        private DevExpress.XtraGrid.GridControl gridControlBabyInfo;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewBabyInfo;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn2;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn3;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn4;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn5;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn6;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn7;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn8;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn9;
        private System.Windows.Forms.ErrorProvider errorProvider;
        private DrectSoft.Common.Ctrs.OTHER.DevButtonClose btn_Close;
        private DrectSoft.Common.Ctrs.OTHER.DevButtonOK btn_OK;
        private DevExpress.XtraEditors.PanelControl panelControl2;
        private DevExpress.XtraEditors.SimpleButton btnEdit;
        private DevExpress.XtraEditors.SimpleButton simpleButtonDeleteInfo;
        private DevExpress.XtraEditors.SimpleButton simpleButtonAddInfo;
        private DevExpress.XtraEditors.PanelControl panelControl1;
        private Common.Library.LookUpEditor lpEdiMidwifery;
        private DevExpress.XtraEditors.CheckEdit chkCCQK1;
        private DevExpress.XtraEditors.LabelControl labelControl23;
        private DevExpress.XtraEditors.LabelControl labelControl33;
        private DevExpress.XtraEditors.LabelControl labelControl30;
        private DevExpress.XtraEditors.LabelControl labelControl27;
        private DevExpress.XtraEditors.TimeEdit BithDayTime;
        private DevExpress.XtraEditors.LabelControl labelControl32;
        private DevExpress.XtraEditors.DateEdit BithDayDate;
        private DevExpress.XtraEditors.LabelControl labelControl11;
        private DevExpress.XtraEditors.LabelControl labelControl34;
        private DevExpress.XtraEditors.CheckEdit chkCYQK3;
        private DevExpress.XtraEditors.LabelControl labelControl2;
        private DevExpress.XtraEditors.LabelControl labelControl29;
        private DevExpress.XtraEditors.CheckEdit chkCCQK4;
        private DevExpress.XtraEditors.LabelControl labelControl15;
        private DevExpress.XtraEditors.CheckEdit chkCCQK3;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private DevExpress.XtraEditors.CheckEdit chkFMFS6;
        private DevExpress.XtraEditors.TextEdit txtheigh;
        private DevExpress.XtraEditors.CheckEdit chkFMFS3;
        private DevExpress.XtraEditors.TextEdit txtAPJPF;
        private DevExpress.XtraEditors.TextEdit txtweight;
        private DevExpress.XtraEditors.CheckEdit chkFMFS1;
        private DevExpress.XtraEditors.CheckEdit chkSex2;
        private DevExpress.XtraEditors.CheckEdit chkFMFS4;
        private DevExpress.XtraEditors.CheckEdit chkCYQK2;
        private DevExpress.XtraEditors.CheckEdit chkCYQK1;
        private DevExpress.XtraEditors.CheckEdit chkSex1;
        private DevExpress.XtraEditors.CheckEdit chkCCQK2;
        private DevExpress.XtraEditors.CheckEdit chkFMFS2;
        private DevExpress.XtraEditors.CheckEdit chkFMFS5;
        private DevExpress.XtraEditors.LabelControl labelControl21;
        private DevExpress.XtraEditors.LabelControl labelControl20;
        private DevExpress.XtraEditors.LabelControl labelControl19;
        private DevExpress.XtraEditors.LabelControl labelControl18;
        private DevExpress.XtraEditors.LabelControl labelControl16;
        private DevExpress.XtraEditors.LabelControl labelControl14;
        private DevExpress.XtraEditors.LabelControl labelControl13;
        private DevExpress.XtraEditors.LabelControl labelControl12;
        private DevExpress.XtraEditors.LabelControl labelControl10;
        private DevExpress.XtraEditors.PanelControl panelControl3;
        private DevExpress.XtraEditors.LabelControl labelControl5;
        private DevExpress.XtraEditors.LabelControl labelControl4;
        private DevExpress.XtraEditors.LabelControl labelControl3;
        private DevExpress.XtraEditors.CheckEdit chkCC3;
        private DevExpress.XtraEditors.CheckEdit chkCFHYPLD3;
        private DevExpress.XtraEditors.CheckEdit chkTB3;
        private DevExpress.XtraEditors.CheckEdit chkTC3;
        private DevExpress.XtraEditors.CheckEdit chkCC2;
        private DevExpress.XtraEditors.CheckEdit chkCFHYPLD2;
        private DevExpress.XtraEditors.CheckEdit chkTB2;
        private DevExpress.XtraEditors.CheckEdit chkTC2;
        private DevExpress.XtraEditors.CheckEdit chkCC1;
        private DevExpress.XtraEditors.CheckEdit chkCFHYPLD1;
        private DevExpress.XtraEditors.CheckEdit chkTB1;
        private DevExpress.XtraEditors.CheckEdit chkTC1;
        private DevExpress.XtraEditors.LabelControl labelControl9;
        private DevExpress.XtraEditors.LabelControl labelControl35;
        private DevExpress.XtraEditors.LabelControl labelControl8;
        private DevExpress.XtraEditors.LabelControl labelControl7;
    }
}
