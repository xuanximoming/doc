﻿namespace YidanSoft.Core.IEMMainPage
{
    partial class Print_UCIemOperInfo
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.barManager1 = new DevExpress.XtraBars.BarManager();
            this.barDockControlTop = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlBottom = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlLeft = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlRight = new DevExpress.XtraBars.BarDockControl();
            this.btn_del_Operinfo = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem1 = new DevExpress.XtraBars.BarButtonItem();
            this.btn_del_operbefore_diag = new DevExpress.XtraBars.BarButtonItem();
            this.btn_operafter_diag = new DevExpress.XtraBars.BarButtonItem();
            this.popupMenu1 = new DevExpress.XtraBars.PopupMenu();
            this.hLineEx8 = new YidanSoft.Core.IEMMainPage.HLineEx();
            this.hLineEx7 = new YidanSoft.Core.IEMMainPage.HLineEx();
            this.hLineEx6 = new YidanSoft.Core.IEMMainPage.HLineEx();
            this.hLineEx5 = new YidanSoft.Core.IEMMainPage.HLineEx();
            this.hLineEx4 = new YidanSoft.Core.IEMMainPage.HLineEx();
            this.hLineEx3 = new YidanSoft.Core.IEMMainPage.HLineEx();
            this.labelControl4 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl5 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl6 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl7 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl8 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl9 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl10 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl11 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl12 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl13 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl14 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl15 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl16 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl17 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl18 = new DevExpress.XtraEditors.LabelControl();
            this.labOperation_Code1 = new DevExpress.XtraEditors.LabelControl();
            this.labOperation_Date1 = new DevExpress.XtraEditors.LabelControl();
            this.labOperation_Name1 = new DevExpress.XtraEditors.LabelControl();
            this.labExecute_User1_Name1 = new DevExpress.XtraEditors.LabelControl();
            this.labExecute_User2_Name1 = new DevExpress.XtraEditors.LabelControl();
            this.labExecute_User3_Name1 = new DevExpress.XtraEditors.LabelControl();
            this.labAnaesthesia_Type_Name1 = new DevExpress.XtraEditors.LabelControl();
            this.labAnaesthesia_User_Name1 = new DevExpress.XtraEditors.LabelControl();
            this.labClose_Level_Name1 = new DevExpress.XtraEditors.LabelControl();
            this.labOperation_Code2 = new DevExpress.XtraEditors.LabelControl();
            this.labOperation_Date2 = new DevExpress.XtraEditors.LabelControl();
            this.labOperation_Name2 = new DevExpress.XtraEditors.LabelControl();
            this.labExecute_User1_Name2 = new DevExpress.XtraEditors.LabelControl();
            this.labExecute_User2_Name2 = new DevExpress.XtraEditors.LabelControl();
            this.labExecute_User3_Name2 = new DevExpress.XtraEditors.LabelControl();
            this.labAnaesthesia_Type_Name2 = new DevExpress.XtraEditors.LabelControl();
            this.labAnaesthesia_User_Name2 = new DevExpress.XtraEditors.LabelControl();
            this.labClose_Level_Name2 = new DevExpress.XtraEditors.LabelControl();
            this.labExecute_User2_Name3 = new DevExpress.XtraEditors.LabelControl();
            this.labExecute_User1_Name3 = new DevExpress.XtraEditors.LabelControl();
            this.labExecute_User3_Name3 = new DevExpress.XtraEditors.LabelControl();
            this.labOperation_Name3 = new DevExpress.XtraEditors.LabelControl();
            this.labAnaesthesia_Type_Name3 = new DevExpress.XtraEditors.LabelControl();
            this.labOperation_Date3 = new DevExpress.XtraEditors.LabelControl();
            this.labAnaesthesia_User_Name3 = new DevExpress.XtraEditors.LabelControl();
            this.labOperation_Code3 = new DevExpress.XtraEditors.LabelControl();
            this.labClose_Level_Name3 = new DevExpress.XtraEditors.LabelControl();
            this.labOperation_Name4 = new DevExpress.XtraEditors.LabelControl();
            this.labAnaesthesia_Type_Name4 = new DevExpress.XtraEditors.LabelControl();
            this.labExecute_User3_Name4 = new DevExpress.XtraEditors.LabelControl();
            this.labOperation_Date4 = new DevExpress.XtraEditors.LabelControl();
            this.labExecute_User1_Name4 = new DevExpress.XtraEditors.LabelControl();
            this.labAnaesthesia_User_Name4 = new DevExpress.XtraEditors.LabelControl();
            this.labExecute_User2_Name4 = new DevExpress.XtraEditors.LabelControl();
            this.labOperation_Code4 = new DevExpress.XtraEditors.LabelControl();
            this.labClose_Level_Name4 = new DevExpress.XtraEditors.LabelControl();
            this.vLineEx1 = new YidanSoft.Core.IEMMainPage.VLineEx();
            this.vLineEx2 = new YidanSoft.Core.IEMMainPage.VLineEx();
            this.vLineEx3 = new YidanSoft.Core.IEMMainPage.VLineEx();
            this.vLineEx4 = new YidanSoft.Core.IEMMainPage.VLineEx();
            this.vLineEx5 = new YidanSoft.Core.IEMMainPage.VLineEx();
            this.vLineEx6 = new YidanSoft.Core.IEMMainPage.VLineEx();
            this.vLineEx7 = new YidanSoft.Core.IEMMainPage.VLineEx();
            this.vLineEx8 = new YidanSoft.Core.IEMMainPage.VLineEx();
            this.hLineEx1 = new YidanSoft.Core.IEMMainPage.HLineEx();
            ((System.ComponentModel.ISupportInitialize)(this.barManager1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.popupMenu1)).BeginInit();
            this.SuspendLayout();
            // 
            // barManager1
            // 
            this.barManager1.DockControls.Add(this.barDockControlTop);
            this.barManager1.DockControls.Add(this.barDockControlBottom);
            this.barManager1.DockControls.Add(this.barDockControlLeft);
            this.barManager1.DockControls.Add(this.barDockControlRight);
            this.barManager1.Form = this;
            this.barManager1.Items.AddRange(new DevExpress.XtraBars.BarItem[] {
            this.btn_del_Operinfo,
            this.barButtonItem1,
            this.btn_del_operbefore_diag,
            this.btn_operafter_diag});
            this.barManager1.MaxItemId = 5;
            // 
            // barDockControlTop
            // 
            this.barDockControlTop.CausesValidation = false;
            this.barDockControlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.barDockControlTop.Location = new System.Drawing.Point(0, 0);
            this.barDockControlTop.Size = new System.Drawing.Size(666, 0);
            // 
            // barDockControlBottom
            // 
            this.barDockControlBottom.CausesValidation = false;
            this.barDockControlBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.barDockControlBottom.Location = new System.Drawing.Point(0, 170);
            this.barDockControlBottom.Size = new System.Drawing.Size(666, 0);
            // 
            // barDockControlLeft
            // 
            this.barDockControlLeft.CausesValidation = false;
            this.barDockControlLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.barDockControlLeft.Location = new System.Drawing.Point(0, 0);
            this.barDockControlLeft.Size = new System.Drawing.Size(0, 170);
            // 
            // barDockControlRight
            // 
            this.barDockControlRight.CausesValidation = false;
            this.barDockControlRight.Dock = System.Windows.Forms.DockStyle.Right;
            this.barDockControlRight.Location = new System.Drawing.Point(666, 0);
            this.barDockControlRight.Size = new System.Drawing.Size(0, 170);
            // 
            // btn_del_Operinfo
            // 
            this.btn_del_Operinfo.Caption = "删除";
            this.btn_del_Operinfo.Id = 1;
            this.btn_del_Operinfo.Name = "btn_del_Operinfo";
            // 
            // barButtonItem1
            // 
            this.barButtonItem1.Caption = "barButtonItem1";
            this.barButtonItem1.Id = 2;
            this.barButtonItem1.Name = "barButtonItem1";
            // 
            // btn_del_operbefore_diag
            // 
            this.btn_del_operbefore_diag.Caption = "删除";
            this.btn_del_operbefore_diag.Id = 3;
            this.btn_del_operbefore_diag.Name = "btn_del_operbefore_diag";
            // 
            // btn_operafter_diag
            // 
            this.btn_operafter_diag.Caption = "删除";
            this.btn_operafter_diag.Id = 4;
            this.btn_operafter_diag.Name = "btn_operafter_diag";
            // 
            // popupMenu1
            // 
            this.popupMenu1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.btn_del_Operinfo),
            new DevExpress.XtraBars.LinkPersistInfo(this.btn_del_operbefore_diag),
            new DevExpress.XtraBars.LinkPersistInfo(this.btn_operafter_diag)});
            this.popupMenu1.Manager = this.barManager1;
            this.popupMenu1.Name = "popupMenu1";
            // 
            // hLineEx8
            // 
            this.hLineEx8.BackColor = System.Drawing.Color.White;
            this.hLineEx8.IsBold = true;
            this.hLineEx8.Location = new System.Drawing.Point(3, 156);
            this.hLineEx8.Name = "hLineEx8";
            this.hLineEx8.Size = new System.Drawing.Size(658, 2);
            this.hLineEx8.TabIndex = 155;
            this.hLineEx8.Text = "hLineEx3";
            // 
            // hLineEx7
            // 
            this.hLineEx7.BackColor = System.Drawing.Color.White;
            this.hLineEx7.IsBold = false;
            this.hLineEx7.Location = new System.Drawing.Point(5, 129);
            this.hLineEx7.Name = "hLineEx7";
            this.hLineEx7.Size = new System.Drawing.Size(658, 1);
            this.hLineEx7.TabIndex = 154;
            this.hLineEx7.Text = "hLineEx3";
            // 
            // hLineEx6
            // 
            this.hLineEx6.BackColor = System.Drawing.Color.White;
            this.hLineEx6.IsBold = false;
            this.hLineEx6.Location = new System.Drawing.Point(5, 102);
            this.hLineEx6.Name = "hLineEx6";
            this.hLineEx6.Size = new System.Drawing.Size(658, 1);
            this.hLineEx6.TabIndex = 153;
            this.hLineEx6.Text = "hLineEx3";
            // 
            // hLineEx5
            // 
            this.hLineEx5.BackColor = System.Drawing.Color.White;
            this.hLineEx5.IsBold = false;
            this.hLineEx5.Location = new System.Drawing.Point(5, 75);
            this.hLineEx5.Name = "hLineEx5";
            this.hLineEx5.Size = new System.Drawing.Size(658, 1);
            this.hLineEx5.TabIndex = 149;
            this.hLineEx5.Text = "hLineEx3";
            // 
            // hLineEx4
            // 
            this.hLineEx4.BackColor = System.Drawing.Color.White;
            this.hLineEx4.IsBold = false;
            this.hLineEx4.Location = new System.Drawing.Point(5, 48);
            this.hLineEx4.Name = "hLineEx4";
            this.hLineEx4.Size = new System.Drawing.Size(658, 1);
            this.hLineEx4.TabIndex = 150;
            this.hLineEx4.Text = "hLineEx3";
            // 
            // hLineEx3
            // 
            this.hLineEx3.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton;
            this.hLineEx3.BackColor = System.Drawing.Color.White;
            this.hLineEx3.IsBold = false;
            this.hLineEx3.Location = new System.Drawing.Point(5, 3);
            this.hLineEx3.Name = "hLineEx3";
            this.hLineEx3.Size = new System.Drawing.Size(658, 1);
            this.hLineEx3.TabIndex = 151;
            this.hLineEx3.Text = "hLineEx3";
            // 
            // labelControl4
            // 
            this.labelControl4.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl4.Location = new System.Drawing.Point(13, 10);
            this.labelControl4.Name = "labelControl4";
            this.labelControl4.Size = new System.Drawing.Size(60, 14);
            this.labelControl4.TabIndex = 78;
            this.labelControl4.Text = "手术、操作";
            // 
            // labelControl5
            // 
            this.labelControl5.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl5.Location = new System.Drawing.Point(20, 28);
            this.labelControl5.Name = "labelControl5";
            this.labelControl5.Size = new System.Drawing.Size(48, 14);
            this.labelControl5.TabIndex = 78;
            this.labelControl5.Text = "编      码";
            // 
            // labelControl6
            // 
            this.labelControl6.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl6.Location = new System.Drawing.Point(95, 10);
            this.labelControl6.Name = "labelControl6";
            this.labelControl6.Size = new System.Drawing.Size(60, 14);
            this.labelControl6.TabIndex = 78;
            this.labelControl6.Text = "手术、操作";
            // 
            // labelControl7
            // 
            this.labelControl7.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl7.Location = new System.Drawing.Point(99, 30);
            this.labelControl7.Name = "labelControl7";
            this.labelControl7.Size = new System.Drawing.Size(48, 14);
            this.labelControl7.TabIndex = 157;
            this.labelControl7.Text = "日      期";
            // 
            // labelControl8
            // 
            this.labelControl8.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl8.Location = new System.Drawing.Point(205, 19);
            this.labelControl8.Name = "labelControl8";
            this.labelControl8.Size = new System.Drawing.Size(84, 14);
            this.labelControl8.TabIndex = 78;
            this.labelControl8.Text = "手术、操作名称";
            // 
            // labelControl9
            // 
            this.labelControl9.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl9.Location = new System.Drawing.Point(351, 30);
            this.labelControl9.Name = "labelControl9";
            this.labelControl9.Size = new System.Drawing.Size(24, 14);
            this.labelControl9.TabIndex = 157;
            this.labelControl9.Text = "术者";
            // 
            // labelControl10
            // 
            this.labelControl10.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl10.Location = new System.Drawing.Point(405, 30);
            this.labelControl10.Name = "labelControl10";
            this.labelControl10.Size = new System.Drawing.Size(16, 14);
            this.labelControl10.TabIndex = 157;
            this.labelControl10.Text = "I助";
            // 
            // labelControl11
            // 
            this.labelControl11.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl11.Location = new System.Drawing.Point(457, 30);
            this.labelControl11.Name = "labelControl11";
            this.labelControl11.Size = new System.Drawing.Size(20, 14);
            this.labelControl11.TabIndex = 157;
            this.labelControl11.Text = "II助";
            // 
            // labelControl12
            // 
            this.labelControl12.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl12.Location = new System.Drawing.Point(372, 10);
            this.labelControl12.Name = "labelControl12";
            this.labelControl12.Size = new System.Drawing.Size(84, 14);
            this.labelControl12.TabIndex = 78;
            this.labelControl12.Text = "手术、操作医师";
            // 
            // labelControl13
            // 
            this.labelControl13.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl13.Location = new System.Drawing.Point(558, 10);
            this.labelControl13.Name = "labelControl13";
            this.labelControl13.Size = new System.Drawing.Size(36, 14);
            this.labelControl13.TabIndex = 157;
            this.labelControl13.Text = "切口愈";
            // 
            // labelControl14
            // 
            this.labelControl14.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl14.Location = new System.Drawing.Point(558, 30);
            this.labelControl14.Name = "labelControl14";
            this.labelControl14.Size = new System.Drawing.Size(36, 14);
            this.labelControl14.TabIndex = 157;
            this.labelControl14.Text = "合等级";
            // 
            // labelControl15
            // 
            this.labelControl15.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl15.Location = new System.Drawing.Point(502, 10);
            this.labelControl15.Name = "labelControl15";
            this.labelControl15.Size = new System.Drawing.Size(36, 14);
            this.labelControl15.TabIndex = 157;
            this.labelControl15.Text = "麻   醉";
            // 
            // labelControl16
            // 
            this.labelControl16.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl16.Location = new System.Drawing.Point(502, 30);
            this.labelControl16.Name = "labelControl16";
            this.labelControl16.Size = new System.Drawing.Size(36, 14);
            this.labelControl16.TabIndex = 157;
            this.labelControl16.Text = "方   式";
            // 
            // labelControl17
            // 
            this.labelControl17.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl17.Location = new System.Drawing.Point(617, 10);
            this.labelControl17.Name = "labelControl17";
            this.labelControl17.Size = new System.Drawing.Size(36, 14);
            this.labelControl17.TabIndex = 157;
            this.labelControl17.Text = "麻   醉";
            // 
            // labelControl18
            // 
            this.labelControl18.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl18.Location = new System.Drawing.Point(617, 30);
            this.labelControl18.Name = "labelControl18";
            this.labelControl18.Size = new System.Drawing.Size(36, 14);
            this.labelControl18.TabIndex = 157;
            this.labelControl18.Text = "医   师";
            // 
            // labOperation_Code1
            // 
            this.labOperation_Code1.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labOperation_Code1.Location = new System.Drawing.Point(7, 55);
            this.labOperation_Code1.Name = "labOperation_Code1";
            this.labOperation_Code1.Size = new System.Drawing.Size(48, 14);
            this.labOperation_Code1.TabIndex = 78;
            this.labOperation_Code1.Text = "编      码";
            this.labOperation_Code1.Visible = false;
            // 
            // labOperation_Date1
            // 
            this.labOperation_Date1.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labOperation_Date1.Location = new System.Drawing.Point(87, 55);
            this.labOperation_Date1.Name = "labOperation_Date1";
            this.labOperation_Date1.Size = new System.Drawing.Size(48, 14);
            this.labOperation_Date1.TabIndex = 157;
            this.labOperation_Date1.Text = "日      期";
            this.labOperation_Date1.Visible = false;
            // 
            // labOperation_Name1
            // 
            this.labOperation_Name1.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labOperation_Name1.Location = new System.Drawing.Point(169, 55);
            this.labOperation_Name1.Name = "labOperation_Name1";
            this.labOperation_Name1.Size = new System.Drawing.Size(84, 14);
            this.labOperation_Name1.TabIndex = 78;
            this.labOperation_Name1.Text = "手术、操作名称";
            this.labOperation_Name1.Visible = false;
            // 
            // labExecute_User1_Name1
            // 
            this.labExecute_User1_Name1.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labExecute_User1_Name1.Location = new System.Drawing.Point(337, 55);
            this.labExecute_User1_Name1.Name = "labExecute_User1_Name1";
            this.labExecute_User1_Name1.Size = new System.Drawing.Size(24, 14);
            this.labExecute_User1_Name1.TabIndex = 157;
            this.labExecute_User1_Name1.Text = "术者";
            this.labExecute_User1_Name1.Visible = false;
            // 
            // labExecute_User2_Name1
            // 
            this.labExecute_User2_Name1.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labExecute_User2_Name1.Location = new System.Drawing.Point(391, 55);
            this.labExecute_User2_Name1.Name = "labExecute_User2_Name1";
            this.labExecute_User2_Name1.Size = new System.Drawing.Size(16, 14);
            this.labExecute_User2_Name1.TabIndex = 157;
            this.labExecute_User2_Name1.Text = "I助";
            this.labExecute_User2_Name1.Visible = false;
            // 
            // labExecute_User3_Name1
            // 
            this.labExecute_User3_Name1.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labExecute_User3_Name1.Location = new System.Drawing.Point(444, 55);
            this.labExecute_User3_Name1.Name = "labExecute_User3_Name1";
            this.labExecute_User3_Name1.Size = new System.Drawing.Size(20, 14);
            this.labExecute_User3_Name1.TabIndex = 157;
            this.labExecute_User3_Name1.Text = "II助";
            this.labExecute_User3_Name1.Visible = false;
            // 
            // labAnaesthesia_Type_Name1
            // 
            this.labAnaesthesia_Type_Name1.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labAnaesthesia_Type_Name1.Location = new System.Drawing.Point(494, 55);
            this.labAnaesthesia_Type_Name1.Name = "labAnaesthesia_Type_Name1";
            this.labAnaesthesia_Type_Name1.Size = new System.Drawing.Size(36, 14);
            this.labAnaesthesia_Type_Name1.TabIndex = 157;
            this.labAnaesthesia_Type_Name1.Text = "麻   醉";
            this.labAnaesthesia_Type_Name1.Visible = false;
            // 
            // labAnaesthesia_User_Name1
            // 
            this.labAnaesthesia_User_Name1.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labAnaesthesia_User_Name1.Location = new System.Drawing.Point(607, 55);
            this.labAnaesthesia_User_Name1.Name = "labAnaesthesia_User_Name1";
            this.labAnaesthesia_User_Name1.Size = new System.Drawing.Size(36, 14);
            this.labAnaesthesia_User_Name1.TabIndex = 157;
            this.labAnaesthesia_User_Name1.Text = "麻   醉";
            this.labAnaesthesia_User_Name1.Visible = false;
            // 
            // labClose_Level_Name1
            // 
            this.labClose_Level_Name1.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labClose_Level_Name1.Location = new System.Drawing.Point(552, 55);
            this.labClose_Level_Name1.Name = "labClose_Level_Name1";
            this.labClose_Level_Name1.Size = new System.Drawing.Size(5, 14);
            this.labClose_Level_Name1.TabIndex = 157;
            this.labClose_Level_Name1.Text = "/";
            this.labClose_Level_Name1.Visible = false;
            // 
            // labOperation_Code2
            // 
            this.labOperation_Code2.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labOperation_Code2.Location = new System.Drawing.Point(7, 82);
            this.labOperation_Code2.Name = "labOperation_Code2";
            this.labOperation_Code2.Size = new System.Drawing.Size(48, 14);
            this.labOperation_Code2.TabIndex = 78;
            this.labOperation_Code2.Text = "编      码";
            this.labOperation_Code2.Visible = false;
            // 
            // labOperation_Date2
            // 
            this.labOperation_Date2.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labOperation_Date2.Location = new System.Drawing.Point(87, 82);
            this.labOperation_Date2.Name = "labOperation_Date2";
            this.labOperation_Date2.Size = new System.Drawing.Size(48, 14);
            this.labOperation_Date2.TabIndex = 157;
            this.labOperation_Date2.Text = "日      期";
            this.labOperation_Date2.Visible = false;
            // 
            // labOperation_Name2
            // 
            this.labOperation_Name2.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labOperation_Name2.Location = new System.Drawing.Point(169, 82);
            this.labOperation_Name2.Name = "labOperation_Name2";
            this.labOperation_Name2.Size = new System.Drawing.Size(84, 14);
            this.labOperation_Name2.TabIndex = 78;
            this.labOperation_Name2.Text = "手术、操作名称";
            this.labOperation_Name2.Visible = false;
            // 
            // labExecute_User1_Name2
            // 
            this.labExecute_User1_Name2.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labExecute_User1_Name2.Location = new System.Drawing.Point(337, 82);
            this.labExecute_User1_Name2.Name = "labExecute_User1_Name2";
            this.labExecute_User1_Name2.Size = new System.Drawing.Size(24, 14);
            this.labExecute_User1_Name2.TabIndex = 157;
            this.labExecute_User1_Name2.Text = "术者";
            this.labExecute_User1_Name2.Visible = false;
            // 
            // labExecute_User2_Name2
            // 
            this.labExecute_User2_Name2.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labExecute_User2_Name2.Location = new System.Drawing.Point(391, 82);
            this.labExecute_User2_Name2.Name = "labExecute_User2_Name2";
            this.labExecute_User2_Name2.Size = new System.Drawing.Size(16, 14);
            this.labExecute_User2_Name2.TabIndex = 157;
            this.labExecute_User2_Name2.Text = "I助";
            this.labExecute_User2_Name2.Visible = false;
            // 
            // labExecute_User3_Name2
            // 
            this.labExecute_User3_Name2.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labExecute_User3_Name2.Location = new System.Drawing.Point(444, 82);
            this.labExecute_User3_Name2.Name = "labExecute_User3_Name2";
            this.labExecute_User3_Name2.Size = new System.Drawing.Size(20, 14);
            this.labExecute_User3_Name2.TabIndex = 157;
            this.labExecute_User3_Name2.Text = "II助";
            this.labExecute_User3_Name2.Visible = false;
            // 
            // labAnaesthesia_Type_Name2
            // 
            this.labAnaesthesia_Type_Name2.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labAnaesthesia_Type_Name2.Location = new System.Drawing.Point(494, 82);
            this.labAnaesthesia_Type_Name2.Name = "labAnaesthesia_Type_Name2";
            this.labAnaesthesia_Type_Name2.Size = new System.Drawing.Size(36, 14);
            this.labAnaesthesia_Type_Name2.TabIndex = 157;
            this.labAnaesthesia_Type_Name2.Text = "麻   醉";
            this.labAnaesthesia_Type_Name2.Visible = false;
            // 
            // labAnaesthesia_User_Name2
            // 
            this.labAnaesthesia_User_Name2.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labAnaesthesia_User_Name2.Location = new System.Drawing.Point(607, 82);
            this.labAnaesthesia_User_Name2.Name = "labAnaesthesia_User_Name2";
            this.labAnaesthesia_User_Name2.Size = new System.Drawing.Size(36, 14);
            this.labAnaesthesia_User_Name2.TabIndex = 157;
            this.labAnaesthesia_User_Name2.Text = "麻   醉";
            this.labAnaesthesia_User_Name2.Visible = false;
            // 
            // labClose_Level_Name2
            // 
            this.labClose_Level_Name2.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labClose_Level_Name2.Location = new System.Drawing.Point(552, 82);
            this.labClose_Level_Name2.Name = "labClose_Level_Name2";
            this.labClose_Level_Name2.Size = new System.Drawing.Size(5, 14);
            this.labClose_Level_Name2.TabIndex = 157;
            this.labClose_Level_Name2.Text = "/";
            this.labClose_Level_Name2.Visible = false;
            // 
            // labExecute_User2_Name3
            // 
            this.labExecute_User2_Name3.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labExecute_User2_Name3.Location = new System.Drawing.Point(391, 109);
            this.labExecute_User2_Name3.Name = "labExecute_User2_Name3";
            this.labExecute_User2_Name3.Size = new System.Drawing.Size(16, 14);
            this.labExecute_User2_Name3.TabIndex = 157;
            this.labExecute_User2_Name3.Text = "I助";
            this.labExecute_User2_Name3.Visible = false;
            // 
            // labExecute_User1_Name3
            // 
            this.labExecute_User1_Name3.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labExecute_User1_Name3.Location = new System.Drawing.Point(337, 109);
            this.labExecute_User1_Name3.Name = "labExecute_User1_Name3";
            this.labExecute_User1_Name3.Size = new System.Drawing.Size(24, 14);
            this.labExecute_User1_Name3.TabIndex = 157;
            this.labExecute_User1_Name3.Text = "术者";
            this.labExecute_User1_Name3.Visible = false;
            // 
            // labExecute_User3_Name3
            // 
            this.labExecute_User3_Name3.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labExecute_User3_Name3.Location = new System.Drawing.Point(444, 109);
            this.labExecute_User3_Name3.Name = "labExecute_User3_Name3";
            this.labExecute_User3_Name3.Size = new System.Drawing.Size(20, 14);
            this.labExecute_User3_Name3.TabIndex = 157;
            this.labExecute_User3_Name3.Text = "II助";
            this.labExecute_User3_Name3.Visible = false;
            // 
            // labOperation_Name3
            // 
            this.labOperation_Name3.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labOperation_Name3.Location = new System.Drawing.Point(169, 109);
            this.labOperation_Name3.Name = "labOperation_Name3";
            this.labOperation_Name3.Size = new System.Drawing.Size(84, 14);
            this.labOperation_Name3.TabIndex = 78;
            this.labOperation_Name3.Text = "手术、操作名称";
            this.labOperation_Name3.Visible = false;
            // 
            // labAnaesthesia_Type_Name3
            // 
            this.labAnaesthesia_Type_Name3.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labAnaesthesia_Type_Name3.Location = new System.Drawing.Point(494, 109);
            this.labAnaesthesia_Type_Name3.Name = "labAnaesthesia_Type_Name3";
            this.labAnaesthesia_Type_Name3.Size = new System.Drawing.Size(36, 14);
            this.labAnaesthesia_Type_Name3.TabIndex = 157;
            this.labAnaesthesia_Type_Name3.Text = "麻   醉";
            this.labAnaesthesia_Type_Name3.Visible = false;
            // 
            // labOperation_Date3
            // 
            this.labOperation_Date3.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labOperation_Date3.Location = new System.Drawing.Point(87, 109);
            this.labOperation_Date3.Name = "labOperation_Date3";
            this.labOperation_Date3.Size = new System.Drawing.Size(48, 14);
            this.labOperation_Date3.TabIndex = 157;
            this.labOperation_Date3.Text = "日      期";
            this.labOperation_Date3.Visible = false;
            // 
            // labAnaesthesia_User_Name3
            // 
            this.labAnaesthesia_User_Name3.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labAnaesthesia_User_Name3.Location = new System.Drawing.Point(607, 109);
            this.labAnaesthesia_User_Name3.Name = "labAnaesthesia_User_Name3";
            this.labAnaesthesia_User_Name3.Size = new System.Drawing.Size(36, 14);
            this.labAnaesthesia_User_Name3.TabIndex = 157;
            this.labAnaesthesia_User_Name3.Text = "麻   醉";
            this.labAnaesthesia_User_Name3.Visible = false;
            // 
            // labOperation_Code3
            // 
            this.labOperation_Code3.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labOperation_Code3.Location = new System.Drawing.Point(7, 109);
            this.labOperation_Code3.Name = "labOperation_Code3";
            this.labOperation_Code3.Size = new System.Drawing.Size(48, 14);
            this.labOperation_Code3.TabIndex = 78;
            this.labOperation_Code3.Text = "编      码";
            this.labOperation_Code3.Visible = false;
            // 
            // labClose_Level_Name3
            // 
            this.labClose_Level_Name3.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labClose_Level_Name3.Location = new System.Drawing.Point(552, 109);
            this.labClose_Level_Name3.Name = "labClose_Level_Name3";
            this.labClose_Level_Name3.Size = new System.Drawing.Size(5, 14);
            this.labClose_Level_Name3.TabIndex = 157;
            this.labClose_Level_Name3.Text = "/";
            this.labClose_Level_Name3.Visible = false;
            // 
            // labOperation_Name4
            // 
            this.labOperation_Name4.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labOperation_Name4.Location = new System.Drawing.Point(169, 136);
            this.labOperation_Name4.Name = "labOperation_Name4";
            this.labOperation_Name4.Size = new System.Drawing.Size(84, 14);
            this.labOperation_Name4.TabIndex = 78;
            this.labOperation_Name4.Text = "手术、操作名称";
            this.labOperation_Name4.Visible = false;
            // 
            // labAnaesthesia_Type_Name4
            // 
            this.labAnaesthesia_Type_Name4.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labAnaesthesia_Type_Name4.Location = new System.Drawing.Point(494, 136);
            this.labAnaesthesia_Type_Name4.Name = "labAnaesthesia_Type_Name4";
            this.labAnaesthesia_Type_Name4.Size = new System.Drawing.Size(36, 14);
            this.labAnaesthesia_Type_Name4.TabIndex = 157;
            this.labAnaesthesia_Type_Name4.Text = "麻   醉";
            this.labAnaesthesia_Type_Name4.Visible = false;
            // 
            // labExecute_User3_Name4
            // 
            this.labExecute_User3_Name4.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labExecute_User3_Name4.Location = new System.Drawing.Point(444, 136);
            this.labExecute_User3_Name4.Name = "labExecute_User3_Name4";
            this.labExecute_User3_Name4.Size = new System.Drawing.Size(20, 14);
            this.labExecute_User3_Name4.TabIndex = 157;
            this.labExecute_User3_Name4.Text = "II助";
            this.labExecute_User3_Name4.Visible = false;
            // 
            // labOperation_Date4
            // 
            this.labOperation_Date4.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labOperation_Date4.Location = new System.Drawing.Point(87, 136);
            this.labOperation_Date4.Name = "labOperation_Date4";
            this.labOperation_Date4.Size = new System.Drawing.Size(48, 14);
            this.labOperation_Date4.TabIndex = 157;
            this.labOperation_Date4.Text = "日      期";
            this.labOperation_Date4.Visible = false;
            // 
            // labExecute_User1_Name4
            // 
            this.labExecute_User1_Name4.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labExecute_User1_Name4.Location = new System.Drawing.Point(337, 136);
            this.labExecute_User1_Name4.Name = "labExecute_User1_Name4";
            this.labExecute_User1_Name4.Size = new System.Drawing.Size(24, 14);
            this.labExecute_User1_Name4.TabIndex = 157;
            this.labExecute_User1_Name4.Text = "术者";
            this.labExecute_User1_Name4.Visible = false;
            // 
            // labAnaesthesia_User_Name4
            // 
            this.labAnaesthesia_User_Name4.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labAnaesthesia_User_Name4.Location = new System.Drawing.Point(607, 136);
            this.labAnaesthesia_User_Name4.Name = "labAnaesthesia_User_Name4";
            this.labAnaesthesia_User_Name4.Size = new System.Drawing.Size(36, 14);
            this.labAnaesthesia_User_Name4.TabIndex = 157;
            this.labAnaesthesia_User_Name4.Text = "麻   醉";
            this.labAnaesthesia_User_Name4.Visible = false;
            // 
            // labExecute_User2_Name4
            // 
            this.labExecute_User2_Name4.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labExecute_User2_Name4.Location = new System.Drawing.Point(391, 136);
            this.labExecute_User2_Name4.Name = "labExecute_User2_Name4";
            this.labExecute_User2_Name4.Size = new System.Drawing.Size(16, 14);
            this.labExecute_User2_Name4.TabIndex = 157;
            this.labExecute_User2_Name4.Text = "I助";
            this.labExecute_User2_Name4.Visible = false;
            // 
            // labOperation_Code4
            // 
            this.labOperation_Code4.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labOperation_Code4.Location = new System.Drawing.Point(7, 136);
            this.labOperation_Code4.Name = "labOperation_Code4";
            this.labOperation_Code4.Size = new System.Drawing.Size(48, 14);
            this.labOperation_Code4.TabIndex = 78;
            this.labOperation_Code4.Text = "编      码";
            this.labOperation_Code4.Visible = false;
            // 
            // labClose_Level_Name4
            // 
            this.labClose_Level_Name4.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labClose_Level_Name4.Location = new System.Drawing.Point(552, 136);
            this.labClose_Level_Name4.Name = "labClose_Level_Name4";
            this.labClose_Level_Name4.Size = new System.Drawing.Size(5, 14);
            this.labClose_Level_Name4.TabIndex = 157;
            this.labClose_Level_Name4.Text = "/";
            this.labClose_Level_Name4.Visible = false;
            // 
            // vLineEx1
            // 
            this.vLineEx1.BackColor = System.Drawing.Color.White;
            this.vLineEx1.Location = new System.Drawing.Point(164, 4);
            this.vLineEx1.Name = "vLineEx1";
            this.vLineEx1.Size = new System.Drawing.Size(1, 153);
            this.vLineEx1.TabIndex = 181;
            this.vLineEx1.Text = "vLineEx1";
            // 
            // vLineEx2
            // 
            this.vLineEx2.BackColor = System.Drawing.Color.White;
            this.vLineEx2.Location = new System.Drawing.Point(82, 4);
            this.vLineEx2.Name = "vLineEx2";
            this.vLineEx2.Size = new System.Drawing.Size(1, 153);
            this.vLineEx2.TabIndex = 182;
            this.vLineEx2.Text = "vLineEx2";
            // 
            // vLineEx3
            // 
            this.vLineEx3.BackColor = System.Drawing.Color.White;
            this.vLineEx3.Location = new System.Drawing.Point(333, 4);
            this.vLineEx3.Name = "vLineEx3";
            this.vLineEx3.Size = new System.Drawing.Size(1, 153);
            this.vLineEx3.TabIndex = 183;
            this.vLineEx3.Text = "vLineEx3";
            // 
            // vLineEx4
            // 
            this.vLineEx4.BackColor = System.Drawing.Color.White;
            this.vLineEx4.Location = new System.Drawing.Point(489, 4);
            this.vLineEx4.Name = "vLineEx4";
            this.vLineEx4.Size = new System.Drawing.Size(1, 153);
            this.vLineEx4.TabIndex = 184;
            this.vLineEx4.Text = "vLineEx4";
            // 
            // vLineEx5
            // 
            this.vLineEx5.BackColor = System.Drawing.Color.White;
            this.vLineEx5.Location = new System.Drawing.Point(547, 3);
            this.vLineEx5.Name = "vLineEx5";
            this.vLineEx5.Size = new System.Drawing.Size(1, 153);
            this.vLineEx5.TabIndex = 185;
            this.vLineEx5.Text = "vLineEx5";
            // 
            // vLineEx6
            // 
            this.vLineEx6.BackColor = System.Drawing.Color.White;
            this.vLineEx6.Location = new System.Drawing.Point(604, 4);
            this.vLineEx6.Name = "vLineEx6";
            this.vLineEx6.Size = new System.Drawing.Size(1, 153);
            this.vLineEx6.TabIndex = 186;
            this.vLineEx6.Text = "vLineEx6";
            // 
            // vLineEx7
            // 
            this.vLineEx7.BackColor = System.Drawing.Color.White;
            this.vLineEx7.Location = new System.Drawing.Point(387, 26);
            this.vLineEx7.Name = "vLineEx7";
            this.vLineEx7.Size = new System.Drawing.Size(1, 130);
            this.vLineEx7.TabIndex = 187;
            this.vLineEx7.Text = "vLineEx7";
            // 
            // vLineEx8
            // 
            this.vLineEx8.BackColor = System.Drawing.Color.White;
            this.vLineEx8.Location = new System.Drawing.Point(439, 26);
            this.vLineEx8.Name = "vLineEx8";
            this.vLineEx8.Size = new System.Drawing.Size(1, 131);
            this.vLineEx8.TabIndex = 188;
            this.vLineEx8.Text = "vLineEx8";
            // 
            // hLineEx1
            // 
            this.hLineEx1.BackColor = System.Drawing.Color.White;
            this.hLineEx1.IsBold = false;
            this.hLineEx1.Location = new System.Drawing.Point(333, 26);
            this.hLineEx1.Name = "hLineEx1";
            this.hLineEx1.Size = new System.Drawing.Size(157, 1);
            this.hLineEx1.TabIndex = 189;
            this.hLineEx1.Text = "hLineEx3";
            // 
            // Print_UCIemOperInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(239)))), ((int)(((byte)(255)))));
            this.Controls.Add(this.hLineEx1);
            this.Controls.Add(this.vLineEx8);
            this.Controls.Add(this.vLineEx7);
            this.Controls.Add(this.vLineEx6);
            this.Controls.Add(this.vLineEx5);
            this.Controls.Add(this.vLineEx4);
            this.Controls.Add(this.vLineEx3);
            this.Controls.Add(this.vLineEx2);
            this.Controls.Add(this.vLineEx1);
            this.Controls.Add(this.labClose_Level_Name4);
            this.Controls.Add(this.labOperation_Code4);
            this.Controls.Add(this.labOperation_Name4);
            this.Controls.Add(this.labExecute_User2_Name4);
            this.Controls.Add(this.labAnaesthesia_Type_Name4);
            this.Controls.Add(this.labAnaesthesia_User_Name4);
            this.Controls.Add(this.labExecute_User3_Name4);
            this.Controls.Add(this.labExecute_User1_Name4);
            this.Controls.Add(this.labOperation_Date4);
            this.Controls.Add(this.labClose_Level_Name3);
            this.Controls.Add(this.labOperation_Code3);
            this.Controls.Add(this.labExecute_User2_Name3);
            this.Controls.Add(this.labAnaesthesia_User_Name3);
            this.Controls.Add(this.labExecute_User1_Name3);
            this.Controls.Add(this.labOperation_Date3);
            this.Controls.Add(this.labExecute_User3_Name3);
            this.Controls.Add(this.labAnaesthesia_Type_Name3);
            this.Controls.Add(this.labOperation_Name3);
            this.Controls.Add(this.labClose_Level_Name2);
            this.Controls.Add(this.labOperation_Code2);
            this.Controls.Add(this.labAnaesthesia_User_Name2);
            this.Controls.Add(this.labOperation_Date2);
            this.Controls.Add(this.labAnaesthesia_Type_Name2);
            this.Controls.Add(this.labOperation_Name2);
            this.Controls.Add(this.labExecute_User3_Name2);
            this.Controls.Add(this.labExecute_User1_Name2);
            this.Controls.Add(this.labExecute_User2_Name2);
            this.Controls.Add(this.labClose_Level_Name1);
            this.Controls.Add(this.labAnaesthesia_User_Name1);
            this.Controls.Add(this.labAnaesthesia_Type_Name1);
            this.Controls.Add(this.labExecute_User3_Name1);
            this.Controls.Add(this.labExecute_User2_Name1);
            this.Controls.Add(this.labExecute_User1_Name1);
            this.Controls.Add(this.labOperation_Name1);
            this.Controls.Add(this.labOperation_Date1);
            this.Controls.Add(this.labOperation_Code1);
            this.Controls.Add(this.labelControl18);
            this.Controls.Add(this.labelControl17);
            this.Controls.Add(this.labelControl16);
            this.Controls.Add(this.labelControl15);
            this.Controls.Add(this.labelControl14);
            this.Controls.Add(this.labelControl13);
            this.Controls.Add(this.labelControl12);
            this.Controls.Add(this.labelControl11);
            this.Controls.Add(this.labelControl10);
            this.Controls.Add(this.labelControl9);
            this.Controls.Add(this.labelControl8);
            this.Controls.Add(this.labelControl7);
            this.Controls.Add(this.labelControl6);
            this.Controls.Add(this.labelControl5);
            this.Controls.Add(this.labelControl4);
            this.Controls.Add(this.hLineEx8);
            this.Controls.Add(this.hLineEx7);
            this.Controls.Add(this.hLineEx6);
            this.Controls.Add(this.hLineEx5);
            this.Controls.Add(this.hLineEx4);
            this.Controls.Add(this.hLineEx3);
            this.Controls.Add(this.barDockControlLeft);
            this.Controls.Add(this.barDockControlRight);
            this.Controls.Add(this.barDockControlBottom);
            this.Controls.Add(this.barDockControlTop);
            this.Name = "Print_UCIemOperInfo";
            this.Size = new System.Drawing.Size(666, 170);
            ((System.ComponentModel.ISupportInitialize)(this.barManager1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.popupMenu1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevExpress.XtraBars.BarManager barManager1;
        private DevExpress.XtraBars.BarDockControl barDockControlTop;
        private DevExpress.XtraBars.BarDockControl barDockControlBottom;
        private DevExpress.XtraBars.BarDockControl barDockControlLeft;
        private DevExpress.XtraBars.BarDockControl barDockControlRight;
        private DevExpress.XtraBars.BarButtonItem btn_del_Operinfo;
        private DevExpress.XtraBars.PopupMenu popupMenu1;
        private DevExpress.XtraBars.BarButtonItem barButtonItem1;
        private DevExpress.XtraBars.BarButtonItem btn_del_operbefore_diag;
        private DevExpress.XtraBars.BarButtonItem btn_operafter_diag;
        private HLineEx hLineEx8;
        private HLineEx hLineEx7;
        private HLineEx hLineEx6;
        private HLineEx hLineEx5;
        private HLineEx hLineEx4;
        private HLineEx hLineEx3;
        private DevExpress.XtraEditors.LabelControl labelControl8;
        private DevExpress.XtraEditors.LabelControl labelControl7;
        private DevExpress.XtraEditors.LabelControl labelControl6;
        private DevExpress.XtraEditors.LabelControl labelControl5;
        private DevExpress.XtraEditors.LabelControl labelControl4;
        private DevExpress.XtraEditors.LabelControl labelControl18;
        private DevExpress.XtraEditors.LabelControl labelControl17;
        private DevExpress.XtraEditors.LabelControl labelControl16;
        private DevExpress.XtraEditors.LabelControl labelControl15;
        private DevExpress.XtraEditors.LabelControl labelControl14;
        private DevExpress.XtraEditors.LabelControl labelControl13;
        private DevExpress.XtraEditors.LabelControl labelControl12;
        private DevExpress.XtraEditors.LabelControl labelControl11;
        private DevExpress.XtraEditors.LabelControl labelControl10;
        private DevExpress.XtraEditors.LabelControl labelControl9;
        private DevExpress.XtraEditors.LabelControl labClose_Level_Name4;
        private DevExpress.XtraEditors.LabelControl labOperation_Code4;
        private DevExpress.XtraEditors.LabelControl labOperation_Name4;
        private DevExpress.XtraEditors.LabelControl labExecute_User2_Name4;
        private DevExpress.XtraEditors.LabelControl labAnaesthesia_Type_Name4;
        private DevExpress.XtraEditors.LabelControl labAnaesthesia_User_Name4;
        private DevExpress.XtraEditors.LabelControl labExecute_User3_Name4;
        private DevExpress.XtraEditors.LabelControl labExecute_User1_Name4;
        private DevExpress.XtraEditors.LabelControl labOperation_Date4;
        private DevExpress.XtraEditors.LabelControl labClose_Level_Name3;
        private DevExpress.XtraEditors.LabelControl labOperation_Code3;
        private DevExpress.XtraEditors.LabelControl labExecute_User2_Name3;
        private DevExpress.XtraEditors.LabelControl labAnaesthesia_User_Name3;
        private DevExpress.XtraEditors.LabelControl labExecute_User1_Name3;
        private DevExpress.XtraEditors.LabelControl labOperation_Date3;
        private DevExpress.XtraEditors.LabelControl labExecute_User3_Name3;
        private DevExpress.XtraEditors.LabelControl labAnaesthesia_Type_Name3;
        private DevExpress.XtraEditors.LabelControl labOperation_Name3;
        private DevExpress.XtraEditors.LabelControl labClose_Level_Name2;
        private DevExpress.XtraEditors.LabelControl labOperation_Code2;
        private DevExpress.XtraEditors.LabelControl labAnaesthesia_User_Name2;
        private DevExpress.XtraEditors.LabelControl labOperation_Date2;
        private DevExpress.XtraEditors.LabelControl labAnaesthesia_Type_Name2;
        private DevExpress.XtraEditors.LabelControl labOperation_Name2;
        private DevExpress.XtraEditors.LabelControl labExecute_User3_Name2;
        private DevExpress.XtraEditors.LabelControl labExecute_User1_Name2;
        private DevExpress.XtraEditors.LabelControl labExecute_User2_Name2;
        private DevExpress.XtraEditors.LabelControl labClose_Level_Name1;
        private DevExpress.XtraEditors.LabelControl labAnaesthesia_User_Name1;
        private DevExpress.XtraEditors.LabelControl labAnaesthesia_Type_Name1;
        private DevExpress.XtraEditors.LabelControl labExecute_User3_Name1;
        private DevExpress.XtraEditors.LabelControl labExecute_User2_Name1;
        private DevExpress.XtraEditors.LabelControl labExecute_User1_Name1;
        private DevExpress.XtraEditors.LabelControl labOperation_Name1;
        private DevExpress.XtraEditors.LabelControl labOperation_Date1;
        private DevExpress.XtraEditors.LabelControl labOperation_Code1;
        private HLineEx hLineEx1;
        private VLineEx vLineEx8;
        private VLineEx vLineEx7;
        private VLineEx vLineEx6;
        private VLineEx vLineEx5;
        private VLineEx vLineEx4;
        private VLineEx vLineEx3;
        private VLineEx vLineEx2;
        private VLineEx vLineEx1;
    }
}
