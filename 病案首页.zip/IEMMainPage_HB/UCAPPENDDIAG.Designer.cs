﻿namespace DrectSoft.Core.IEMMainPage_JS
{
    partial class UCAPPENDDIAG
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.chkzg_flag5 = new DevExpress.XtraEditors.CheckEdit();
            this.chkzg_flag4 = new DevExpress.XtraEditors.CheckEdit();
            this.chkzg_flag3 = new DevExpress.XtraEditors.CheckEdit();
            this.chkzg_flag2 = new DevExpress.XtraEditors.CheckEdit();
            this.chkzg_flag1 = new DevExpress.XtraEditors.CheckEdit();
            ((System.ComponentModel.ISupportInitialize)(this.chkzg_flag5.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkzg_flag4.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkzg_flag3.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkzg_flag2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkzg_flag1.Properties)).BeginInit();
            this.SuspendLayout();
            // 
            // labelControl1
            // 
            this.labelControl1.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl1.Location = new System.Drawing.Point(3, 13);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(132, 14);
            this.labelControl1.TabIndex = 11;
            this.labelControl1.Text = "主要诊断治愈好转情况：";
            // 
            // chkzg_flag5
            // 
            this.chkzg_flag5.Location = new System.Drawing.Point(405, 10);
            this.chkzg_flag5.Name = "chkzg_flag5";
            this.chkzg_flag5.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkzg_flag5.Properties.Appearance.Options.UseForeColor = true;
            this.chkzg_flag5.Properties.Caption = "5.其他";
            this.chkzg_flag5.Properties.RadioGroupIndex = 2;
            this.chkzg_flag5.Size = new System.Drawing.Size(60, 19);
            this.chkzg_flag5.TabIndex = 16;
            this.chkzg_flag5.TabStop = false;
            // 
            // chkzg_flag4
            // 
            this.chkzg_flag4.Location = new System.Drawing.Point(339, 10);
            this.chkzg_flag4.Name = "chkzg_flag4";
            this.chkzg_flag4.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkzg_flag4.Properties.Appearance.Options.UseForeColor = true;
            this.chkzg_flag4.Properties.Caption = "4.死亡";
            this.chkzg_flag4.Properties.RadioGroupIndex = 2;
            this.chkzg_flag4.Size = new System.Drawing.Size(60, 19);
            this.chkzg_flag4.TabIndex = 15;
            this.chkzg_flag4.TabStop = false;
            // 
            // chkzg_flag3
            // 
            this.chkzg_flag3.Location = new System.Drawing.Point(273, 10);
            this.chkzg_flag3.Name = "chkzg_flag3";
            this.chkzg_flag3.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkzg_flag3.Properties.Appearance.Options.UseForeColor = true;
            this.chkzg_flag3.Properties.Caption = "3.未愈";
            this.chkzg_flag3.Properties.RadioGroupIndex = 2;
            this.chkzg_flag3.Size = new System.Drawing.Size(60, 19);
            this.chkzg_flag3.TabIndex = 14;
            this.chkzg_flag3.TabStop = false;
            // 
            // chkzg_flag2
            // 
            this.chkzg_flag2.Location = new System.Drawing.Point(207, 10);
            this.chkzg_flag2.Name = "chkzg_flag2";
            this.chkzg_flag2.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkzg_flag2.Properties.Appearance.Options.UseForeColor = true;
            this.chkzg_flag2.Properties.Caption = "2.好转";
            this.chkzg_flag2.Properties.RadioGroupIndex = 2;
            this.chkzg_flag2.Size = new System.Drawing.Size(60, 19);
            this.chkzg_flag2.TabIndex = 13;
            this.chkzg_flag2.TabStop = false;
            // 
            // chkzg_flag1
            // 
            this.chkzg_flag1.Location = new System.Drawing.Point(141, 10);
            this.chkzg_flag1.Name = "chkzg_flag1";
            this.chkzg_flag1.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkzg_flag1.Properties.Appearance.Options.UseForeColor = true;
            this.chkzg_flag1.Properties.Caption = "1.治愈";
            this.chkzg_flag1.Properties.RadioGroupIndex = 2;
            this.chkzg_flag1.Size = new System.Drawing.Size(60, 19);
            this.chkzg_flag1.TabIndex = 12;
            this.chkzg_flag1.TabStop = false;
            // 
            // UCAPPENDDIAG
            // 
            this.Appearance.BackColor = System.Drawing.Color.White;
            this.Appearance.Options.UseBackColor = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.labelControl1);
            this.Controls.Add(this.chkzg_flag5);
            this.Controls.Add(this.chkzg_flag4);
            this.Controls.Add(this.chkzg_flag3);
            this.Controls.Add(this.chkzg_flag2);
            this.Controls.Add(this.chkzg_flag1);
            this.Name = "UCAPPENDDIAG";
            this.Size = new System.Drawing.Size(620, 368);
            ((System.ComponentModel.ISupportInitialize)(this.chkzg_flag5.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkzg_flag4.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkzg_flag3.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkzg_flag2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkzg_flag1.Properties)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevExpress.XtraEditors.LabelControl labelControl1;
        private DevExpress.XtraEditors.CheckEdit chkzg_flag5;
        private DevExpress.XtraEditors.CheckEdit chkzg_flag4;
        private DevExpress.XtraEditors.CheckEdit chkzg_flag3;
        private DevExpress.XtraEditors.CheckEdit chkzg_flag2;
        private DevExpress.XtraEditors.CheckEdit chkzg_flag1;
    }
}
