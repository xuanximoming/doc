﻿namespace YidanSoft.Core.IEMMainPage
{
    partial class UCOthers
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.panelControl7 = new DevExpress.XtraEditors.PanelControl();
            this.labelZhiLiao = new DevExpress.XtraEditors.LabelControl();
            this.labelControl28 = new DevExpress.XtraEditors.LabelControl();
            this.lblRate = new DevExpress.XtraEditors.LabelControl();
            this.labelControl64 = new DevExpress.XtraEditors.LabelControl();
            this.lblOthers = new DevExpress.XtraEditors.LabelControl();
            this.labelControl62 = new DevExpress.XtraEditors.LabelControl();
            this.lblFollwBed = new DevExpress.XtraEditors.LabelControl();
            this.labelControl60 = new DevExpress.XtraEditors.LabelControl();
            this.lblBaby = new DevExpress.XtraEditors.LabelControl();
            this.labelControl58 = new DevExpress.XtraEditors.LabelControl();
            this.lblAnaesthesia = new DevExpress.XtraEditors.LabelControl();
            this.labelControl56 = new DevExpress.XtraEditors.LabelControl();
            this.lblRis = new DevExpress.XtraEditors.LabelControl();
            this.labelControl53 = new DevExpress.XtraEditors.LabelControl();
            this.lblAccouche = new DevExpress.XtraEditors.LabelControl();
            this.labelControl51 = new DevExpress.XtraEditors.LabelControl();
            this.lblOperation = new DevExpress.XtraEditors.LabelControl();
            this.labelControl49 = new DevExpress.XtraEditors.LabelControl();
            this.lblMecical = new DevExpress.XtraEditors.LabelControl();
            this.labelControl47 = new DevExpress.XtraEditors.LabelControl();
            this.lblBlood = new DevExpress.XtraEditors.LabelControl();
            this.labelControl45 = new DevExpress.XtraEditors.LabelControl();
            this.lblOx = new DevExpress.XtraEditors.LabelControl();
            this.labelControl43 = new DevExpress.XtraEditors.LabelControl();
            this.lblAssay = new DevExpress.XtraEditors.LabelControl();
            this.labelControl41 = new DevExpress.XtraEditors.LabelControl();
            this.lblRadiate = new DevExpress.XtraEditors.LabelControl();
            this.labelControl39 = new DevExpress.XtraEditors.LabelControl();
            this.lblCMedical = new DevExpress.XtraEditors.LabelControl();
            this.labelControl37 = new DevExpress.XtraEditors.LabelControl();
            this.lblCPMedical = new DevExpress.XtraEditors.LabelControl();
            this.lblWMedical = new DevExpress.XtraEditors.LabelControl();
            this.lblCare = new DevExpress.XtraEditors.LabelControl();
            this.lblBed = new DevExpress.XtraEditors.LabelControl();
            this.labelControl35 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl33 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl31 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl29 = new DevExpress.XtraEditors.LabelControl();
            this.lblTotal = new DevExpress.XtraEditors.LabelControl();
            this.labelControl26 = new DevExpress.XtraEditors.LabelControl();
            this.btnFee = new DevExpress.XtraEditors.SimpleButton();
            this.seWb = new DevExpress.XtraEditors.SpinEdit();
            this.sePlasma = new DevExpress.XtraEditors.SpinEdit();
            this.sePlt = new DevExpress.XtraEditors.SpinEdit();
            this.labelControl19 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl17 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl18 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl15 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl16 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl6 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl7 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl13 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl14 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl12 = new DevExpress.XtraEditors.LabelControl();
            this.chkBloodReaction3 = new DevExpress.XtraEditors.CheckEdit();
            this.chkBloodReaction2 = new DevExpress.XtraEditors.CheckEdit();
            this.chkBloodReaction1 = new DevExpress.XtraEditors.CheckEdit();
            this.labelControl5 = new DevExpress.XtraEditors.LabelControl();
            this.chkRh3 = new DevExpress.XtraEditors.CheckEdit();
            this.chkRh2 = new DevExpress.XtraEditors.CheckEdit();
            this.chkRh1 = new DevExpress.XtraEditors.CheckEdit();
            this.labelControl4 = new DevExpress.XtraEditors.LabelControl();
            this.chkBlood5 = new DevExpress.XtraEditors.CheckEdit();
            this.chkBlood4 = new DevExpress.XtraEditors.CheckEdit();
            this.chkBlood3 = new DevExpress.XtraEditors.CheckEdit();
            this.chkBlood2 = new DevExpress.XtraEditors.CheckEdit();
            this.chkBlood1 = new DevExpress.XtraEditors.CheckEdit();
            this.labelControl3 = new DevExpress.XtraEditors.LabelControl();
            this.chkIsTeachingCase2 = new DevExpress.XtraEditors.CheckEdit();
            this.chkIsTeachingCase1 = new DevExpress.XtraEditors.CheckEdit();
            this.labelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.txtIsFollowingYear = new DevExpress.XtraEditors.TextEdit();
            this.labelControl10 = new DevExpress.XtraEditors.LabelControl();
            this.txtIsFollowingMon = new DevExpress.XtraEditors.TextEdit();
            this.labelControl11 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl8 = new DevExpress.XtraEditors.LabelControl();
            this.txtIsFollowingDay = new DevExpress.XtraEditors.TextEdit();
            this.labelControl9 = new DevExpress.XtraEditors.LabelControl();
            this.chkIsFollowing2 = new DevExpress.XtraEditors.CheckEdit();
            this.chkIsFollowing1 = new DevExpress.XtraEditors.CheckEdit();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.chkIsFirstCase2 = new DevExpress.XtraEditors.CheckEdit();
            this.chkIsFirstCase1 = new DevExpress.XtraEditors.CheckEdit();
            this.labelControl54 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl20 = new DevExpress.XtraEditors.LabelControl();
            this.seRbc = new DevExpress.XtraEditors.SpinEdit();
            this.txtOthers = new DevExpress.XtraEditors.SpinEdit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl7)).BeginInit();
            this.panelControl7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.seWb.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sePlasma.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sePlt.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkBloodReaction3.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkBloodReaction2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkBloodReaction1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkRh3.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkRh2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkRh1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkBlood5.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkBlood4.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkBlood3.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkBlood2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkBlood1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkIsTeachingCase2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkIsTeachingCase1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtIsFollowingYear.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtIsFollowingMon.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtIsFollowingDay.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkIsFollowing2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkIsFollowing1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkIsFirstCase2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkIsFirstCase1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.seRbc.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtOthers.Properties)).BeginInit();
            this.SuspendLayout();
            // 
            // panelControl7
            // 
            this.panelControl7.Appearance.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panelControl7.Appearance.Options.UseBackColor = true;
            this.panelControl7.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.panelControl7.Controls.Add(this.labelZhiLiao);
            this.panelControl7.Controls.Add(this.labelControl28);
            this.panelControl7.Controls.Add(this.lblRate);
            this.panelControl7.Controls.Add(this.labelControl64);
            this.panelControl7.Controls.Add(this.lblOthers);
            this.panelControl7.Controls.Add(this.labelControl62);
            this.panelControl7.Controls.Add(this.lblFollwBed);
            this.panelControl7.Controls.Add(this.labelControl60);
            this.panelControl7.Controls.Add(this.lblBaby);
            this.panelControl7.Controls.Add(this.labelControl58);
            this.panelControl7.Controls.Add(this.lblAnaesthesia);
            this.panelControl7.Controls.Add(this.labelControl56);
            this.panelControl7.Controls.Add(this.lblRis);
            this.panelControl7.Controls.Add(this.labelControl53);
            this.panelControl7.Controls.Add(this.lblAccouche);
            this.panelControl7.Controls.Add(this.labelControl51);
            this.panelControl7.Controls.Add(this.lblOperation);
            this.panelControl7.Controls.Add(this.labelControl49);
            this.panelControl7.Controls.Add(this.lblMecical);
            this.panelControl7.Controls.Add(this.labelControl47);
            this.panelControl7.Controls.Add(this.lblBlood);
            this.panelControl7.Controls.Add(this.labelControl45);
            this.panelControl7.Controls.Add(this.lblOx);
            this.panelControl7.Controls.Add(this.labelControl43);
            this.panelControl7.Controls.Add(this.lblAssay);
            this.panelControl7.Controls.Add(this.labelControl41);
            this.panelControl7.Controls.Add(this.lblRadiate);
            this.panelControl7.Controls.Add(this.labelControl39);
            this.panelControl7.Controls.Add(this.lblCMedical);
            this.panelControl7.Controls.Add(this.labelControl37);
            this.panelControl7.Controls.Add(this.lblCPMedical);
            this.panelControl7.Controls.Add(this.lblWMedical);
            this.panelControl7.Controls.Add(this.lblCare);
            this.panelControl7.Controls.Add(this.lblBed);
            this.panelControl7.Controls.Add(this.labelControl35);
            this.panelControl7.Controls.Add(this.labelControl33);
            this.panelControl7.Controls.Add(this.labelControl31);
            this.panelControl7.Controls.Add(this.labelControl29);
            this.panelControl7.Controls.Add(this.lblTotal);
            this.panelControl7.Controls.Add(this.labelControl26);
            this.panelControl7.Controls.Add(this.btnFee);
            this.panelControl7.Location = new System.Drawing.Point(18, 31);
            this.panelControl7.Name = "panelControl7";
            this.panelControl7.Size = new System.Drawing.Size(580, 128);
            this.panelControl7.TabIndex = 2;
            // 
            // labelZhiLiao
            // 
            this.labelZhiLiao.Appearance.ForeColor = System.Drawing.Color.DarkGray;
            this.labelZhiLiao.Location = new System.Drawing.Point(132, 94);
            this.labelZhiLiao.Name = "labelZhiLiao";
            this.labelZhiLiao.Size = new System.Drawing.Size(32, 14);
            this.labelZhiLiao.TabIndex = 213;
            this.labelZhiLiao.Text = " 1911";
            // 
            // labelControl28
            // 
            this.labelControl28.Appearance.ForeColor = System.Drawing.Color.DarkGray;
            this.labelControl28.Location = new System.Drawing.Point(98, 94);
            this.labelControl28.Name = "labelControl28";
            this.labelControl28.Size = new System.Drawing.Size(24, 14);
            this.labelControl28.TabIndex = 212;
            this.labelControl28.Text = "治疗";
            // 
            // lblRate
            // 
            this.lblRate.Appearance.ForeColor = System.Drawing.Color.DarkGray;
            this.lblRate.Location = new System.Drawing.Point(225, 94);
            this.lblRate.Name = "lblRate";
            this.lblRate.Size = new System.Drawing.Size(28, 14);
            this.lblRate.TabIndex = 211;
            this.lblRate.Text = "2011";
            // 
            // labelControl64
            // 
            this.labelControl64.Appearance.ForeColor = System.Drawing.Color.DarkGray;
            this.labelControl64.Location = new System.Drawing.Point(183, 94);
            this.labelControl64.Name = "labelControl64";
            this.labelControl64.Size = new System.Drawing.Size(36, 14);
            this.labelControl64.TabIndex = 210;
            this.labelControl64.Text = "药占比";
            // 
            // lblOthers
            // 
            this.lblOthers.Appearance.ForeColor = System.Drawing.Color.DarkGray;
            this.lblOthers.Location = new System.Drawing.Point(46, 94);
            this.lblOthers.Name = "lblOthers";
            this.lblOthers.Size = new System.Drawing.Size(32, 14);
            this.lblOthers.TabIndex = 209;
            this.lblOthers.Text = " 1811";
            // 
            // labelControl62
            // 
            this.labelControl62.Appearance.ForeColor = System.Drawing.Color.DarkGray;
            this.labelControl62.Location = new System.Drawing.Point(13, 94);
            this.labelControl62.Name = "labelControl62";
            this.labelControl62.Size = new System.Drawing.Size(24, 14);
            this.labelControl62.TabIndex = 208;
            this.labelControl62.Text = "其他";
            // 
            // lblFollwBed
            // 
            this.lblFollwBed.Appearance.ForeColor = System.Drawing.Color.DarkGray;
            this.lblFollwBed.Location = new System.Drawing.Point(521, 65);
            this.lblFollwBed.Name = "lblFollwBed";
            this.lblFollwBed.Size = new System.Drawing.Size(28, 14);
            this.lblFollwBed.TabIndex = 207;
            this.lblFollwBed.Text = "1711";
            // 
            // labelControl60
            // 
            this.labelControl60.Appearance.ForeColor = System.Drawing.Color.DarkGray;
            this.labelControl60.Location = new System.Drawing.Point(479, 65);
            this.labelControl60.Name = "labelControl60";
            this.labelControl60.Size = new System.Drawing.Size(36, 14);
            this.labelControl60.TabIndex = 206;
            this.labelControl60.Text = "陪床费";
            // 
            // lblBaby
            // 
            this.lblBaby.Appearance.ForeColor = System.Drawing.Color.DarkGray;
            this.lblBaby.Location = new System.Drawing.Point(416, 65);
            this.lblBaby.Name = "lblBaby";
            this.lblBaby.Size = new System.Drawing.Size(28, 14);
            this.lblBaby.TabIndex = 205;
            this.lblBaby.Text = "1611";
            // 
            // labelControl58
            // 
            this.labelControl58.Appearance.ForeColor = System.Drawing.Color.DarkGray;
            this.labelControl58.Location = new System.Drawing.Point(374, 65);
            this.labelControl58.Name = "labelControl58";
            this.labelControl58.Size = new System.Drawing.Size(36, 14);
            this.labelControl58.TabIndex = 204;
            this.labelControl58.Text = "婴儿费";
            // 
            // lblAnaesthesia
            // 
            this.lblAnaesthesia.Appearance.ForeColor = System.Drawing.Color.DarkGray;
            this.lblAnaesthesia.Location = new System.Drawing.Point(312, 65);
            this.lblAnaesthesia.Name = "lblAnaesthesia";
            this.lblAnaesthesia.Size = new System.Drawing.Size(28, 14);
            this.lblAnaesthesia.TabIndex = 203;
            this.lblAnaesthesia.Text = "1511";
            // 
            // labelControl56
            // 
            this.labelControl56.Appearance.ForeColor = System.Drawing.Color.DarkGray;
            this.labelControl56.Location = new System.Drawing.Point(268, 65);
            this.labelControl56.Name = "labelControl56";
            this.labelControl56.Size = new System.Drawing.Size(36, 14);
            this.labelControl56.TabIndex = 202;
            this.labelControl56.Text = "麻醉费";
            // 
            // lblRis
            // 
            this.lblRis.Appearance.ForeColor = System.Drawing.Color.DarkGray;
            this.lblRis.Location = new System.Drawing.Point(215, 65);
            this.lblRis.Name = "lblRis";
            this.lblRis.Size = new System.Drawing.Size(32, 14);
            this.lblRis.TabIndex = 201;
            this.lblRis.Text = " 1411";
            // 
            // labelControl53
            // 
            this.labelControl53.Appearance.ForeColor = System.Drawing.Color.DarkGray;
            this.labelControl53.Location = new System.Drawing.Point(182, 65);
            this.labelControl53.Name = "labelControl53";
            this.labelControl53.Size = new System.Drawing.Size(24, 14);
            this.labelControl53.TabIndex = 200;
            this.labelControl53.Text = "检查";
            // 
            // lblAccouche
            // 
            this.lblAccouche.Appearance.ForeColor = System.Drawing.Color.DarkGray;
            this.lblAccouche.Location = new System.Drawing.Point(130, 65);
            this.lblAccouche.Name = "lblAccouche";
            this.lblAccouche.Size = new System.Drawing.Size(28, 14);
            this.lblAccouche.TabIndex = 199;
            this.lblAccouche.Text = "1311";
            // 
            // labelControl51
            // 
            this.labelControl51.Appearance.ForeColor = System.Drawing.Color.DarkGray;
            this.labelControl51.Location = new System.Drawing.Point(98, 65);
            this.labelControl51.Name = "labelControl51";
            this.labelControl51.Size = new System.Drawing.Size(24, 14);
            this.labelControl51.TabIndex = 198;
            this.labelControl51.Text = "接生";
            // 
            // lblOperation
            // 
            this.lblOperation.Appearance.ForeColor = System.Drawing.Color.DarkGray;
            this.lblOperation.Location = new System.Drawing.Point(46, 65);
            this.lblOperation.Name = "lblOperation";
            this.lblOperation.Size = new System.Drawing.Size(32, 14);
            this.lblOperation.TabIndex = 197;
            this.lblOperation.Text = " 1211";
            // 
            // labelControl49
            // 
            this.labelControl49.Appearance.ForeColor = System.Drawing.Color.DarkGray;
            this.labelControl49.Location = new System.Drawing.Point(13, 65);
            this.labelControl49.Name = "labelControl49";
            this.labelControl49.Size = new System.Drawing.Size(24, 14);
            this.labelControl49.TabIndex = 196;
            this.labelControl49.Text = "手术";
            // 
            // lblMecical
            // 
            this.lblMecical.Appearance.ForeColor = System.Drawing.Color.DarkGray;
            this.lblMecical.Location = new System.Drawing.Point(519, 35);
            this.lblMecical.Name = "lblMecical";
            this.lblMecical.Size = new System.Drawing.Size(32, 14);
            this.lblMecical.TabIndex = 195;
            this.lblMecical.Text = " 1100";
            // 
            // labelControl47
            // 
            this.labelControl47.Appearance.ForeColor = System.Drawing.Color.DarkGray;
            this.labelControl47.Location = new System.Drawing.Point(486, 35);
            this.labelControl47.Name = "labelControl47";
            this.labelControl47.Size = new System.Drawing.Size(24, 14);
            this.labelControl47.TabIndex = 194;
            this.labelControl47.Text = "诊疗";
            // 
            // lblBlood
            // 
            this.lblBlood.Appearance.ForeColor = System.Drawing.Color.DarkGray;
            this.lblBlood.Location = new System.Drawing.Point(433, 35);
            this.lblBlood.Name = "lblBlood";
            this.lblBlood.Size = new System.Drawing.Size(32, 14);
            this.lblBlood.TabIndex = 193;
            this.lblBlood.Text = " 1000";
            // 
            // labelControl45
            // 
            this.labelControl45.Appearance.ForeColor = System.Drawing.Color.DarkGray;
            this.labelControl45.Location = new System.Drawing.Point(401, 35);
            this.labelControl45.Name = "labelControl45";
            this.labelControl45.Size = new System.Drawing.Size(24, 14);
            this.labelControl45.TabIndex = 192;
            this.labelControl45.Text = "输血";
            // 
            // lblOx
            // 
            this.lblOx.Appearance.ForeColor = System.Drawing.Color.DarkGray;
            this.lblOx.Location = new System.Drawing.Point(339, 35);
            this.lblOx.Name = "lblOx";
            this.lblOx.Size = new System.Drawing.Size(21, 14);
            this.lblOx.TabIndex = 191;
            this.lblOx.Text = "900";
            // 
            // labelControl43
            // 
            this.labelControl43.Appearance.ForeColor = System.Drawing.Color.DarkGray;
            this.labelControl43.Location = new System.Drawing.Point(309, 35);
            this.labelControl43.Name = "labelControl43";
            this.labelControl43.Size = new System.Drawing.Size(24, 14);
            this.labelControl43.TabIndex = 190;
            this.labelControl43.Text = "输氧";
            // 
            // lblAssay
            // 
            this.lblAssay.Appearance.ForeColor = System.Drawing.Color.DarkGray;
            this.lblAssay.Location = new System.Drawing.Point(255, 35);
            this.lblAssay.Name = "lblAssay";
            this.lblAssay.Size = new System.Drawing.Size(21, 14);
            this.lblAssay.TabIndex = 189;
            this.lblAssay.Text = "800";
            // 
            // labelControl41
            // 
            this.labelControl41.Appearance.ForeColor = System.Drawing.Color.DarkGray;
            this.labelControl41.Location = new System.Drawing.Point(225, 35);
            this.labelControl41.Name = "labelControl41";
            this.labelControl41.Size = new System.Drawing.Size(24, 14);
            this.labelControl41.TabIndex = 188;
            this.labelControl41.Text = "检验";
            // 
            // lblRadiate
            // 
            this.lblRadiate.Appearance.ForeColor = System.Drawing.Color.DarkGray;
            this.lblRadiate.Location = new System.Drawing.Point(173, 35);
            this.lblRadiate.Name = "lblRadiate";
            this.lblRadiate.Size = new System.Drawing.Size(25, 14);
            this.lblRadiate.TabIndex = 187;
            this.lblRadiate.Text = " 700";
            // 
            // labelControl39
            // 
            this.labelControl39.Appearance.ForeColor = System.Drawing.Color.DarkGray;
            this.labelControl39.Location = new System.Drawing.Point(143, 35);
            this.labelControl39.Name = "labelControl39";
            this.labelControl39.Size = new System.Drawing.Size(24, 14);
            this.labelControl39.TabIndex = 186;
            this.labelControl39.Text = "放射";
            // 
            // lblCMedical
            // 
            this.lblCMedical.Appearance.ForeColor = System.Drawing.Color.DarkGray;
            this.lblCMedical.Location = new System.Drawing.Point(99, 35);
            this.lblCMedical.Name = "lblCMedical";
            this.lblCMedical.Size = new System.Drawing.Size(25, 14);
            this.lblCMedical.TabIndex = 185;
            this.lblCMedical.Text = " 600";
            // 
            // labelControl37
            // 
            this.labelControl37.Appearance.ForeColor = System.Drawing.Color.DarkGray;
            this.labelControl37.Location = new System.Drawing.Point(55, 35);
            this.labelControl37.Name = "labelControl37";
            this.labelControl37.Size = new System.Drawing.Size(36, 14);
            this.labelControl37.TabIndex = 184;
            this.labelControl37.Text = "中草药";
            // 
            // lblCPMedical
            // 
            this.lblCPMedical.Appearance.ForeColor = System.Drawing.Color.DarkGray;
            this.lblCPMedical.Location = new System.Drawing.Point(527, 8);
            this.lblCPMedical.Name = "lblCPMedical";
            this.lblCPMedical.Size = new System.Drawing.Size(25, 14);
            this.lblCPMedical.TabIndex = 183;
            this.lblCPMedical.Text = " 500";
            // 
            // lblWMedical
            // 
            this.lblWMedical.Appearance.ForeColor = System.Drawing.Color.DarkGray;
            this.lblWMedical.Location = new System.Drawing.Point(434, 8);
            this.lblWMedical.Name = "lblWMedical";
            this.lblWMedical.Size = new System.Drawing.Size(25, 14);
            this.lblWMedical.TabIndex = 182;
            this.lblWMedical.Text = " 400";
            // 
            // lblCare
            // 
            this.lblCare.Appearance.ForeColor = System.Drawing.Color.DarkGray;
            this.lblCare.Location = new System.Drawing.Point(354, 8);
            this.lblCare.Name = "lblCare";
            this.lblCare.Size = new System.Drawing.Size(25, 14);
            this.lblCare.TabIndex = 181;
            this.lblCare.Text = " 300";
            // 
            // lblBed
            // 
            this.lblBed.Appearance.ForeColor = System.Drawing.Color.DarkGray;
            this.lblBed.Location = new System.Drawing.Point(258, 8);
            this.lblBed.Name = "lblBed";
            this.lblBed.Size = new System.Drawing.Size(25, 14);
            this.lblBed.TabIndex = 180;
            this.lblBed.Text = " 200";
            // 
            // labelControl35
            // 
            this.labelControl35.Appearance.ForeColor = System.Drawing.Color.DarkGray;
            this.labelControl35.Location = new System.Drawing.Point(484, 8);
            this.labelControl35.Name = "labelControl35";
            this.labelControl35.Size = new System.Drawing.Size(36, 14);
            this.labelControl35.TabIndex = 179;
            this.labelControl35.Text = "中成药";
            // 
            // labelControl33
            // 
            this.labelControl33.Appearance.ForeColor = System.Drawing.Color.DarkGray;
            this.labelControl33.Location = new System.Drawing.Point(401, 8);
            this.labelControl33.Name = "labelControl33";
            this.labelControl33.Size = new System.Drawing.Size(24, 14);
            this.labelControl33.TabIndex = 177;
            this.labelControl33.Text = "西药";
            // 
            // labelControl31
            // 
            this.labelControl31.Appearance.ForeColor = System.Drawing.Color.DarkGray;
            this.labelControl31.Location = new System.Drawing.Point(308, 8);
            this.labelControl31.Name = "labelControl31";
            this.labelControl31.Size = new System.Drawing.Size(36, 14);
            this.labelControl31.TabIndex = 175;
            this.labelControl31.Text = "护理费";
            // 
            // labelControl29
            // 
            this.labelControl29.Appearance.ForeColor = System.Drawing.Color.DarkGray;
            this.labelControl29.Location = new System.Drawing.Point(225, 8);
            this.labelControl29.Name = "labelControl29";
            this.labelControl29.Size = new System.Drawing.Size(24, 14);
            this.labelControl29.TabIndex = 170;
            this.labelControl29.Text = "床费";
            // 
            // lblTotal
            // 
            this.lblTotal.Appearance.ForeColor = System.Drawing.Color.DarkGray;
            this.lblTotal.Location = new System.Drawing.Point(163, 8);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(45, 14);
            this.lblTotal.TabIndex = 169;
            this.lblTotal.Text = "100      ";
            // 
            // labelControl26
            // 
            this.labelControl26.Appearance.ForeColor = System.Drawing.Color.DarkGray;
            this.labelControl26.Location = new System.Drawing.Point(55, 8);
            this.labelControl26.Name = "labelControl26";
            this.labelControl26.Size = new System.Drawing.Size(106, 14);
            this.labelControl26.TabIndex = 168;
            this.labelControl26.Text = "住院费用总计(元)：";
            // 
            // btnFee
            // 
            this.btnFee.Location = new System.Drawing.Point(4, 10);
            this.btnFee.Name = "btnFee";
            this.btnFee.Size = new System.Drawing.Size(44, 30);
            this.btnFee.TabIndex = 3;
            this.btnFee.Text = "提取";
            this.btnFee.Click += new System.EventHandler(this.btnFee_Click);
            // 
            // seWb
            // 
            this.seWb.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.seWb.Location = new System.Drawing.Point(521, 213);
            this.seWb.Name = "seWb";
            this.seWb.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.seWb.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.seWb.Properties.IsFloatValue = false;
            this.seWb.Properties.Mask.EditMask = "N00";
            this.seWb.Properties.MaxValue = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.seWb.Size = new System.Drawing.Size(55, 19);
            this.seWb.TabIndex = 25;
            // 
            // sePlasma
            // 
            this.sePlasma.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.sePlasma.Location = new System.Drawing.Point(398, 213);
            this.sePlasma.Name = "sePlasma";
            this.sePlasma.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.sePlasma.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.sePlasma.Properties.IsFloatValue = false;
            this.sePlasma.Properties.Mask.EditMask = "N00";
            this.sePlasma.Properties.MaxValue = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.sePlasma.Size = new System.Drawing.Size(55, 19);
            this.sePlasma.TabIndex = 24;
            // 
            // sePlt
            // 
            this.sePlt.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.sePlt.Location = new System.Drawing.Point(269, 213);
            this.sePlt.Name = "sePlt";
            this.sePlt.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.sePlt.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.sePlt.Properties.IsFloatValue = false;
            this.sePlt.Properties.Mask.EditMask = "N00";
            this.sePlt.Properties.MaxValue = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.sePlt.Size = new System.Drawing.Size(55, 19);
            this.sePlt.TabIndex = 23;
            // 
            // labelControl19
            // 
            this.labelControl19.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl19.Location = new System.Drawing.Point(78, 242);
            this.labelControl19.Name = "labelControl19";
            this.labelControl19.Size = new System.Drawing.Size(39, 14);
            this.labelControl19.TabIndex = 161;
            this.labelControl19.Text = " 5.其他";
            // 
            // labelControl17
            // 
            this.labelControl17.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl17.Location = new System.Drawing.Point(578, 216);
            this.labelControl17.Name = "labelControl17";
            this.labelControl17.Size = new System.Drawing.Size(12, 14);
            this.labelControl17.TabIndex = 160;
            this.labelControl17.Text = "ml";
            // 
            // labelControl18
            // 
            this.labelControl18.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl18.Location = new System.Drawing.Point(482, 216);
            this.labelControl18.Name = "labelControl18";
            this.labelControl18.Size = new System.Drawing.Size(35, 14);
            this.labelControl18.TabIndex = 158;
            this.labelControl18.Text = "4.全血";
            // 
            // labelControl15
            // 
            this.labelControl15.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl15.Location = new System.Drawing.Point(455, 216);
            this.labelControl15.Name = "labelControl15";
            this.labelControl15.Size = new System.Drawing.Size(12, 14);
            this.labelControl15.TabIndex = 157;
            this.labelControl15.Text = "ml";
            // 
            // labelControl16
            // 
            this.labelControl16.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl16.Location = new System.Drawing.Point(361, 216);
            this.labelControl16.Name = "labelControl16";
            this.labelControl16.Size = new System.Drawing.Size(35, 14);
            this.labelControl16.TabIndex = 155;
            this.labelControl16.Text = "3.血浆";
            // 
            // labelControl6
            // 
            this.labelControl6.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl6.Location = new System.Drawing.Point(326, 216);
            this.labelControl6.Name = "labelControl6";
            this.labelControl6.Size = new System.Drawing.Size(12, 14);
            this.labelControl6.TabIndex = 154;
            this.labelControl6.Text = "ml";
            // 
            // labelControl7
            // 
            this.labelControl7.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl7.Location = new System.Drawing.Point(220, 216);
            this.labelControl7.Name = "labelControl7";
            this.labelControl7.Size = new System.Drawing.Size(47, 14);
            this.labelControl7.TabIndex = 152;
            this.labelControl7.Text = "2.血小板";
            // 
            // labelControl13
            // 
            this.labelControl13.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl13.Location = new System.Drawing.Point(187, 216);
            this.labelControl13.Name = "labelControl13";
            this.labelControl13.Size = new System.Drawing.Size(24, 14);
            this.labelControl13.TabIndex = 151;
            this.labelControl13.Text = "单位";
            // 
            // labelControl14
            // 
            this.labelControl14.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl14.Location = new System.Drawing.Point(81, 216);
            this.labelControl14.Name = "labelControl14";
            this.labelControl14.Size = new System.Drawing.Size(47, 14);
            this.labelControl14.TabIndex = 149;
            this.labelControl14.Text = "1.红细胞";
            // 
            // labelControl12
            // 
            this.labelControl12.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl12.Location = new System.Drawing.Point(25, 216);
            this.labelControl12.Name = "labelControl12";
            this.labelControl12.Size = new System.Drawing.Size(48, 14);
            this.labelControl12.TabIndex = 148;
            this.labelControl12.Text = "输血品种";
            // 
            // chkBloodReaction3
            // 
            this.chkBloodReaction3.Location = new System.Drawing.Point(546, 189);
            this.chkBloodReaction3.Name = "chkBloodReaction3";
            this.chkBloodReaction3.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkBloodReaction3.Properties.Appearance.Options.UseForeColor = true;
            this.chkBloodReaction3.Properties.Caption = "2.无";
            this.chkBloodReaction3.Properties.RadioGroupIndex = 5;
            this.chkBloodReaction3.Size = new System.Drawing.Size(44, 19);
            this.chkBloodReaction3.TabIndex = 21;
            this.chkBloodReaction3.TabStop = false;
            // 
            // chkBloodReaction2
            // 
            this.chkBloodReaction2.Location = new System.Drawing.Point(501, 189);
            this.chkBloodReaction2.Name = "chkBloodReaction2";
            this.chkBloodReaction2.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkBloodReaction2.Properties.Appearance.Options.UseForeColor = true;
            this.chkBloodReaction2.Properties.Caption = "1.有";
            this.chkBloodReaction2.Properties.RadioGroupIndex = 5;
            this.chkBloodReaction2.Size = new System.Drawing.Size(47, 19);
            this.chkBloodReaction2.TabIndex = 20;
            this.chkBloodReaction2.TabStop = false;
            // 
            // chkBloodReaction1
            // 
            this.chkBloodReaction1.Location = new System.Drawing.Point(444, 189);
            this.chkBloodReaction1.Name = "chkBloodReaction1";
            this.chkBloodReaction1.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkBloodReaction1.Properties.Appearance.Options.UseForeColor = true;
            this.chkBloodReaction1.Properties.Caption = "0.未输";
            this.chkBloodReaction1.Properties.RadioGroupIndex = 5;
            this.chkBloodReaction1.Size = new System.Drawing.Size(56, 19);
            this.chkBloodReaction1.TabIndex = 19;
            this.chkBloodReaction1.TabStop = false;
            // 
            // labelControl5
            // 
            this.labelControl5.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl5.Location = new System.Drawing.Point(391, 191);
            this.labelControl5.Name = "labelControl5";
            this.labelControl5.Size = new System.Drawing.Size(48, 14);
            this.labelControl5.TabIndex = 146;
            this.labelControl5.Text = "输血反应";
            // 
            // chkRh3
            // 
            this.chkRh3.Location = new System.Drawing.Point(340, 189);
            this.chkRh3.Name = "chkRh3";
            this.chkRh3.Properties.Appearance.ForeColor = System.Drawing.Color.Red;
            this.chkRh3.Properties.Appearance.Options.UseForeColor = true;
            this.chkRh3.Properties.Caption = "2.阳";
            this.chkRh3.Properties.RadioGroupIndex = 4;
            this.chkRh3.Size = new System.Drawing.Size(45, 19);
            this.chkRh3.TabIndex = 18;
            this.chkRh3.TabStop = false;
            // 
            // chkRh2
            // 
            this.chkRh2.Location = new System.Drawing.Point(295, 189);
            this.chkRh2.Name = "chkRh2";
            this.chkRh2.Properties.Appearance.ForeColor = System.Drawing.Color.Red;
            this.chkRh2.Properties.Appearance.Options.UseForeColor = true;
            this.chkRh2.Properties.Caption = "1.阴";
            this.chkRh2.Properties.RadioGroupIndex = 4;
            this.chkRh2.Size = new System.Drawing.Size(43, 19);
            this.chkRh2.TabIndex = 17;
            this.chkRh2.TabStop = false;
            // 
            // chkRh1
            // 
            this.chkRh1.Location = new System.Drawing.Point(239, 189);
            this.chkRh1.Name = "chkRh1";
            this.chkRh1.Properties.Appearance.ForeColor = System.Drawing.Color.Red;
            this.chkRh1.Properties.Appearance.Options.UseForeColor = true;
            this.chkRh1.Properties.Caption = "0.末做";
            this.chkRh1.Properties.RadioGroupIndex = 4;
            this.chkRh1.Size = new System.Drawing.Size(61, 19);
            this.chkRh1.TabIndex = 16;
            this.chkRh1.TabStop = false;
            // 
            // labelControl4
            // 
            this.labelControl4.Appearance.ForeColor = System.Drawing.Color.Red;
            this.labelControl4.Location = new System.Drawing.Point(223, 191);
            this.labelControl4.Name = "labelControl4";
            this.labelControl4.Size = new System.Drawing.Size(14, 14);
            this.labelControl4.TabIndex = 127;
            this.labelControl4.Text = "Rh";
            // 
            // chkBlood5
            // 
            this.chkBlood5.Location = new System.Drawing.Point(173, 189);
            this.chkBlood5.Name = "chkBlood5";
            this.chkBlood5.Properties.Appearance.ForeColor = System.Drawing.Color.Red;
            this.chkBlood5.Properties.Appearance.Options.UseForeColor = true;
            this.chkBlood5.Properties.Caption = "其他";
            this.chkBlood5.Properties.RadioGroupIndex = 3;
            this.chkBlood5.Size = new System.Drawing.Size(47, 19);
            this.chkBlood5.TabIndex = 15;
            this.chkBlood5.TabStop = false;
            // 
            // chkBlood4
            // 
            this.chkBlood4.Location = new System.Drawing.Point(144, 189);
            this.chkBlood4.Name = "chkBlood4";
            this.chkBlood4.Properties.Appearance.ForeColor = System.Drawing.Color.Red;
            this.chkBlood4.Properties.Appearance.Options.UseForeColor = true;
            this.chkBlood4.Properties.Caption = "O";
            this.chkBlood4.Properties.RadioGroupIndex = 3;
            this.chkBlood4.Size = new System.Drawing.Size(33, 19);
            this.chkBlood4.TabIndex = 14;
            this.chkBlood4.TabStop = false;
            // 
            // chkBlood3
            // 
            this.chkBlood3.Location = new System.Drawing.Point(109, 189);
            this.chkBlood3.Name = "chkBlood3";
            this.chkBlood3.Properties.Appearance.ForeColor = System.Drawing.Color.Red;
            this.chkBlood3.Properties.Appearance.Options.UseForeColor = true;
            this.chkBlood3.Properties.Caption = "AB";
            this.chkBlood3.Properties.RadioGroupIndex = 3;
            this.chkBlood3.Size = new System.Drawing.Size(43, 19);
            this.chkBlood3.TabIndex = 13;
            this.chkBlood3.TabStop = false;
            // 
            // chkBlood2
            // 
            this.chkBlood2.Location = new System.Drawing.Point(81, 189);
            this.chkBlood2.Name = "chkBlood2";
            this.chkBlood2.Properties.Appearance.ForeColor = System.Drawing.Color.Red;
            this.chkBlood2.Properties.Appearance.Options.UseForeColor = true;
            this.chkBlood2.Properties.Caption = "B";
            this.chkBlood2.Properties.RadioGroupIndex = 3;
            this.chkBlood2.Size = new System.Drawing.Size(29, 19);
            this.chkBlood2.TabIndex = 12;
            this.chkBlood2.TabStop = false;
            // 
            // chkBlood1
            // 
            this.chkBlood1.Location = new System.Drawing.Point(52, 189);
            this.chkBlood1.Name = "chkBlood1";
            this.chkBlood1.Properties.Appearance.ForeColor = System.Drawing.Color.Red;
            this.chkBlood1.Properties.Appearance.Options.UseForeColor = true;
            this.chkBlood1.Properties.Caption = "A";
            this.chkBlood1.Properties.RadioGroupIndex = 3;
            this.chkBlood1.Size = new System.Drawing.Size(37, 19);
            this.chkBlood1.TabIndex = 11;
            this.chkBlood1.TabStop = false;
            // 
            // labelControl3
            // 
            this.labelControl3.Appearance.ForeColor = System.Drawing.Color.Red;
            this.labelControl3.Location = new System.Drawing.Point(25, 191);
            this.labelControl3.Name = "labelControl3";
            this.labelControl3.Size = new System.Drawing.Size(24, 14);
            this.labelControl3.TabIndex = 125;
            this.labelControl3.Text = "血型";
            // 
            // chkIsTeachingCase2
            // 
            this.chkIsTeachingCase2.Location = new System.Drawing.Point(542, 165);
            this.chkIsTeachingCase2.Name = "chkIsTeachingCase2";
            this.chkIsTeachingCase2.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkIsTeachingCase2.Properties.Appearance.Options.UseForeColor = true;
            this.chkIsTeachingCase2.Properties.Caption = "2.否";
            this.chkIsTeachingCase2.Properties.RadioGroupIndex = 2;
            this.chkIsTeachingCase2.Size = new System.Drawing.Size(52, 19);
            this.chkIsTeachingCase2.TabIndex = 10;
            this.chkIsTeachingCase2.TabStop = false;
            // 
            // chkIsTeachingCase1
            // 
            this.chkIsTeachingCase1.Location = new System.Drawing.Point(480, 165);
            this.chkIsTeachingCase1.Name = "chkIsTeachingCase1";
            this.chkIsTeachingCase1.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkIsTeachingCase1.Properties.Appearance.Options.UseForeColor = true;
            this.chkIsTeachingCase1.Properties.Caption = "1.是";
            this.chkIsTeachingCase1.Properties.RadioGroupIndex = 2;
            this.chkIsTeachingCase1.Size = new System.Drawing.Size(52, 19);
            this.chkIsTeachingCase1.TabIndex = 9;
            this.chkIsTeachingCase1.TabStop = false;
            // 
            // labelControl2
            // 
            this.labelControl2.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl2.Location = new System.Drawing.Point(422, 167);
            this.labelControl2.Name = "labelControl2";
            this.labelControl2.Size = new System.Drawing.Size(48, 14);
            this.labelControl2.TabIndex = 144;
            this.labelControl2.Text = "示教病例";
            // 
            // txtIsFollowingYear
            // 
            this.txtIsFollowingYear.EditValue = "";
            this.txtIsFollowingYear.Location = new System.Drawing.Point(333, 165);
            this.txtIsFollowingYear.Name = "txtIsFollowingYear";
            this.txtIsFollowingYear.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtIsFollowingYear.Size = new System.Drawing.Size(55, 19);
            this.txtIsFollowingYear.TabIndex = 8;
            // 
            // labelControl10
            // 
            this.labelControl10.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl10.Location = new System.Drawing.Point(392, 167);
            this.labelControl10.Name = "labelControl10";
            this.labelControl10.Size = new System.Drawing.Size(12, 14);
            this.labelControl10.TabIndex = 142;
            this.labelControl10.Text = "年";
            // 
            // txtIsFollowingMon
            // 
            this.txtIsFollowingMon.Location = new System.Drawing.Point(272, 165);
            this.txtIsFollowingMon.Name = "txtIsFollowingMon";
            this.txtIsFollowingMon.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtIsFollowingMon.Size = new System.Drawing.Size(37, 19);
            this.txtIsFollowingMon.TabIndex = 7;
            // 
            // labelControl11
            // 
            this.labelControl11.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl11.Location = new System.Drawing.Point(315, 167);
            this.labelControl11.Name = "labelControl11";
            this.labelControl11.Size = new System.Drawing.Size(12, 14);
            this.labelControl11.TabIndex = 140;
            this.labelControl11.Text = "月";
            // 
            // labelControl8
            // 
            this.labelControl8.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl8.Location = new System.Drawing.Point(254, 167);
            this.labelControl8.Name = "labelControl8";
            this.labelControl8.Size = new System.Drawing.Size(12, 14);
            this.labelControl8.TabIndex = 139;
            this.labelControl8.Text = "周";
            // 
            // txtIsFollowingDay
            // 
            this.txtIsFollowingDay.Location = new System.Drawing.Point(213, 165);
            this.txtIsFollowingDay.Name = "txtIsFollowingDay";
            this.txtIsFollowingDay.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtIsFollowingDay.Size = new System.Drawing.Size(37, 19);
            this.txtIsFollowingDay.TabIndex = 6;
            // 
            // labelControl9
            // 
            this.labelControl9.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl9.Location = new System.Drawing.Point(157, 167);
            this.labelControl9.Name = "labelControl9";
            this.labelControl9.Size = new System.Drawing.Size(48, 14);
            this.labelControl9.TabIndex = 137;
            this.labelControl9.Text = "随诊期限";
            // 
            // chkIsFollowing2
            // 
            this.chkIsFollowing2.Location = new System.Drawing.Point(103, 165);
            this.chkIsFollowing2.Name = "chkIsFollowing2";
            this.chkIsFollowing2.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkIsFollowing2.Properties.Appearance.Options.UseForeColor = true;
            this.chkIsFollowing2.Properties.Caption = "2.否";
            this.chkIsFollowing2.Properties.RadioGroupIndex = 1;
            this.chkIsFollowing2.Size = new System.Drawing.Size(52, 19);
            this.chkIsFollowing2.TabIndex = 5;
            this.chkIsFollowing2.TabStop = false;
            // 
            // chkIsFollowing1
            // 
            this.chkIsFollowing1.Location = new System.Drawing.Point(52, 165);
            this.chkIsFollowing1.Name = "chkIsFollowing1";
            this.chkIsFollowing1.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkIsFollowing1.Properties.Appearance.Options.UseForeColor = true;
            this.chkIsFollowing1.Properties.Caption = "1.是";
            this.chkIsFollowing1.Properties.RadioGroupIndex = 1;
            this.chkIsFollowing1.Size = new System.Drawing.Size(52, 19);
            this.chkIsFollowing1.TabIndex = 4;
            this.chkIsFollowing1.TabStop = false;
            // 
            // labelControl1
            // 
            this.labelControl1.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl1.Location = new System.Drawing.Point(25, 167);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(24, 14);
            this.labelControl1.TabIndex = 125;
            this.labelControl1.Text = "随诊";
            // 
            // chkIsFirstCase2
            // 
            this.chkIsFirstCase2.Location = new System.Drawing.Point(313, 9);
            this.chkIsFirstCase2.Name = "chkIsFirstCase2";
            this.chkIsFirstCase2.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkIsFirstCase2.Properties.Appearance.Options.UseForeColor = true;
            this.chkIsFirstCase2.Properties.Caption = "2.否";
            this.chkIsFirstCase2.Properties.RadioGroupIndex = 0;
            this.chkIsFirstCase2.Size = new System.Drawing.Size(52, 19);
            this.chkIsFirstCase2.TabIndex = 2;
            this.chkIsFirstCase2.TabStop = false;
            // 
            // chkIsFirstCase1
            // 
            this.chkIsFirstCase1.Location = new System.Drawing.Point(251, 9);
            this.chkIsFirstCase1.Name = "chkIsFirstCase1";
            this.chkIsFirstCase1.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkIsFirstCase1.Properties.Appearance.Options.UseForeColor = true;
            this.chkIsFirstCase1.Properties.Caption = "1.是";
            this.chkIsFirstCase1.Properties.RadioGroupIndex = 0;
            this.chkIsFirstCase1.Size = new System.Drawing.Size(52, 19);
            this.chkIsFirstCase1.TabIndex = 1;
            this.chkIsFirstCase1.TabStop = false;
            // 
            // labelControl54
            // 
            this.labelControl54.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl54.Location = new System.Drawing.Point(25, 11);
            this.labelControl54.Name = "labelControl54";
            this.labelControl54.Size = new System.Drawing.Size(204, 14);
            this.labelControl54.TabIndex = 125;
            this.labelControl54.Text = "手术、治疗、检查、诊断为本院第一例";
            // 
            // labelControl20
            // 
            this.labelControl20.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl20.Location = new System.Drawing.Point(191, 243);
            this.labelControl20.Name = "labelControl20";
            this.labelControl20.Size = new System.Drawing.Size(12, 14);
            this.labelControl20.TabIndex = 157;
            this.labelControl20.Text = "ml";
            // 
            // seRbc
            // 
            this.seRbc.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.seRbc.Location = new System.Drawing.Point(131, 213);
            this.seRbc.Name = "seRbc";
            this.seRbc.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.seRbc.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.seRbc.Properties.IsFloatValue = false;
            this.seRbc.Properties.Mask.EditMask = "N00";
            this.seRbc.Properties.MaxValue = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.seRbc.Size = new System.Drawing.Size(55, 19);
            this.seRbc.TabIndex = 22;
            // 
            // txtOthers
            // 
            this.txtOthers.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtOthers.Location = new System.Drawing.Point(131, 241);
            this.txtOthers.Name = "txtOthers";
            this.txtOthers.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtOthers.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.txtOthers.Properties.IsFloatValue = false;
            this.txtOthers.Properties.Mask.EditMask = "N00";
            this.txtOthers.Properties.MaxValue = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.txtOthers.Size = new System.Drawing.Size(55, 19);
            this.txtOthers.TabIndex = 22;
            // 
            // UCOthers
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(239)))), ((int)(((byte)(255)))));
            this.Controls.Add(this.chkBloodReaction3);
            this.Controls.Add(this.chkRh3);
            this.Controls.Add(this.chkBloodReaction2);
            this.Controls.Add(this.chkBlood5);
            this.Controls.Add(this.chkBloodReaction1);
            this.Controls.Add(this.chkRh2);
            this.Controls.Add(this.chkIsTeachingCase2);
            this.Controls.Add(this.chkRh1);
            this.Controls.Add(this.chkBlood4);
            this.Controls.Add(this.chkIsTeachingCase1);
            this.Controls.Add(this.chkBlood3);
            this.Controls.Add(this.chkBlood2);
            this.Controls.Add(this.chkIsFollowing2);
            this.Controls.Add(this.chkBlood1);
            this.Controls.Add(this.chkIsFollowing1);
            this.Controls.Add(this.panelControl7);
            this.Controls.Add(this.seWb);
            this.Controls.Add(this.labelControl54);
            this.Controls.Add(this.sePlasma);
            this.Controls.Add(this.sePlt);
            this.Controls.Add(this.labelControl1);
            this.Controls.Add(this.txtOthers);
            this.Controls.Add(this.seRbc);
            this.Controls.Add(this.labelControl9);
            this.Controls.Add(this.chkIsFirstCase2);
            this.Controls.Add(this.chkIsFirstCase1);
            this.Controls.Add(this.labelControl19);
            this.Controls.Add(this.txtIsFollowingDay);
            this.Controls.Add(this.labelControl17);
            this.Controls.Add(this.labelControl8);
            this.Controls.Add(this.labelControl18);
            this.Controls.Add(this.labelControl11);
            this.Controls.Add(this.labelControl20);
            this.Controls.Add(this.labelControl15);
            this.Controls.Add(this.txtIsFollowingMon);
            this.Controls.Add(this.labelControl16);
            this.Controls.Add(this.labelControl10);
            this.Controls.Add(this.labelControl6);
            this.Controls.Add(this.txtIsFollowingYear);
            this.Controls.Add(this.labelControl7);
            this.Controls.Add(this.labelControl2);
            this.Controls.Add(this.labelControl13);
            this.Controls.Add(this.labelControl14);
            this.Controls.Add(this.labelControl3);
            this.Controls.Add(this.labelControl12);
            this.Controls.Add(this.labelControl4);
            this.Controls.Add(this.labelControl5);
            this.Name = "UCOthers";
            this.Size = new System.Drawing.Size(620, 275);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.UCOthers_Paint);
            ((System.ComponentModel.ISupportInitialize)(this.panelControl7)).EndInit();
            this.panelControl7.ResumeLayout(false);
            this.panelControl7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.seWb.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sePlasma.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sePlt.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkBloodReaction3.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkBloodReaction2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkBloodReaction1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkRh3.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkRh2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkRh1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkBlood5.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkBlood4.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkBlood3.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkBlood2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkBlood1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkIsTeachingCase2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkIsTeachingCase1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtIsFollowingYear.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtIsFollowingMon.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtIsFollowingDay.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkIsFollowing2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkIsFollowing1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkIsFirstCase2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkIsFirstCase1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.seRbc.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtOthers.Properties)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevExpress.XtraEditors.CheckEdit chkIsFirstCase2;
        private DevExpress.XtraEditors.CheckEdit chkIsFirstCase1;
        private DevExpress.XtraEditors.LabelControl labelControl54;
        private DevExpress.XtraEditors.CheckEdit chkIsFollowing2;
        private DevExpress.XtraEditors.CheckEdit chkIsFollowing1;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private DevExpress.XtraEditors.TextEdit txtIsFollowingYear;
        private DevExpress.XtraEditors.LabelControl labelControl10;
        private DevExpress.XtraEditors.TextEdit txtIsFollowingMon;
        private DevExpress.XtraEditors.LabelControl labelControl11;
        private DevExpress.XtraEditors.LabelControl labelControl8;
        private DevExpress.XtraEditors.TextEdit txtIsFollowingDay;
        private DevExpress.XtraEditors.LabelControl labelControl9;
        private DevExpress.XtraEditors.CheckEdit chkIsTeachingCase2;
        private DevExpress.XtraEditors.CheckEdit chkIsTeachingCase1;
        private DevExpress.XtraEditors.LabelControl labelControl2;
        private DevExpress.XtraEditors.CheckEdit chkBlood3;
        private DevExpress.XtraEditors.CheckEdit chkBlood2;
        private DevExpress.XtraEditors.CheckEdit chkBlood1;
        private DevExpress.XtraEditors.LabelControl labelControl3;
        private DevExpress.XtraEditors.CheckEdit chkBlood5;
        private DevExpress.XtraEditors.CheckEdit chkBlood4;
        private DevExpress.XtraEditors.CheckEdit chkRh3;
        private DevExpress.XtraEditors.CheckEdit chkRh2;
        private DevExpress.XtraEditors.CheckEdit chkRh1;
        private DevExpress.XtraEditors.LabelControl labelControl4;
        private DevExpress.XtraEditors.CheckEdit chkBloodReaction2;
        private DevExpress.XtraEditors.CheckEdit chkBloodReaction1;
        private DevExpress.XtraEditors.LabelControl labelControl5;
        private DevExpress.XtraEditors.CheckEdit chkBloodReaction3;
        private DevExpress.XtraEditors.LabelControl labelControl12;
        private DevExpress.XtraEditors.LabelControl labelControl6;
        private DevExpress.XtraEditors.LabelControl labelControl7;
        private DevExpress.XtraEditors.LabelControl labelControl13;
        private DevExpress.XtraEditors.LabelControl labelControl14;
        private DevExpress.XtraEditors.LabelControl labelControl15;
        private DevExpress.XtraEditors.LabelControl labelControl16;
        private DevExpress.XtraEditors.LabelControl labelControl17;
        private DevExpress.XtraEditors.LabelControl labelControl18;
        private DevExpress.XtraEditors.LabelControl labelControl19;
        private DevExpress.XtraEditors.SpinEdit sePlasma;
        private DevExpress.XtraEditors.SpinEdit sePlt;
        private DevExpress.XtraEditors.SpinEdit seWb;
        private DevExpress.XtraEditors.PanelControl panelControl7;
        private DevExpress.XtraEditors.SimpleButton btnFee;
        private DevExpress.XtraEditors.LabelControl labelControl26;
        private DevExpress.XtraEditors.LabelControl labelControl29;
        private DevExpress.XtraEditors.LabelControl lblTotal;
        private DevExpress.XtraEditors.LabelControl labelControl31;
        private DevExpress.XtraEditors.LabelControl labelControl33;
        private DevExpress.XtraEditors.LabelControl lblCPMedical;
        private DevExpress.XtraEditors.LabelControl lblWMedical;
        private DevExpress.XtraEditors.LabelControl lblCare;
        private DevExpress.XtraEditors.LabelControl lblBed;
        private DevExpress.XtraEditors.LabelControl lblCMedical;
        private DevExpress.XtraEditors.LabelControl lblAssay;
        private DevExpress.XtraEditors.LabelControl labelControl41;
        private DevExpress.XtraEditors.LabelControl lblRadiate;
        private DevExpress.XtraEditors.LabelControl lblRis;
        private DevExpress.XtraEditors.LabelControl labelControl53;
        private DevExpress.XtraEditors.LabelControl lblOthers;
        private DevExpress.XtraEditors.LabelControl labelControl62;
        private DevExpress.XtraEditors.LabelControl lblRate;
        private DevExpress.XtraEditors.LabelControl labelControl64;
        private DevExpress.XtraEditors.LabelControl lblFollwBed;
        private DevExpress.XtraEditors.LabelControl labelControl60;
        private DevExpress.XtraEditors.LabelControl lblBaby;
        private DevExpress.XtraEditors.LabelControl labelControl58;
        private DevExpress.XtraEditors.LabelControl lblAnaesthesia;
        private DevExpress.XtraEditors.LabelControl labelControl56;
        private DevExpress.XtraEditors.LabelControl lblAccouche;
        private DevExpress.XtraEditors.LabelControl labelControl51;
        private DevExpress.XtraEditors.LabelControl lblOperation;
        private DevExpress.XtraEditors.LabelControl labelControl49;
        private DevExpress.XtraEditors.LabelControl lblMecical;
        private DevExpress.XtraEditors.LabelControl labelControl47;
        private DevExpress.XtraEditors.LabelControl lblBlood;
        private DevExpress.XtraEditors.LabelControl labelControl45;
        private DevExpress.XtraEditors.LabelControl lblOx;
        private DevExpress.XtraEditors.LabelControl labelControl43;
        private DevExpress.XtraEditors.LabelControl labelControl39;
        private DevExpress.XtraEditors.LabelControl labelControl37;
        private DevExpress.XtraEditors.LabelControl labelControl35;
        private DevExpress.XtraEditors.LabelControl labelZhiLiao;
        private DevExpress.XtraEditors.LabelControl labelControl28;
        private DevExpress.XtraEditors.LabelControl labelControl20;
        private DevExpress.XtraEditors.SpinEdit seRbc;
        private DevExpress.XtraEditors.SpinEdit txtOthers;
    }
}
