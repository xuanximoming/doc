﻿namespace YidanSoft.Core.IEMMainPage
{
    partial class Print_UCObstetricsBaby
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.hLineEx8 = new YidanSoft.Core.IEMMainPage.HLineEx();
            this.hLineEx7 = new YidanSoft.Core.IEMMainPage.HLineEx();
            this.hLineEx3 = new YidanSoft.Core.IEMMainPage.HLineEx();
            this.labelControl17 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl18 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl3 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl4 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl5 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl6 = new DevExpress.XtraEditors.LabelControl();
            this.txtMidwifery = new DevExpress.XtraEditors.TextEdit();
            this.labTC = new DevExpress.XtraEditors.LabelControl();
            this.labCC = new DevExpress.XtraEditors.LabelControl();
            this.labTB = new DevExpress.XtraEditors.LabelControl();
            this.labCFHYPLD = new DevExpress.XtraEditors.LabelControl();
            this.labelControl10 = new DevExpress.XtraEditors.LabelControl();
            this.labSex = new DevExpress.XtraEditors.LabelControl();
            this.labelControl12 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl13 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl14 = new DevExpress.XtraEditors.LabelControl();
            this.labAPJ = new DevExpress.XtraEditors.LabelControl();
            this.labelControl16 = new DevExpress.XtraEditors.LabelControl();
            this.txtheigh = new DevExpress.XtraEditors.TextEdit();
            this.labelControl19 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl20 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl21 = new DevExpress.XtraEditors.LabelControl();
            this.txtweight = new DevExpress.XtraEditors.TextEdit();
            this.labelControl22 = new DevExpress.XtraEditors.LabelControl();
            this.labCCQK = new DevExpress.XtraEditors.LabelControl();
            this.labelControl24 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl25 = new DevExpress.XtraEditors.LabelControl();
            this.txtBithDay = new DevExpress.XtraEditors.TextEdit();
            this.labelControl26 = new DevExpress.XtraEditors.LabelControl();
            this.labFMFS = new DevExpress.XtraEditors.LabelControl();
            this.labelControl28 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl29 = new DevExpress.XtraEditors.LabelControl();
            this.labCYQK = new DevExpress.XtraEditors.LabelControl();
            this.labelControl31 = new DevExpress.XtraEditors.LabelControl();
            ((System.ComponentModel.ISupportInitialize)(this.txtMidwifery.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtheigh.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtweight.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtBithDay.Properties)).BeginInit();
            this.SuspendLayout();
            // 
            // hLineEx8
            // 
            this.hLineEx8.BackColor = System.Drawing.Color.White;
            this.hLineEx8.IsBold = false;
            this.hLineEx8.Location = new System.Drawing.Point(5, 229);
            this.hLineEx8.Name = "hLineEx8";
            this.hLineEx8.Size = new System.Drawing.Size(658, 1);
            this.hLineEx8.TabIndex = 155;
            this.hLineEx8.Text = "hLineEx3";
            // 
            // hLineEx7
            // 
            this.hLineEx7.BackColor = System.Drawing.Color.White;
            this.hLineEx7.IsBold = false;
            this.hLineEx7.Location = new System.Drawing.Point(5, 206);
            this.hLineEx7.Name = "hLineEx7";
            this.hLineEx7.Size = new System.Drawing.Size(658, 1);
            this.hLineEx7.TabIndex = 154;
            this.hLineEx7.Text = "hLineEx3";
            // 
            // hLineEx3
            // 
            this.hLineEx3.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton;
            this.hLineEx3.BackColor = System.Drawing.Color.White;
            this.hLineEx3.IsBold = false;
            this.hLineEx3.Location = new System.Drawing.Point(5, 50);
            this.hLineEx3.Name = "hLineEx3";
            this.hLineEx3.Size = new System.Drawing.Size(658, 1);
            this.hLineEx3.TabIndex = 151;
            this.hLineEx3.Text = "hLineEx3";
            // 
            // labelControl17
            // 
            this.labelControl17.Appearance.Font = new System.Drawing.Font("华文楷体", 21.75F, System.Drawing.FontStyle.Bold);
            this.labelControl17.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl17.Location = new System.Drawing.Point(205, 11);
            this.labelControl17.Name = "labelControl17";
            this.labelControl17.Size = new System.Drawing.Size(296, 33);
            this.labelControl17.TabIndex = 157;
            this.labelControl17.Text = "产 科 产 妇 婴 儿 情 况";
            // 
            // labelControl18
            // 
            this.labelControl18.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl18.Location = new System.Drawing.Point(14, 72);
            this.labelControl18.Name = "labelControl18";
            this.labelControl18.Size = new System.Drawing.Size(24, 14);
            this.labelControl18.TabIndex = 157;
            this.labelControl18.Text = "胎次";
            // 
            // labelControl1
            // 
            this.labelControl1.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl1.Location = new System.Drawing.Point(73, 72);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(24, 14);
            this.labelControl1.TabIndex = 157;
            this.labelControl1.Text = "产次";
            // 
            // labelControl2
            // 
            this.labelControl2.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl2.Location = new System.Drawing.Point(126, 72);
            this.labelControl2.Name = "labelControl2";
            this.labelControl2.Size = new System.Drawing.Size(24, 14);
            this.labelControl2.TabIndex = 157;
            this.labelControl2.Text = "胎别";
            // 
            // labelControl3
            // 
            this.labelControl3.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl3.Location = new System.Drawing.Point(176, 72);
            this.labelControl3.Name = "labelControl3";
            this.labelControl3.Size = new System.Drawing.Size(97, 14);
            this.labelControl3.TabIndex = 157;
            this.labelControl3.Text = "（1单  2双  3多）";
            // 
            // labelControl4
            // 
            this.labelControl4.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl4.Location = new System.Drawing.Point(280, 72);
            this.labelControl4.Name = "labelControl4";
            this.labelControl4.Size = new System.Drawing.Size(84, 14);
            this.labelControl4.TabIndex = 157;
            this.labelControl4.Text = "产妇会阴破裂度";
            // 
            // labelControl5
            // 
            this.labelControl5.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl5.Location = new System.Drawing.Point(387, 72);
            this.labelControl5.Name = "labelControl5";
            this.labelControl5.Size = new System.Drawing.Size(97, 14);
            this.labelControl5.TabIndex = 157;
            this.labelControl5.Text = "（1 I  2 II  3 III）";
            // 
            // labelControl6
            // 
            this.labelControl6.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl6.Location = new System.Drawing.Point(490, 72);
            this.labelControl6.Name = "labelControl6";
            this.labelControl6.Size = new System.Drawing.Size(36, 14);
            this.labelControl6.TabIndex = 157;
            this.labelControl6.Text = "接产者";
            // 
            // txtMidwifery
            // 
            this.txtMidwifery.EditValue = "";
            this.txtMidwifery.Location = new System.Drawing.Point(532, 70);
            this.txtMidwifery.Name = "txtMidwifery";
            this.txtMidwifery.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtMidwifery.Size = new System.Drawing.Size(129, 19);
            this.txtMidwifery.TabIndex = 162;
            // 
            // labTC
            // 
            this.labTC.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Office2003;
            this.labTC.Location = new System.Drawing.Point(44, 71);
            this.labTC.Name = "labTC";
            this.labTC.Size = new System.Drawing.Size(14, 16);
            this.labTC.TabIndex = 163;
            this.labTC.Text = "   ";
            // 
            // labCC
            // 
            this.labCC.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Office2003;
            this.labCC.Location = new System.Drawing.Point(103, 71);
            this.labCC.Name = "labCC";
            this.labCC.Size = new System.Drawing.Size(14, 16);
            this.labCC.TabIndex = 163;
            this.labCC.Text = "   ";
            // 
            // labTB
            // 
            this.labTB.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Office2003;
            this.labTB.Location = new System.Drawing.Point(156, 71);
            this.labTB.Name = "labTB";
            this.labTB.Size = new System.Drawing.Size(14, 16);
            this.labTB.TabIndex = 163;
            this.labTB.Text = "   ";
            // 
            // labCFHYPLD
            // 
            this.labCFHYPLD.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Office2003;
            this.labCFHYPLD.Location = new System.Drawing.Point(367, 71);
            this.labCFHYPLD.Name = "labCFHYPLD";
            this.labCFHYPLD.Size = new System.Drawing.Size(14, 16);
            this.labCFHYPLD.TabIndex = 163;
            this.labCFHYPLD.Text = "   ";
            // 
            // labelControl10
            // 
            this.labelControl10.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl10.Location = new System.Drawing.Point(14, 103);
            this.labelControl10.Name = "labelControl10";
            this.labelControl10.Size = new System.Drawing.Size(24, 14);
            this.labelControl10.TabIndex = 157;
            this.labelControl10.Text = "性别";
            // 
            // labSex
            // 
            this.labSex.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Office2003;
            this.labSex.Location = new System.Drawing.Point(44, 102);
            this.labSex.Name = "labSex";
            this.labSex.Size = new System.Drawing.Size(14, 16);
            this.labSex.TabIndex = 163;
            this.labSex.Text = "   ";
            // 
            // labelControl12
            // 
            this.labelControl12.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl12.Location = new System.Drawing.Point(55, 103);
            this.labelControl12.Name = "labelControl12";
            this.labelControl12.Size = new System.Drawing.Size(78, 14);
            this.labelControl12.TabIndex = 157;
            this.labelControl12.Text = "（1 男  2 女）";
            // 
            // labelControl13
            // 
            this.labelControl13.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl13.Location = new System.Drawing.Point(139, 103);
            this.labelControl13.Name = "labelControl13";
            this.labelControl13.Size = new System.Drawing.Size(60, 14);
            this.labelControl13.TabIndex = 157;
            this.labelControl13.Text = "阿帕加评加";
            // 
            // labelControl14
            // 
            this.labelControl14.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl14.Location = new System.Drawing.Point(225, 103);
            this.labelControl14.Name = "labelControl14";
            this.labelControl14.Size = new System.Drawing.Size(95, 14);
            this.labelControl14.TabIndex = 157;
            this.labelControl14.Text = "（1一分...A+分）";
            // 
            // labAPJ
            // 
            this.labAPJ.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Office2003;
            this.labAPJ.Location = new System.Drawing.Point(205, 102);
            this.labAPJ.Name = "labAPJ";
            this.labAPJ.Size = new System.Drawing.Size(14, 16);
            this.labAPJ.TabIndex = 163;
            this.labAPJ.Text = "   ";
            // 
            // labelControl16
            // 
            this.labelControl16.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl16.Location = new System.Drawing.Point(389, 103);
            this.labelControl16.Name = "labelControl16";
            this.labelControl16.Size = new System.Drawing.Size(24, 14);
            this.labelControl16.TabIndex = 157;
            this.labelControl16.Text = "身长";
            // 
            // txtheigh
            // 
            this.txtheigh.EditValue = "";
            this.txtheigh.Location = new System.Drawing.Point(419, 101);
            this.txtheigh.Name = "txtheigh";
            this.txtheigh.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtheigh.Size = new System.Drawing.Size(71, 19);
            this.txtheigh.TabIndex = 162;
            // 
            // labelControl19
            // 
            this.labelControl19.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl19.Location = new System.Drawing.Point(493, 106);
            this.labelControl19.Name = "labelControl19";
            this.labelControl19.Size = new System.Drawing.Size(16, 14);
            this.labelControl19.TabIndex = 157;
            this.labelControl19.Text = "CM";
            // 
            // labelControl20
            // 
            this.labelControl20.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl20.Location = new System.Drawing.Point(532, 104);
            this.labelControl20.Name = "labelControl20";
            this.labelControl20.Size = new System.Drawing.Size(24, 14);
            this.labelControl20.TabIndex = 157;
            this.labelControl20.Text = "体重";
            // 
            // labelControl21
            // 
            this.labelControl21.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl21.Location = new System.Drawing.Point(643, 106);
            this.labelControl21.Name = "labelControl21";
            this.labelControl21.Size = new System.Drawing.Size(8, 14);
            this.labelControl21.TabIndex = 157;
            this.labelControl21.Text = "G";
            // 
            // txtweight
            // 
            this.txtweight.EditValue = "";
            this.txtweight.Location = new System.Drawing.Point(562, 102);
            this.txtweight.Name = "txtweight";
            this.txtweight.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtweight.Size = new System.Drawing.Size(73, 19);
            this.txtweight.TabIndex = 162;
            // 
            // labelControl22
            // 
            this.labelControl22.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl22.Location = new System.Drawing.Point(14, 134);
            this.labelControl22.Name = "labelControl22";
            this.labelControl22.Size = new System.Drawing.Size(48, 14);
            this.labelControl22.TabIndex = 157;
            this.labelControl22.Text = "产出情况";
            // 
            // labCCQK
            // 
            this.labCCQK.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Office2003;
            this.labCCQK.Location = new System.Drawing.Point(68, 133);
            this.labCCQK.Name = "labCCQK";
            this.labCCQK.Size = new System.Drawing.Size(14, 16);
            this.labCCQK.TabIndex = 163;
            this.labCCQK.Text = "   ";
            // 
            // labelControl24
            // 
            this.labelControl24.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl24.Location = new System.Drawing.Point(85, 134);
            this.labelControl24.Name = "labelControl24";
            this.labelControl24.Size = new System.Drawing.Size(188, 14);
            this.labelControl24.TabIndex = 157;
            this.labelControl24.Text = "（1 活产  2 死产  3 死胎  4 畸形）";
            // 
            // labelControl25
            // 
            this.labelControl25.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl25.Location = new System.Drawing.Point(387, 134);
            this.labelControl25.Name = "labelControl25";
            this.labelControl25.Size = new System.Drawing.Size(48, 14);
            this.labelControl25.TabIndex = 157;
            this.labelControl25.Text = "出生时间";
            // 
            // txtBithDay
            // 
            this.txtBithDay.EditValue = "";
            this.txtBithDay.Location = new System.Drawing.Point(441, 132);
            this.txtBithDay.Name = "txtBithDay";
            this.txtBithDay.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtBithDay.Size = new System.Drawing.Size(220, 19);
            this.txtBithDay.TabIndex = 162;
            // 
            // labelControl26
            // 
            this.labelControl26.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl26.Location = new System.Drawing.Point(14, 166);
            this.labelControl26.Name = "labelControl26";
            this.labelControl26.Size = new System.Drawing.Size(48, 14);
            this.labelControl26.TabIndex = 157;
            this.labelControl26.Text = "分娩方式";
            // 
            // labFMFS
            // 
            this.labFMFS.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Office2003;
            this.labFMFS.Location = new System.Drawing.Point(68, 165);
            this.labFMFS.Name = "labFMFS";
            this.labFMFS.Size = new System.Drawing.Size(14, 16);
            this.labFMFS.TabIndex = 163;
            this.labFMFS.Text = "   ";
            // 
            // labelControl28
            // 
            this.labelControl28.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl28.Location = new System.Drawing.Point(85, 166);
            this.labelControl28.Name = "labelControl28";
            this.labelControl28.Size = new System.Drawing.Size(286, 14);
            this.labelControl28.TabIndex = 157;
            this.labelControl28.Text = "（1 自然  2 侧+吸  3 产钳  4 臂牵引  5剖宫  6其他）";
            // 
            // labelControl29
            // 
            this.labelControl29.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl29.Location = new System.Drawing.Point(422, 166);
            this.labelControl29.Name = "labelControl29";
            this.labelControl29.Size = new System.Drawing.Size(48, 14);
            this.labelControl29.TabIndex = 157;
            this.labelControl29.Text = "出院情况";
            // 
            // labCYQK
            // 
            this.labCYQK.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Office2003;
            this.labCYQK.Location = new System.Drawing.Point(476, 165);
            this.labCYQK.Name = "labCYQK";
            this.labCYQK.Size = new System.Drawing.Size(14, 16);
            this.labCYQK.TabIndex = 163;
            this.labCYQK.Text = "   ";
            // 
            // labelControl31
            // 
            this.labelControl31.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl31.Location = new System.Drawing.Point(496, 166);
            this.labelControl31.Name = "labelControl31";
            this.labelControl31.Size = new System.Drawing.Size(165, 14);
            this.labelControl31.TabIndex = 157;
            this.labelControl31.Text = "（1 正常  2 有病  3交叉感染）";
            // 
            // Print_UCObstetricsBaby
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(239)))), ((int)(((byte)(255)))));
            this.Controls.Add(this.labCFHYPLD);
            this.Controls.Add(this.labTB);
            this.Controls.Add(this.labCC);
            this.Controls.Add(this.labAPJ);
            this.Controls.Add(this.labCYQK);
            this.Controls.Add(this.labFMFS);
            this.Controls.Add(this.labCCQK);
            this.Controls.Add(this.labSex);
            this.Controls.Add(this.labTC);
            this.Controls.Add(this.txtweight);
            this.Controls.Add(this.txtBithDay);
            this.Controls.Add(this.txtheigh);
            this.Controls.Add(this.txtMidwifery);
            this.Controls.Add(this.labelControl6);
            this.Controls.Add(this.labelControl5);
            this.Controls.Add(this.labelControl4);
            this.Controls.Add(this.labelControl3);
            this.Controls.Add(this.labelControl2);
            this.Controls.Add(this.labelControl1);
            this.Controls.Add(this.labelControl13);
            this.Controls.Add(this.labelControl29);
            this.Controls.Add(this.labelControl26);
            this.Controls.Add(this.labelControl22);
            this.Controls.Add(this.labelControl10);
            this.Controls.Add(this.labelControl21);
            this.Controls.Add(this.labelControl19);
            this.Controls.Add(this.labelControl20);
            this.Controls.Add(this.labelControl25);
            this.Controls.Add(this.labelControl16);
            this.Controls.Add(this.labelControl14);
            this.Controls.Add(this.labelControl28);
            this.Controls.Add(this.labelControl31);
            this.Controls.Add(this.labelControl24);
            this.Controls.Add(this.labelControl12);
            this.Controls.Add(this.labelControl18);
            this.Controls.Add(this.labelControl17);
            this.Controls.Add(this.hLineEx8);
            this.Controls.Add(this.hLineEx7);
            this.Controls.Add(this.hLineEx3);
            this.Name = "Print_UCObstetricsBaby";
            this.Size = new System.Drawing.Size(666, 236);
            ((System.ComponentModel.ISupportInitialize)(this.txtMidwifery.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtheigh.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtweight.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtBithDay.Properties)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private HLineEx hLineEx8;
        private HLineEx hLineEx7;
        private HLineEx hLineEx3;
        private DevExpress.XtraEditors.LabelControl labelControl17;
        private DevExpress.XtraEditors.LabelControl labelControl18;
        private DevExpress.XtraEditors.LabelControl labelControl6;
        private DevExpress.XtraEditors.LabelControl labelControl5;
        private DevExpress.XtraEditors.LabelControl labelControl4;
        private DevExpress.XtraEditors.LabelControl labelControl3;
        private DevExpress.XtraEditors.LabelControl labelControl2;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private DevExpress.XtraEditors.TextEdit txtMidwifery;
        private DevExpress.XtraEditors.LabelControl labCFHYPLD;
        private DevExpress.XtraEditors.LabelControl labTB;
        private DevExpress.XtraEditors.LabelControl labCC;
        private DevExpress.XtraEditors.LabelControl labTC;
        private DevExpress.XtraEditors.LabelControl labSex;
        private DevExpress.XtraEditors.LabelControl labelControl13;
        private DevExpress.XtraEditors.LabelControl labelControl10;
        private DevExpress.XtraEditors.LabelControl labelControl12;
        private DevExpress.XtraEditors.LabelControl labAPJ;
        private DevExpress.XtraEditors.TextEdit txtweight;
        private DevExpress.XtraEditors.TextEdit txtheigh;
        private DevExpress.XtraEditors.LabelControl labelControl21;
        private DevExpress.XtraEditors.LabelControl labelControl19;
        private DevExpress.XtraEditors.LabelControl labelControl20;
        private DevExpress.XtraEditors.LabelControl labelControl16;
        private DevExpress.XtraEditors.LabelControl labelControl14;
        private DevExpress.XtraEditors.LabelControl labCCQK;
        private DevExpress.XtraEditors.TextEdit txtBithDay;
        private DevExpress.XtraEditors.LabelControl labelControl22;
        private DevExpress.XtraEditors.LabelControl labelControl25;
        private DevExpress.XtraEditors.LabelControl labelControl24;
        private DevExpress.XtraEditors.LabelControl labCYQK;
        private DevExpress.XtraEditors.LabelControl labFMFS;
        private DevExpress.XtraEditors.LabelControl labelControl29;
        private DevExpress.XtraEditors.LabelControl labelControl26;
        private DevExpress.XtraEditors.LabelControl labelControl28;
        private DevExpress.XtraEditors.LabelControl labelControl31;
    }
}
