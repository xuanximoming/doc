﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraEditors;

namespace DrectSoft.Core.IEMMainPage_JS
{
    /// <summary>
    /// 浦口所需诊断追加栏位
    /// add by ywk 2012年11月28日17:47:52
    /// </summary>
    public partial class UCAPPENDDIAG : DevExpress.XtraEditors.XtraUserControl
    {
        public UCAPPENDDIAG()
        {
            InitializeComponent();
        }
    }
}
