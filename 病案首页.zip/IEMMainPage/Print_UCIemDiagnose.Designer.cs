﻿namespace YidanSoft.Core.IEMMainPage
{
    partial class Print_UCIemDiagnose
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.txtPathologyName = new DevExpress.XtraEditors.TextEdit();
            this.labelControl116 = new DevExpress.XtraEditors.LabelControl();
            this.lueInDiag = new YidanSoft.Common.Library.LookUpEditor();
            this.labelControl59 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl58 = new DevExpress.XtraEditors.LabelControl();
            this.lueOutDiag = new YidanSoft.Common.Library.LookUpEditor();
            this.labelControl57 = new DevExpress.XtraEditors.LabelControl();
            this.labAdmitInfo = new DevExpress.XtraEditors.LabelControl();
            this.labelControl13 = new DevExpress.XtraEditors.LabelControl();
            this.txtIn_Check_Date = new DevExpress.XtraEditors.TextEdit();
            this.labelControl14 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl15 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl16 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl17 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl18 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl19 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl20 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl21 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl22 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl23 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl24 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl25 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl26 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl27 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl28 = new DevExpress.XtraEditors.LabelControl();
            this.chkHBsAg = new DevExpress.XtraEditors.LabelControl();
            this.labelControl30 = new DevExpress.XtraEditors.LabelControl();
            this.chkHCV = new DevExpress.XtraEditors.LabelControl();
            this.labelControl32 = new DevExpress.XtraEditors.LabelControl();
            this.chkHIV = new DevExpress.XtraEditors.LabelControl();
            this.labelControl34 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl35 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl36 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl37 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl38 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl39 = new DevExpress.XtraEditors.LabelControl();
            this.chkOpdIpd = new DevExpress.XtraEditors.LabelControl();
            this.chkInOut = new DevExpress.XtraEditors.LabelControl();
            this.chkBeforeAfter = new DevExpress.XtraEditors.LabelControl();
            this.chkClinical = new DevExpress.XtraEditors.LabelControl();
            this.labelControl44 = new DevExpress.XtraEditors.LabelControl();
            this.chkPacsPathology = new DevExpress.XtraEditors.LabelControl();
            this.labelControl46 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl47 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl48 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl49 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl50 = new DevExpress.XtraEditors.LabelControl();
            this.seSaveTimes = new DevExpress.XtraEditors.TextEdit();
            this.seSuccessTimes = new DevExpress.XtraEditors.TextEdit();
            this.labelControl51 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl52 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl53 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl55 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl56 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl60 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl61 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl62 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl63 = new DevExpress.XtraEditors.LabelControl();
            this.labMedical_Quality = new DevExpress.XtraEditors.LabelControl();
            this.labelControl65 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl66 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl67 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl68 = new DevExpress.XtraEditors.LabelControl();
            this.textEdit3 = new DevExpress.XtraEditors.TextEdit();
            this.txtAllergicDrug = new DevExpress.XtraEditors.TextEdit();
            this.labDiagnosis_Name1 = new DevExpress.XtraEditors.LabelControl();
            this.labDiagnosis_Name2 = new DevExpress.XtraEditors.LabelControl();
            this.labDiagnosis_Name3 = new DevExpress.XtraEditors.LabelControl();
            this.labDiagnosis_Name4 = new DevExpress.XtraEditors.LabelControl();
            this.labDiagnosis_Name5 = new DevExpress.XtraEditors.LabelControl();
            this.labDiagnosis_Name6 = new DevExpress.XtraEditors.LabelControl();
            this.labDiagnosis_Name7 = new DevExpress.XtraEditors.LabelControl();
            this.chkStatus_1_1 = new System.Windows.Forms.CheckBox();
            this.chkStatus_2_1 = new System.Windows.Forms.CheckBox();
            this.chkStatus_3_1 = new System.Windows.Forms.CheckBox();
            this.chkStatus_5_1 = new System.Windows.Forms.CheckBox();
            this.chkStatus_4_1 = new System.Windows.Forms.CheckBox();
            this.labDiagnosis_Code1 = new DevExpress.XtraEditors.LabelControl();
            this.chkStatus_1_2 = new System.Windows.Forms.CheckBox();
            this.chkStatus_2_2 = new System.Windows.Forms.CheckBox();
            this.chkStatus_3_2 = new System.Windows.Forms.CheckBox();
            this.chkStatus_5_2 = new System.Windows.Forms.CheckBox();
            this.chkStatus_4_2 = new System.Windows.Forms.CheckBox();
            this.labDiagnosis_Code2 = new DevExpress.XtraEditors.LabelControl();
            this.chkStatus_3_3 = new System.Windows.Forms.CheckBox();
            this.chkStatus_5_3 = new System.Windows.Forms.CheckBox();
            this.chkStatus_2_3 = new System.Windows.Forms.CheckBox();
            this.chkStatus_4_3 = new System.Windows.Forms.CheckBox();
            this.chkStatus_1_3 = new System.Windows.Forms.CheckBox();
            this.labDiagnosis_Code3 = new DevExpress.XtraEditors.LabelControl();
            this.chkStatus_2_4 = new System.Windows.Forms.CheckBox();
            this.chkStatus_5_4 = new System.Windows.Forms.CheckBox();
            this.chkStatus_4_4 = new System.Windows.Forms.CheckBox();
            this.chkStatus_3_4 = new System.Windows.Forms.CheckBox();
            this.chkStatus_1_4 = new System.Windows.Forms.CheckBox();
            this.labDiagnosis_Code4 = new DevExpress.XtraEditors.LabelControl();
            this.chkStatus_4_5 = new System.Windows.Forms.CheckBox();
            this.chkStatus_5_5 = new System.Windows.Forms.CheckBox();
            this.chkStatus_3_5 = new System.Windows.Forms.CheckBox();
            this.chkStatus_2_5 = new System.Windows.Forms.CheckBox();
            this.chkStatus_1_5 = new System.Windows.Forms.CheckBox();
            this.labDiagnosis_Code5 = new DevExpress.XtraEditors.LabelControl();
            this.chkStatus_3_7 = new System.Windows.Forms.CheckBox();
            this.chkStatus_5_7 = new System.Windows.Forms.CheckBox();
            this.chkStatus_2_7 = new System.Windows.Forms.CheckBox();
            this.chkStatus_4_7 = new System.Windows.Forms.CheckBox();
            this.chkStatus_1_7 = new System.Windows.Forms.CheckBox();
            this.labDiagnosis_Code7 = new DevExpress.XtraEditors.LabelControl();
            this.chkStatus_2_6 = new System.Windows.Forms.CheckBox();
            this.chkStatus_5_6 = new System.Windows.Forms.CheckBox();
            this.chkStatus_4_6 = new System.Windows.Forms.CheckBox();
            this.chkStatus_3_6 = new System.Windows.Forms.CheckBox();
            this.chkStatus_1_6 = new System.Windows.Forms.CheckBox();
            this.labDiagnosis_Code6 = new DevExpress.XtraEditors.LabelControl();
            this.lueBmy = new YidanSoft.Common.Library.LookUpEditor();
            this.lueSxys = new YidanSoft.Common.Library.LookUpEditor();
            this.lueYjs = new YidanSoft.Common.Library.LookUpEditor();
            this.lueJxys = new YidanSoft.Common.Library.LookUpEditor();
            this.lueZyys = new YidanSoft.Common.Library.LookUpEditor();
            this.lueZzys = new YidanSoft.Common.Library.LookUpEditor();
            this.lueZrys = new YidanSoft.Common.Library.LookUpEditor();
            this.lueKszr = new YidanSoft.Common.Library.LookUpEditor();
            this.lueZkys = new YidanSoft.Common.Library.LookUpEditor();
            this.lueZkhs = new YidanSoft.Common.Library.LookUpEditor();
            this.hLineEx1 = new YidanSoft.Core.IEMMainPage.HLineEx();
            this.vLineEx6 = new YidanSoft.Core.IEMMainPage.VLineEx();
            this.vLineEx5 = new YidanSoft.Core.IEMMainPage.VLineEx();
            this.vLineEx4 = new YidanSoft.Core.IEMMainPage.VLineEx();
            this.vLineEx3 = new YidanSoft.Core.IEMMainPage.VLineEx();
            this.vLineEx2 = new YidanSoft.Core.IEMMainPage.VLineEx();
            this.vLineEx1 = new YidanSoft.Core.IEMMainPage.VLineEx();
            this.hLineExlast = new YidanSoft.Core.IEMMainPage.HLineEx();
            this.hLineEx19 = new YidanSoft.Core.IEMMainPage.HLineEx();
            this.hLineEx18 = new YidanSoft.Core.IEMMainPage.HLineEx();
            this.hLineEx17 = new YidanSoft.Core.IEMMainPage.HLineEx();
            this.hLineEx16 = new YidanSoft.Core.IEMMainPage.HLineEx();
            this.hLineEx15 = new YidanSoft.Core.IEMMainPage.HLineEx();
            this.hLineEx14 = new YidanSoft.Core.IEMMainPage.HLineEx();
            this.hLineEx13 = new YidanSoft.Core.IEMMainPage.HLineEx();
            this.hLineEx12 = new YidanSoft.Core.IEMMainPage.HLineEx();
            this.hLineEx11 = new YidanSoft.Core.IEMMainPage.HLineEx();
            this.hLineEx10 = new YidanSoft.Core.IEMMainPage.HLineEx();
            this.hLineEx9 = new YidanSoft.Core.IEMMainPage.HLineEx();
            this.hLineEx8 = new YidanSoft.Core.IEMMainPage.HLineEx();
            this.hLineEx7 = new YidanSoft.Core.IEMMainPage.HLineEx();
            this.hLineEx6 = new YidanSoft.Core.IEMMainPage.HLineEx();
            this.hLineEx5 = new YidanSoft.Core.IEMMainPage.HLineEx();
            this.hLineEx4 = new YidanSoft.Core.IEMMainPage.HLineEx();
            this.hLineEx3 = new YidanSoft.Core.IEMMainPage.HLineEx();
            this.labZymosis = new DevExpress.XtraEditors.LabelControl();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            ((System.ComponentModel.ISupportInitialize)(this.txtPathologyName.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueInDiag)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueOutDiag)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtIn_Check_Date.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.seSaveTimes.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.seSuccessTimes.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit3.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtAllergicDrug.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueBmy)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueSxys)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueYjs)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueJxys)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueZyys)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueZzys)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueZrys)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueKszr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueZkys)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueZkhs)).BeginInit();
            this.SuspendLayout();
            // 
            // txtPathologyName
            // 
            this.txtPathologyName.EditValue = "";
            this.txtPathologyName.Location = new System.Drawing.Point(101, 331);
            this.txtPathologyName.Name = "txtPathologyName";
            this.txtPathologyName.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtPathologyName.Size = new System.Drawing.Size(296, 19);
            this.txtPathologyName.TabIndex = 10;
            // 
            // labelControl116
            // 
            this.labelControl116.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl116.Location = new System.Drawing.Point(400, 41);
            this.labelControl116.Name = "labelControl116";
            this.labelControl116.Size = new System.Drawing.Size(84, 14);
            this.labelControl116.TabIndex = 110;
            this.labelControl116.Text = "入院后确诊日期";
            // 
            // lueInDiag
            // 
            this.lueInDiag.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lueInDiag.Kind = YidanSoft.Wordbook.WordbookKind.Sql;
            this.lueInDiag.ListWindow = null;
            this.lueInDiag.Location = new System.Drawing.Point(101, 38);
            this.lueInDiag.Name = "lueInDiag";
            this.lueInDiag.ShowSButton = true;
            this.lueInDiag.Size = new System.Drawing.Size(282, 19);
            this.lueInDiag.TabIndex = 5;
            // 
            // labelControl59
            // 
            this.labelControl59.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl59.Location = new System.Drawing.Point(25, 41);
            this.labelControl59.Name = "labelControl59";
            this.labelControl59.Size = new System.Drawing.Size(48, 14);
            this.labelControl59.TabIndex = 112;
            this.labelControl59.Text = "入院诊断";
            // 
            // labelControl58
            // 
            this.labelControl58.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl58.Location = new System.Drawing.Point(400, 14);
            this.labelControl58.Name = "labelControl58";
            this.labelControl58.Size = new System.Drawing.Size(60, 14);
            this.labelControl58.TabIndex = 110;
            this.labelControl58.Text = "入院状态：";
            // 
            // lueOutDiag
            // 
            this.lueOutDiag.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lueOutDiag.Kind = YidanSoft.Wordbook.WordbookKind.Sql;
            this.lueOutDiag.ListWindow = null;
            this.lueOutDiag.Location = new System.Drawing.Point(101, 11);
            this.lueOutDiag.Name = "lueOutDiag";
            this.lueOutDiag.ShowSButton = true;
            this.lueOutDiag.Size = new System.Drawing.Size(282, 19);
            this.lueOutDiag.TabIndex = 1;
            // 
            // labelControl57
            // 
            this.labelControl57.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl57.Location = new System.Drawing.Point(25, 14);
            this.labelControl57.Name = "labelControl57";
            this.labelControl57.Size = new System.Drawing.Size(70, 14);
            this.labelControl57.TabIndex = 110;
            this.labelControl57.Text = "门(急)诊诊断";
            // 
            // labAdmitInfo
            // 
            this.labAdmitInfo.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Simple;
            this.labAdmitInfo.Location = new System.Drawing.Point(477, 13);
            this.labAdmitInfo.Name = "labAdmitInfo";
            this.labAdmitInfo.Size = new System.Drawing.Size(14, 16);
            this.labAdmitInfo.TabIndex = 143;
            this.labAdmitInfo.Text = "   ";
            // 
            // labelControl13
            // 
            this.labelControl13.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl13.Location = new System.Drawing.Point(509, 14);
            this.labelControl13.Name = "labelControl13";
            this.labelControl13.Size = new System.Drawing.Size(137, 14);
            this.labelControl13.TabIndex = 110;
            this.labelControl13.Text = "1、危    2、急    3、一般";
            // 
            // txtIn_Check_Date
            // 
            this.txtIn_Check_Date.EditValue = "";
            this.txtIn_Check_Date.Location = new System.Drawing.Point(490, 39);
            this.txtIn_Check_Date.Name = "txtIn_Check_Date";
            this.txtIn_Check_Date.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtIn_Check_Date.Size = new System.Drawing.Size(156, 19);
            this.txtIn_Check_Date.TabIndex = 10;
            // 
            // labelControl14
            // 
            this.labelControl14.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl14.Location = new System.Drawing.Point(25, 117);
            this.labelControl14.Name = "labelControl14";
            this.labelControl14.Size = new System.Drawing.Size(48, 14);
            this.labelControl14.TabIndex = 112;
            this.labelControl14.Text = "主要诊断";
            // 
            // labelControl15
            // 
            this.labelControl15.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl15.Location = new System.Drawing.Point(150, 81);
            this.labelControl15.Name = "labelControl15";
            this.labelControl15.Size = new System.Drawing.Size(96, 14);
            this.labelControl15.TabIndex = 145;
            this.labelControl15.Text = "出    院    诊    断";
            // 
            // labelControl16
            // 
            this.labelControl16.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl16.Location = new System.Drawing.Point(25, 144);
            this.labelControl16.Name = "labelControl16";
            this.labelControl16.Size = new System.Drawing.Size(48, 14);
            this.labelControl16.TabIndex = 112;
            this.labelControl16.Text = "其他诊断";
            // 
            // labelControl17
            // 
            this.labelControl17.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl17.Location = new System.Drawing.Point(25, 306);
            this.labelControl17.Name = "labelControl17";
            this.labelControl17.Size = new System.Drawing.Size(84, 14);
            this.labelControl17.TabIndex = 112;
            this.labelControl17.Text = "医院传染病名称";
            // 
            // labelControl18
            // 
            this.labelControl18.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl18.Location = new System.Drawing.Point(408, 93);
            this.labelControl18.Name = "labelControl18";
            this.labelControl18.Size = new System.Drawing.Size(31, 14);
            this.labelControl18.TabIndex = 112;
            this.labelControl18.Text = "1治愈";
            // 
            // labelControl19
            // 
            this.labelControl19.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl19.Location = new System.Drawing.Point(445, 93);
            this.labelControl19.Name = "labelControl19";
            this.labelControl19.Size = new System.Drawing.Size(31, 14);
            this.labelControl19.TabIndex = 112;
            this.labelControl19.Text = "2好转";
            // 
            // labelControl20
            // 
            this.labelControl20.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl20.Location = new System.Drawing.Point(482, 93);
            this.labelControl20.Name = "labelControl20";
            this.labelControl20.Size = new System.Drawing.Size(31, 14);
            this.labelControl20.TabIndex = 112;
            this.labelControl20.Text = "3未愈";
            // 
            // labelControl21
            // 
            this.labelControl21.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl21.Location = new System.Drawing.Point(519, 93);
            this.labelControl21.Name = "labelControl21";
            this.labelControl21.Size = new System.Drawing.Size(31, 14);
            this.labelControl21.TabIndex = 112;
            this.labelControl21.Text = "4死亡";
            // 
            // labelControl22
            // 
            this.labelControl22.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl22.Location = new System.Drawing.Point(556, 93);
            this.labelControl22.Name = "labelControl22";
            this.labelControl22.Size = new System.Drawing.Size(31, 14);
            this.labelControl22.TabIndex = 112;
            this.labelControl22.Text = "5其他";
            // 
            // labelControl23
            // 
            this.labelControl23.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl23.Location = new System.Drawing.Point(447, 70);
            this.labelControl23.Name = "labelControl23";
            this.labelControl23.Size = new System.Drawing.Size(96, 14);
            this.labelControl23.TabIndex = 145;
            this.labelControl23.Text = "出    院    情    况";
            // 
            // labelControl24
            // 
            this.labelControl24.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl24.Location = new System.Drawing.Point(609, 81);
            this.labelControl24.Name = "labelControl24";
            this.labelControl24.Size = new System.Drawing.Size(37, 14);
            this.labelControl24.TabIndex = 145;
            this.labelControl24.Text = "ICD-10";
            // 
            // labelControl25
            // 
            this.labelControl25.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl25.Location = new System.Drawing.Point(25, 333);
            this.labelControl25.Name = "labelControl25";
            this.labelControl25.Size = new System.Drawing.Size(48, 14);
            this.labelControl25.TabIndex = 112;
            this.labelControl25.Text = "病理诊断";
            // 
            // labelControl26
            // 
            this.labelControl26.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl26.Location = new System.Drawing.Point(25, 361);
            this.labelControl26.Name = "labelControl26";
            this.labelControl26.Size = new System.Drawing.Size(132, 14);
            this.labelControl26.TabIndex = 112;
            this.labelControl26.Text = "损伤、中毒的外部因素：";
            // 
            // labelControl27
            // 
            this.labelControl27.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl27.Location = new System.Drawing.Point(25, 390);
            this.labelControl27.Name = "labelControl27";
            this.labelControl27.Size = new System.Drawing.Size(48, 14);
            this.labelControl27.TabIndex = 112;
            this.labelControl27.Text = "药物过敏";
            // 
            // labelControl28
            // 
            this.labelControl28.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl28.Location = new System.Drawing.Point(223, 390);
            this.labelControl28.Name = "labelControl28";
            this.labelControl28.Size = new System.Drawing.Size(35, 14);
            this.labelControl28.TabIndex = 112;
            this.labelControl28.Text = "HBsAg";
            // 
            // chkHBsAg
            // 
            this.chkHBsAg.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Office2003;
            this.chkHBsAg.Location = new System.Drawing.Point(272, 389);
            this.chkHBsAg.Name = "chkHBsAg";
            this.chkHBsAg.Size = new System.Drawing.Size(14, 16);
            this.chkHBsAg.TabIndex = 156;
            this.chkHBsAg.Text = "   ";
            // 
            // labelControl30
            // 
            this.labelControl30.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl30.Location = new System.Drawing.Point(318, 390);
            this.labelControl30.Name = "labelControl30";
            this.labelControl30.Size = new System.Drawing.Size(42, 14);
            this.labelControl30.TabIndex = 112;
            this.labelControl30.Text = "HCV-Ab";
            // 
            // chkHCV
            // 
            this.chkHCV.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Office2003;
            this.chkHCV.Location = new System.Drawing.Point(373, 389);
            this.chkHCV.Name = "chkHCV";
            this.chkHCV.Size = new System.Drawing.Size(14, 16);
            this.chkHCV.TabIndex = 156;
            this.chkHCV.Text = "   ";
            // 
            // labelControl32
            // 
            this.labelControl32.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl32.Location = new System.Drawing.Point(411, 390);
            this.labelControl32.Name = "labelControl32";
            this.labelControl32.Size = new System.Drawing.Size(39, 14);
            this.labelControl32.TabIndex = 112;
            this.labelControl32.Text = "HIV-Ab";
            // 
            // chkHIV
            // 
            this.chkHIV.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Office2003;
            this.chkHIV.Location = new System.Drawing.Point(462, 389);
            this.chkHIV.Name = "chkHIV";
            this.chkHIV.Size = new System.Drawing.Size(14, 16);
            this.chkHIV.TabIndex = 156;
            this.chkHIV.Text = "   ";
            // 
            // labelControl34
            // 
            this.labelControl34.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl34.Location = new System.Drawing.Point(509, 390);
            this.labelControl34.Name = "labelControl34";
            this.labelControl34.Size = new System.Drawing.Size(129, 14);
            this.labelControl34.TabIndex = 157;
            this.labelControl34.Text = "0.未做   1.阴性   2.阳性";
            // 
            // labelControl35
            // 
            this.labelControl35.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl35.Location = new System.Drawing.Point(25, 416);
            this.labelControl35.Name = "labelControl35";
            this.labelControl35.Size = new System.Drawing.Size(72, 14);
            this.labelControl35.TabIndex = 112;
            this.labelControl35.Text = "诊断符合情况";
            // 
            // labelControl36
            // 
            this.labelControl36.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl36.Location = new System.Drawing.Point(129, 416);
            this.labelControl36.Name = "labelControl36";
            this.labelControl36.Size = new System.Drawing.Size(60, 14);
            this.labelControl36.TabIndex = 112;
            this.labelControl36.Text = "门诊与出院";
            // 
            // labelControl37
            // 
            this.labelControl37.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl37.Location = new System.Drawing.Point(274, 416);
            this.labelControl37.Name = "labelControl37";
            this.labelControl37.Size = new System.Drawing.Size(60, 14);
            this.labelControl37.TabIndex = 112;
            this.labelControl37.Text = "入院与出院";
            // 
            // labelControl38
            // 
            this.labelControl38.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl38.Location = new System.Drawing.Point(408, 416);
            this.labelControl38.Name = "labelControl38";
            this.labelControl38.Size = new System.Drawing.Size(60, 14);
            this.labelControl38.TabIndex = 112;
            this.labelControl38.Text = "术前与术后";
            // 
            // labelControl39
            // 
            this.labelControl39.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl39.Location = new System.Drawing.Point(527, 416);
            this.labelControl39.Name = "labelControl39";
            this.labelControl39.Size = new System.Drawing.Size(60, 14);
            this.labelControl39.TabIndex = 112;
            this.labelControl39.Text = "临床与病理";
            // 
            // chkOpdIpd
            // 
            this.chkOpdIpd.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Office2003;
            this.chkOpdIpd.Location = new System.Drawing.Point(212, 415);
            this.chkOpdIpd.Name = "chkOpdIpd";
            this.chkOpdIpd.Size = new System.Drawing.Size(14, 16);
            this.chkOpdIpd.TabIndex = 156;
            this.chkOpdIpd.Text = "   ";
            // 
            // chkInOut
            // 
            this.chkInOut.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Office2003;
            this.chkInOut.Location = new System.Drawing.Point(364, 415);
            this.chkInOut.Name = "chkInOut";
            this.chkInOut.Size = new System.Drawing.Size(14, 16);
            this.chkInOut.TabIndex = 162;
            this.chkInOut.Text = "   ";
            // 
            // chkBeforeAfter
            // 
            this.chkBeforeAfter.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Office2003;
            this.chkBeforeAfter.Location = new System.Drawing.Point(490, 415);
            this.chkBeforeAfter.Name = "chkBeforeAfter";
            this.chkBeforeAfter.Size = new System.Drawing.Size(14, 16);
            this.chkBeforeAfter.TabIndex = 163;
            this.chkBeforeAfter.Text = "   ";
            // 
            // chkClinical
            // 
            this.chkClinical.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Office2003;
            this.chkClinical.Location = new System.Drawing.Point(609, 415);
            this.chkClinical.Name = "chkClinical";
            this.chkClinical.Size = new System.Drawing.Size(14, 16);
            this.chkClinical.TabIndex = 164;
            this.chkClinical.Text = "   ";
            // 
            // labelControl44
            // 
            this.labelControl44.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl44.Location = new System.Drawing.Point(129, 443);
            this.labelControl44.Name = "labelControl44";
            this.labelControl44.Size = new System.Drawing.Size(60, 14);
            this.labelControl44.TabIndex = 112;
            this.labelControl44.Text = "放射与病理";
            // 
            // chkPacsPathology
            // 
            this.chkPacsPathology.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Office2003;
            this.chkPacsPathology.Location = new System.Drawing.Point(212, 442);
            this.chkPacsPathology.Name = "chkPacsPathology";
            this.chkPacsPathology.Size = new System.Drawing.Size(14, 16);
            this.chkPacsPathology.TabIndex = 164;
            this.chkPacsPathology.Text = "   ";
            // 
            // labelControl46
            // 
            this.labelControl46.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl46.Location = new System.Drawing.Point(247, 443);
            this.labelControl46.Name = "labelControl46";
            this.labelControl46.Size = new System.Drawing.Size(188, 14);
            this.labelControl46.TabIndex = 157;
            this.labelControl46.Text = "0.未做  1.符合  2.不符合  3.不肯定";
            // 
            // labelControl47
            // 
            this.labelControl47.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl47.Location = new System.Drawing.Point(460, 443);
            this.labelControl47.Name = "labelControl47";
            this.labelControl47.Size = new System.Drawing.Size(24, 14);
            this.labelControl47.TabIndex = 112;
            this.labelControl47.Text = "抢救";
            // 
            // labelControl48
            // 
            this.labelControl48.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl48.Location = new System.Drawing.Point(563, 443);
            this.labelControl48.Name = "labelControl48";
            this.labelControl48.Size = new System.Drawing.Size(24, 14);
            this.labelControl48.TabIndex = 112;
            this.labelControl48.Text = "成功";
            // 
            // labelControl49
            // 
            this.labelControl49.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl49.Location = new System.Drawing.Point(525, 443);
            this.labelControl49.Name = "labelControl49";
            this.labelControl49.Size = new System.Drawing.Size(12, 14);
            this.labelControl49.TabIndex = 112;
            this.labelControl49.Text = "次";
            // 
            // labelControl50
            // 
            this.labelControl50.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl50.Location = new System.Drawing.Point(627, 443);
            this.labelControl50.Name = "labelControl50";
            this.labelControl50.Size = new System.Drawing.Size(12, 14);
            this.labelControl50.TabIndex = 112;
            this.labelControl50.Text = "次";
            // 
            // seSaveTimes
            // 
            this.seSaveTimes.EditValue = "";
            this.seSaveTimes.Location = new System.Drawing.Point(486, 441);
            this.seSaveTimes.Name = "seSaveTimes";
            this.seSaveTimes.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.seSaveTimes.Size = new System.Drawing.Size(35, 19);
            this.seSaveTimes.TabIndex = 165;
            // 
            // seSuccessTimes
            // 
            this.seSuccessTimes.EditValue = "";
            this.seSuccessTimes.Location = new System.Drawing.Point(590, 441);
            this.seSuccessTimes.Name = "seSuccessTimes";
            this.seSuccessTimes.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.seSuccessTimes.Size = new System.Drawing.Size(35, 19);
            this.seSuccessTimes.TabIndex = 165;
            // 
            // labelControl51
            // 
            this.labelControl51.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl51.Location = new System.Drawing.Point(25, 469);
            this.labelControl51.Name = "labelControl51";
            this.labelControl51.Size = new System.Drawing.Size(36, 14);
            this.labelControl51.TabIndex = 112;
            this.labelControl51.Text = "科主任";
            // 
            // labelControl52
            // 
            this.labelControl52.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl52.Location = new System.Drawing.Point(157, 469);
            this.labelControl52.Name = "labelControl52";
            this.labelControl52.Size = new System.Drawing.Size(96, 14);
            this.labelControl52.TabIndex = 112;
            this.labelControl52.Text = "主（副主）任医师";
            // 
            // labelControl53
            // 
            this.labelControl53.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl53.Location = new System.Drawing.Point(353, 469);
            this.labelControl53.Name = "labelControl53";
            this.labelControl53.Size = new System.Drawing.Size(48, 14);
            this.labelControl53.TabIndex = 112;
            this.labelControl53.Text = "主治医师";
            // 
            // labelControl55
            // 
            this.labelControl55.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl55.Location = new System.Drawing.Point(495, 469);
            this.labelControl55.Name = "labelControl55";
            this.labelControl55.Size = new System.Drawing.Size(48, 14);
            this.labelControl55.TabIndex = 112;
            this.labelControl55.Text = "住院医师";
            // 
            // labelControl56
            // 
            this.labelControl56.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl56.Location = new System.Drawing.Point(25, 496);
            this.labelControl56.Name = "labelControl56";
            this.labelControl56.Size = new System.Drawing.Size(48, 14);
            this.labelControl56.TabIndex = 112;
            this.labelControl56.Text = "进修医师";
            // 
            // labelControl60
            // 
            this.labelControl60.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl60.Location = new System.Drawing.Point(157, 498);
            this.labelControl60.Name = "labelControl60";
            this.labelControl60.Size = new System.Drawing.Size(84, 14);
            this.labelControl60.TabIndex = 112;
            this.labelControl60.Text = "研究生实习医师";
            // 
            // labelControl61
            // 
            this.labelControl61.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl61.Location = new System.Drawing.Point(353, 498);
            this.labelControl61.Name = "labelControl61";
            this.labelControl61.Size = new System.Drawing.Size(48, 14);
            this.labelControl61.TabIndex = 112;
            this.labelControl61.Text = "实习医师";
            // 
            // labelControl62
            // 
            this.labelControl62.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl62.Location = new System.Drawing.Point(495, 496);
            this.labelControl62.Name = "labelControl62";
            this.labelControl62.Size = new System.Drawing.Size(36, 14);
            this.labelControl62.TabIndex = 112;
            this.labelControl62.Text = "编码员";
            // 
            // labelControl63
            // 
            this.labelControl63.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl63.Location = new System.Drawing.Point(25, 524);
            this.labelControl63.Name = "labelControl63";
            this.labelControl63.Size = new System.Drawing.Size(48, 14);
            this.labelControl63.TabIndex = 167;
            this.labelControl63.Text = "病案质量";
            // 
            // labMedical_Quality
            // 
            this.labMedical_Quality.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Office2003;
            this.labMedical_Quality.Location = new System.Drawing.Point(88, 523);
            this.labMedical_Quality.Name = "labMedical_Quality";
            this.labMedical_Quality.Size = new System.Drawing.Size(14, 16);
            this.labMedical_Quality.TabIndex = 156;
            this.labMedical_Quality.Text = "   ";
            // 
            // labelControl65
            // 
            this.labelControl65.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl65.Location = new System.Drawing.Point(122, 524);
            this.labelControl65.Name = "labelControl65";
            this.labelControl65.Size = new System.Drawing.Size(101, 14);
            this.labelControl65.TabIndex = 157;
            this.labelControl65.Text = "1.甲    2.乙    3.丙";
            // 
            // labelControl66
            // 
            this.labelControl66.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl66.Location = new System.Drawing.Point(238, 524);
            this.labelControl66.Name = "labelControl66";
            this.labelControl66.Size = new System.Drawing.Size(48, 14);
            this.labelControl66.TabIndex = 167;
            this.labelControl66.Text = "质控医师";
            // 
            // labelControl67
            // 
            this.labelControl67.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl67.Location = new System.Drawing.Point(373, 524);
            this.labelControl67.Name = "labelControl67";
            this.labelControl67.Size = new System.Drawing.Size(48, 14);
            this.labelControl67.TabIndex = 167;
            this.labelControl67.Text = "质控护士";
            // 
            // labelControl68
            // 
            this.labelControl68.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl68.Location = new System.Drawing.Point(502, 524);
            this.labelControl68.Name = "labelControl68";
            this.labelControl68.Size = new System.Drawing.Size(36, 14);
            this.labelControl68.TabIndex = 167;
            this.labelControl68.Text = "日期：";
            // 
            // textEdit3
            // 
            this.textEdit3.EditValue = "";
            this.textEdit3.Location = new System.Drawing.Point(544, 522);
            this.textEdit3.Name = "textEdit3";
            this.textEdit3.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.textEdit3.Size = new System.Drawing.Size(107, 19);
            this.textEdit3.TabIndex = 10;
            // 
            // txtAllergicDrug
            // 
            this.txtAllergicDrug.EditValue = "";
            this.txtAllergicDrug.Location = new System.Drawing.Point(79, 387);
            this.txtAllergicDrug.Name = "txtAllergicDrug";
            this.txtAllergicDrug.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtAllergicDrug.Size = new System.Drawing.Size(138, 19);
            this.txtAllergicDrug.TabIndex = 13;
            // 
            // labDiagnosis_Name1
            // 
            this.labDiagnosis_Name1.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labDiagnosis_Name1.Location = new System.Drawing.Point(101, 117);
            this.labDiagnosis_Name1.Name = "labDiagnosis_Name1";
            this.labDiagnosis_Name1.Size = new System.Drawing.Size(48, 14);
            this.labDiagnosis_Name1.TabIndex = 112;
            this.labDiagnosis_Name1.Text = "诊断名称";
            this.labDiagnosis_Name1.Visible = false;
            // 
            // labDiagnosis_Name2
            // 
            this.labDiagnosis_Name2.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labDiagnosis_Name2.Location = new System.Drawing.Point(101, 144);
            this.labDiagnosis_Name2.Name = "labDiagnosis_Name2";
            this.labDiagnosis_Name2.Size = new System.Drawing.Size(48, 14);
            this.labDiagnosis_Name2.TabIndex = 112;
            this.labDiagnosis_Name2.Text = "诊断名称";
            this.labDiagnosis_Name2.Visible = false;
            // 
            // labDiagnosis_Name3
            // 
            this.labDiagnosis_Name3.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labDiagnosis_Name3.Location = new System.Drawing.Point(101, 171);
            this.labDiagnosis_Name3.Name = "labDiagnosis_Name3";
            this.labDiagnosis_Name3.Size = new System.Drawing.Size(48, 14);
            this.labDiagnosis_Name3.TabIndex = 112;
            this.labDiagnosis_Name3.Text = "诊断名称";
            this.labDiagnosis_Name3.Visible = false;
            // 
            // labDiagnosis_Name4
            // 
            this.labDiagnosis_Name4.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labDiagnosis_Name4.Location = new System.Drawing.Point(101, 198);
            this.labDiagnosis_Name4.Name = "labDiagnosis_Name4";
            this.labDiagnosis_Name4.Size = new System.Drawing.Size(48, 14);
            this.labDiagnosis_Name4.TabIndex = 112;
            this.labDiagnosis_Name4.Text = "诊断名称";
            this.labDiagnosis_Name4.Visible = false;
            // 
            // labDiagnosis_Name5
            // 
            this.labDiagnosis_Name5.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labDiagnosis_Name5.Location = new System.Drawing.Point(101, 225);
            this.labDiagnosis_Name5.Name = "labDiagnosis_Name5";
            this.labDiagnosis_Name5.Size = new System.Drawing.Size(48, 14);
            this.labDiagnosis_Name5.TabIndex = 112;
            this.labDiagnosis_Name5.Text = "诊断名称";
            this.labDiagnosis_Name5.Visible = false;
            // 
            // labDiagnosis_Name6
            // 
            this.labDiagnosis_Name6.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labDiagnosis_Name6.Location = new System.Drawing.Point(101, 252);
            this.labDiagnosis_Name6.Name = "labDiagnosis_Name6";
            this.labDiagnosis_Name6.Size = new System.Drawing.Size(48, 14);
            this.labDiagnosis_Name6.TabIndex = 112;
            this.labDiagnosis_Name6.Text = "诊断名称";
            this.labDiagnosis_Name6.Visible = false;
            // 
            // labDiagnosis_Name7
            // 
            this.labDiagnosis_Name7.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labDiagnosis_Name7.Location = new System.Drawing.Point(101, 279);
            this.labDiagnosis_Name7.Name = "labDiagnosis_Name7";
            this.labDiagnosis_Name7.Size = new System.Drawing.Size(48, 14);
            this.labDiagnosis_Name7.TabIndex = 112;
            this.labDiagnosis_Name7.Text = "诊断名称";
            this.labDiagnosis_Name7.Visible = false;
            // 
            // chkStatus_1_1
            // 
            this.chkStatus_1_1.AutoSize = true;
            this.chkStatus_1_1.Checked = true;
            this.chkStatus_1_1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkStatus_1_1.Enabled = false;
            this.chkStatus_1_1.Location = new System.Drawing.Point(414, 117);
            this.chkStatus_1_1.Name = "chkStatus_1_1";
            this.chkStatus_1_1.Size = new System.Drawing.Size(15, 14);
            this.chkStatus_1_1.TabIndex = 169;
            this.chkStatus_1_1.UseVisualStyleBackColor = true;
            this.chkStatus_1_1.Visible = false;
            // 
            // chkStatus_2_1
            // 
            this.chkStatus_2_1.AutoSize = true;
            this.chkStatus_2_1.Checked = true;
            this.chkStatus_2_1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkStatus_2_1.Enabled = false;
            this.chkStatus_2_1.Location = new System.Drawing.Point(453, 117);
            this.chkStatus_2_1.Name = "chkStatus_2_1";
            this.chkStatus_2_1.Size = new System.Drawing.Size(15, 14);
            this.chkStatus_2_1.TabIndex = 169;
            this.chkStatus_2_1.UseVisualStyleBackColor = true;
            this.chkStatus_2_1.Visible = false;
            // 
            // chkStatus_3_1
            // 
            this.chkStatus_3_1.AutoSize = true;
            this.chkStatus_3_1.Checked = true;
            this.chkStatus_3_1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkStatus_3_1.Enabled = false;
            this.chkStatus_3_1.Location = new System.Drawing.Point(490, 117);
            this.chkStatus_3_1.Name = "chkStatus_3_1";
            this.chkStatus_3_1.Size = new System.Drawing.Size(15, 14);
            this.chkStatus_3_1.TabIndex = 169;
            this.chkStatus_3_1.UseVisualStyleBackColor = true;
            this.chkStatus_3_1.Visible = false;
            // 
            // chkStatus_5_1
            // 
            this.chkStatus_5_1.AutoSize = true;
            this.chkStatus_5_1.Checked = true;
            this.chkStatus_5_1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkStatus_5_1.Enabled = false;
            this.chkStatus_5_1.Location = new System.Drawing.Point(563, 117);
            this.chkStatus_5_1.Name = "chkStatus_5_1";
            this.chkStatus_5_1.Size = new System.Drawing.Size(15, 14);
            this.chkStatus_5_1.TabIndex = 169;
            this.chkStatus_5_1.UseVisualStyleBackColor = true;
            this.chkStatus_5_1.Visible = false;
            // 
            // chkStatus_4_1
            // 
            this.chkStatus_4_1.AutoSize = true;
            this.chkStatus_4_1.Checked = true;
            this.chkStatus_4_1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkStatus_4_1.Enabled = false;
            this.chkStatus_4_1.Location = new System.Drawing.Point(525, 117);
            this.chkStatus_4_1.Name = "chkStatus_4_1";
            this.chkStatus_4_1.Size = new System.Drawing.Size(15, 14);
            this.chkStatus_4_1.TabIndex = 169;
            this.chkStatus_4_1.UseVisualStyleBackColor = true;
            this.chkStatus_4_1.Visible = false;
            // 
            // labDiagnosis_Code1
            // 
            this.labDiagnosis_Code1.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labDiagnosis_Code1.Location = new System.Drawing.Point(594, 117);
            this.labDiagnosis_Code1.Name = "labDiagnosis_Code1";
            this.labDiagnosis_Code1.Size = new System.Drawing.Size(37, 14);
            this.labDiagnosis_Code1.TabIndex = 112;
            this.labDiagnosis_Code1.Text = "ICD-10";
            this.labDiagnosis_Code1.Visible = false;
            // 
            // chkStatus_1_2
            // 
            this.chkStatus_1_2.AutoSize = true;
            this.chkStatus_1_2.Checked = true;
            this.chkStatus_1_2.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkStatus_1_2.Enabled = false;
            this.chkStatus_1_2.Location = new System.Drawing.Point(414, 146);
            this.chkStatus_1_2.Name = "chkStatus_1_2";
            this.chkStatus_1_2.Size = new System.Drawing.Size(15, 14);
            this.chkStatus_1_2.TabIndex = 169;
            this.chkStatus_1_2.UseVisualStyleBackColor = true;
            this.chkStatus_1_2.Visible = false;
            // 
            // chkStatus_2_2
            // 
            this.chkStatus_2_2.AutoSize = true;
            this.chkStatus_2_2.Checked = true;
            this.chkStatus_2_2.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkStatus_2_2.Enabled = false;
            this.chkStatus_2_2.Location = new System.Drawing.Point(453, 146);
            this.chkStatus_2_2.Name = "chkStatus_2_2";
            this.chkStatus_2_2.Size = new System.Drawing.Size(15, 14);
            this.chkStatus_2_2.TabIndex = 169;
            this.chkStatus_2_2.UseVisualStyleBackColor = true;
            this.chkStatus_2_2.Visible = false;
            // 
            // chkStatus_3_2
            // 
            this.chkStatus_3_2.AutoSize = true;
            this.chkStatus_3_2.Checked = true;
            this.chkStatus_3_2.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkStatus_3_2.Enabled = false;
            this.chkStatus_3_2.Location = new System.Drawing.Point(490, 146);
            this.chkStatus_3_2.Name = "chkStatus_3_2";
            this.chkStatus_3_2.Size = new System.Drawing.Size(15, 14);
            this.chkStatus_3_2.TabIndex = 169;
            this.chkStatus_3_2.UseVisualStyleBackColor = true;
            this.chkStatus_3_2.Visible = false;
            // 
            // chkStatus_5_2
            // 
            this.chkStatus_5_2.AutoSize = true;
            this.chkStatus_5_2.Checked = true;
            this.chkStatus_5_2.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkStatus_5_2.Enabled = false;
            this.chkStatus_5_2.Location = new System.Drawing.Point(563, 146);
            this.chkStatus_5_2.Name = "chkStatus_5_2";
            this.chkStatus_5_2.Size = new System.Drawing.Size(15, 14);
            this.chkStatus_5_2.TabIndex = 169;
            this.chkStatus_5_2.UseVisualStyleBackColor = true;
            this.chkStatus_5_2.Visible = false;
            // 
            // chkStatus_4_2
            // 
            this.chkStatus_4_2.AutoSize = true;
            this.chkStatus_4_2.Checked = true;
            this.chkStatus_4_2.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkStatus_4_2.Enabled = false;
            this.chkStatus_4_2.Location = new System.Drawing.Point(525, 146);
            this.chkStatus_4_2.Name = "chkStatus_4_2";
            this.chkStatus_4_2.Size = new System.Drawing.Size(15, 14);
            this.chkStatus_4_2.TabIndex = 169;
            this.chkStatus_4_2.UseVisualStyleBackColor = true;
            this.chkStatus_4_2.Visible = false;
            // 
            // labDiagnosis_Code2
            // 
            this.labDiagnosis_Code2.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labDiagnosis_Code2.Location = new System.Drawing.Point(594, 146);
            this.labDiagnosis_Code2.Name = "labDiagnosis_Code2";
            this.labDiagnosis_Code2.Size = new System.Drawing.Size(37, 14);
            this.labDiagnosis_Code2.TabIndex = 112;
            this.labDiagnosis_Code2.Text = "ICD-10";
            this.labDiagnosis_Code2.Visible = false;
            // 
            // chkStatus_3_3
            // 
            this.chkStatus_3_3.AutoSize = true;
            this.chkStatus_3_3.Checked = true;
            this.chkStatus_3_3.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkStatus_3_3.Enabled = false;
            this.chkStatus_3_3.Location = new System.Drawing.Point(490, 171);
            this.chkStatus_3_3.Name = "chkStatus_3_3";
            this.chkStatus_3_3.Size = new System.Drawing.Size(15, 14);
            this.chkStatus_3_3.TabIndex = 169;
            this.chkStatus_3_3.UseVisualStyleBackColor = true;
            this.chkStatus_3_3.Visible = false;
            // 
            // chkStatus_5_3
            // 
            this.chkStatus_5_3.AutoSize = true;
            this.chkStatus_5_3.Checked = true;
            this.chkStatus_5_3.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkStatus_5_3.Enabled = false;
            this.chkStatus_5_3.Location = new System.Drawing.Point(563, 171);
            this.chkStatus_5_3.Name = "chkStatus_5_3";
            this.chkStatus_5_3.Size = new System.Drawing.Size(15, 14);
            this.chkStatus_5_3.TabIndex = 169;
            this.chkStatus_5_3.UseVisualStyleBackColor = true;
            this.chkStatus_5_3.Visible = false;
            // 
            // chkStatus_2_3
            // 
            this.chkStatus_2_3.AutoSize = true;
            this.chkStatus_2_3.Checked = true;
            this.chkStatus_2_3.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkStatus_2_3.Enabled = false;
            this.chkStatus_2_3.Location = new System.Drawing.Point(453, 171);
            this.chkStatus_2_3.Name = "chkStatus_2_3";
            this.chkStatus_2_3.Size = new System.Drawing.Size(15, 14);
            this.chkStatus_2_3.TabIndex = 169;
            this.chkStatus_2_3.UseVisualStyleBackColor = true;
            this.chkStatus_2_3.Visible = false;
            // 
            // chkStatus_4_3
            // 
            this.chkStatus_4_3.AutoSize = true;
            this.chkStatus_4_3.Checked = true;
            this.chkStatus_4_3.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkStatus_4_3.Enabled = false;
            this.chkStatus_4_3.Location = new System.Drawing.Point(525, 171);
            this.chkStatus_4_3.Name = "chkStatus_4_3";
            this.chkStatus_4_3.Size = new System.Drawing.Size(15, 14);
            this.chkStatus_4_3.TabIndex = 169;
            this.chkStatus_4_3.UseVisualStyleBackColor = true;
            this.chkStatus_4_3.Visible = false;
            // 
            // chkStatus_1_3
            // 
            this.chkStatus_1_3.AutoSize = true;
            this.chkStatus_1_3.Checked = true;
            this.chkStatus_1_3.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkStatus_1_3.Enabled = false;
            this.chkStatus_1_3.Location = new System.Drawing.Point(414, 171);
            this.chkStatus_1_3.Name = "chkStatus_1_3";
            this.chkStatus_1_3.Size = new System.Drawing.Size(15, 14);
            this.chkStatus_1_3.TabIndex = 169;
            this.chkStatus_1_3.UseVisualStyleBackColor = true;
            this.chkStatus_1_3.Visible = false;
            // 
            // labDiagnosis_Code3
            // 
            this.labDiagnosis_Code3.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labDiagnosis_Code3.Location = new System.Drawing.Point(594, 171);
            this.labDiagnosis_Code3.Name = "labDiagnosis_Code3";
            this.labDiagnosis_Code3.Size = new System.Drawing.Size(37, 14);
            this.labDiagnosis_Code3.TabIndex = 112;
            this.labDiagnosis_Code3.Text = "ICD-10";
            this.labDiagnosis_Code3.Visible = false;
            // 
            // chkStatus_2_4
            // 
            this.chkStatus_2_4.AutoSize = true;
            this.chkStatus_2_4.Checked = true;
            this.chkStatus_2_4.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkStatus_2_4.Enabled = false;
            this.chkStatus_2_4.Location = new System.Drawing.Point(453, 198);
            this.chkStatus_2_4.Name = "chkStatus_2_4";
            this.chkStatus_2_4.Size = new System.Drawing.Size(15, 14);
            this.chkStatus_2_4.TabIndex = 169;
            this.chkStatus_2_4.UseVisualStyleBackColor = true;
            this.chkStatus_2_4.Visible = false;
            // 
            // chkStatus_5_4
            // 
            this.chkStatus_5_4.AutoSize = true;
            this.chkStatus_5_4.Checked = true;
            this.chkStatus_5_4.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkStatus_5_4.Enabled = false;
            this.chkStatus_5_4.Location = new System.Drawing.Point(563, 198);
            this.chkStatus_5_4.Name = "chkStatus_5_4";
            this.chkStatus_5_4.Size = new System.Drawing.Size(15, 14);
            this.chkStatus_5_4.TabIndex = 169;
            this.chkStatus_5_4.UseVisualStyleBackColor = true;
            this.chkStatus_5_4.Visible = false;
            // 
            // chkStatus_4_4
            // 
            this.chkStatus_4_4.AutoSize = true;
            this.chkStatus_4_4.Checked = true;
            this.chkStatus_4_4.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkStatus_4_4.Enabled = false;
            this.chkStatus_4_4.Location = new System.Drawing.Point(525, 198);
            this.chkStatus_4_4.Name = "chkStatus_4_4";
            this.chkStatus_4_4.Size = new System.Drawing.Size(15, 14);
            this.chkStatus_4_4.TabIndex = 169;
            this.chkStatus_4_4.UseVisualStyleBackColor = true;
            this.chkStatus_4_4.Visible = false;
            // 
            // chkStatus_3_4
            // 
            this.chkStatus_3_4.AutoSize = true;
            this.chkStatus_3_4.Checked = true;
            this.chkStatus_3_4.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkStatus_3_4.Enabled = false;
            this.chkStatus_3_4.Location = new System.Drawing.Point(490, 198);
            this.chkStatus_3_4.Name = "chkStatus_3_4";
            this.chkStatus_3_4.Size = new System.Drawing.Size(15, 14);
            this.chkStatus_3_4.TabIndex = 169;
            this.chkStatus_3_4.UseVisualStyleBackColor = true;
            this.chkStatus_3_4.Visible = false;
            // 
            // chkStatus_1_4
            // 
            this.chkStatus_1_4.AutoSize = true;
            this.chkStatus_1_4.Checked = true;
            this.chkStatus_1_4.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkStatus_1_4.Enabled = false;
            this.chkStatus_1_4.Location = new System.Drawing.Point(414, 198);
            this.chkStatus_1_4.Name = "chkStatus_1_4";
            this.chkStatus_1_4.Size = new System.Drawing.Size(15, 14);
            this.chkStatus_1_4.TabIndex = 169;
            this.chkStatus_1_4.UseVisualStyleBackColor = true;
            this.chkStatus_1_4.Visible = false;
            // 
            // labDiagnosis_Code4
            // 
            this.labDiagnosis_Code4.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labDiagnosis_Code4.Location = new System.Drawing.Point(594, 198);
            this.labDiagnosis_Code4.Name = "labDiagnosis_Code4";
            this.labDiagnosis_Code4.Size = new System.Drawing.Size(37, 14);
            this.labDiagnosis_Code4.TabIndex = 112;
            this.labDiagnosis_Code4.Text = "ICD-10";
            this.labDiagnosis_Code4.Visible = false;
            // 
            // chkStatus_4_5
            // 
            this.chkStatus_4_5.AutoSize = true;
            this.chkStatus_4_5.Checked = true;
            this.chkStatus_4_5.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkStatus_4_5.Enabled = false;
            this.chkStatus_4_5.Location = new System.Drawing.Point(525, 225);
            this.chkStatus_4_5.Name = "chkStatus_4_5";
            this.chkStatus_4_5.Size = new System.Drawing.Size(15, 14);
            this.chkStatus_4_5.TabIndex = 169;
            this.chkStatus_4_5.UseVisualStyleBackColor = true;
            this.chkStatus_4_5.Visible = false;
            // 
            // chkStatus_5_5
            // 
            this.chkStatus_5_5.AutoSize = true;
            this.chkStatus_5_5.Checked = true;
            this.chkStatus_5_5.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkStatus_5_5.Enabled = false;
            this.chkStatus_5_5.Location = new System.Drawing.Point(563, 225);
            this.chkStatus_5_5.Name = "chkStatus_5_5";
            this.chkStatus_5_5.Size = new System.Drawing.Size(15, 14);
            this.chkStatus_5_5.TabIndex = 169;
            this.chkStatus_5_5.UseVisualStyleBackColor = true;
            this.chkStatus_5_5.Visible = false;
            // 
            // chkStatus_3_5
            // 
            this.chkStatus_3_5.AutoSize = true;
            this.chkStatus_3_5.Checked = true;
            this.chkStatus_3_5.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkStatus_3_5.Enabled = false;
            this.chkStatus_3_5.Location = new System.Drawing.Point(490, 225);
            this.chkStatus_3_5.Name = "chkStatus_3_5";
            this.chkStatus_3_5.Size = new System.Drawing.Size(15, 14);
            this.chkStatus_3_5.TabIndex = 169;
            this.chkStatus_3_5.UseVisualStyleBackColor = true;
            this.chkStatus_3_5.Visible = false;
            // 
            // chkStatus_2_5
            // 
            this.chkStatus_2_5.AutoSize = true;
            this.chkStatus_2_5.Checked = true;
            this.chkStatus_2_5.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkStatus_2_5.Enabled = false;
            this.chkStatus_2_5.Location = new System.Drawing.Point(453, 225);
            this.chkStatus_2_5.Name = "chkStatus_2_5";
            this.chkStatus_2_5.Size = new System.Drawing.Size(15, 14);
            this.chkStatus_2_5.TabIndex = 169;
            this.chkStatus_2_5.UseVisualStyleBackColor = true;
            this.chkStatus_2_5.Visible = false;
            // 
            // chkStatus_1_5
            // 
            this.chkStatus_1_5.AutoSize = true;
            this.chkStatus_1_5.Checked = true;
            this.chkStatus_1_5.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkStatus_1_5.Enabled = false;
            this.chkStatus_1_5.Location = new System.Drawing.Point(414, 225);
            this.chkStatus_1_5.Name = "chkStatus_1_5";
            this.chkStatus_1_5.Size = new System.Drawing.Size(15, 14);
            this.chkStatus_1_5.TabIndex = 169;
            this.chkStatus_1_5.UseVisualStyleBackColor = true;
            this.chkStatus_1_5.Visible = false;
            // 
            // labDiagnosis_Code5
            // 
            this.labDiagnosis_Code5.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labDiagnosis_Code5.Location = new System.Drawing.Point(594, 225);
            this.labDiagnosis_Code5.Name = "labDiagnosis_Code5";
            this.labDiagnosis_Code5.Size = new System.Drawing.Size(37, 14);
            this.labDiagnosis_Code5.TabIndex = 112;
            this.labDiagnosis_Code5.Text = "ICD-10";
            this.labDiagnosis_Code5.Visible = false;
            // 
            // chkStatus_3_7
            // 
            this.chkStatus_3_7.AutoSize = true;
            this.chkStatus_3_7.Checked = true;
            this.chkStatus_3_7.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkStatus_3_7.Enabled = false;
            this.chkStatus_3_7.Location = new System.Drawing.Point(490, 279);
            this.chkStatus_3_7.Name = "chkStatus_3_7";
            this.chkStatus_3_7.Size = new System.Drawing.Size(15, 14);
            this.chkStatus_3_7.TabIndex = 169;
            this.chkStatus_3_7.UseVisualStyleBackColor = true;
            this.chkStatus_3_7.Visible = false;
            // 
            // chkStatus_5_7
            // 
            this.chkStatus_5_7.AutoSize = true;
            this.chkStatus_5_7.Checked = true;
            this.chkStatus_5_7.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkStatus_5_7.Enabled = false;
            this.chkStatus_5_7.Location = new System.Drawing.Point(563, 279);
            this.chkStatus_5_7.Name = "chkStatus_5_7";
            this.chkStatus_5_7.Size = new System.Drawing.Size(15, 14);
            this.chkStatus_5_7.TabIndex = 169;
            this.chkStatus_5_7.UseVisualStyleBackColor = true;
            this.chkStatus_5_7.Visible = false;
            // 
            // chkStatus_2_7
            // 
            this.chkStatus_2_7.AutoSize = true;
            this.chkStatus_2_7.Checked = true;
            this.chkStatus_2_7.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkStatus_2_7.Enabled = false;
            this.chkStatus_2_7.Location = new System.Drawing.Point(453, 279);
            this.chkStatus_2_7.Name = "chkStatus_2_7";
            this.chkStatus_2_7.Size = new System.Drawing.Size(15, 14);
            this.chkStatus_2_7.TabIndex = 169;
            this.chkStatus_2_7.UseVisualStyleBackColor = true;
            this.chkStatus_2_7.Visible = false;
            // 
            // chkStatus_4_7
            // 
            this.chkStatus_4_7.AutoSize = true;
            this.chkStatus_4_7.Checked = true;
            this.chkStatus_4_7.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkStatus_4_7.Enabled = false;
            this.chkStatus_4_7.Location = new System.Drawing.Point(525, 279);
            this.chkStatus_4_7.Name = "chkStatus_4_7";
            this.chkStatus_4_7.Size = new System.Drawing.Size(15, 14);
            this.chkStatus_4_7.TabIndex = 169;
            this.chkStatus_4_7.UseVisualStyleBackColor = true;
            this.chkStatus_4_7.Visible = false;
            // 
            // chkStatus_1_7
            // 
            this.chkStatus_1_7.AutoSize = true;
            this.chkStatus_1_7.Checked = true;
            this.chkStatus_1_7.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkStatus_1_7.Enabled = false;
            this.chkStatus_1_7.Location = new System.Drawing.Point(414, 279);
            this.chkStatus_1_7.Name = "chkStatus_1_7";
            this.chkStatus_1_7.Size = new System.Drawing.Size(15, 14);
            this.chkStatus_1_7.TabIndex = 169;
            this.chkStatus_1_7.UseVisualStyleBackColor = true;
            this.chkStatus_1_7.Visible = false;
            // 
            // labDiagnosis_Code7
            // 
            this.labDiagnosis_Code7.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labDiagnosis_Code7.Location = new System.Drawing.Point(594, 279);
            this.labDiagnosis_Code7.Name = "labDiagnosis_Code7";
            this.labDiagnosis_Code7.Size = new System.Drawing.Size(37, 14);
            this.labDiagnosis_Code7.TabIndex = 112;
            this.labDiagnosis_Code7.Text = "ICD-10";
            this.labDiagnosis_Code7.Visible = false;
            // 
            // chkStatus_2_6
            // 
            this.chkStatus_2_6.AutoSize = true;
            this.chkStatus_2_6.Checked = true;
            this.chkStatus_2_6.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkStatus_2_6.Enabled = false;
            this.chkStatus_2_6.Location = new System.Drawing.Point(453, 252);
            this.chkStatus_2_6.Name = "chkStatus_2_6";
            this.chkStatus_2_6.Size = new System.Drawing.Size(15, 14);
            this.chkStatus_2_6.TabIndex = 169;
            this.chkStatus_2_6.UseVisualStyleBackColor = true;
            this.chkStatus_2_6.Visible = false;
            // 
            // chkStatus_5_6
            // 
            this.chkStatus_5_6.AutoSize = true;
            this.chkStatus_5_6.Checked = true;
            this.chkStatus_5_6.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkStatus_5_6.Enabled = false;
            this.chkStatus_5_6.Location = new System.Drawing.Point(563, 252);
            this.chkStatus_5_6.Name = "chkStatus_5_6";
            this.chkStatus_5_6.Size = new System.Drawing.Size(15, 14);
            this.chkStatus_5_6.TabIndex = 169;
            this.chkStatus_5_6.UseVisualStyleBackColor = true;
            this.chkStatus_5_6.Visible = false;
            // 
            // chkStatus_4_6
            // 
            this.chkStatus_4_6.AutoSize = true;
            this.chkStatus_4_6.Checked = true;
            this.chkStatus_4_6.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkStatus_4_6.Enabled = false;
            this.chkStatus_4_6.Location = new System.Drawing.Point(525, 252);
            this.chkStatus_4_6.Name = "chkStatus_4_6";
            this.chkStatus_4_6.Size = new System.Drawing.Size(15, 14);
            this.chkStatus_4_6.TabIndex = 169;
            this.chkStatus_4_6.UseVisualStyleBackColor = true;
            this.chkStatus_4_6.Visible = false;
            // 
            // chkStatus_3_6
            // 
            this.chkStatus_3_6.AutoSize = true;
            this.chkStatus_3_6.Checked = true;
            this.chkStatus_3_6.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkStatus_3_6.Enabled = false;
            this.chkStatus_3_6.Location = new System.Drawing.Point(490, 252);
            this.chkStatus_3_6.Name = "chkStatus_3_6";
            this.chkStatus_3_6.Size = new System.Drawing.Size(15, 14);
            this.chkStatus_3_6.TabIndex = 169;
            this.chkStatus_3_6.UseVisualStyleBackColor = true;
            this.chkStatus_3_6.Visible = false;
            // 
            // chkStatus_1_6
            // 
            this.chkStatus_1_6.AutoSize = true;
            this.chkStatus_1_6.Checked = true;
            this.chkStatus_1_6.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkStatus_1_6.Enabled = false;
            this.chkStatus_1_6.Location = new System.Drawing.Point(414, 252);
            this.chkStatus_1_6.Name = "chkStatus_1_6";
            this.chkStatus_1_6.Size = new System.Drawing.Size(15, 14);
            this.chkStatus_1_6.TabIndex = 169;
            this.chkStatus_1_6.UseVisualStyleBackColor = true;
            this.chkStatus_1_6.Visible = false;
            // 
            // labDiagnosis_Code6
            // 
            this.labDiagnosis_Code6.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labDiagnosis_Code6.Location = new System.Drawing.Point(594, 252);
            this.labDiagnosis_Code6.Name = "labDiagnosis_Code6";
            this.labDiagnosis_Code6.Size = new System.Drawing.Size(37, 14);
            this.labDiagnosis_Code6.TabIndex = 112;
            this.labDiagnosis_Code6.Text = "ICD-10";
            this.labDiagnosis_Code6.Visible = false;
            // 
            // lueBmy
            // 
            this.lueBmy.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lueBmy.Kind = YidanSoft.Wordbook.WordbookKind.Sql;
            this.lueBmy.ListWindow = null;
            this.lueBmy.Location = new System.Drawing.Point(556, 495);
            this.lueBmy.Name = "lueBmy";
            this.lueBmy.ShowSButton = true;
            this.lueBmy.Size = new System.Drawing.Size(77, 19);
            this.lueBmy.TabIndex = 177;
            // 
            // lueSxys
            // 
            this.lueSxys.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lueSxys.Kind = YidanSoft.Wordbook.WordbookKind.Sql;
            this.lueSxys.ListWindow = null;
            this.lueSxys.Location = new System.Drawing.Point(407, 495);
            this.lueSxys.Name = "lueSxys";
            this.lueSxys.ShowSButton = true;
            this.lueSxys.Size = new System.Drawing.Size(81, 19);
            this.lueSxys.TabIndex = 176;
            // 
            // lueYjs
            // 
            this.lueYjs.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lueYjs.Kind = YidanSoft.Wordbook.WordbookKind.Sql;
            this.lueYjs.ListWindow = null;
            this.lueYjs.Location = new System.Drawing.Point(259, 495);
            this.lueYjs.Name = "lueYjs";
            this.lueYjs.ShowSButton = true;
            this.lueYjs.Size = new System.Drawing.Size(82, 19);
            this.lueYjs.TabIndex = 175;
            // 
            // lueJxys
            // 
            this.lueJxys.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lueJxys.Kind = YidanSoft.Wordbook.WordbookKind.Sql;
            this.lueJxys.ListWindow = null;
            this.lueJxys.Location = new System.Drawing.Point(79, 494);
            this.lueJxys.Name = "lueJxys";
            this.lueJxys.ShowSButton = true;
            this.lueJxys.Size = new System.Drawing.Size(73, 19);
            this.lueJxys.TabIndex = 174;
            // 
            // lueZyys
            // 
            this.lueZyys.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lueZyys.Kind = YidanSoft.Wordbook.WordbookKind.Sql;
            this.lueZyys.ListWindow = null;
            this.lueZyys.Location = new System.Drawing.Point(556, 468);
            this.lueZyys.Name = "lueZyys";
            this.lueZyys.ShowSButton = true;
            this.lueZyys.Size = new System.Drawing.Size(77, 19);
            this.lueZyys.TabIndex = 173;
            // 
            // lueZzys
            // 
            this.lueZzys.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lueZzys.Kind = YidanSoft.Wordbook.WordbookKind.Sql;
            this.lueZzys.ListWindow = null;
            this.lueZzys.Location = new System.Drawing.Point(407, 468);
            this.lueZzys.Name = "lueZzys";
            this.lueZzys.ShowSButton = true;
            this.lueZzys.Size = new System.Drawing.Size(81, 19);
            this.lueZzys.TabIndex = 172;
            // 
            // lueZrys
            // 
            this.lueZrys.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lueZrys.Kind = YidanSoft.Wordbook.WordbookKind.Sql;
            this.lueZrys.ListWindow = null;
            this.lueZrys.Location = new System.Drawing.Point(259, 468);
            this.lueZrys.Name = "lueZrys";
            this.lueZrys.ShowSButton = true;
            this.lueZrys.Size = new System.Drawing.Size(82, 19);
            this.lueZrys.TabIndex = 171;
            // 
            // lueKszr
            // 
            this.lueKszr.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lueKszr.Kind = YidanSoft.Wordbook.WordbookKind.Sql;
            this.lueKszr.ListWindow = null;
            this.lueKszr.Location = new System.Drawing.Point(67, 466);
            this.lueKszr.Name = "lueKszr";
            this.lueKszr.Size = new System.Drawing.Size(73, 18);
            this.lueKszr.TabIndex = 170;
            // 
            // lueZkys
            // 
            this.lueZkys.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lueZkys.Kind = YidanSoft.Wordbook.WordbookKind.Sql;
            this.lueZkys.ListWindow = null;
            this.lueZkys.Location = new System.Drawing.Point(292, 521);
            this.lueZkys.Name = "lueZkys";
            this.lueZkys.ShowSButton = true;
            this.lueZkys.Size = new System.Drawing.Size(71, 19);
            this.lueZkys.TabIndex = 178;
            // 
            // lueZkhs
            // 
            this.lueZkhs.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lueZkhs.Kind = YidanSoft.Wordbook.WordbookKind.Sql;
            this.lueZkhs.ListWindow = null;
            this.lueZkhs.Location = new System.Drawing.Point(428, 521);
            this.lueZkhs.Name = "lueZkhs";
            this.lueZkhs.ShowSButton = true;
            this.lueZkhs.Size = new System.Drawing.Size(72, 19);
            this.lueZkhs.TabIndex = 179;
            // 
            // hLineEx1
            // 
            this.hLineEx1.BackColor = System.Drawing.Color.White;
            this.hLineEx1.IsBold = false;
            this.hLineEx1.Location = new System.Drawing.Point(404, 87);
            this.hLineEx1.Name = "hLineEx1";
            this.hLineEx1.Size = new System.Drawing.Size(188, 1);
            this.hLineEx1.TabIndex = 186;
            this.hLineEx1.Text = "hLineEx3";
            // 
            // vLineEx6
            // 
            this.vLineEx6.BackColor = System.Drawing.Color.White;
            this.vLineEx6.Location = new System.Drawing.Point(552, 88);
            this.vLineEx6.Name = "vLineEx6";
            this.vLineEx6.Size = new System.Drawing.Size(1, 239);
            this.vLineEx6.TabIndex = 185;
            this.vLineEx6.Text = "vLineEx6";
            // 
            // vLineEx5
            // 
            this.vLineEx5.BackColor = System.Drawing.Color.White;
            this.vLineEx5.Location = new System.Drawing.Point(517, 88);
            this.vLineEx5.Name = "vLineEx5";
            this.vLineEx5.Size = new System.Drawing.Size(1, 239);
            this.vLineEx5.TabIndex = 184;
            this.vLineEx5.Text = "vLineEx5";
            // 
            // vLineEx4
            // 
            this.vLineEx4.BackColor = System.Drawing.Color.White;
            this.vLineEx4.Location = new System.Drawing.Point(479, 88);
            this.vLineEx4.Name = "vLineEx4";
            this.vLineEx4.Size = new System.Drawing.Size(1, 239);
            this.vLineEx4.TabIndex = 183;
            this.vLineEx4.Text = "vLineEx4";
            // 
            // vLineEx3
            // 
            this.vLineEx3.BackColor = System.Drawing.Color.White;
            this.vLineEx3.Location = new System.Drawing.Point(442, 88);
            this.vLineEx3.Name = "vLineEx3";
            this.vLineEx3.Size = new System.Drawing.Size(1, 239);
            this.vLineEx3.TabIndex = 182;
            this.vLineEx3.Text = "vLineEx3";
            // 
            // vLineEx2
            // 
            this.vLineEx2.BackColor = System.Drawing.Color.White;
            this.vLineEx2.Location = new System.Drawing.Point(591, 66);
            this.vLineEx2.Name = "vLineEx2";
            this.vLineEx2.Size = new System.Drawing.Size(1, 261);
            this.vLineEx2.TabIndex = 181;
            this.vLineEx2.Text = "vLineEx2";
            // 
            // vLineEx1
            // 
            this.vLineEx1.BackColor = System.Drawing.Color.White;
            this.vLineEx1.Location = new System.Drawing.Point(404, 65);
            this.vLineEx1.Name = "vLineEx1";
            this.vLineEx1.Size = new System.Drawing.Size(1, 261);
            this.vLineEx1.TabIndex = 180;
            this.vLineEx1.Text = "vLineEx1";
            // 
            // hLineExlast
            // 
            this.hLineExlast.BackColor = System.Drawing.Color.White;
            this.hLineExlast.IsBold = true;
            this.hLineExlast.Location = new System.Drawing.Point(5, 550);
            this.hLineExlast.Name = "hLineExlast";
            this.hLineExlast.Size = new System.Drawing.Size(658, 2);
            this.hLineExlast.TabIndex = 168;
            this.hLineExlast.Text = "hLineEx21";
            // 
            // hLineEx19
            // 
            this.hLineEx19.BackColor = System.Drawing.Color.White;
            this.hLineEx19.IsBold = false;
            this.hLineEx19.Location = new System.Drawing.Point(4, 516);
            this.hLineEx19.Name = "hLineEx19";
            this.hLineEx19.Size = new System.Drawing.Size(658, 1);
            this.hLineEx19.TabIndex = 161;
            this.hLineEx19.Text = "hLineEx3";
            // 
            // hLineEx18
            // 
            this.hLineEx18.BackColor = System.Drawing.Color.White;
            this.hLineEx18.IsBold = false;
            this.hLineEx18.Location = new System.Drawing.Point(4, 489);
            this.hLineEx18.Name = "hLineEx18";
            this.hLineEx18.Size = new System.Drawing.Size(658, 1);
            this.hLineEx18.TabIndex = 160;
            this.hLineEx18.Text = "hLineEx3";
            // 
            // hLineEx17
            // 
            this.hLineEx17.BackColor = System.Drawing.Color.White;
            this.hLineEx17.IsBold = false;
            this.hLineEx17.Location = new System.Drawing.Point(4, 462);
            this.hLineEx17.Name = "hLineEx17";
            this.hLineEx17.Size = new System.Drawing.Size(658, 1);
            this.hLineEx17.TabIndex = 159;
            this.hLineEx17.Text = "hLineEx3";
            // 
            // hLineEx16
            // 
            this.hLineEx16.BackColor = System.Drawing.Color.White;
            this.hLineEx16.IsBold = false;
            this.hLineEx16.Location = new System.Drawing.Point(4, 435);
            this.hLineEx16.Name = "hLineEx16";
            this.hLineEx16.Size = new System.Drawing.Size(658, 1);
            this.hLineEx16.TabIndex = 158;
            this.hLineEx16.Text = "hLineEx3";
            // 
            // hLineEx15
            // 
            this.hLineEx15.BackColor = System.Drawing.Color.White;
            this.hLineEx15.IsBold = false;
            this.hLineEx15.Location = new System.Drawing.Point(5, 408);
            this.hLineEx15.Name = "hLineEx15";
            this.hLineEx15.Size = new System.Drawing.Size(658, 1);
            this.hLineEx15.TabIndex = 155;
            this.hLineEx15.Text = "hLineEx3";
            // 
            // hLineEx14
            // 
            this.hLineEx14.BackColor = System.Drawing.Color.White;
            this.hLineEx14.IsBold = false;
            this.hLineEx14.Location = new System.Drawing.Point(5, 381);
            this.hLineEx14.Name = "hLineEx14";
            this.hLineEx14.Size = new System.Drawing.Size(658, 1);
            this.hLineEx14.TabIndex = 155;
            this.hLineEx14.Text = "hLineEx3";
            // 
            // hLineEx13
            // 
            this.hLineEx13.BackColor = System.Drawing.Color.White;
            this.hLineEx13.IsBold = false;
            this.hLineEx13.Location = new System.Drawing.Point(5, 354);
            this.hLineEx13.Name = "hLineEx13";
            this.hLineEx13.Size = new System.Drawing.Size(658, 1);
            this.hLineEx13.TabIndex = 154;
            this.hLineEx13.Text = "hLineEx3";
            // 
            // hLineEx12
            // 
            this.hLineEx12.BackColor = System.Drawing.Color.White;
            this.hLineEx12.IsBold = false;
            this.hLineEx12.Location = new System.Drawing.Point(5, 326);
            this.hLineEx12.Name = "hLineEx12";
            this.hLineEx12.Size = new System.Drawing.Size(658, 1);
            this.hLineEx12.TabIndex = 152;
            this.hLineEx12.Text = "hLineEx3";
            // 
            // hLineEx11
            // 
            this.hLineEx11.BackColor = System.Drawing.Color.White;
            this.hLineEx11.IsBold = false;
            this.hLineEx11.Location = new System.Drawing.Point(5, 299);
            this.hLineEx11.Name = "hLineEx11";
            this.hLineEx11.Size = new System.Drawing.Size(658, 1);
            this.hLineEx11.TabIndex = 151;
            this.hLineEx11.Text = "hLineEx3";
            // 
            // hLineEx10
            // 
            this.hLineEx10.BackColor = System.Drawing.Color.White;
            this.hLineEx10.IsBold = false;
            this.hLineEx10.Location = new System.Drawing.Point(5, 272);
            this.hLineEx10.Name = "hLineEx10";
            this.hLineEx10.Size = new System.Drawing.Size(658, 1);
            this.hLineEx10.TabIndex = 150;
            this.hLineEx10.Text = "hLineEx3";
            // 
            // hLineEx9
            // 
            this.hLineEx9.BackColor = System.Drawing.Color.White;
            this.hLineEx9.IsBold = false;
            this.hLineEx9.Location = new System.Drawing.Point(5, 245);
            this.hLineEx9.Name = "hLineEx9";
            this.hLineEx9.Size = new System.Drawing.Size(658, 1);
            this.hLineEx9.TabIndex = 149;
            this.hLineEx9.Text = "hLineEx3";
            // 
            // hLineEx8
            // 
            this.hLineEx8.BackColor = System.Drawing.Color.White;
            this.hLineEx8.IsBold = false;
            this.hLineEx8.Location = new System.Drawing.Point(5, 218);
            this.hLineEx8.Name = "hLineEx8";
            this.hLineEx8.Size = new System.Drawing.Size(658, 1);
            this.hLineEx8.TabIndex = 148;
            this.hLineEx8.Text = "hLineEx3";
            // 
            // hLineEx7
            // 
            this.hLineEx7.BackColor = System.Drawing.Color.White;
            this.hLineEx7.IsBold = false;
            this.hLineEx7.Location = new System.Drawing.Point(5, 191);
            this.hLineEx7.Name = "hLineEx7";
            this.hLineEx7.Size = new System.Drawing.Size(658, 1);
            this.hLineEx7.TabIndex = 147;
            this.hLineEx7.Text = "hLineEx3";
            // 
            // hLineEx6
            // 
            this.hLineEx6.BackColor = System.Drawing.Color.White;
            this.hLineEx6.IsBold = false;
            this.hLineEx6.Location = new System.Drawing.Point(5, 164);
            this.hLineEx6.Name = "hLineEx6";
            this.hLineEx6.Size = new System.Drawing.Size(658, 1);
            this.hLineEx6.TabIndex = 146;
            this.hLineEx6.Text = "hLineEx3";
            // 
            // hLineEx5
            // 
            this.hLineEx5.BackColor = System.Drawing.Color.White;
            this.hLineEx5.IsBold = false;
            this.hLineEx5.Location = new System.Drawing.Point(5, 137);
            this.hLineEx5.Name = "hLineEx5";
            this.hLineEx5.Size = new System.Drawing.Size(658, 1);
            this.hLineEx5.TabIndex = 144;
            this.hLineEx5.Text = "hLineEx3";
            // 
            // hLineEx4
            // 
            this.hLineEx4.BackColor = System.Drawing.Color.White;
            this.hLineEx4.IsBold = false;
            this.hLineEx4.Location = new System.Drawing.Point(5, 110);
            this.hLineEx4.Name = "hLineEx4";
            this.hLineEx4.Size = new System.Drawing.Size(658, 1);
            this.hLineEx4.TabIndex = 144;
            this.hLineEx4.Text = "hLineEx3";
            // 
            // hLineEx3
            // 
            this.hLineEx3.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton;
            this.hLineEx3.BackColor = System.Drawing.Color.White;
            this.hLineEx3.IsBold = false;
            this.hLineEx3.Location = new System.Drawing.Point(5, 65);
            this.hLineEx3.Name = "hLineEx3";
            this.hLineEx3.Size = new System.Drawing.Size(658, 1);
            this.hLineEx3.TabIndex = 144;
            this.hLineEx3.Text = "hLineEx3";
            // 
            // labZymosis
            // 
            this.labZymosis.Appearance.ForeColor = System.Drawing.Color.Red;
            this.labZymosis.Location = new System.Drawing.Point(122, 306);
            this.labZymosis.Name = "labZymosis";
            this.labZymosis.Size = new System.Drawing.Size(84, 14);
            this.labZymosis.TabIndex = 112;
            this.labZymosis.Text = "医院传染病名称";
            this.labZymosis.Visible = false;
            // 
            // labelControl1
            // 
            this.labelControl1.Appearance.ForeColor = System.Drawing.Color.Red;
            this.labelControl1.Location = new System.Drawing.Point(163, 361);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(132, 14);
            this.labelControl1.TabIndex = 112;
            this.labelControl1.Text = "损伤、中毒的外部因素：";
            // 
            // Print_UCIemDiagnose
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(239)))), ((int)(((byte)(255)))));
            this.Controls.Add(this.hLineEx1);
            this.Controls.Add(this.vLineEx6);
            this.Controls.Add(this.vLineEx5);
            this.Controls.Add(this.vLineEx4);
            this.Controls.Add(this.vLineEx3);
            this.Controls.Add(this.vLineEx2);
            this.Controls.Add(this.vLineEx1);
            this.Controls.Add(this.lueZkys);
            this.Controls.Add(this.lueZkhs);
            this.Controls.Add(this.lueBmy);
            this.Controls.Add(this.lueSxys);
            this.Controls.Add(this.lueYjs);
            this.Controls.Add(this.lueJxys);
            this.Controls.Add(this.lueZyys);
            this.Controls.Add(this.lueZzys);
            this.Controls.Add(this.lueZrys);
            this.Controls.Add(this.lueKszr);
            this.Controls.Add(this.labDiagnosis_Code6);
            this.Controls.Add(this.chkStatus_1_6);
            this.Controls.Add(this.chkStatus_2_6);
            this.Controls.Add(this.chkStatus_3_6);
            this.Controls.Add(this.chkStatus_5_6);
            this.Controls.Add(this.chkStatus_4_6);
            this.Controls.Add(this.labDiagnosis_Code7);
            this.Controls.Add(this.chkStatus_1_7);
            this.Controls.Add(this.chkStatus_3_7);
            this.Controls.Add(this.chkStatus_4_7);
            this.Controls.Add(this.chkStatus_5_7);
            this.Controls.Add(this.chkStatus_2_7);
            this.Controls.Add(this.labDiagnosis_Code5);
            this.Controls.Add(this.chkStatus_1_5);
            this.Controls.Add(this.chkStatus_4_5);
            this.Controls.Add(this.chkStatus_2_5);
            this.Controls.Add(this.chkStatus_5_5);
            this.Controls.Add(this.chkStatus_3_5);
            this.Controls.Add(this.labDiagnosis_Code4);
            this.Controls.Add(this.chkStatus_1_4);
            this.Controls.Add(this.chkStatus_2_4);
            this.Controls.Add(this.chkStatus_3_4);
            this.Controls.Add(this.chkStatus_5_4);
            this.Controls.Add(this.chkStatus_4_4);
            this.Controls.Add(this.labDiagnosis_Code3);
            this.Controls.Add(this.chkStatus_1_3);
            this.Controls.Add(this.chkStatus_3_3);
            this.Controls.Add(this.chkStatus_4_3);
            this.Controls.Add(this.chkStatus_5_3);
            this.Controls.Add(this.chkStatus_2_3);
            this.Controls.Add(this.labDiagnosis_Code2);
            this.Controls.Add(this.chkStatus_1_2);
            this.Controls.Add(this.chkStatus_4_2);
            this.Controls.Add(this.chkStatus_2_2);
            this.Controls.Add(this.chkStatus_5_2);
            this.Controls.Add(this.chkStatus_3_2);
            this.Controls.Add(this.labDiagnosis_Code1);
            this.Controls.Add(this.chkStatus_4_1);
            this.Controls.Add(this.chkStatus_5_1);
            this.Controls.Add(this.chkStatus_3_1);
            this.Controls.Add(this.chkStatus_2_1);
            this.Controls.Add(this.chkStatus_1_1);
            this.Controls.Add(this.labZymosis);
            this.Controls.Add(this.labDiagnosis_Name7);
            this.Controls.Add(this.labDiagnosis_Name6);
            this.Controls.Add(this.labDiagnosis_Name5);
            this.Controls.Add(this.labDiagnosis_Name4);
            this.Controls.Add(this.labDiagnosis_Name3);
            this.Controls.Add(this.labDiagnosis_Name2);
            this.Controls.Add(this.labDiagnosis_Name1);
            this.Controls.Add(this.hLineExlast);
            this.Controls.Add(this.textEdit3);
            this.Controls.Add(this.labelControl68);
            this.Controls.Add(this.labelControl67);
            this.Controls.Add(this.labelControl66);
            this.Controls.Add(this.labelControl65);
            this.Controls.Add(this.labMedical_Quality);
            this.Controls.Add(this.labelControl63);
            this.Controls.Add(this.labelControl62);
            this.Controls.Add(this.labelControl56);
            this.Controls.Add(this.labelControl61);
            this.Controls.Add(this.labelControl60);
            this.Controls.Add(this.labelControl55);
            this.Controls.Add(this.labelControl53);
            this.Controls.Add(this.labelControl52);
            this.Controls.Add(this.labelControl51);
            this.Controls.Add(this.seSuccessTimes);
            this.Controls.Add(this.seSaveTimes);
            this.Controls.Add(this.labelControl50);
            this.Controls.Add(this.labelControl49);
            this.Controls.Add(this.labelControl48);
            this.Controls.Add(this.labelControl47);
            this.Controls.Add(this.labelControl46);
            this.Controls.Add(this.chkPacsPathology);
            this.Controls.Add(this.labelControl44);
            this.Controls.Add(this.chkClinical);
            this.Controls.Add(this.chkBeforeAfter);
            this.Controls.Add(this.chkInOut);
            this.Controls.Add(this.chkOpdIpd);
            this.Controls.Add(this.labelControl39);
            this.Controls.Add(this.labelControl38);
            this.Controls.Add(this.labelControl37);
            this.Controls.Add(this.labelControl36);
            this.Controls.Add(this.labelControl35);
            this.Controls.Add(this.hLineEx19);
            this.Controls.Add(this.hLineEx18);
            this.Controls.Add(this.hLineEx17);
            this.Controls.Add(this.hLineEx16);
            this.Controls.Add(this.labelControl34);
            this.Controls.Add(this.chkHIV);
            this.Controls.Add(this.labelControl32);
            this.Controls.Add(this.chkHCV);
            this.Controls.Add(this.labelControl30);
            this.Controls.Add(this.chkHBsAg);
            this.Controls.Add(this.labelControl28);
            this.Controls.Add(this.labelControl27);
            this.Controls.Add(this.hLineEx15);
            this.Controls.Add(this.labelControl1);
            this.Controls.Add(this.labelControl26);
            this.Controls.Add(this.hLineEx14);
            this.Controls.Add(this.labelControl25);
            this.Controls.Add(this.hLineEx13);
            this.Controls.Add(this.labelControl24);
            this.Controls.Add(this.labelControl23);
            this.Controls.Add(this.labelControl22);
            this.Controls.Add(this.labelControl21);
            this.Controls.Add(this.labelControl20);
            this.Controls.Add(this.labelControl19);
            this.Controls.Add(this.labelControl18);
            this.Controls.Add(this.labelControl17);
            this.Controls.Add(this.hLineEx12);
            this.Controls.Add(this.hLineEx11);
            this.Controls.Add(this.hLineEx10);
            this.Controls.Add(this.hLineEx9);
            this.Controls.Add(this.hLineEx8);
            this.Controls.Add(this.hLineEx7);
            this.Controls.Add(this.hLineEx6);
            this.Controls.Add(this.labelControl15);
            this.Controls.Add(this.hLineEx5);
            this.Controls.Add(this.hLineEx4);
            this.Controls.Add(this.hLineEx3);
            this.Controls.Add(this.labAdmitInfo);
            this.Controls.Add(this.txtIn_Check_Date);
            this.Controls.Add(this.txtPathologyName);
            this.Controls.Add(this.lueOutDiag);
            this.Controls.Add(this.labelControl57);
            this.Controls.Add(this.labelControl13);
            this.Controls.Add(this.labelControl58);
            this.Controls.Add(this.labelControl16);
            this.Controls.Add(this.labelControl14);
            this.Controls.Add(this.labelControl59);
            this.Controls.Add(this.lueInDiag);
            this.Controls.Add(this.labelControl116);
            this.Controls.Add(this.txtAllergicDrug);
            this.Name = "Print_UCIemDiagnose";
            this.Size = new System.Drawing.Size(666, 570);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.UCIemDiagnose_Paint);
            ((System.ComponentModel.ISupportInitialize)(this.txtPathologyName.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueInDiag)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueOutDiag)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtIn_Check_Date.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.seSaveTimes.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.seSuccessTimes.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit3.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtAllergicDrug.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueBmy)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueSxys)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueYjs)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueJxys)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueZyys)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueZzys)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueZrys)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueKszr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueZkys)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueZkhs)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevExpress.XtraEditors.LabelControl labelControl116;
        private YidanSoft.Common.Library.LookUpEditor lueInDiag;
        private DevExpress.XtraEditors.LabelControl labelControl59;
        private DevExpress.XtraEditors.LabelControl labelControl58;
        private YidanSoft.Common.Library.LookUpEditor lueOutDiag;
        private DevExpress.XtraEditors.LabelControl labelControl57;
        private DevExpress.XtraEditors.TextEdit txtPathologyName;
        private DevExpress.XtraEditors.LabelControl labAdmitInfo;
        private DevExpress.XtraEditors.LabelControl labelControl13;
        private DevExpress.XtraEditors.TextEdit txtIn_Check_Date;
        private HLineEx hLineEx3;
        private HLineEx hLineEx4;
        private HLineEx hLineEx5;
        private DevExpress.XtraEditors.LabelControl labelControl14;
        private DevExpress.XtraEditors.LabelControl labelControl15;
        private HLineEx hLineEx6;
        private HLineEx hLineEx7;
        private HLineEx hLineEx8;
        private HLineEx hLineEx9;
        private HLineEx hLineEx10;
        private HLineEx hLineEx11;
        private HLineEx hLineEx12;
        private DevExpress.XtraEditors.LabelControl labelControl16;
        private DevExpress.XtraEditors.LabelControl labelControl17;
        private DevExpress.XtraEditors.LabelControl labelControl18;
        private DevExpress.XtraEditors.LabelControl labelControl19;
        private DevExpress.XtraEditors.LabelControl labelControl20;
        private DevExpress.XtraEditors.LabelControl labelControl21;
        private DevExpress.XtraEditors.LabelControl labelControl22;
        private DevExpress.XtraEditors.LabelControl labelControl23;
        private DevExpress.XtraEditors.LabelControl labelControl24;
        private HLineEx hLineEx13;
        private DevExpress.XtraEditors.LabelControl labelControl25;
        private HLineEx hLineEx14;
        private DevExpress.XtraEditors.LabelControl labelControl26;
        private HLineEx hLineEx15;
        private DevExpress.XtraEditors.LabelControl labelControl27;
        private DevExpress.XtraEditors.LabelControl labelControl28;
        private DevExpress.XtraEditors.LabelControl chkHBsAg;
        private DevExpress.XtraEditors.LabelControl labelControl30;
        private DevExpress.XtraEditors.LabelControl chkHCV;
        private DevExpress.XtraEditors.LabelControl labelControl32;
        private DevExpress.XtraEditors.LabelControl chkHIV;
        private DevExpress.XtraEditors.LabelControl labelControl34;
        private HLineEx hLineEx16;
        private HLineEx hLineEx17;
        private HLineEx hLineEx18;
        private HLineEx hLineEx19;
        private DevExpress.XtraEditors.LabelControl labelControl35;
        private DevExpress.XtraEditors.LabelControl labelControl36;
        private DevExpress.XtraEditors.LabelControl labelControl37;
        private DevExpress.XtraEditors.LabelControl labelControl38;
        private DevExpress.XtraEditors.LabelControl labelControl39;
        private DevExpress.XtraEditors.LabelControl chkOpdIpd;
        private DevExpress.XtraEditors.LabelControl chkInOut;
        private DevExpress.XtraEditors.LabelControl chkBeforeAfter;
        private DevExpress.XtraEditors.LabelControl chkClinical;
        private DevExpress.XtraEditors.LabelControl labelControl44;
        private DevExpress.XtraEditors.LabelControl chkPacsPathology;
        private DevExpress.XtraEditors.LabelControl labelControl46;
        private DevExpress.XtraEditors.LabelControl labelControl47;
        private DevExpress.XtraEditors.LabelControl labelControl48;
        private DevExpress.XtraEditors.LabelControl labelControl49;
        private DevExpress.XtraEditors.LabelControl labelControl50;
        private DevExpress.XtraEditors.TextEdit seSaveTimes;
        private DevExpress.XtraEditors.TextEdit seSuccessTimes;
        private DevExpress.XtraEditors.LabelControl labelControl51;
        private DevExpress.XtraEditors.LabelControl labelControl52;
        private DevExpress.XtraEditors.LabelControl labelControl53;
        private DevExpress.XtraEditors.LabelControl labelControl55;
        private DevExpress.XtraEditors.LabelControl labelControl56;
        private DevExpress.XtraEditors.LabelControl labelControl60;
        private DevExpress.XtraEditors.LabelControl labelControl61;
        private DevExpress.XtraEditors.LabelControl labelControl62;
        private DevExpress.XtraEditors.LabelControl labelControl63;
        private DevExpress.XtraEditors.LabelControl labMedical_Quality;
        private DevExpress.XtraEditors.LabelControl labelControl65;
        private DevExpress.XtraEditors.LabelControl labelControl66;
        private DevExpress.XtraEditors.LabelControl labelControl67;
        private DevExpress.XtraEditors.LabelControl labelControl68;
        private DevExpress.XtraEditors.TextEdit textEdit3;
        private HLineEx hLineExlast;
        private DevExpress.XtraEditors.TextEdit txtAllergicDrug;
        private DevExpress.XtraEditors.LabelControl labDiagnosis_Name1;
        private DevExpress.XtraEditors.LabelControl labDiagnosis_Name2;
        private DevExpress.XtraEditors.LabelControl labDiagnosis_Name3;
        private DevExpress.XtraEditors.LabelControl labDiagnosis_Name4;
        private DevExpress.XtraEditors.LabelControl labDiagnosis_Name5;
        private DevExpress.XtraEditors.LabelControl labDiagnosis_Name6;
        private DevExpress.XtraEditors.LabelControl labDiagnosis_Name7;
        private System.Windows.Forms.CheckBox chkStatus_1_1;
        private System.Windows.Forms.CheckBox chkStatus_2_1;
        private System.Windows.Forms.CheckBox chkStatus_3_1;
        private System.Windows.Forms.CheckBox chkStatus_5_1;
        private System.Windows.Forms.CheckBox chkStatus_4_1;
        private DevExpress.XtraEditors.LabelControl labDiagnosis_Code1;
        private System.Windows.Forms.CheckBox chkStatus_1_2;
        private System.Windows.Forms.CheckBox chkStatus_2_2;
        private System.Windows.Forms.CheckBox chkStatus_3_2;
        private System.Windows.Forms.CheckBox chkStatus_5_2;
        private System.Windows.Forms.CheckBox chkStatus_4_2;
        private DevExpress.XtraEditors.LabelControl labDiagnosis_Code2;
        private System.Windows.Forms.CheckBox chkStatus_3_3;
        private System.Windows.Forms.CheckBox chkStatus_5_3;
        private System.Windows.Forms.CheckBox chkStatus_2_3;
        private System.Windows.Forms.CheckBox chkStatus_4_3;
        private System.Windows.Forms.CheckBox chkStatus_1_3;
        private DevExpress.XtraEditors.LabelControl labDiagnosis_Code3;
        private System.Windows.Forms.CheckBox chkStatus_2_4;
        private System.Windows.Forms.CheckBox chkStatus_5_4;
        private System.Windows.Forms.CheckBox chkStatus_4_4;
        private System.Windows.Forms.CheckBox chkStatus_3_4;
        private System.Windows.Forms.CheckBox chkStatus_1_4;
        private DevExpress.XtraEditors.LabelControl labDiagnosis_Code4;
        private System.Windows.Forms.CheckBox chkStatus_4_5;
        private System.Windows.Forms.CheckBox chkStatus_5_5;
        private System.Windows.Forms.CheckBox chkStatus_3_5;
        private System.Windows.Forms.CheckBox chkStatus_2_5;
        private System.Windows.Forms.CheckBox chkStatus_1_5;
        private DevExpress.XtraEditors.LabelControl labDiagnosis_Code5;
        private System.Windows.Forms.CheckBox chkStatus_3_7;
        private System.Windows.Forms.CheckBox chkStatus_5_7;
        private System.Windows.Forms.CheckBox chkStatus_2_7;
        private System.Windows.Forms.CheckBox chkStatus_4_7;
        private System.Windows.Forms.CheckBox chkStatus_1_7;
        private DevExpress.XtraEditors.LabelControl labDiagnosis_Code7;
        private System.Windows.Forms.CheckBox chkStatus_2_6;
        private System.Windows.Forms.CheckBox chkStatus_5_6;
        private System.Windows.Forms.CheckBox chkStatus_4_6;
        private System.Windows.Forms.CheckBox chkStatus_3_6;
        private System.Windows.Forms.CheckBox chkStatus_1_6;
        private DevExpress.XtraEditors.LabelControl labDiagnosis_Code6;
        private Common.Library.LookUpEditor lueBmy;
        private Common.Library.LookUpEditor lueSxys;
        private Common.Library.LookUpEditor lueYjs;
        private Common.Library.LookUpEditor lueJxys;
        private Common.Library.LookUpEditor lueZyys;
        private Common.Library.LookUpEditor lueZzys;
        private Common.Library.LookUpEditor lueZrys;
        private Common.Library.LookUpEditor lueKszr;
        private Common.Library.LookUpEditor lueZkys;
        private Common.Library.LookUpEditor lueZkhs;
        private VLineEx vLineEx1;
        private VLineEx vLineEx2;
        private VLineEx vLineEx3;
        private VLineEx vLineEx4;
        private VLineEx vLineEx5;
        private VLineEx vLineEx6;
        private HLineEx hLineEx1;
        private DevExpress.XtraEditors.LabelControl labZymosis;
        private DevExpress.XtraEditors.LabelControl labelControl1;
    }
}
