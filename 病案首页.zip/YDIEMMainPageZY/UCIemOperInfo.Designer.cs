﻿namespace DrectSoft.Core.IEMMainPageZY
{
    partial class UCIemOperInfo
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UCIemOperInfo));
            this.btnAddOperation = new DevExpress.XtraEditors.SimpleButton();
            this.gridControl1 = new DevExpress.XtraGrid.GridControl();
            this.gridViewOper = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn10 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn11 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn3 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn4 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn14 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn5 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn15 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn6 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn16 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn17 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn7 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn18 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn8 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn19 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn9 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn12 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.barManager1 = new DevExpress.XtraBars.BarManager(this.components);
            this.barDockControlTop = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlBottom = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlLeft = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlRight = new DevExpress.XtraBars.BarDockControl();
            this.btn_del_Operinfo = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem1 = new DevExpress.XtraBars.BarButtonItem();
            this.btn_del_operbefore_diag = new DevExpress.XtraBars.BarButtonItem();
            this.btn_operafter_diag = new DevExpress.XtraBars.BarButtonItem();
            this.popupMenu1 = new DevExpress.XtraBars.PopupMenu(this.components);
            this.txtLaterHosComaMinute = new DrectSoft.Common.Ctrs.OTHER.DSTextBox();
            this.txtBeforeHosComaMinute = new DrectSoft.Common.Ctrs.OTHER.DSTextBox();
            this.txtLaterHosComaHour = new DrectSoft.Common.Ctrs.OTHER.DSTextBox();
            this.txtBeforeHosComaHour = new DrectSoft.Common.Ctrs.OTHER.DSTextBox();
            this.txtLaterHosComaDay = new DrectSoft.Common.Ctrs.OTHER.DSTextBox();
            this.txtBeforeHosComaDay = new DrectSoft.Common.Ctrs.OTHER.DSTextBox();
            this.txtAgainInHospitalReason = new DrectSoft.Common.Ctrs.OTHER.DSTextBox();
            this.txtReceiveHosPital2 = new DrectSoft.Common.Ctrs.OTHER.DSTextBox();
            this.txtReceiveHosPital = new DrectSoft.Common.Ctrs.OTHER.DSTextBox();
            this.labelControl24 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl23 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl38 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl32 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl36 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl30 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl34 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl27 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl25 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl22 = new DevExpress.XtraEditors.LabelControl();
            this.chkAgainInHospital2 = new DevExpress.XtraEditors.CheckEdit();
            this.chkOutHosType2 = new DevExpress.XtraEditors.CheckEdit();
            this.chkOutHosType3 = new DevExpress.XtraEditors.CheckEdit();
            this.chkOutHosType9 = new DevExpress.XtraEditors.CheckEdit();
            this.chkOutHosType5 = new DevExpress.XtraEditors.CheckEdit();
            this.chkOutHosType4 = new DevExpress.XtraEditors.CheckEdit();
            this.chkAgainInHospital1 = new DevExpress.XtraEditors.CheckEdit();
            this.chkOutHosType1 = new DevExpress.XtraEditors.CheckEdit();
            this.hLineEx1 = new DrectSoft.Core.IEMMainPageZY.HLineEx();
            this.btnEditOperation = new DevExpress.XtraEditors.SimpleButton();
            this.btn_Close = new DrectSoft.Common.Ctrs.OTHER.DevButtonClose(this.components);
            this.btn_OK = new DrectSoft.Common.Ctrs.OTHER.DevButtonSave(this.components);
            this.btnDelete = new DrectSoft.Common.Ctrs.OTHER.DevButtonDelete(this.components);
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.txtScore = new DrectSoft.Common.Ctrs.OTHER.DSTextBox();
            this.labelControl2 = new DevExpress.XtraEditors.LabelControl();
            ((System.ComponentModel.ISupportInitialize)(this.gridControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewOper)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.barManager1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.popupMenu1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtLaterHosComaMinute.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtBeforeHosComaMinute.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtLaterHosComaHour.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtBeforeHosComaHour.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtLaterHosComaDay.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtBeforeHosComaDay.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtAgainInHospitalReason.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtReceiveHosPital2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtReceiveHosPital.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkAgainInHospital2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkOutHosType2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkOutHosType3.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkOutHosType9.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkOutHosType5.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkOutHosType4.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkAgainInHospital1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkOutHosType1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtScore.Properties)).BeginInit();
            this.SuspendLayout();
            // 
            // btnAddOperation
            // 
            this.btnAddOperation.Location = new System.Drawing.Point(25, 11);
            this.btnAddOperation.Name = "btnAddOperation";
            this.btnAddOperation.Size = new System.Drawing.Size(103, 23);
            this.btnAddOperation.TabIndex = 1;
            this.btnAddOperation.Text = "新增手术信息";
            this.btnAddOperation.Click += new System.EventHandler(this.btnAddDiagnose_Click);
            // 
            // gridControl1
            // 
            this.gridControl1.Location = new System.Drawing.Point(5, 40);
            this.gridControl1.MainView = this.gridViewOper;
            this.gridControl1.Name = "gridControl1";
            this.gridControl1.Size = new System.Drawing.Size(631, 109);
            this.gridControl1.TabIndex = 0;
            this.gridControl1.TabStop = false;
            this.gridControl1.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridViewOper});
            this.gridControl1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.gridControl1_MouseUp);
            // 
            // gridViewOper
            // 
            this.gridViewOper.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn1,
            this.gridColumn2,
            this.gridColumn10,
            this.gridColumn11,
            this.gridColumn3,
            this.gridColumn4,
            this.gridColumn14,
            this.gridColumn5,
            this.gridColumn15,
            this.gridColumn6,
            this.gridColumn16,
            this.gridColumn17,
            this.gridColumn7,
            this.gridColumn18,
            this.gridColumn8,
            this.gridColumn19,
            this.gridColumn9,
            this.gridColumn12});
            this.gridViewOper.GridControl = this.gridControl1;
            this.gridViewOper.Name = "gridViewOper";
            this.gridViewOper.OptionsCustomization.AllowColumnMoving = false;
            this.gridViewOper.OptionsCustomization.AllowFilter = false;
            this.gridViewOper.OptionsCustomization.AllowGroup = false;
            this.gridViewOper.OptionsCustomization.AllowQuickHideColumns = false;
            this.gridViewOper.OptionsMenu.EnableColumnMenu = false;
            this.gridViewOper.OptionsMenu.EnableFooterMenu = false;
            this.gridViewOper.OptionsMenu.EnableGroupPanelMenu = false;
            this.gridViewOper.OptionsMenu.ShowAutoFilterRowItem = false;
            this.gridViewOper.OptionsMenu.ShowDateTimeGroupIntervalItems = false;
            this.gridViewOper.OptionsMenu.ShowGroupSortSummaryItems = false;
            this.gridViewOper.OptionsView.ShowGroupPanel = false;
            this.gridViewOper.OptionsView.ShowIndicator = false;
            this.gridViewOper.MouseUp += new System.Windows.Forms.MouseEventHandler(this.gridControl1_MouseUp);
            // 
            // gridColumn1
            // 
            this.gridColumn1.Caption = "手术操作码";
            this.gridColumn1.FieldName = "Operation_Code";
            this.gridColumn1.Name = "gridColumn1";
            this.gridColumn1.OptionsColumn.AllowEdit = false;
            this.gridColumn1.Visible = true;
            this.gridColumn1.VisibleIndex = 0;
            this.gridColumn1.Width = 65;
            // 
            // gridColumn2
            // 
            this.gridColumn2.Caption = "手术操作日期";
            this.gridColumn2.FieldName = "Operation_Date";
            this.gridColumn2.Name = "gridColumn2";
            this.gridColumn2.OptionsColumn.AllowEdit = false;
            this.gridColumn2.Visible = true;
            this.gridColumn2.VisibleIndex = 1;
            this.gridColumn2.Width = 70;
            // 
            // gridColumn10
            // 
            this.gridColumn10.Caption = "手术等级";
            this.gridColumn10.FieldName = "OPERATION_LEVEL_NAME";
            this.gridColumn10.Name = "gridColumn10";
            this.gridColumn10.OptionsColumn.AllowEdit = false;
            this.gridColumn10.Visible = true;
            this.gridColumn10.VisibleIndex = 2;
            this.gridColumn10.Width = 55;
            // 
            // gridColumn11
            // 
            this.gridColumn11.Caption = "手术等级编号";
            this.gridColumn11.FieldName = "OPERATION_LEVEL";
            this.gridColumn11.Name = "gridColumn11";
            // 
            // gridColumn3
            // 
            this.gridColumn3.Caption = "手术操作名称";
            this.gridColumn3.FieldName = "Operation_Name";
            this.gridColumn3.Name = "gridColumn3";
            this.gridColumn3.OptionsColumn.AllowEdit = false;
            this.gridColumn3.Visible = true;
            this.gridColumn3.VisibleIndex = 3;
            this.gridColumn3.Width = 55;
            // 
            // gridColumn4
            // 
            this.gridColumn4.Caption = "术者";
            this.gridColumn4.FieldName = "Execute_User1_Name";
            this.gridColumn4.Name = "gridColumn4";
            this.gridColumn4.OptionsColumn.AllowEdit = false;
            this.gridColumn4.Visible = true;
            this.gridColumn4.VisibleIndex = 4;
            this.gridColumn4.Width = 55;
            // 
            // gridColumn14
            // 
            this.gridColumn14.Caption = "术者ID";
            this.gridColumn14.FieldName = "Execute_User1";
            this.gridColumn14.Name = "gridColumn14";
            this.gridColumn14.OptionsColumn.AllowEdit = false;
            // 
            // gridColumn5
            // 
            this.gridColumn5.Caption = "I助";
            this.gridColumn5.FieldName = "Execute_User2_Name";
            this.gridColumn5.Name = "gridColumn5";
            this.gridColumn5.OptionsColumn.AllowEdit = false;
            this.gridColumn5.Visible = true;
            this.gridColumn5.VisibleIndex = 5;
            this.gridColumn5.Width = 55;
            // 
            // gridColumn15
            // 
            this.gridColumn15.Caption = "I助ID";
            this.gridColumn15.FieldName = "Execute_User2";
            this.gridColumn15.Name = "gridColumn15";
            this.gridColumn15.OptionsColumn.AllowEdit = false;
            // 
            // gridColumn6
            // 
            this.gridColumn6.Caption = "II助";
            this.gridColumn6.FieldName = "Execute_User3_Name";
            this.gridColumn6.Name = "gridColumn6";
            this.gridColumn6.OptionsColumn.AllowEdit = false;
            this.gridColumn6.Visible = true;
            this.gridColumn6.VisibleIndex = 6;
            this.gridColumn6.Width = 55;
            // 
            // gridColumn16
            // 
            this.gridColumn16.Caption = "II助ID";
            this.gridColumn16.FieldName = "Execute_User3";
            this.gridColumn16.Name = "gridColumn16";
            this.gridColumn16.OptionsColumn.AllowEdit = false;
            // 
            // gridColumn17
            // 
            this.gridColumn17.Caption = "麻醉方式";
            this.gridColumn17.FieldName = "Anaesthesia_Type_Name";
            this.gridColumn17.Name = "gridColumn17";
            this.gridColumn17.OptionsColumn.AllowEdit = false;
            this.gridColumn17.Visible = true;
            this.gridColumn17.VisibleIndex = 7;
            this.gridColumn17.Width = 55;
            // 
            // gridColumn7
            // 
            this.gridColumn7.Caption = "麻醉方式ID";
            this.gridColumn7.FieldName = "Anaesthesia_Type_Id";
            this.gridColumn7.Name = "gridColumn7";
            this.gridColumn7.OptionsColumn.AllowEdit = false;
            // 
            // gridColumn18
            // 
            this.gridColumn18.Caption = "切口愈合等级";
            this.gridColumn18.FieldName = "Close_Level_Name";
            this.gridColumn18.Name = "gridColumn18";
            this.gridColumn18.OptionsColumn.AllowEdit = false;
            this.gridColumn18.Visible = true;
            this.gridColumn18.VisibleIndex = 8;
            this.gridColumn18.Width = 55;
            // 
            // gridColumn8
            // 
            this.gridColumn8.Caption = "切口愈合等级ID";
            this.gridColumn8.FieldName = "Close_Level";
            this.gridColumn8.Name = "gridColumn8";
            this.gridColumn8.OptionsColumn.AllowEdit = false;
            // 
            // gridColumn19
            // 
            this.gridColumn19.Caption = "麻醉医师";
            this.gridColumn19.FieldName = "Anaesthesia_User_Name";
            this.gridColumn19.Name = "gridColumn19";
            this.gridColumn19.OptionsColumn.AllowEdit = false;
            this.gridColumn19.Visible = true;
            this.gridColumn19.VisibleIndex = 9;
            this.gridColumn19.Width = 88;
            // 
            // gridColumn9
            // 
            this.gridColumn9.Caption = "麻醉医师ID";
            this.gridColumn9.FieldName = "Anaesthesia_User";
            this.gridColumn9.Name = "gridColumn9";
            this.gridColumn9.OptionsColumn.AllowEdit = false;
            // 
            // gridColumn12
            // 
            this.gridColumn12.Caption = "手术用时";
            this.gridColumn12.FieldName = "OperInTimes";
            this.gridColumn12.Name = "gridColumn12";
            this.gridColumn12.Visible = true;
            this.gridColumn12.VisibleIndex = 10;
            // 
            // barManager1
            // 
            this.barManager1.DockControls.Add(this.barDockControlTop);
            this.barManager1.DockControls.Add(this.barDockControlBottom);
            this.barManager1.DockControls.Add(this.barDockControlLeft);
            this.barManager1.DockControls.Add(this.barDockControlRight);
            this.barManager1.Form = this;
            this.barManager1.Items.AddRange(new DevExpress.XtraBars.BarItem[] {
            this.btn_del_Operinfo,
            this.barButtonItem1,
            this.btn_del_operbefore_diag,
            this.btn_operafter_diag});
            this.barManager1.MaxItemId = 7;
            this.barManager1.QueryShowPopupMenu += new DevExpress.XtraBars.QueryShowPopupMenuEventHandler(this.barManager1_QueryShowPopupMenu);
            // 
            // barDockControlTop
            // 
            this.barDockControlTop.CausesValidation = false;
            this.barDockControlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.barDockControlTop.Location = new System.Drawing.Point(0, 0);
            this.barDockControlTop.Size = new System.Drawing.Size(650, 0);
            // 
            // barDockControlBottom
            // 
            this.barDockControlBottom.CausesValidation = false;
            this.barDockControlBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.barDockControlBottom.Location = new System.Drawing.Point(0, 387);
            this.barDockControlBottom.Size = new System.Drawing.Size(650, 0);
            // 
            // barDockControlLeft
            // 
            this.barDockControlLeft.CausesValidation = false;
            this.barDockControlLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.barDockControlLeft.Location = new System.Drawing.Point(0, 0);
            this.barDockControlLeft.Size = new System.Drawing.Size(0, 387);
            // 
            // barDockControlRight
            // 
            this.barDockControlRight.CausesValidation = false;
            this.barDockControlRight.Dock = System.Windows.Forms.DockStyle.Right;
            this.barDockControlRight.Location = new System.Drawing.Point(650, 0);
            this.barDockControlRight.Size = new System.Drawing.Size(0, 387);
            // 
            // btn_del_Operinfo
            // 
            this.btn_del_Operinfo.Caption = "删除";
            this.btn_del_Operinfo.Id = 1;
            this.btn_del_Operinfo.Name = "btn_del_Operinfo";
            this.btn_del_Operinfo.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btn_del_Operinfo_ItemClick);
            // 
            // barButtonItem1
            // 
            this.barButtonItem1.Caption = "barButtonItem1";
            this.barButtonItem1.Id = 2;
            this.barButtonItem1.Name = "barButtonItem1";
            // 
            // btn_del_operbefore_diag
            // 
            this.btn_del_operbefore_diag.Id = 5;
            this.btn_del_operbefore_diag.Name = "btn_del_operbefore_diag";
            // 
            // btn_operafter_diag
            // 
            this.btn_operafter_diag.Id = 6;
            this.btn_operafter_diag.Name = "btn_operafter_diag";
            // 
            // popupMenu1
            // 
            this.popupMenu1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.btn_del_Operinfo),
            new DevExpress.XtraBars.LinkPersistInfo(this.btn_del_operbefore_diag),
            new DevExpress.XtraBars.LinkPersistInfo(this.btn_operafter_diag)});
            this.popupMenu1.Manager = this.barManager1;
            this.popupMenu1.Name = "popupMenu1";
            // 
            // txtLaterHosComaMinute
            // 
            this.txtLaterHosComaMinute.EnterMoveNextControl = true;
            this.txtLaterHosComaMinute.Location = new System.Drawing.Point(573, 270);
            this.txtLaterHosComaMinute.Name = "txtLaterHosComaMinute";
            this.txtLaterHosComaMinute.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtLaterHosComaMinute.Size = new System.Drawing.Size(36, 19);
            this.txtLaterHosComaMinute.TabIndex = 20;
            // 
            // txtBeforeHosComaMinute
            // 
            this.txtBeforeHosComaMinute.EnterMoveNextControl = true;
            this.txtBeforeHosComaMinute.Location = new System.Drawing.Point(317, 271);
            this.txtBeforeHosComaMinute.Name = "txtBeforeHosComaMinute";
            this.txtBeforeHosComaMinute.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtBeforeHosComaMinute.Size = new System.Drawing.Size(36, 19);
            this.txtBeforeHosComaMinute.TabIndex = 17;
            // 
            // txtLaterHosComaHour
            // 
            this.txtLaterHosComaHour.EnterMoveNextControl = true;
            this.txtLaterHosComaHour.Location = new System.Drawing.Point(501, 270);
            this.txtLaterHosComaHour.Name = "txtLaterHosComaHour";
            this.txtLaterHosComaHour.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtLaterHosComaHour.Size = new System.Drawing.Size(36, 19);
            this.txtLaterHosComaHour.TabIndex = 19;
            // 
            // txtBeforeHosComaHour
            // 
            this.txtBeforeHosComaHour.EnterMoveNextControl = true;
            this.txtBeforeHosComaHour.Location = new System.Drawing.Point(247, 271);
            this.txtBeforeHosComaHour.Name = "txtBeforeHosComaHour";
            this.txtBeforeHosComaHour.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtBeforeHosComaHour.Size = new System.Drawing.Size(36, 19);
            this.txtBeforeHosComaHour.TabIndex = 16;
            // 
            // txtLaterHosComaDay
            // 
            this.txtLaterHosComaDay.EnterMoveNextControl = true;
            this.txtLaterHosComaDay.Location = new System.Drawing.Point(441, 271);
            this.txtLaterHosComaDay.Name = "txtLaterHosComaDay";
            this.txtLaterHosComaDay.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtLaterHosComaDay.Size = new System.Drawing.Size(36, 19);
            this.txtLaterHosComaDay.TabIndex = 18;
            // 
            // txtBeforeHosComaDay
            // 
            this.txtBeforeHosComaDay.EnterMoveNextControl = true;
            this.txtBeforeHosComaDay.Location = new System.Drawing.Point(191, 271);
            this.txtBeforeHosComaDay.Name = "txtBeforeHosComaDay";
            this.txtBeforeHosComaDay.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtBeforeHosComaDay.Size = new System.Drawing.Size(36, 19);
            this.txtBeforeHosComaDay.TabIndex = 15;
            // 
            // txtAgainInHospitalReason
            // 
            this.txtAgainInHospitalReason.EditValue = "";
            this.txtAgainInHospitalReason.EnterMoveNextControl = true;
            this.txtAgainInHospitalReason.Location = new System.Drawing.Point(341, 247);
            this.txtAgainInHospitalReason.Name = "txtAgainInHospitalReason";
            this.txtAgainInHospitalReason.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtAgainInHospitalReason.Size = new System.Drawing.Size(294, 19);
            this.txtAgainInHospitalReason.TabIndex = 14;
            // 
            // txtReceiveHosPital2
            // 
            this.txtReceiveHosPital2.EditValue = "";
            this.txtReceiveHosPital2.EnterMoveNextControl = true;
            this.txtReceiveHosPital2.Location = new System.Drawing.Point(401, 199);
            this.txtReceiveHosPital2.Name = "txtReceiveHosPital2";
            this.txtReceiveHosPital2.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtReceiveHosPital2.Size = new System.Drawing.Size(234, 19);
            this.txtReceiveHosPital2.TabIndex = 8;
            // 
            // txtReceiveHosPital
            // 
            this.txtReceiveHosPital.EditValue = "";
            this.txtReceiveHosPital.EnterMoveNextControl = true;
            this.txtReceiveHosPital.Location = new System.Drawing.Point(385, 174);
            this.txtReceiveHosPital.Name = "txtReceiveHosPital";
            this.txtReceiveHosPital.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtReceiveHosPital.Size = new System.Drawing.Size(251, 19);
            this.txtReceiveHosPital.TabIndex = 6;
            // 
            // labelControl24
            // 
            this.labelControl24.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl24.Location = new System.Drawing.Point(13, 273);
            this.labelControl24.Name = "labelControl24";
            this.labelControl24.Size = new System.Drawing.Size(172, 14);
            this.labelControl24.TabIndex = 232;
            this.labelControl24.Text = "颅脑损伤患者昏迷时间： 入院前";
            // 
            // labelControl23
            // 
            this.labelControl23.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl23.Location = new System.Drawing.Point(15, 249);
            this.labelControl23.Name = "labelControl23";
            this.labelControl23.Size = new System.Drawing.Size(170, 14);
            this.labelControl23.TabIndex = 231;
            this.labelControl23.Text = "是否有出院31天内再住院计划：";
            // 
            // labelControl38
            // 
            this.labelControl38.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl38.Location = new System.Drawing.Point(611, 272);
            this.labelControl38.Name = "labelControl38";
            this.labelControl38.Size = new System.Drawing.Size(24, 14);
            this.labelControl38.TabIndex = 234;
            this.labelControl38.Text = "分钟";
            // 
            // labelControl32
            // 
            this.labelControl32.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl32.Location = new System.Drawing.Point(399, 273);
            this.labelControl32.Name = "labelControl32";
            this.labelControl32.Size = new System.Drawing.Size(36, 14);
            this.labelControl32.TabIndex = 233;
            this.labelControl32.Text = "入院后";
            // 
            // labelControl36
            // 
            this.labelControl36.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl36.Location = new System.Drawing.Point(543, 272);
            this.labelControl36.Name = "labelControl36";
            this.labelControl36.Size = new System.Drawing.Size(24, 14);
            this.labelControl36.TabIndex = 230;
            this.labelControl36.Text = "小时";
            // 
            // labelControl30
            // 
            this.labelControl30.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl30.Location = new System.Drawing.Point(361, 273);
            this.labelControl30.Name = "labelControl30";
            this.labelControl30.Size = new System.Drawing.Size(24, 14);
            this.labelControl30.TabIndex = 226;
            this.labelControl30.Text = "分钟";
            // 
            // labelControl34
            // 
            this.labelControl34.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl34.Location = new System.Drawing.Point(483, 273);
            this.labelControl34.Name = "labelControl34";
            this.labelControl34.Size = new System.Drawing.Size(12, 14);
            this.labelControl34.TabIndex = 225;
            this.labelControl34.Text = "天";
            // 
            // labelControl27
            // 
            this.labelControl27.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl27.Location = new System.Drawing.Point(287, 273);
            this.labelControl27.Name = "labelControl27";
            this.labelControl27.Size = new System.Drawing.Size(24, 14);
            this.labelControl27.TabIndex = 227;
            this.labelControl27.Text = "小时";
            // 
            // labelControl25
            // 
            this.labelControl25.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl25.Location = new System.Drawing.Point(233, 273);
            this.labelControl25.Name = "labelControl25";
            this.labelControl25.Size = new System.Drawing.Size(12, 14);
            this.labelControl25.TabIndex = 229;
            this.labelControl25.Text = "天";
            // 
            // labelControl22
            // 
            this.labelControl22.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl22.Location = new System.Drawing.Point(15, 175);
            this.labelControl22.Name = "labelControl22";
            this.labelControl22.Size = new System.Drawing.Size(60, 14);
            this.labelControl22.TabIndex = 228;
            this.labelControl22.Text = "离院方式：";
            // 
            // chkAgainInHospital2
            // 
            this.chkAgainInHospital2.Location = new System.Drawing.Point(245, 246);
            this.chkAgainInHospital2.Name = "chkAgainInHospital2";
            this.chkAgainInHospital2.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkAgainInHospital2.Properties.Appearance.Options.UseForeColor = true;
            this.chkAgainInHospital2.Properties.Caption = "2.有，目的:";
            this.chkAgainInHospital2.Properties.RadioGroupIndex = 1;
            this.chkAgainInHospital2.Size = new System.Drawing.Size(90, 19);
            this.chkAgainInHospital2.TabIndex = 13;
            this.chkAgainInHospital2.TabStop = false;
            this.chkAgainInHospital2.Click += new System.EventHandler(this.chk_CheckedChanged);
            // 
            // chkOutHosType2
            // 
            this.chkOutHosType2.Location = new System.Drawing.Point(169, 173);
            this.chkOutHosType2.Name = "chkOutHosType2";
            this.chkOutHosType2.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkOutHosType2.Properties.Appearance.Options.UseForeColor = true;
            this.chkOutHosType2.Properties.Caption = "2.医嘱转院，拟接收医疗机构名称：";
            this.chkOutHosType2.Properties.RadioGroupIndex = 0;
            this.chkOutHosType2.Size = new System.Drawing.Size(201, 19);
            this.chkOutHosType2.TabIndex = 5;
            this.chkOutHosType2.TabStop = false;
            this.chkOutHosType2.Click += new System.EventHandler(this.chk_CheckedChanged);
            // 
            // chkOutHosType3
            // 
            this.chkOutHosType3.Location = new System.Drawing.Point(24, 199);
            this.chkOutHosType3.Name = "chkOutHosType3";
            this.chkOutHosType3.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkOutHosType3.Properties.Appearance.Options.UseForeColor = true;
            this.chkOutHosType3.Properties.Caption = "3.医嘱转社区卫生服务机构/乡镇卫生院，拟接收医疗机构名称：";
            this.chkOutHosType3.Properties.RadioGroupIndex = 0;
            this.chkOutHosType3.Size = new System.Drawing.Size(361, 19);
            this.chkOutHosType3.TabIndex = 7;
            this.chkOutHosType3.TabStop = false;
            this.chkOutHosType3.Click += new System.EventHandler(this.chk_CheckedChanged);
            // 
            // chkOutHosType9
            // 
            this.chkOutHosType9.Location = new System.Drawing.Point(199, 224);
            this.chkOutHosType9.Name = "chkOutHosType9";
            this.chkOutHosType9.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkOutHosType9.Properties.Appearance.Options.UseForeColor = true;
            this.chkOutHosType9.Properties.Caption = "9.其他";
            this.chkOutHosType9.Properties.RadioGroupIndex = 0;
            this.chkOutHosType9.Size = new System.Drawing.Size(59, 19);
            this.chkOutHosType9.TabIndex = 11;
            this.chkOutHosType9.TabStop = false;
            this.chkOutHosType9.Click += new System.EventHandler(this.chk_CheckedChanged);
            // 
            // chkOutHosType5
            // 
            this.chkOutHosType5.Location = new System.Drawing.Point(134, 224);
            this.chkOutHosType5.Name = "chkOutHosType5";
            this.chkOutHosType5.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkOutHosType5.Properties.Appearance.Options.UseForeColor = true;
            this.chkOutHosType5.Properties.Caption = "5.死亡";
            this.chkOutHosType5.Properties.RadioGroupIndex = 0;
            this.chkOutHosType5.Size = new System.Drawing.Size(59, 19);
            this.chkOutHosType5.TabIndex = 10;
            this.chkOutHosType5.TabStop = false;
            this.chkOutHosType5.Click += new System.EventHandler(this.chk_CheckedChanged);
            // 
            // chkOutHosType4
            // 
            this.chkOutHosType4.Location = new System.Drawing.Point(24, 224);
            this.chkOutHosType4.Name = "chkOutHosType4";
            this.chkOutHosType4.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkOutHosType4.Properties.Appearance.Options.UseForeColor = true;
            this.chkOutHosType4.Properties.Caption = "4.非医嘱离院";
            this.chkOutHosType4.Properties.RadioGroupIndex = 0;
            this.chkOutHosType4.Size = new System.Drawing.Size(104, 19);
            this.chkOutHosType4.TabIndex = 9;
            this.chkOutHosType4.TabStop = false;
            this.chkOutHosType4.Click += new System.EventHandler(this.chk_CheckedChanged);
            // 
            // chkAgainInHospital1
            // 
            this.chkAgainInHospital1.Location = new System.Drawing.Point(196, 246);
            this.chkAgainInHospital1.Name = "chkAgainInHospital1";
            this.chkAgainInHospital1.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkAgainInHospital1.Properties.Appearance.Options.UseForeColor = true;
            this.chkAgainInHospital1.Properties.Caption = "1.无";
            this.chkAgainInHospital1.Properties.RadioGroupIndex = 1;
            this.chkAgainInHospital1.Size = new System.Drawing.Size(46, 19);
            this.chkAgainInHospital1.TabIndex = 12;
            this.chkAgainInHospital1.TabStop = false;
            this.chkAgainInHospital1.Click += new System.EventHandler(this.chk_CheckedChanged);
            // 
            // chkOutHosType1
            // 
            this.chkOutHosType1.Location = new System.Drawing.Point(75, 173);
            this.chkOutHosType1.Name = "chkOutHosType1";
            this.chkOutHosType1.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkOutHosType1.Properties.Appearance.Options.UseForeColor = true;
            this.chkOutHosType1.Properties.Caption = "1.医嘱离院";
            this.chkOutHosType1.Properties.RadioGroupIndex = 0;
            this.chkOutHosType1.Size = new System.Drawing.Size(84, 19);
            this.chkOutHosType1.TabIndex = 4;
            this.chkOutHosType1.TabStop = false;
            this.chkOutHosType1.Click += new System.EventHandler(this.chk_CheckedChanged);
            // 
            // hLineEx1
            // 
            this.hLineEx1.BackColor = System.Drawing.Color.White;
            this.hLineEx1.IsBold = false;
            this.hLineEx1.Location = new System.Drawing.Point(0, 166);
            this.hLineEx1.Name = "hLineEx1";
            this.hLineEx1.Size = new System.Drawing.Size(635, 1);
            this.hLineEx1.TabIndex = 244;
            this.hLineEx1.Text = "hLineEx3";
            // 
            // btnEditOperation
            // 
            this.btnEditOperation.Location = new System.Drawing.Point(144, 11);
            this.btnEditOperation.Name = "btnEditOperation";
            this.btnEditOperation.Size = new System.Drawing.Size(103, 23);
            this.btnEditOperation.TabIndex = 2;
            this.btnEditOperation.Text = "编辑手术信息";
            this.btnEditOperation.Click += new System.EventHandler(this.btnEditOperation_Click);
            // 
            // btn_Close
            // 
            this.btn_Close.Image = ((System.Drawing.Image)(resources.GetObject("btn_Close.Image")));
            this.btn_Close.Location = new System.Drawing.Point(525, 337);
            this.btn_Close.Name = "btn_Close";
            this.btn_Close.Size = new System.Drawing.Size(80, 23);
            this.btn_Close.TabIndex = 23;
            this.btn_Close.Text = "关闭(&T)";
            this.btn_Close.Click += new System.EventHandler(this.btn_Close_Click);
            // 
            // btn_OK
            // 
            this.btn_OK.Image = ((System.Drawing.Image)(resources.GetObject("btn_OK.Image")));
            this.btn_OK.Location = new System.Drawing.Point(443, 337);
            this.btn_OK.Name = "btn_OK";
            this.btn_OK.Size = new System.Drawing.Size(80, 23);
            this.btn_OK.TabIndex = 22;
            this.btn_OK.Text = "保存(&S)";
            this.btn_OK.Click += new System.EventHandler(this.btn_OK_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Image = ((System.Drawing.Image)(resources.GetObject("btnDelete.Image")));
            this.btnDelete.Location = new System.Drawing.Point(263, 11);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(80, 23);
            this.btnDelete.TabIndex = 3;
            this.btnDelete.Text = "删除(&D)";
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // labelControl1
            // 
            this.labelControl1.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl1.Location = new System.Drawing.Point(15, 307);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(83, 14);
            this.labelControl1.TabIndex = 254;
            this.labelControl1.Text = "ASA分级评分：";
            // 
            // txtScore
            // 
            this.txtScore.EnterMoveNextControl = true;
            this.txtScore.Location = new System.Drawing.Point(103, 305);
            this.txtScore.MenuManager = this.barManager1;
            this.txtScore.Name = "txtScore";
            this.txtScore.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtScore.Size = new System.Drawing.Size(124, 19);
            this.txtScore.TabIndex = 21;
            // 
            // labelControl2
            // 
            this.labelControl2.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl2.Location = new System.Drawing.Point(236, 307);
            this.labelControl2.Name = "labelControl2";
            this.labelControl2.Size = new System.Drawing.Size(22, 14);
            this.labelControl2.TabIndex = 256;
            this.labelControl2.Text = "(分)";
            // 
            // UCIemOperInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.labelControl2);
            this.Controls.Add(this.txtScore);
            this.Controls.Add(this.labelControl1);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btn_OK);
            this.Controls.Add(this.btn_Close);
            this.Controls.Add(this.btnEditOperation);
            this.Controls.Add(this.hLineEx1);
            this.Controls.Add(this.txtLaterHosComaMinute);
            this.Controls.Add(this.txtBeforeHosComaMinute);
            this.Controls.Add(this.txtLaterHosComaHour);
            this.Controls.Add(this.txtBeforeHosComaHour);
            this.Controls.Add(this.txtLaterHosComaDay);
            this.Controls.Add(this.txtBeforeHosComaDay);
            this.Controls.Add(this.txtAgainInHospitalReason);
            this.Controls.Add(this.txtReceiveHosPital2);
            this.Controls.Add(this.txtReceiveHosPital);
            this.Controls.Add(this.labelControl24);
            this.Controls.Add(this.labelControl23);
            this.Controls.Add(this.labelControl38);
            this.Controls.Add(this.labelControl32);
            this.Controls.Add(this.labelControl36);
            this.Controls.Add(this.labelControl30);
            this.Controls.Add(this.labelControl34);
            this.Controls.Add(this.labelControl27);
            this.Controls.Add(this.labelControl25);
            this.Controls.Add(this.labelControl22);
            this.Controls.Add(this.chkAgainInHospital2);
            this.Controls.Add(this.chkOutHosType2);
            this.Controls.Add(this.chkOutHosType3);
            this.Controls.Add(this.chkOutHosType9);
            this.Controls.Add(this.chkOutHosType5);
            this.Controls.Add(this.chkOutHosType4);
            this.Controls.Add(this.chkAgainInHospital1);
            this.Controls.Add(this.chkOutHosType1);
            this.Controls.Add(this.btnAddOperation);
            this.Controls.Add(this.gridControl1);
            this.Controls.Add(this.barDockControlLeft);
            this.Controls.Add(this.barDockControlRight);
            this.Controls.Add(this.barDockControlBottom);
            this.Controls.Add(this.barDockControlTop);
            this.Name = "UCIemOperInfo";
            this.Size = new System.Drawing.Size(650, 387);
            this.Load += new System.EventHandler(this.UCIemOperInfo_Load);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.UCIemOperInfo_Paint);
            ((System.ComponentModel.ISupportInitialize)(this.gridControl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewOper)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.barManager1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.popupMenu1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtLaterHosComaMinute.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtBeforeHosComaMinute.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtLaterHosComaHour.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtBeforeHosComaHour.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtLaterHosComaDay.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtBeforeHosComaDay.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtAgainInHospitalReason.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtReceiveHosPital2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtReceiveHosPital.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkAgainInHospital2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkOutHosType2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkOutHosType3.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkOutHosType9.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkOutHosType5.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkOutHosType4.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkAgainInHospital1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkOutHosType1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtScore.Properties)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevExpress.XtraGrid.GridControl gridControl1;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewOper;
        private DevExpress.XtraEditors.SimpleButton btnAddOperation;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn2;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn3;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn4;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn5;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn6;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn7;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn8;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn9;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn14;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn15;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn16;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn17;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn18;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn19;
        private DevExpress.XtraBars.BarManager barManager1;
        private DevExpress.XtraBars.BarDockControl barDockControlTop;
        private DevExpress.XtraBars.BarDockControl barDockControlBottom;
        private DevExpress.XtraBars.BarDockControl barDockControlLeft;
        private DevExpress.XtraBars.BarDockControl barDockControlRight;
        private DevExpress.XtraBars.BarButtonItem btn_del_Operinfo;
        private DevExpress.XtraBars.PopupMenu popupMenu1;
        private DevExpress.XtraBars.BarButtonItem barButtonItem1;
        private DevExpress.XtraBars.BarButtonItem btn_del_operbefore_diag;
        private DevExpress.XtraBars.BarButtonItem btn_operafter_diag;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn10;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn11;
        private DrectSoft.Common.Ctrs.OTHER.DSTextBox txtLaterHosComaMinute;
        private DrectSoft.Common.Ctrs.OTHER.DSTextBox txtBeforeHosComaMinute;
        private DrectSoft.Common.Ctrs.OTHER.DSTextBox txtLaterHosComaHour;
        private DrectSoft.Common.Ctrs.OTHER.DSTextBox txtBeforeHosComaHour;
        private DrectSoft.Common.Ctrs.OTHER.DSTextBox txtLaterHosComaDay;
        private DrectSoft.Common.Ctrs.OTHER.DSTextBox txtBeforeHosComaDay;
        private DrectSoft.Common.Ctrs.OTHER.DSTextBox txtAgainInHospitalReason;
        private DrectSoft.Common.Ctrs.OTHER.DSTextBox txtReceiveHosPital2;
        private DrectSoft.Common.Ctrs.OTHER.DSTextBox txtReceiveHosPital;
        private DevExpress.XtraEditors.LabelControl labelControl24;
        private DevExpress.XtraEditors.LabelControl labelControl23;
        private DevExpress.XtraEditors.LabelControl labelControl38;
        private DevExpress.XtraEditors.LabelControl labelControl32;
        private DevExpress.XtraEditors.LabelControl labelControl36;
        private DevExpress.XtraEditors.LabelControl labelControl30;
        private DevExpress.XtraEditors.LabelControl labelControl34;
        private DevExpress.XtraEditors.LabelControl labelControl27;
        private DevExpress.XtraEditors.LabelControl labelControl25;
        private DevExpress.XtraEditors.LabelControl labelControl22;
        private DevExpress.XtraEditors.CheckEdit chkAgainInHospital2;
        private DevExpress.XtraEditors.CheckEdit chkOutHosType2;
        private DevExpress.XtraEditors.CheckEdit chkOutHosType3;
        private DevExpress.XtraEditors.CheckEdit chkOutHosType9;
        private DevExpress.XtraEditors.CheckEdit chkOutHosType5;
        private DevExpress.XtraEditors.CheckEdit chkOutHosType4;
        private DevExpress.XtraEditors.CheckEdit chkAgainInHospital1;
        private DevExpress.XtraEditors.CheckEdit chkOutHosType1;
        private HLineEx hLineEx1;
        private DevExpress.XtraEditors.SimpleButton btnEditOperation;
        private DrectSoft.Common.Ctrs.OTHER.DevButtonSave btn_OK;
        private DrectSoft.Common.Ctrs.OTHER.DevButtonClose btn_Close;
        private DrectSoft.Common.Ctrs.OTHER.DevButtonDelete btnDelete;
        private DevExpress.XtraEditors.LabelControl labelControl2;
        private DrectSoft.Common.Ctrs.OTHER.DSTextBox txtScore;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn12;
    }
}
