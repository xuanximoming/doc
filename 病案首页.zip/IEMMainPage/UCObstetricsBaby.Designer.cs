﻿namespace YidanSoft.Core.IEMMainPage
{
    partial class UCObstetricsBaby
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.labelControl17 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl29 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl7 = new DevExpress.XtraEditors.LabelControl();
            this.chkTC1 = new DevExpress.XtraEditors.CheckEdit();
            this.chkTC2 = new DevExpress.XtraEditors.CheckEdit();
            this.chkTC3 = new DevExpress.XtraEditors.CheckEdit();
            this.labelControl8 = new DevExpress.XtraEditors.LabelControl();
            this.chkCC1 = new DevExpress.XtraEditors.CheckEdit();
            this.chkCC2 = new DevExpress.XtraEditors.CheckEdit();
            this.chkCC3 = new DevExpress.XtraEditors.CheckEdit();
            this.labelControl9 = new DevExpress.XtraEditors.LabelControl();
            this.chkCFHYPLD1 = new DevExpress.XtraEditors.CheckEdit();
            this.chkCFHYPLD2 = new DevExpress.XtraEditors.CheckEdit();
            this.chkCFHYPLD3 = new DevExpress.XtraEditors.CheckEdit();
            this.labelControl11 = new DevExpress.XtraEditors.LabelControl();
            this.chkSex1 = new DevExpress.XtraEditors.CheckEdit();
            this.chkSex2 = new DevExpress.XtraEditors.CheckEdit();
            this.labelControl15 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl23 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl27 = new DevExpress.XtraEditors.LabelControl();
            this.txtheigh = new DevExpress.XtraEditors.TextEdit();
            this.labelControl30 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl32 = new DevExpress.XtraEditors.LabelControl();
            this.txtweight = new DevExpress.XtraEditors.TextEdit();
            this.labelControl33 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl34 = new DevExpress.XtraEditors.LabelControl();
            this.chkCCQK1 = new DevExpress.XtraEditors.CheckEdit();
            this.chkCCQK2 = new DevExpress.XtraEditors.CheckEdit();
            this.chkCCQK3 = new DevExpress.XtraEditors.CheckEdit();
            this.chkCCQK4 = new DevExpress.XtraEditors.CheckEdit();
            this.labelControl35 = new DevExpress.XtraEditors.LabelControl();
            this.chkTB1 = new DevExpress.XtraEditors.CheckEdit();
            this.chkTB2 = new DevExpress.XtraEditors.CheckEdit();
            this.chkTB3 = new DevExpress.XtraEditors.CheckEdit();
            this.txtAPJPF = new DevExpress.XtraEditors.TextEdit();
            this.chkCYQK1 = new DevExpress.XtraEditors.CheckEdit();
            this.chkCYQK2 = new DevExpress.XtraEditors.CheckEdit();
            this.chkCYQK3 = new DevExpress.XtraEditors.CheckEdit();
            this.labelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.chkFMFS1 = new DevExpress.XtraEditors.CheckEdit();
            this.chkFMFS2 = new DevExpress.XtraEditors.CheckEdit();
            this.chkFMFS3 = new DevExpress.XtraEditors.CheckEdit();
            this.chkFMFS4 = new DevExpress.XtraEditors.CheckEdit();
            this.chkFMFS5 = new DevExpress.XtraEditors.CheckEdit();
            this.chkFMFS6 = new DevExpress.XtraEditors.CheckEdit();
            this.hLineEx7 = new YidanSoft.Core.IEMMainPage.HLineEx();
            this.hLineEx3 = new YidanSoft.Core.IEMMainPage.HLineEx();
            this.BithDayTime = new DevExpress.XtraEditors.TimeEdit();
            this.BithDayDate = new DevExpress.XtraEditors.DateEdit();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.txtMidwifery = new DevExpress.XtraEditors.TextEdit();
            ((System.ComponentModel.ISupportInitialize)(this.chkTC1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkTC2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkTC3.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCC1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCC2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCC3.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCFHYPLD1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCFHYPLD2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCFHYPLD3.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkSex1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkSex2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtheigh.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtweight.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCCQK1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCCQK2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCCQK3.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCCQK4.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkTB1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkTB2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkTB3.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtAPJPF.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCYQK1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCYQK2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCYQK3.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkFMFS1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkFMFS2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkFMFS3.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkFMFS4.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkFMFS5.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkFMFS6.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BithDayTime.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BithDayDate.Properties.VistaTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BithDayDate.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMidwifery.Properties)).BeginInit();
            this.SuspendLayout();
            // 
            // labelControl17
            // 
            this.labelControl17.Appearance.Font = new System.Drawing.Font("华文楷体", 21.75F, System.Drawing.FontStyle.Bold);
            this.labelControl17.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl17.Location = new System.Drawing.Point(149, 11);
            this.labelControl17.Name = "labelControl17";
            this.labelControl17.Size = new System.Drawing.Size(296, 33);
            this.labelControl17.TabIndex = 157;
            this.labelControl17.Text = "产 科 产 妇 婴 儿 情 况";
            // 
            // labelControl29
            // 
            this.labelControl29.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl29.Location = new System.Drawing.Point(346, 175);
            this.labelControl29.Name = "labelControl29";
            this.labelControl29.Size = new System.Drawing.Size(48, 14);
            this.labelControl29.TabIndex = 157;
            this.labelControl29.Text = "出院情况";
            // 
            // labelControl7
            // 
            this.labelControl7.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl7.Location = new System.Drawing.Point(20, 57);
            this.labelControl7.Name = "labelControl7";
            this.labelControl7.Size = new System.Drawing.Size(48, 14);
            this.labelControl7.TabIndex = 157;
            this.labelControl7.Text = "胎      次";
            // 
            // chkTC1
            // 
            this.chkTC1.Location = new System.Drawing.Point(81, 56);
            this.chkTC1.Name = "chkTC1";
            this.chkTC1.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkTC1.Properties.Appearance.Options.UseForeColor = true;
            this.chkTC1.Properties.Caption = "1.单";
            this.chkTC1.Properties.RadioGroupIndex = 1;
            this.chkTC1.Size = new System.Drawing.Size(67, 19);
            this.chkTC1.TabIndex = 168;
            this.chkTC1.TabStop = false;
            // 
            // chkTC2
            // 
            this.chkTC2.Location = new System.Drawing.Point(148, 56);
            this.chkTC2.Name = "chkTC2";
            this.chkTC2.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkTC2.Properties.Appearance.Options.UseForeColor = true;
            this.chkTC2.Properties.Caption = "2.双";
            this.chkTC2.Properties.RadioGroupIndex = 1;
            this.chkTC2.Size = new System.Drawing.Size(63, 19);
            this.chkTC2.TabIndex = 169;
            this.chkTC2.TabStop = false;
            // 
            // chkTC3
            // 
            this.chkTC3.Location = new System.Drawing.Point(211, 56);
            this.chkTC3.Name = "chkTC3";
            this.chkTC3.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkTC3.Properties.Appearance.Options.UseForeColor = true;
            this.chkTC3.Properties.Caption = "3.多";
            this.chkTC3.Properties.RadioGroupIndex = 1;
            this.chkTC3.Size = new System.Drawing.Size(57, 19);
            this.chkTC3.TabIndex = 170;
            this.chkTC3.TabStop = false;
            // 
            // labelControl8
            // 
            this.labelControl8.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl8.Location = new System.Drawing.Point(346, 58);
            this.labelControl8.Name = "labelControl8";
            this.labelControl8.Size = new System.Drawing.Size(48, 14);
            this.labelControl8.TabIndex = 157;
            this.labelControl8.Text = "产      次";
            // 
            // chkCC1
            // 
            this.chkCC1.Location = new System.Drawing.Point(407, 56);
            this.chkCC1.Name = "chkCC1";
            this.chkCC1.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkCC1.Properties.Appearance.Options.UseForeColor = true;
            this.chkCC1.Properties.Caption = "1.单";
            this.chkCC1.Properties.RadioGroupIndex = 2;
            this.chkCC1.Size = new System.Drawing.Size(67, 19);
            this.chkCC1.TabIndex = 168;
            this.chkCC1.TabStop = false;
            // 
            // chkCC2
            // 
            this.chkCC2.Location = new System.Drawing.Point(474, 56);
            this.chkCC2.Name = "chkCC2";
            this.chkCC2.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkCC2.Properties.Appearance.Options.UseForeColor = true;
            this.chkCC2.Properties.Caption = "2.双";
            this.chkCC2.Properties.RadioGroupIndex = 2;
            this.chkCC2.Size = new System.Drawing.Size(63, 19);
            this.chkCC2.TabIndex = 169;
            this.chkCC2.TabStop = false;
            // 
            // chkCC3
            // 
            this.chkCC3.Location = new System.Drawing.Point(537, 56);
            this.chkCC3.Name = "chkCC3";
            this.chkCC3.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkCC3.Properties.Appearance.Options.UseForeColor = true;
            this.chkCC3.Properties.Caption = "3.多";
            this.chkCC3.Properties.RadioGroupIndex = 2;
            this.chkCC3.Size = new System.Drawing.Size(57, 19);
            this.chkCC3.TabIndex = 170;
            this.chkCC3.TabStop = false;
            // 
            // labelControl9
            // 
            this.labelControl9.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl9.Location = new System.Drawing.Point(336, 78);
            this.labelControl9.Name = "labelControl9";
            this.labelControl9.Size = new System.Drawing.Size(60, 14);
            this.labelControl9.TabIndex = 157;
            this.labelControl9.Text = "会阴破裂度";
            // 
            // chkCFHYPLD1
            // 
            this.chkCFHYPLD1.Location = new System.Drawing.Point(407, 77);
            this.chkCFHYPLD1.Name = "chkCFHYPLD1";
            this.chkCFHYPLD1.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkCFHYPLD1.Properties.Appearance.Options.UseForeColor = true;
            this.chkCFHYPLD1.Properties.Caption = "1.I";
            this.chkCFHYPLD1.Properties.RadioGroupIndex = 4;
            this.chkCFHYPLD1.Size = new System.Drawing.Size(67, 19);
            this.chkCFHYPLD1.TabIndex = 168;
            this.chkCFHYPLD1.TabStop = false;
            // 
            // chkCFHYPLD2
            // 
            this.chkCFHYPLD2.Location = new System.Drawing.Point(474, 77);
            this.chkCFHYPLD2.Name = "chkCFHYPLD2";
            this.chkCFHYPLD2.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkCFHYPLD2.Properties.Appearance.Options.UseForeColor = true;
            this.chkCFHYPLD2.Properties.Caption = "2.II";
            this.chkCFHYPLD2.Properties.RadioGroupIndex = 4;
            this.chkCFHYPLD2.Size = new System.Drawing.Size(63, 19);
            this.chkCFHYPLD2.TabIndex = 169;
            this.chkCFHYPLD2.TabStop = false;
            // 
            // chkCFHYPLD3
            // 
            this.chkCFHYPLD3.Location = new System.Drawing.Point(537, 77);
            this.chkCFHYPLD3.Name = "chkCFHYPLD3";
            this.chkCFHYPLD3.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkCFHYPLD3.Properties.Appearance.Options.UseForeColor = true;
            this.chkCFHYPLD3.Properties.Caption = "3.III";
            this.chkCFHYPLD3.Properties.RadioGroupIndex = 4;
            this.chkCFHYPLD3.Size = new System.Drawing.Size(57, 19);
            this.chkCFHYPLD3.TabIndex = 170;
            this.chkCFHYPLD3.TabStop = false;
            // 
            // labelControl11
            // 
            this.labelControl11.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl11.Location = new System.Drawing.Point(20, 103);
            this.labelControl11.Name = "labelControl11";
            this.labelControl11.Size = new System.Drawing.Size(48, 14);
            this.labelControl11.TabIndex = 157;
            this.labelControl11.Text = "性      别";
            // 
            // chkSex1
            // 
            this.chkSex1.Location = new System.Drawing.Point(81, 100);
            this.chkSex1.Name = "chkSex1";
            this.chkSex1.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkSex1.Properties.Appearance.Options.UseForeColor = true;
            this.chkSex1.Properties.Caption = "1.男";
            this.chkSex1.Properties.RadioGroupIndex = 5;
            this.chkSex1.Size = new System.Drawing.Size(67, 19);
            this.chkSex1.TabIndex = 168;
            this.chkSex1.TabStop = false;
            // 
            // chkSex2
            // 
            this.chkSex2.Location = new System.Drawing.Point(148, 100);
            this.chkSex2.Name = "chkSex2";
            this.chkSex2.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkSex2.Properties.Appearance.Options.UseForeColor = true;
            this.chkSex2.Properties.Caption = "2.女";
            this.chkSex2.Properties.RadioGroupIndex = 5;
            this.chkSex2.Size = new System.Drawing.Size(49, 19);
            this.chkSex2.TabIndex = 169;
            this.chkSex2.TabStop = false;
            // 
            // labelControl15
            // 
            this.labelControl15.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl15.Location = new System.Drawing.Point(336, 102);
            this.labelControl15.Name = "labelControl15";
            this.labelControl15.Size = new System.Drawing.Size(60, 14);
            this.labelControl15.TabIndex = 157;
            this.labelControl15.Text = "阿帕加评分";
            // 
            // labelControl23
            // 
            this.labelControl23.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl23.Location = new System.Drawing.Point(20, 127);
            this.labelControl23.Name = "labelControl23";
            this.labelControl23.Size = new System.Drawing.Size(48, 14);
            this.labelControl23.TabIndex = 157;
            this.labelControl23.Text = "身      长";
            // 
            // labelControl27
            // 
            this.labelControl27.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl27.Location = new System.Drawing.Point(189, 127);
            this.labelControl27.Name = "labelControl27";
            this.labelControl27.Size = new System.Drawing.Size(16, 14);
            this.labelControl27.TabIndex = 157;
            this.labelControl27.Text = "CM";
            // 
            // txtheigh
            // 
            this.txtheigh.EditValue = "";
            this.txtheigh.Location = new System.Drawing.Point(83, 125);
            this.txtheigh.Name = "txtheigh";
            this.txtheigh.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtheigh.Size = new System.Drawing.Size(100, 19);
            this.txtheigh.TabIndex = 162;
            // 
            // labelControl30
            // 
            this.labelControl30.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl30.Location = new System.Drawing.Point(370, 127);
            this.labelControl30.Name = "labelControl30";
            this.labelControl30.Size = new System.Drawing.Size(24, 14);
            this.labelControl30.TabIndex = 157;
            this.labelControl30.Text = "体重";
            // 
            // labelControl32
            // 
            this.labelControl32.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl32.Location = new System.Drawing.Point(518, 127);
            this.labelControl32.Name = "labelControl32";
            this.labelControl32.Size = new System.Drawing.Size(8, 14);
            this.labelControl32.TabIndex = 157;
            this.labelControl32.Text = "G";
            // 
            // txtweight
            // 
            this.txtweight.EditValue = "";
            this.txtweight.Location = new System.Drawing.Point(409, 125);
            this.txtweight.Name = "txtweight";
            this.txtweight.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtweight.Size = new System.Drawing.Size(100, 19);
            this.txtweight.TabIndex = 162;
            // 
            // labelControl33
            // 
            this.labelControl33.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl33.Location = new System.Drawing.Point(20, 151);
            this.labelControl33.Name = "labelControl33";
            this.labelControl33.Size = new System.Drawing.Size(48, 14);
            this.labelControl33.TabIndex = 157;
            this.labelControl33.Text = "出生时间";
            // 
            // labelControl34
            // 
            this.labelControl34.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl34.Location = new System.Drawing.Point(20, 176);
            this.labelControl34.Name = "labelControl34";
            this.labelControl34.Size = new System.Drawing.Size(48, 14);
            this.labelControl34.TabIndex = 157;
            this.labelControl34.Text = "产出情况";
            // 
            // chkCCQK1
            // 
            this.chkCCQK1.Location = new System.Drawing.Point(81, 173);
            this.chkCCQK1.Name = "chkCCQK1";
            this.chkCCQK1.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkCCQK1.Properties.Appearance.Options.UseForeColor = true;
            this.chkCCQK1.Properties.Caption = "1.活产";
            this.chkCCQK1.Properties.RadioGroupIndex = 6;
            this.chkCCQK1.Size = new System.Drawing.Size(67, 19);
            this.chkCCQK1.TabIndex = 168;
            this.chkCCQK1.TabStop = false;
            // 
            // chkCCQK2
            // 
            this.chkCCQK2.Location = new System.Drawing.Point(148, 173);
            this.chkCCQK2.Name = "chkCCQK2";
            this.chkCCQK2.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkCCQK2.Properties.Appearance.Options.UseForeColor = true;
            this.chkCCQK2.Properties.Caption = "2.死产";
            this.chkCCQK2.Properties.RadioGroupIndex = 6;
            this.chkCCQK2.Size = new System.Drawing.Size(63, 19);
            this.chkCCQK2.TabIndex = 169;
            this.chkCCQK2.TabStop = false;
            // 
            // chkCCQK3
            // 
            this.chkCCQK3.Location = new System.Drawing.Point(211, 173);
            this.chkCCQK3.Name = "chkCCQK3";
            this.chkCCQK3.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkCCQK3.Properties.Appearance.Options.UseForeColor = true;
            this.chkCCQK3.Properties.Caption = "3.死胎";
            this.chkCCQK3.Properties.RadioGroupIndex = 6;
            this.chkCCQK3.Size = new System.Drawing.Size(57, 19);
            this.chkCCQK3.TabIndex = 170;
            this.chkCCQK3.TabStop = false;
            // 
            // chkCCQK4
            // 
            this.chkCCQK4.Location = new System.Drawing.Point(269, 173);
            this.chkCCQK4.Name = "chkCCQK4";
            this.chkCCQK4.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkCCQK4.Properties.Appearance.Options.UseForeColor = true;
            this.chkCCQK4.Properties.Caption = "4.畸形";
            this.chkCCQK4.Properties.RadioGroupIndex = 6;
            this.chkCCQK4.Size = new System.Drawing.Size(57, 19);
            this.chkCCQK4.TabIndex = 170;
            this.chkCCQK4.TabStop = false;
            // 
            // labelControl35
            // 
            this.labelControl35.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl35.Location = new System.Drawing.Point(20, 80);
            this.labelControl35.Name = "labelControl35";
            this.labelControl35.Size = new System.Drawing.Size(48, 14);
            this.labelControl35.TabIndex = 157;
            this.labelControl35.Text = "胎      别";
            // 
            // chkTB1
            // 
            this.chkTB1.Location = new System.Drawing.Point(81, 77);
            this.chkTB1.Name = "chkTB1";
            this.chkTB1.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkTB1.Properties.Appearance.Options.UseForeColor = true;
            this.chkTB1.Properties.Caption = "1.单";
            this.chkTB1.Properties.RadioGroupIndex = 3;
            this.chkTB1.Size = new System.Drawing.Size(67, 19);
            this.chkTB1.TabIndex = 168;
            this.chkTB1.TabStop = false;
            // 
            // chkTB2
            // 
            this.chkTB2.Location = new System.Drawing.Point(148, 77);
            this.chkTB2.Name = "chkTB2";
            this.chkTB2.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkTB2.Properties.Appearance.Options.UseForeColor = true;
            this.chkTB2.Properties.Caption = "2.双";
            this.chkTB2.Properties.RadioGroupIndex = 3;
            this.chkTB2.Size = new System.Drawing.Size(63, 19);
            this.chkTB2.TabIndex = 169;
            this.chkTB2.TabStop = false;
            // 
            // chkTB3
            // 
            this.chkTB3.Location = new System.Drawing.Point(211, 77);
            this.chkTB3.Name = "chkTB3";
            this.chkTB3.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkTB3.Properties.Appearance.Options.UseForeColor = true;
            this.chkTB3.Properties.Caption = "3.多";
            this.chkTB3.Properties.RadioGroupIndex = 3;
            this.chkTB3.Size = new System.Drawing.Size(57, 19);
            this.chkTB3.TabIndex = 170;
            this.chkTB3.TabStop = false;
            // 
            // txtAPJPF
            // 
            this.txtAPJPF.EditValue = "";
            this.txtAPJPF.Location = new System.Drawing.Point(409, 100);
            this.txtAPJPF.Name = "txtAPJPF";
            this.txtAPJPF.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtAPJPF.Size = new System.Drawing.Size(185, 19);
            this.txtAPJPF.TabIndex = 162;
            // 
            // chkCYQK1
            // 
            this.chkCYQK1.Location = new System.Drawing.Point(407, 173);
            this.chkCYQK1.Name = "chkCYQK1";
            this.chkCYQK1.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkCYQK1.Properties.Appearance.Options.UseForeColor = true;
            this.chkCYQK1.Properties.Caption = "1.正常";
            this.chkCYQK1.Properties.RadioGroupIndex = 7;
            this.chkCYQK1.Size = new System.Drawing.Size(67, 19);
            this.chkCYQK1.TabIndex = 168;
            this.chkCYQK1.TabStop = false;
            // 
            // chkCYQK2
            // 
            this.chkCYQK2.Location = new System.Drawing.Point(463, 173);
            this.chkCYQK2.Name = "chkCYQK2";
            this.chkCYQK2.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkCYQK2.Properties.Appearance.Options.UseForeColor = true;
            this.chkCYQK2.Properties.Caption = "2.有病";
            this.chkCYQK2.Properties.RadioGroupIndex = 7;
            this.chkCYQK2.Size = new System.Drawing.Size(63, 19);
            this.chkCYQK2.TabIndex = 169;
            this.chkCYQK2.TabStop = false;
            // 
            // chkCYQK3
            // 
            this.chkCYQK3.Location = new System.Drawing.Point(530, 173);
            this.chkCYQK3.Name = "chkCYQK3";
            this.chkCYQK3.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkCYQK3.Properties.Appearance.Options.UseForeColor = true;
            this.chkCYQK3.Properties.Caption = "3.交叉感染";
            this.chkCYQK3.Properties.RadioGroupIndex = 7;
            this.chkCYQK3.Size = new System.Drawing.Size(82, 19);
            this.chkCYQK3.TabIndex = 170;
            this.chkCYQK3.TabStop = false;
            // 
            // labelControl2
            // 
            this.labelControl2.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl2.Location = new System.Drawing.Point(20, 199);
            this.labelControl2.Name = "labelControl2";
            this.labelControl2.Size = new System.Drawing.Size(48, 14);
            this.labelControl2.TabIndex = 157;
            this.labelControl2.Text = "分娩方式";
            // 
            // chkFMFS1
            // 
            this.chkFMFS1.Location = new System.Drawing.Point(81, 196);
            this.chkFMFS1.Name = "chkFMFS1";
            this.chkFMFS1.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkFMFS1.Properties.Appearance.Options.UseForeColor = true;
            this.chkFMFS1.Properties.Caption = "1.自然";
            this.chkFMFS1.Properties.RadioGroupIndex = 8;
            this.chkFMFS1.Size = new System.Drawing.Size(67, 19);
            this.chkFMFS1.TabIndex = 168;
            this.chkFMFS1.TabStop = false;
            // 
            // chkFMFS2
            // 
            this.chkFMFS2.Location = new System.Drawing.Point(148, 196);
            this.chkFMFS2.Name = "chkFMFS2";
            this.chkFMFS2.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkFMFS2.Properties.Appearance.Options.UseForeColor = true;
            this.chkFMFS2.Properties.Caption = "2.侧+吸";
            this.chkFMFS2.Properties.RadioGroupIndex = 8;
            this.chkFMFS2.Size = new System.Drawing.Size(72, 19);
            this.chkFMFS2.TabIndex = 169;
            this.chkFMFS2.TabStop = false;
            // 
            // chkFMFS3
            // 
            this.chkFMFS3.Location = new System.Drawing.Point(226, 196);
            this.chkFMFS3.Name = "chkFMFS3";
            this.chkFMFS3.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkFMFS3.Properties.Appearance.Options.UseForeColor = true;
            this.chkFMFS3.Properties.Caption = "3.产钳";
            this.chkFMFS3.Properties.RadioGroupIndex = 8;
            this.chkFMFS3.Size = new System.Drawing.Size(57, 19);
            this.chkFMFS3.TabIndex = 170;
            this.chkFMFS3.TabStop = false;
            // 
            // chkFMFS4
            // 
            this.chkFMFS4.Location = new System.Drawing.Point(289, 196);
            this.chkFMFS4.Name = "chkFMFS4";
            this.chkFMFS4.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkFMFS4.Properties.Appearance.Options.UseForeColor = true;
            this.chkFMFS4.Properties.Caption = "4.臂牵引";
            this.chkFMFS4.Properties.RadioGroupIndex = 8;
            this.chkFMFS4.Size = new System.Drawing.Size(67, 19);
            this.chkFMFS4.TabIndex = 168;
            this.chkFMFS4.TabStop = false;
            // 
            // chkFMFS5
            // 
            this.chkFMFS5.Location = new System.Drawing.Point(368, 196);
            this.chkFMFS5.Name = "chkFMFS5";
            this.chkFMFS5.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkFMFS5.Properties.Appearance.Options.UseForeColor = true;
            this.chkFMFS5.Properties.Caption = "5.剖宫";
            this.chkFMFS5.Properties.RadioGroupIndex = 8;
            this.chkFMFS5.Size = new System.Drawing.Size(63, 19);
            this.chkFMFS5.TabIndex = 169;
            this.chkFMFS5.TabStop = false;
            // 
            // chkFMFS6
            // 
            this.chkFMFS6.Location = new System.Drawing.Point(437, 196);
            this.chkFMFS6.Name = "chkFMFS6";
            this.chkFMFS6.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkFMFS6.Properties.Appearance.Options.UseForeColor = true;
            this.chkFMFS6.Properties.Caption = "6.其他";
            this.chkFMFS6.Properties.RadioGroupIndex = 8;
            this.chkFMFS6.Size = new System.Drawing.Size(57, 19);
            this.chkFMFS6.TabIndex = 170;
            this.chkFMFS6.TabStop = false;
            // 
            // hLineEx7
            // 
            this.hLineEx7.BackColor = System.Drawing.Color.White;
            this.hLineEx7.IsBold = false;
            this.hLineEx7.Location = new System.Drawing.Point(1, 225);
            this.hLineEx7.Name = "hLineEx7";
            this.hLineEx7.Size = new System.Drawing.Size(618, 1);
            this.hLineEx7.TabIndex = 154;
            this.hLineEx7.Text = "hLineEx3";
            // 
            // hLineEx3
            // 
            this.hLineEx3.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton;
            this.hLineEx3.BackColor = System.Drawing.Color.White;
            this.hLineEx3.IsBold = false;
            this.hLineEx3.Location = new System.Drawing.Point(1, 50);
            this.hLineEx3.Name = "hLineEx3";
            this.hLineEx3.Size = new System.Drawing.Size(618, 1);
            this.hLineEx3.TabIndex = 151;
            this.hLineEx3.Text = "hLineEx3";
            // 
            // BithDayTime
            // 
            this.BithDayTime.EditValue = new System.DateTime(2011, 3, 5, 0, 0, 0, 0);
            this.BithDayTime.Location = new System.Drawing.Point(189, 149);
            this.BithDayTime.Name = "BithDayTime";
            this.BithDayTime.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.BithDayTime.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.BithDayTime.Properties.Mask.EditMask = "HH:mm";
            this.BithDayTime.Size = new System.Drawing.Size(79, 19);
            this.BithDayTime.TabIndex = 172;
            // 
            // BithDayDate
            // 
            this.BithDayDate.EditValue = null;
            this.BithDayDate.Location = new System.Drawing.Point(83, 149);
            this.BithDayDate.Name = "BithDayDate";
            this.BithDayDate.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.BithDayDate.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.BithDayDate.Properties.VistaTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.BithDayDate.Size = new System.Drawing.Size(100, 19);
            this.BithDayDate.TabIndex = 171;
            // 
            // labelControl1
            // 
            this.labelControl1.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl1.Location = new System.Drawing.Point(358, 151);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(36, 14);
            this.labelControl1.TabIndex = 157;
            this.labelControl1.Text = "接产者";
            // 
            // txtMidwifery
            // 
            this.txtMidwifery.EditValue = "";
            this.txtMidwifery.Location = new System.Drawing.Point(409, 149);
            this.txtMidwifery.Name = "txtMidwifery";
            this.txtMidwifery.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtMidwifery.Size = new System.Drawing.Size(185, 19);
            this.txtMidwifery.TabIndex = 162;
            // 
            // UCObstetricsBaby
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(239)))), ((int)(((byte)(255)))));
            this.Controls.Add(this.BithDayTime);
            this.Controls.Add(this.BithDayDate);
            this.Controls.Add(this.chkCC3);
            this.Controls.Add(this.chkCYQK3);
            this.Controls.Add(this.chkCFHYPLD3);
            this.Controls.Add(this.chkCCQK4);
            this.Controls.Add(this.chkCCQK3);
            this.Controls.Add(this.chkFMFS6);
            this.Controls.Add(this.chkFMFS3);
            this.Controls.Add(this.chkTB3);
            this.Controls.Add(this.chkTC3);
            this.Controls.Add(this.chkCC2);
            this.Controls.Add(this.chkSex2);
            this.Controls.Add(this.chkCYQK2);
            this.Controls.Add(this.chkCFHYPLD2);
            this.Controls.Add(this.chkCCQK2);
            this.Controls.Add(this.chkFMFS5);
            this.Controls.Add(this.chkFMFS2);
            this.Controls.Add(this.chkTB2);
            this.Controls.Add(this.chkTC2);
            this.Controls.Add(this.chkCC1);
            this.Controls.Add(this.chkSex1);
            this.Controls.Add(this.chkCYQK1);
            this.Controls.Add(this.chkCFHYPLD1);
            this.Controls.Add(this.chkCCQK1);
            this.Controls.Add(this.chkFMFS4);
            this.Controls.Add(this.chkFMFS1);
            this.Controls.Add(this.chkTB1);
            this.Controls.Add(this.chkTC1);
            this.Controls.Add(this.txtweight);
            this.Controls.Add(this.txtAPJPF);
            this.Controls.Add(this.txtMidwifery);
            this.Controls.Add(this.txtheigh);
            this.Controls.Add(this.labelControl9);
            this.Controls.Add(this.labelControl35);
            this.Controls.Add(this.labelControl8);
            this.Controls.Add(this.labelControl1);
            this.Controls.Add(this.labelControl15);
            this.Controls.Add(this.labelControl29);
            this.Controls.Add(this.labelControl2);
            this.Controls.Add(this.labelControl34);
            this.Controls.Add(this.labelControl11);
            this.Controls.Add(this.labelControl32);
            this.Controls.Add(this.labelControl27);
            this.Controls.Add(this.labelControl30);
            this.Controls.Add(this.labelControl33);
            this.Controls.Add(this.labelControl23);
            this.Controls.Add(this.labelControl7);
            this.Controls.Add(this.labelControl17);
            this.Controls.Add(this.hLineEx7);
            this.Controls.Add(this.hLineEx3);
            this.Name = "UCObstetricsBaby";
            this.Size = new System.Drawing.Size(620, 261);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.UCObstetricsBaby_Paint);
            ((System.ComponentModel.ISupportInitialize)(this.chkTC1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkTC2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkTC3.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCC1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCC2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCC3.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCFHYPLD1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCFHYPLD2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCFHYPLD3.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkSex1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkSex2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtheigh.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtweight.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCCQK1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCCQK2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCCQK3.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCCQK4.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkTB1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkTB2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkTB3.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtAPJPF.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCYQK1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCYQK2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCYQK3.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkFMFS1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkFMFS2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkFMFS3.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkFMFS4.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkFMFS5.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkFMFS6.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BithDayTime.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BithDayDate.Properties.VistaTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BithDayDate.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMidwifery.Properties)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private HLineEx hLineEx7;
        private HLineEx hLineEx3;
        private DevExpress.XtraEditors.LabelControl labelControl17;
        private DevExpress.XtraEditors.LabelControl labelControl29;
        private DevExpress.XtraEditors.CheckEdit chkCC3;
        private DevExpress.XtraEditors.CheckEdit chkTC3;
        private DevExpress.XtraEditors.CheckEdit chkCC2;
        private DevExpress.XtraEditors.CheckEdit chkTC2;
        private DevExpress.XtraEditors.CheckEdit chkCC1;
        private DevExpress.XtraEditors.CheckEdit chkTC1;
        private DevExpress.XtraEditors.LabelControl labelControl8;
        private DevExpress.XtraEditors.LabelControl labelControl7;
        private DevExpress.XtraEditors.CheckEdit chkCFHYPLD3;
        private DevExpress.XtraEditors.CheckEdit chkCCQK3;
        private DevExpress.XtraEditors.CheckEdit chkSex2;
        private DevExpress.XtraEditors.CheckEdit chkCFHYPLD2;
        private DevExpress.XtraEditors.CheckEdit chkCCQK2;
        private DevExpress.XtraEditors.CheckEdit chkSex1;
        private DevExpress.XtraEditors.CheckEdit chkCFHYPLD1;
        private DevExpress.XtraEditors.CheckEdit chkCCQK1;
        private DevExpress.XtraEditors.TextEdit txtweight;
        private DevExpress.XtraEditors.TextEdit txtheigh;
        private DevExpress.XtraEditors.LabelControl labelControl9;
        private DevExpress.XtraEditors.LabelControl labelControl15;
        private DevExpress.XtraEditors.LabelControl labelControl34;
        private DevExpress.XtraEditors.LabelControl labelControl11;
        private DevExpress.XtraEditors.LabelControl labelControl32;
        private DevExpress.XtraEditors.LabelControl labelControl27;
        private DevExpress.XtraEditors.LabelControl labelControl30;
        private DevExpress.XtraEditors.LabelControl labelControl33;
        private DevExpress.XtraEditors.LabelControl labelControl23;
        private DevExpress.XtraEditors.CheckEdit chkCCQK4;
        private DevExpress.XtraEditors.CheckEdit chkTB3;
        private DevExpress.XtraEditors.CheckEdit chkTB2;
        private DevExpress.XtraEditors.CheckEdit chkTB1;
        private DevExpress.XtraEditors.LabelControl labelControl35;
        private DevExpress.XtraEditors.CheckEdit chkCYQK3;
        private DevExpress.XtraEditors.CheckEdit chkCYQK2;
        private DevExpress.XtraEditors.CheckEdit chkCYQK1;
        private DevExpress.XtraEditors.TextEdit txtAPJPF;
        private DevExpress.XtraEditors.LabelControl labelControl2;
        private DevExpress.XtraEditors.CheckEdit chkFMFS6;
        private DevExpress.XtraEditors.CheckEdit chkFMFS3;
        private DevExpress.XtraEditors.CheckEdit chkFMFS5;
        private DevExpress.XtraEditors.CheckEdit chkFMFS2;
        private DevExpress.XtraEditors.CheckEdit chkFMFS4;
        private DevExpress.XtraEditors.CheckEdit chkFMFS1;
        private DevExpress.XtraEditors.TimeEdit BithDayTime;
        private DevExpress.XtraEditors.DateEdit BithDayDate;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private DevExpress.XtraEditors.TextEdit txtMidwifery;
    }
}
