﻿namespace DrectSoft.Core.IEMMainPage
{
    partial class UCIemBasInfo
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UCIemBasInfo));
            this.deBirth = new DevExpress.XtraEditors.DateEdit();
            this.seActualDays = new DevExpress.XtraEditors.SpinEdit();
            this.seInCount = new DevExpress.XtraEditors.SpinEdit();
            this.labelControl38 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl39 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl40 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl41 = new DevExpress.XtraEditors.LabelControl();
            this.teOutWardDate = new DevExpress.XtraEditors.TimeEdit();
            this.deOutWardDate = new DevExpress.XtraEditors.DateEdit();
            this.labelControl42 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl35 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl31 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl30 = new DevExpress.XtraEditors.LabelControl();
            this.teAdmitDate = new DevExpress.XtraEditors.TimeEdit();
            this.deAdmitDate = new DevExpress.XtraEditors.DateEdit();
            this.labelControl29 = new DevExpress.XtraEditors.LabelControl();
            this.txtContactTEL = new DevExpress.XtraEditors.TextEdit();
            this.labelControl28 = new DevExpress.XtraEditors.LabelControl();
            this.txtContactAddress = new DevExpress.XtraEditors.TextEdit();
            this.labelControl27 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl26 = new DevExpress.XtraEditors.LabelControl();
            this.txtContactPerson = new DevExpress.XtraEditors.TextEdit();
            this.labelControl25 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl22 = new DevExpress.XtraEditors.LabelControl();
            this.txtXZZ_Post = new DevExpress.XtraEditors.TextEdit();
            this.labelControl21 = new DevExpress.XtraEditors.LabelControl();
            this.txtXZZ_TEL = new DevExpress.XtraEditors.TextEdit();
            this.labelControl20 = new DevExpress.XtraEditors.LabelControl();
            this.txtOfficePlace = new DevExpress.XtraEditors.TextEdit();
            this.labelControl19 = new DevExpress.XtraEditors.LabelControl();
            this.txtIDNO = new DevExpress.XtraEditors.TextEdit();
            this.labelControl18 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl17 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl16 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl12 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl11 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl10 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl9 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl8 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl7 = new DevExpress.XtraEditors.LabelControl();
            this.txtSocialCare = new DevExpress.XtraEditors.TextEdit();
            this.labelControl6 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl4 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl3 = new DevExpress.XtraEditors.LabelControl();
            this.txtName = new DevExpress.XtraEditors.TextEdit();
            this.labelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.txtPatNoOfHis = new DevExpress.XtraEditors.TextEdit();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.labelLogoName = new DevExpress.XtraEditors.LabelControl();
            this.txt_hospitalName = new DevExpress.XtraEditors.LabelControl();
            this.simpleButton1 = new DevExpress.XtraEditors.SimpleButton();
            this.labelControl5 = new DevExpress.XtraEditors.LabelControl();
            this.txtCardNumber = new DevExpress.XtraEditors.TextEdit();
            this.labelControl13 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl14 = new DevExpress.XtraEditors.LabelControl();
            this.txtMonthAge = new DevExpress.XtraEditors.TextEdit();
            this.labelControl15 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl45 = new DevExpress.XtraEditors.LabelControl();
            this.txtWeight = new DevExpress.XtraEditors.TextEdit();
            this.labelControl46 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl47 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl48 = new DevExpress.XtraEditors.LabelControl();
            this.txtInWeight = new DevExpress.XtraEditors.TextEdit();
            this.labelControl49 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl50 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl51 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl52 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl53 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl54 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl55 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl56 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl57 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl58 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl59 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl60 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl61 = new DevExpress.XtraEditors.LabelControl();
            this.txtHKDZ_Post = new DevExpress.XtraEditors.TextEdit();
            this.labelControl62 = new DevExpress.XtraEditors.LabelControl();
            this.txtOfficeTEL = new DevExpress.XtraEditors.TextEdit();
            this.labelControl63 = new DevExpress.XtraEditors.LabelControl();
            this.txtOfficePost = new DevExpress.XtraEditors.TextEdit();
            this.labelControl64 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl65 = new DevExpress.XtraEditors.LabelControl();
            this.chkInHosType1 = new DevExpress.XtraEditors.CheckEdit();
            this.chkInHosType2 = new DevExpress.XtraEditors.CheckEdit();
            this.chkInHosType3 = new DevExpress.XtraEditors.CheckEdit();
            this.chkInHosType4 = new DevExpress.XtraEditors.CheckEdit();
            this.textEdit3 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl23 = new DevExpress.XtraEditors.LabelControl();
            this.chkAdmitInfo1 = new DevExpress.XtraEditors.CheckEdit();
            this.chkAdmitInfo2 = new DevExpress.XtraEditors.CheckEdit();
            this.chkAdmitInfo3 = new DevExpress.XtraEditors.CheckEdit();
            this.chkAdmitInfo4 = new DevExpress.XtraEditors.CheckEdit();
            this.txtXZZAddress = new DevExpress.XtraEditors.TextEdit();
            this.txtHKZZAddress = new DevExpress.XtraEditors.TextEdit();
            this.chkFandB3 = new DevExpress.XtraEditors.CheckEdit();
            this.chkFandB2 = new DevExpress.XtraEditors.CheckEdit();
            this.chkFandB1 = new DevExpress.XtraEditors.CheckEdit();
            this.chkFandB0 = new DevExpress.XtraEditors.CheckEdit();
            this.labelControl24 = new DevExpress.XtraEditors.LabelControl();
            this.chkRThree3 = new DevExpress.XtraEditors.CheckEdit();
            this.chkRThree2 = new DevExpress.XtraEditors.CheckEdit();
            this.chkRThree1 = new DevExpress.XtraEditors.CheckEdit();
            this.chkRThree0 = new DevExpress.XtraEditors.CheckEdit();
            this.labelControl32 = new DevExpress.XtraEditors.LabelControl();
            this.chkLandB3 = new DevExpress.XtraEditors.CheckEdit();
            this.chkLandB2 = new DevExpress.XtraEditors.CheckEdit();
            this.chkLandB1 = new DevExpress.XtraEditors.CheckEdit();
            this.chkLandB0 = new DevExpress.XtraEditors.CheckEdit();
            this.labelControl33 = new DevExpress.XtraEditors.LabelControl();
            this.chkSqAndSh3 = new DevExpress.XtraEditors.CheckEdit();
            this.chkSqAndSh2 = new DevExpress.XtraEditors.CheckEdit();
            this.chkSqAndSh1 = new DevExpress.XtraEditors.CheckEdit();
            this.chkSqAndSh0 = new DevExpress.XtraEditors.CheckEdit();
            this.labelControl34 = new DevExpress.XtraEditors.LabelControl();
            this.chkRandC3 = new DevExpress.XtraEditors.CheckEdit();
            this.chkRandC2 = new DevExpress.XtraEditors.CheckEdit();
            this.chkRandC1 = new DevExpress.XtraEditors.CheckEdit();
            this.chkRandC0 = new DevExpress.XtraEditors.CheckEdit();
            this.labelControl36 = new DevExpress.XtraEditors.LabelControl();
            this.chkMandZ3 = new DevExpress.XtraEditors.CheckEdit();
            this.chkMandZ2 = new DevExpress.XtraEditors.CheckEdit();
            this.chkMandZ1 = new DevExpress.XtraEditors.CheckEdit();
            this.chkMandZ0 = new DevExpress.XtraEditors.CheckEdit();
            this.labelControl37 = new DevExpress.XtraEditors.LabelControl();
            this.txtAge = new DevExpress.XtraEditors.TextEdit();
            this.textEditOrganizationCode = new DevExpress.XtraEditors.TextEdit();
            this.errorProvider = new System.Windows.Forms.ErrorProvider();
            this.lbl_title = new DevExpress.XtraEditors.LabelControl();
            this.lbl_hostName = new DevExpress.XtraEditors.LabelControl();
            this.txtCSDAddress = new DevExpress.XtraEditors.TextEdit();
            this.txtJGAddress = new DevExpress.XtraEditors.TextEdit();
            this.btn_Close = new DrectSoft.Common.Ctrs.OTHER.DevButtonClose();
            this.btn_OK = new DrectSoft.Common.Ctrs.OTHER.DevButtonOK();
            this.txt_newXZZAddress = new DevExpress.XtraEditors.TextEdit();
            this.txt_newHKDZAddress = new DevExpress.XtraEditors.TextEdit();
            this.labelControl43 = new DevExpress.XtraEditors.LabelControl();
            this.lueOutHosWard = new DrectSoft.Common.Library.LookUpEditor();
            this.lueOutHosDept = new DrectSoft.Common.Library.LookUpEditor();
            this.lueTransAdmitDept = new DrectSoft.Common.Library.LookUpEditor();
            this.lueAdmitWard = new DrectSoft.Common.Library.LookUpEditor();
            this.lueAdmitDept = new DrectSoft.Common.Library.LookUpEditor();
            this.lueRelationship = new DrectSoft.Common.Library.LookUpEditor();
            this.lueNationality = new DrectSoft.Common.Library.LookUpEditor();
            this.lueNation = new DrectSoft.Common.Library.LookUpEditor();
            this.lueCSD_ProvinceID = new DrectSoft.Common.Library.LookUpEditor();
            this.luePayId = new DrectSoft.Common.Library.LookUpEditor();
            this.lueMarital = new DrectSoft.Common.Library.LookUpEditor();
            this.lookUpWindowMarital = new DrectSoft.Common.Library.LookUpWindow();
            this.lueJob = new DrectSoft.Common.Library.LookUpEditor();
            this.lueSex = new DrectSoft.Common.Library.LookUpEditor();
            this.lueCSD_CityID = new DrectSoft.Common.Library.LookUpEditor();
            this.lueCSD_DistrictID = new DrectSoft.Common.Library.LookUpEditor();
            this.lueJG_ProvinceID = new DrectSoft.Common.Library.LookUpEditor();
            this.lueJG_CityID = new DrectSoft.Common.Library.LookUpEditor();
            this.lueXZZ_ProvinceID = new DrectSoft.Common.Library.LookUpEditor();
            this.lueXZZ_CityID = new DrectSoft.Common.Library.LookUpEditor();
            this.lueXZZ_DistrictID = new DrectSoft.Common.Library.LookUpEditor();
            this.lueHKDZ_ProvinceID = new DrectSoft.Common.Library.LookUpEditor();
            this.lueHKDZ_CityID = new DrectSoft.Common.Library.LookUpEditor();
            this.lueHKDZ_DistrictID = new DrectSoft.Common.Library.LookUpEditor();
            this.hLineEx1 = new DrectSoft.Core.IEMMainPage.HLineEx();
            ((System.ComponentModel.ISupportInitialize)(this.deBirth.Properties.VistaTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.deBirth.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.seActualDays.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.seInCount.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.teOutWardDate.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.deOutWardDate.Properties.VistaTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.deOutWardDate.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.teAdmitDate.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.deAdmitDate.Properties.VistaTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.deAdmitDate.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtContactTEL.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtContactAddress.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtContactPerson.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtXZZ_Post.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtXZZ_TEL.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtOfficePlace.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtIDNO.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSocialCare.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtName.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPatNoOfHis.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCardNumber.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMonthAge.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtWeight.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtInWeight.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtHKDZ_Post.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtOfficeTEL.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtOfficePost.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkInHosType1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkInHosType2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkInHosType3.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkInHosType4.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit3.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkAdmitInfo1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkAdmitInfo2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkAdmitInfo3.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkAdmitInfo4.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtXZZAddress.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtHKZZAddress.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkFandB3.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkFandB2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkFandB1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkFandB0.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkRThree3.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkRThree2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkRThree1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkRThree0.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkLandB3.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkLandB2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkLandB1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkLandB0.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkSqAndSh3.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkSqAndSh2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkSqAndSh1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkSqAndSh0.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkRandC3.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkRandC2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkRandC1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkRandC0.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkMandZ3.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkMandZ2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkMandZ1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkMandZ0.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtAge.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEditOrganizationCode.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCSDAddress.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtJGAddress.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_newXZZAddress.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_newHKDZAddress.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueOutHosWard)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueOutHosDept)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueTransAdmitDept)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueAdmitWard)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueAdmitDept)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueRelationship)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueNationality)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueNation)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueCSD_ProvinceID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.luePayId)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueMarital)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookUpWindowMarital)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueJob)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueSex)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueCSD_CityID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueCSD_DistrictID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueJG_ProvinceID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueJG_CityID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueXZZ_ProvinceID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueXZZ_CityID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueXZZ_DistrictID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueHKDZ_ProvinceID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueHKDZ_CityID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueHKDZ_DistrictID)).BeginInit();
            this.SuspendLayout();
            // 
            // deBirth
            // 
            this.deBirth.EditValue = null;
            this.deBirth.EnterMoveNextControl = true;
            this.deBirth.Location = new System.Drawing.Point(301, 127);
            this.deBirth.Name = "deBirth";
            this.deBirth.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.deBirth.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.deBirth.Properties.VistaTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.deBirth.Size = new System.Drawing.Size(100, 19);
            this.deBirth.TabIndex = 6;
            this.deBirth.Validating += new System.ComponentModel.CancelEventHandler(this.deBirth_Validating);
            // 
            // seActualDays
            // 
            this.seActualDays.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.seActualDays.EnterMoveNextControl = true;
            this.seActualDays.Location = new System.Drawing.Point(572, 380);
            this.seActualDays.Name = "seActualDays";
            this.seActualDays.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.seActualDays.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.seActualDays.Properties.IsFloatValue = false;
            this.seActualDays.Properties.Mask.EditMask = "N00";
            this.seActualDays.Properties.MaxValue = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.seActualDays.Size = new System.Drawing.Size(76, 19);
            this.seActualDays.TabIndex = 58;
            // 
            // seInCount
            // 
            this.seInCount.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.seInCount.Enabled = false;
            this.seInCount.EnterMoveNextControl = true;
            this.seInCount.Location = new System.Drawing.Point(304, 89);
            this.seInCount.Name = "seInCount";
            this.seInCount.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.seInCount.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.seInCount.Properties.IsFloatValue = false;
            this.seInCount.Properties.Mask.EditMask = "N00";
            this.seInCount.Properties.MaxValue = new decimal(new int[] {
            999,
            0,
            0,
            0});
            this.seInCount.Size = new System.Drawing.Size(40, 19);
            this.seInCount.TabIndex = 2;
            // 
            // labelControl38
            // 
            this.labelControl38.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl38.Location = new System.Drawing.Point(653, 382);
            this.labelControl38.Name = "labelControl38";
            this.labelControl38.Size = new System.Drawing.Size(12, 14);
            this.labelControl38.TabIndex = 116;
            this.labelControl38.Text = "天";
            // 
            // labelControl39
            // 
            this.labelControl39.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl39.Location = new System.Drawing.Point(512, 382);
            this.labelControl39.Name = "labelControl39";
            this.labelControl39.Size = new System.Drawing.Size(60, 14);
            this.labelControl39.TabIndex = 114;
            this.labelControl39.Text = "实际住院：";
            // 
            // labelControl40
            // 
            this.labelControl40.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl40.Location = new System.Drawing.Point(380, 382);
            this.labelControl40.Name = "labelControl40";
            this.labelControl40.Size = new System.Drawing.Size(36, 14);
            this.labelControl40.TabIndex = 112;
            this.labelControl40.Text = "病区：";
            // 
            // labelControl41
            // 
            this.labelControl41.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl41.Location = new System.Drawing.Point(226, 382);
            this.labelControl41.Name = "labelControl41";
            this.labelControl41.Size = new System.Drawing.Size(60, 14);
            this.labelControl41.TabIndex = 110;
            this.labelControl41.Text = "出院科别：";
            // 
            // teOutWardDate
            // 
            this.teOutWardDate.EditValue = new System.DateTime(2011, 3, 5, 0, 0, 0, 0);
            this.teOutWardDate.EnterMoveNextControl = true;
            this.teOutWardDate.Location = new System.Drawing.Point(155, 380);
            this.teOutWardDate.Name = "teOutWardDate";
            this.teOutWardDate.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.teOutWardDate.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.teOutWardDate.Properties.Mask.EditMask = "HH:mm";
            this.teOutWardDate.Size = new System.Drawing.Size(51, 19);
            this.teOutWardDate.TabIndex = 55;
            // 
            // deOutWardDate
            // 
            this.deOutWardDate.EditValue = null;
            this.deOutWardDate.EnterMoveNextControl = true;
            this.deOutWardDate.Location = new System.Drawing.Point(82, 380);
            this.deOutWardDate.Name = "deOutWardDate";
            this.deOutWardDate.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.deOutWardDate.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.deOutWardDate.Properties.VistaTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.deOutWardDate.Size = new System.Drawing.Size(75, 19);
            this.deOutWardDate.TabIndex = 54;
            // 
            // labelControl42
            // 
            this.labelControl42.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl42.Location = new System.Drawing.Point(23, 382);
            this.labelControl42.Name = "labelControl42";
            this.labelControl42.Size = new System.Drawing.Size(60, 14);
            this.labelControl42.TabIndex = 107;
            this.labelControl42.Text = "出院时间：";
            // 
            // labelControl35
            // 
            this.labelControl35.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl35.Location = new System.Drawing.Point(512, 356);
            this.labelControl35.Name = "labelControl35";
            this.labelControl35.Size = new System.Drawing.Size(60, 14);
            this.labelControl35.TabIndex = 105;
            this.labelControl35.Text = "转入科别：";
            // 
            // labelControl31
            // 
            this.labelControl31.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl31.Location = new System.Drawing.Point(380, 356);
            this.labelControl31.Name = "labelControl31";
            this.labelControl31.Size = new System.Drawing.Size(36, 14);
            this.labelControl31.TabIndex = 103;
            this.labelControl31.Text = "病区：";
            // 
            // labelControl30
            // 
            this.labelControl30.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl30.Location = new System.Drawing.Point(226, 356);
            this.labelControl30.Name = "labelControl30";
            this.labelControl30.Size = new System.Drawing.Size(60, 14);
            this.labelControl30.TabIndex = 101;
            this.labelControl30.Text = "入院科别：";
            // 
            // teAdmitDate
            // 
            this.teAdmitDate.EditValue = new System.DateTime(2011, 3, 5, 0, 0, 0, 0);
            this.teAdmitDate.EnterMoveNextControl = true;
            this.teAdmitDate.Location = new System.Drawing.Point(155, 354);
            this.teAdmitDate.Name = "teAdmitDate";
            this.teAdmitDate.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.teAdmitDate.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.teAdmitDate.Properties.Mask.EditMask = "HH:mm";
            this.teAdmitDate.Size = new System.Drawing.Size(51, 19);
            this.teAdmitDate.TabIndex = 50;
            // 
            // deAdmitDate
            // 
            this.deAdmitDate.EditValue = null;
            this.deAdmitDate.EnterMoveNextControl = true;
            this.deAdmitDate.Location = new System.Drawing.Point(82, 354);
            this.deAdmitDate.Name = "deAdmitDate";
            this.deAdmitDate.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.deAdmitDate.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.deAdmitDate.Properties.VistaTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.deAdmitDate.Size = new System.Drawing.Size(75, 19);
            this.deAdmitDate.TabIndex = 49;
            // 
            // labelControl29
            // 
            this.labelControl29.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl29.Location = new System.Drawing.Point(23, 356);
            this.labelControl29.Name = "labelControl29";
            this.labelControl29.Size = new System.Drawing.Size(60, 14);
            this.labelControl29.TabIndex = 98;
            this.labelControl29.Text = "入院时间：";
            // 
            // txtContactTEL
            // 
            this.txtContactTEL.EditValue = "";
            this.txtContactTEL.EnterMoveNextControl = true;
            this.txtContactTEL.Location = new System.Drawing.Point(579, 301);
            this.txtContactTEL.Name = "txtContactTEL";
            this.txtContactTEL.Properties.AppearanceReadOnly.BackColor = System.Drawing.Color.White;
            this.txtContactTEL.Properties.AppearanceReadOnly.BackColor2 = System.Drawing.Color.White;
            this.txtContactTEL.Properties.AppearanceReadOnly.Options.UseBackColor = true;
            this.txtContactTEL.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtContactTEL.Properties.MaxLength = 15;
            this.txtContactTEL.Size = new System.Drawing.Size(101, 19);
            this.txtContactTEL.TabIndex = 40;
            this.txtContactTEL.Enter += new System.EventHandler(this.txt_Enter);
            // 
            // labelControl28
            // 
            this.labelControl28.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl28.Location = new System.Drawing.Point(543, 304);
            this.labelControl28.Name = "labelControl28";
            this.labelControl28.Size = new System.Drawing.Size(36, 14);
            this.labelControl28.TabIndex = 86;
            this.labelControl28.Text = "电话：";
            // 
            // txtContactAddress
            // 
            this.txtContactAddress.EditValue = "";
            this.txtContactAddress.EnterMoveNextControl = true;
            this.txtContactAddress.Location = new System.Drawing.Point(385, 301);
            this.txtContactAddress.Name = "txtContactAddress";
            this.txtContactAddress.Properties.AppearanceReadOnly.BackColor = System.Drawing.Color.White;
            this.txtContactAddress.Properties.AppearanceReadOnly.BackColor2 = System.Drawing.Color.White;
            this.txtContactAddress.Properties.AppearanceReadOnly.Options.UseBackColor = true;
            this.txtContactAddress.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtContactAddress.Size = new System.Drawing.Size(141, 19);
            this.txtContactAddress.TabIndex = 39;
            this.txtContactAddress.Enter += new System.EventHandler(this.txt_Enter);
            // 
            // labelControl27
            // 
            this.labelControl27.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl27.Location = new System.Drawing.Point(349, 304);
            this.labelControl27.Name = "labelControl27";
            this.labelControl27.Size = new System.Drawing.Size(36, 14);
            this.labelControl27.TabIndex = 84;
            this.labelControl27.Text = "地址：";
            // 
            // labelControl26
            // 
            this.labelControl26.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl26.Location = new System.Drawing.Point(204, 304);
            this.labelControl26.Name = "labelControl26";
            this.labelControl26.Size = new System.Drawing.Size(36, 14);
            this.labelControl26.TabIndex = 82;
            this.labelControl26.Text = "关系：";
            // 
            // txtContactPerson
            // 
            this.txtContactPerson.EditValue = "";
            this.txtContactPerson.EnterMoveNextControl = true;
            this.txtContactPerson.Location = new System.Drawing.Point(95, 301);
            this.txtContactPerson.Name = "txtContactPerson";
            this.txtContactPerson.Properties.AppearanceReadOnly.BackColor = System.Drawing.Color.White;
            this.txtContactPerson.Properties.AppearanceReadOnly.BackColor2 = System.Drawing.Color.White;
            this.txtContactPerson.Properties.AppearanceReadOnly.Options.UseBackColor = true;
            this.txtContactPerson.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtContactPerson.Size = new System.Drawing.Size(86, 19);
            this.txtContactPerson.TabIndex = 37;
            this.txtContactPerson.Enter += new System.EventHandler(this.txt_Enter);
            // 
            // labelControl25
            // 
            this.labelControl25.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl25.Location = new System.Drawing.Point(23, 304);
            this.labelControl25.Name = "labelControl25";
            this.labelControl25.Size = new System.Drawing.Size(72, 14);
            this.labelControl25.TabIndex = 80;
            this.labelControl25.Text = "联系人姓名：";
            // 
            // labelControl22
            // 
            this.labelControl22.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl22.Location = new System.Drawing.Point(23, 256);
            this.labelControl22.Name = "labelControl22";
            this.labelControl22.Size = new System.Drawing.Size(60, 14);
            this.labelControl22.TabIndex = 63;
            this.labelControl22.Text = "户口地址：";
            // 
            // txtXZZ_Post
            // 
            this.txtXZZ_Post.EditValue = "";
            this.txtXZZ_Post.EnterMoveNextControl = true;
            this.txtXZZ_Post.Location = new System.Drawing.Point(623, 227);
            this.txtXZZ_Post.Name = "txtXZZ_Post";
            this.txtXZZ_Post.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtXZZ_Post.Properties.MaxLength = 6;
            this.txtXZZ_Post.Size = new System.Drawing.Size(61, 19);
            this.txtXZZ_Post.TabIndex = 28;
            this.txtXZZ_Post.Enter += new System.EventHandler(this.txt_Enter);
            //this.txtXZZ_Post.Leave += new System.EventHandler(this.txtXZZ_Post_Leave);
            // 
            // labelControl21
            // 
            this.labelControl21.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl21.Location = new System.Drawing.Point(565, 229);
            this.labelControl21.Name = "labelControl21";
            this.labelControl21.Size = new System.Drawing.Size(60, 14);
            this.labelControl21.TabIndex = 61;
            this.labelControl21.Text = "邮政编码：";
            // 
            // txtXZZ_TEL
            // 
            this.txtXZZ_TEL.EditValue = "";
            this.txtXZZ_TEL.EnterMoveNextControl = true;
            this.txtXZZ_TEL.Location = new System.Drawing.Point(487, 227);
            this.txtXZZ_TEL.Name = "txtXZZ_TEL";
            this.txtXZZ_TEL.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtXZZ_TEL.Properties.MaxLength = 15;
            this.txtXZZ_TEL.Size = new System.Drawing.Size(70, 19);
            this.txtXZZ_TEL.TabIndex = 27;
            this.txtXZZ_TEL.Enter += new System.EventHandler(this.txt_Enter);
            // 
            // labelControl20
            // 
            this.labelControl20.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl20.Location = new System.Drawing.Point(449, 229);
            this.labelControl20.Name = "labelControl20";
            this.labelControl20.Size = new System.Drawing.Size(36, 14);
            this.labelControl20.TabIndex = 59;
            this.labelControl20.Text = "电话：";
            // 
            // txtOfficePlace
            // 
            this.txtOfficePlace.EditValue = "";
            this.txtOfficePlace.EnterMoveNextControl = true;
            this.txtOfficePlace.Location = new System.Drawing.Point(119, 277);
            this.txtOfficePlace.Name = "txtOfficePlace";
            this.txtOfficePlace.Properties.AppearanceReadOnly.BackColor = System.Drawing.Color.White;
            this.txtOfficePlace.Properties.AppearanceReadOnly.BackColor2 = System.Drawing.Color.White;
            this.txtOfficePlace.Properties.AppearanceReadOnly.Options.UseBackColor = true;
            this.txtOfficePlace.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtOfficePlace.Size = new System.Drawing.Size(178, 19);
            this.txtOfficePlace.TabIndex = 34;
            this.txtOfficePlace.Enter += new System.EventHandler(this.txt_Enter);
            // 
            // labelControl19
            // 
            this.labelControl19.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl19.Location = new System.Drawing.Point(23, 279);
            this.labelControl19.Name = "labelControl19";
            this.labelControl19.Size = new System.Drawing.Size(96, 14);
            this.labelControl19.TabIndex = 74;
            this.labelControl19.Text = "工作单位及地址：";
            // 
            // txtIDNO
            // 
            this.txtIDNO.EditValue = "";
            this.txtIDNO.EnterMoveNextControl = true;
            this.txtIDNO.Location = new System.Drawing.Point(80, 201);
            this.txtIDNO.Name = "txtIDNO";
            this.txtIDNO.Properties.AppearanceReadOnly.BackColor = System.Drawing.Color.White;
            this.txtIDNO.Properties.AppearanceReadOnly.BackColor2 = System.Drawing.Color.White;
            this.txtIDNO.Properties.AppearanceReadOnly.Options.UseBackColor = true;
            this.txtIDNO.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtIDNO.Properties.MaxLength = 18;
            this.txtIDNO.Size = new System.Drawing.Size(175, 19);
            this.txtIDNO.TabIndex = 19;
            this.txtIDNO.Enter += new System.EventHandler(this.txt_Enter);
            // 
            // labelControl18
            // 
            this.labelControl18.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl18.Location = new System.Drawing.Point(23, 203);
            this.labelControl18.Name = "labelControl18";
            this.labelControl18.Size = new System.Drawing.Size(60, 14);
            this.labelControl18.TabIndex = 42;
            this.labelControl18.Text = "身份证号：";
            // 
            // labelControl17
            // 
            this.labelControl17.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl17.Location = new System.Drawing.Point(544, 129);
            this.labelControl17.Name = "labelControl17";
            this.labelControl17.Size = new System.Drawing.Size(36, 14);
            this.labelControl17.TabIndex = 16;
            this.labelControl17.Text = "国籍：";
            // 
            // labelControl16
            // 
            this.labelControl16.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl16.Location = new System.Drawing.Point(520, 203);
            this.labelControl16.Name = "labelControl16";
            this.labelControl16.Size = new System.Drawing.Size(36, 14);
            this.labelControl16.TabIndex = 48;
            this.labelControl16.Text = "民族：";
            // 
            // labelControl12
            // 
            this.labelControl12.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl12.Location = new System.Drawing.Point(23, 177);
            this.labelControl12.Name = "labelControl12";
            this.labelControl12.Size = new System.Drawing.Size(48, 14);
            this.labelControl12.TabIndex = 28;
            this.labelControl12.Text = "出生地：";
            // 
            // labelControl11
            // 
            this.labelControl11.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl11.Location = new System.Drawing.Point(269, 203);
            this.labelControl11.Name = "labelControl11";
            this.labelControl11.Size = new System.Drawing.Size(36, 14);
            this.labelControl11.TabIndex = 44;
            this.labelControl11.Text = "职业：";
            // 
            // labelControl10
            // 
            this.labelControl10.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl10.Location = new System.Drawing.Point(408, 203);
            this.labelControl10.Name = "labelControl10";
            this.labelControl10.Size = new System.Drawing.Size(36, 14);
            this.labelControl10.TabIndex = 46;
            this.labelControl10.Text = "婚姻：";
            // 
            // labelControl9
            // 
            this.labelControl9.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl9.Location = new System.Drawing.Point(423, 129);
            this.labelControl9.Name = "labelControl9";
            this.labelControl9.Size = new System.Drawing.Size(36, 14);
            this.labelControl9.TabIndex = 14;
            this.labelControl9.Text = "年龄：";
            // 
            // labelControl8
            // 
            this.labelControl8.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl8.Location = new System.Drawing.Point(242, 129);
            this.labelControl8.Name = "labelControl8";
            this.labelControl8.Size = new System.Drawing.Size(60, 14);
            this.labelControl8.TabIndex = 12;
            this.labelControl8.Text = "出生日期：";
            // 
            // labelControl7
            // 
            this.labelControl7.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl7.Location = new System.Drawing.Point(127, 129);
            this.labelControl7.Name = "labelControl7";
            this.labelControl7.Size = new System.Drawing.Size(36, 14);
            this.labelControl7.TabIndex = 10;
            this.labelControl7.Text = "性别：";
            // 
            // txtSocialCare
            // 
            this.txtSocialCare.EditValue = "";
            this.txtSocialCare.Enabled = false;
            this.txtSocialCare.EnterMoveNextControl = true;
            this.txtSocialCare.Location = new System.Drawing.Point(94, 22);
            this.txtSocialCare.Name = "txtSocialCare";
            this.txtSocialCare.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtSocialCare.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSocialCare.Properties.Appearance.Options.UseBackColor = true;
            this.txtSocialCare.Properties.Appearance.Options.UseFont = true;
            this.txtSocialCare.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtSocialCare.Size = new System.Drawing.Size(71, 19);
            this.txtSocialCare.TabIndex = 151;
            this.txtSocialCare.TabStop = false;
            this.txtSocialCare.Visible = false;
            // 
            // labelControl6
            // 
            this.labelControl6.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl6.Location = new System.Drawing.Point(23, 68);
            this.labelControl6.Name = "labelControl6";
            this.labelControl6.Size = new System.Drawing.Size(84, 14);
            this.labelControl6.TabIndex = 156;
            this.labelControl6.Text = "医疗付款方式：";
            // 
            // labelControl4
            // 
            this.labelControl4.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl4.Location = new System.Drawing.Point(348, 91);
            this.labelControl4.Name = "labelControl4";
            this.labelControl4.Size = new System.Drawing.Size(36, 14);
            this.labelControl4.TabIndex = 4;
            this.labelControl4.Text = "次入院";
            // 
            // labelControl3
            // 
            this.labelControl3.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl3.Location = new System.Drawing.Point(288, 91);
            this.labelControl3.Name = "labelControl3";
            this.labelControl3.Size = new System.Drawing.Size(12, 14);
            this.labelControl3.TabIndex = 2;
            this.labelControl3.Text = "第";
            // 
            // txtName
            // 
            this.txtName.EnterMoveNextControl = true;
            this.txtName.Location = new System.Drawing.Point(58, 127);
            this.txtName.Name = "txtName";
            this.txtName.Properties.AppearanceDisabled.BackColor = System.Drawing.Color.White;
            this.txtName.Properties.AppearanceDisabled.BackColor2 = System.Drawing.Color.White;
            this.txtName.Properties.AppearanceDisabled.Options.UseBackColor = true;
            this.txtName.Properties.AppearanceReadOnly.BackColor = System.Drawing.Color.White;
            this.txtName.Properties.AppearanceReadOnly.BackColor2 = System.Drawing.Color.White;
            this.txtName.Properties.AppearanceReadOnly.Options.UseBackColor = true;
            this.txtName.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtName.Size = new System.Drawing.Size(59, 19);
            this.txtName.TabIndex = 4;
            this.txtName.Enter += new System.EventHandler(this.txt_Enter);
            // 
            // labelControl2
            // 
            this.labelControl2.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl2.Location = new System.Drawing.Point(23, 129);
            this.labelControl2.Name = "labelControl2";
            this.labelControl2.Size = new System.Drawing.Size(36, 14);
            this.labelControl2.TabIndex = 8;
            this.labelControl2.Text = "姓名：";
            // 
            // txtPatNoOfHis
            // 
            this.txtPatNoOfHis.Enabled = false;
            this.txtPatNoOfHis.EnterMoveNextControl = true;
            this.txtPatNoOfHis.Location = new System.Drawing.Point(561, 89);
            this.txtPatNoOfHis.Name = "txtPatNoOfHis";
            this.txtPatNoOfHis.Properties.Appearance.BackColor = System.Drawing.SystemColors.Control;
            this.txtPatNoOfHis.Properties.Appearance.Options.UseBackColor = true;
            this.txtPatNoOfHis.Properties.AppearanceDisabled.BackColor = System.Drawing.Color.White;
            this.txtPatNoOfHis.Properties.AppearanceDisabled.BackColor2 = System.Drawing.Color.White;
            this.txtPatNoOfHis.Properties.AppearanceDisabled.Options.UseBackColor = true;
            this.txtPatNoOfHis.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtPatNoOfHis.Size = new System.Drawing.Size(107, 19);
            this.txtPatNoOfHis.TabIndex = 3;
            // 
            // labelControl1
            // 
            this.labelControl1.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl1.Location = new System.Drawing.Point(513, 91);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(48, 14);
            this.labelControl1.TabIndex = 5;
            this.labelControl1.Text = "病案号：";
            // 
            // labelLogoName
            // 
            this.labelLogoName.Appearance.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelLogoName.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelLogoName.Location = new System.Drawing.Point(253, 62);
            this.labelLogoName.Name = "labelLogoName";
            this.labelLogoName.Size = new System.Drawing.Size(167, 25);
            this.labelLogoName.TabIndex = 158;
            this.labelLogoName.Text = "住 院 病 案 首 页";
            // 
            // txt_hospitalName
            // 
            this.txt_hospitalName.Appearance.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_hospitalName.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.txt_hospitalName.Location = new System.Drawing.Point(211, 40);
            this.txt_hospitalName.Name = "txt_hospitalName";
            this.txt_hospitalName.Size = new System.Drawing.Size(105, 14);
            this.txt_hospitalName.TabIndex = 153;
            this.txt_hospitalName.Text = "*******人民医院";
            // 
            // simpleButton1
            // 
            this.simpleButton1.ButtonStyle = DevExpress.XtraEditors.Controls.BorderStyles.Office2003;
            this.simpleButton1.Location = new System.Drawing.Point(688, 656);
            this.simpleButton1.Name = "simpleButton1";
            this.simpleButton1.Size = new System.Drawing.Size(10, 10);
            this.simpleButton1.TabIndex = 0;
            // 
            // labelControl5
            // 
            this.labelControl5.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl5.Location = new System.Drawing.Point(23, 92);
            this.labelControl5.Name = "labelControl5";
            this.labelControl5.Size = new System.Drawing.Size(60, 14);
            this.labelControl5.TabIndex = 1;
            this.labelControl5.Text = "健康卡号：";
            // 
            // txtCardNumber
            // 
            this.txtCardNumber.EnterMoveNextControl = true;
            this.txtCardNumber.Location = new System.Drawing.Point(83, 90);
            this.txtCardNumber.Name = "txtCardNumber";
            this.txtCardNumber.Properties.AppearanceDisabled.BackColor = System.Drawing.Color.White;
            this.txtCardNumber.Properties.AppearanceDisabled.BackColor2 = System.Drawing.Color.White;
            this.txtCardNumber.Properties.AppearanceDisabled.Options.UseBackColor = true;
            this.txtCardNumber.Properties.AppearanceReadOnly.BackColor = System.Drawing.Color.White;
            this.txtCardNumber.Properties.AppearanceReadOnly.BackColor2 = System.Drawing.Color.White;
            this.txtCardNumber.Properties.AppearanceReadOnly.Options.UseBackColor = true;
            this.txtCardNumber.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtCardNumber.Size = new System.Drawing.Size(98, 19);
            this.txtCardNumber.TabIndex = 1;
            this.txtCardNumber.Enter += new System.EventHandler(this.txt_Enter);
            // 
            // labelControl13
            // 
            this.labelControl13.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl13.Location = new System.Drawing.Point(23, 151);
            this.labelControl13.Name = "labelControl13";
            this.labelControl13.Size = new System.Drawing.Size(115, 14);
            this.labelControl13.TabIndex = 18;
            this.labelControl13.Text = "（年龄不足1周岁的）";
            // 
            // labelControl14
            // 
            this.labelControl14.Appearance.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.labelControl14.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl14.Location = new System.Drawing.Point(148, 151);
            this.labelControl14.Name = "labelControl14";
            this.labelControl14.Size = new System.Drawing.Size(39, 14);
            this.labelControl14.TabIndex = 19;
            this.labelControl14.Text = "年龄：";
            // 
            // txtMonthAge
            // 
            this.txtMonthAge.EnterMoveNextControl = true;
            this.txtMonthAge.Location = new System.Drawing.Point(180, 149);
            this.txtMonthAge.Name = "txtMonthAge";
            this.txtMonthAge.Properties.AppearanceDisabled.BackColor = System.Drawing.Color.White;
            this.txtMonthAge.Properties.AppearanceDisabled.BackColor2 = System.Drawing.Color.White;
            this.txtMonthAge.Properties.AppearanceDisabled.Options.UseBackColor = true;
            this.txtMonthAge.Properties.AppearanceReadOnly.BackColor = System.Drawing.Color.White;
            this.txtMonthAge.Properties.AppearanceReadOnly.BackColor2 = System.Drawing.Color.White;
            this.txtMonthAge.Properties.AppearanceReadOnly.Options.UseBackColor = true;
            this.txtMonthAge.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtMonthAge.Size = new System.Drawing.Size(40, 19);
            this.txtMonthAge.TabIndex = 9;
            this.txtMonthAge.Enter += new System.EventHandler(this.txt_Enter);
            // 
            // labelControl15
            // 
            this.labelControl15.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl15.Location = new System.Drawing.Point(227, 151);
            this.labelControl15.Name = "labelControl15";
            this.labelControl15.Size = new System.Drawing.Size(12, 14);
            this.labelControl15.TabIndex = 21;
            this.labelControl15.Text = "月";
            // 
            // labelControl45
            // 
            this.labelControl45.Appearance.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.labelControl45.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl45.Location = new System.Drawing.Point(253, 151);
            this.labelControl45.Name = "labelControl45";
            this.labelControl45.Size = new System.Drawing.Size(104, 14);
            this.labelControl45.TabIndex = 22;
            this.labelControl45.Text = "新生儿出生体重：";
            // 
            // txtWeight
            // 
            this.txtWeight.EnterMoveNextControl = true;
            this.txtWeight.Location = new System.Drawing.Point(350, 149);
            this.txtWeight.Name = "txtWeight";
            this.txtWeight.Properties.AppearanceDisabled.BackColor = System.Drawing.Color.White;
            this.txtWeight.Properties.AppearanceDisabled.BackColor2 = System.Drawing.Color.White;
            this.txtWeight.Properties.AppearanceDisabled.Options.UseBackColor = true;
            this.txtWeight.Properties.AppearanceReadOnly.BackColor = System.Drawing.Color.White;
            this.txtWeight.Properties.AppearanceReadOnly.BackColor2 = System.Drawing.Color.White;
            this.txtWeight.Properties.AppearanceReadOnly.Options.UseBackColor = true;
            this.txtWeight.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtWeight.Size = new System.Drawing.Size(40, 19);
            this.txtWeight.TabIndex = 10;
            this.txtWeight.Enter += new System.EventHandler(this.txt_Enter);
            // 
            // labelControl46
            // 
            this.labelControl46.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl46.Location = new System.Drawing.Point(396, 151);
            this.labelControl46.Name = "labelControl46";
            this.labelControl46.Size = new System.Drawing.Size(12, 14);
            this.labelControl46.TabIndex = 24;
            this.labelControl46.Text = "克";
            // 
            // labelControl47
            // 
            this.labelControl47.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl47.Location = new System.Drawing.Point(596, 151);
            this.labelControl47.Name = "labelControl47";
            this.labelControl47.Size = new System.Drawing.Size(12, 14);
            this.labelControl47.TabIndex = 27;
            this.labelControl47.Text = "克";
            // 
            // labelControl48
            // 
            this.labelControl48.Appearance.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.labelControl48.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl48.Location = new System.Drawing.Point(444, 151);
            this.labelControl48.Name = "labelControl48";
            this.labelControl48.Size = new System.Drawing.Size(104, 14);
            this.labelControl48.TabIndex = 25;
            this.labelControl48.Text = "新生儿入院体重：";
            // 
            // txtInWeight
            // 
            this.txtInWeight.EnterMoveNextControl = true;
            this.txtInWeight.Location = new System.Drawing.Point(541, 149);
            this.txtInWeight.Name = "txtInWeight";
            this.txtInWeight.Properties.AppearanceDisabled.BackColor = System.Drawing.Color.White;
            this.txtInWeight.Properties.AppearanceDisabled.BackColor2 = System.Drawing.Color.White;
            this.txtInWeight.Properties.AppearanceDisabled.Options.UseBackColor = true;
            this.txtInWeight.Properties.AppearanceReadOnly.BackColor = System.Drawing.Color.White;
            this.txtInWeight.Properties.AppearanceReadOnly.BackColor2 = System.Drawing.Color.White;
            this.txtInWeight.Properties.AppearanceReadOnly.Options.UseBackColor = true;
            this.txtInWeight.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtInWeight.Size = new System.Drawing.Size(53, 19);
            this.txtInWeight.TabIndex = 11;
            this.txtInWeight.Enter += new System.EventHandler(this.txt_Enter);
            // 
            // labelControl49
            // 
            this.labelControl49.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl49.Location = new System.Drawing.Point(137, 177);
            this.labelControl49.Name = "labelControl49";
            this.labelControl49.Size = new System.Drawing.Size(72, 14);
            this.labelControl49.TabIndex = 31;
            this.labelControl49.Text = "省（区、市）";
            // 
            // labelControl50
            // 
            this.labelControl50.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl50.Location = new System.Drawing.Point(277, 177);
            this.labelControl50.Name = "labelControl50";
            this.labelControl50.Size = new System.Drawing.Size(12, 14);
            this.labelControl50.TabIndex = 33;
            this.labelControl50.Text = "市";
            // 
            // labelControl51
            // 
            this.labelControl51.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl51.Location = new System.Drawing.Point(359, 177);
            this.labelControl51.Name = "labelControl51";
            this.labelControl51.Size = new System.Drawing.Size(12, 14);
            this.labelControl51.TabIndex = 35;
            this.labelControl51.Text = "县";
            // 
            // labelControl52
            // 
            this.labelControl52.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl52.Location = new System.Drawing.Point(385, 177);
            this.labelControl52.Name = "labelControl52";
            this.labelControl52.Size = new System.Drawing.Size(36, 14);
            this.labelControl52.TabIndex = 36;
            this.labelControl52.Text = "籍贯：";
            // 
            // labelControl53
            // 
            this.labelControl53.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl53.Location = new System.Drawing.Point(485, 177);
            this.labelControl53.Name = "labelControl53";
            this.labelControl53.Size = new System.Drawing.Size(72, 14);
            this.labelControl53.TabIndex = 39;
            this.labelControl53.Text = "省（区、市）";
            // 
            // labelControl54
            // 
            this.labelControl54.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl54.Location = new System.Drawing.Point(622, 177);
            this.labelControl54.Name = "labelControl54";
            this.labelControl54.Size = new System.Drawing.Size(12, 14);
            this.labelControl54.TabIndex = 41;
            this.labelControl54.Text = "市";
            // 
            // labelControl55
            // 
            this.labelControl55.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl55.Location = new System.Drawing.Point(23, 229);
            this.labelControl55.Name = "labelControl55";
            this.labelControl55.Size = new System.Drawing.Size(48, 14);
            this.labelControl55.TabIndex = 50;
            this.labelControl55.Text = "现住址：";
            // 
            // labelControl56
            // 
            this.labelControl56.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl56.Location = new System.Drawing.Point(136, 229);
            this.labelControl56.Name = "labelControl56";
            this.labelControl56.Size = new System.Drawing.Size(72, 14);
            this.labelControl56.TabIndex = 53;
            this.labelControl56.Text = "省（区、市）";
            // 
            // labelControl57
            // 
            this.labelControl57.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl57.Location = new System.Drawing.Point(271, 229);
            this.labelControl57.Name = "labelControl57";
            this.labelControl57.Size = new System.Drawing.Size(12, 14);
            this.labelControl57.TabIndex = 55;
            this.labelControl57.Text = "市";
            // 
            // labelControl58
            // 
            this.labelControl58.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl58.Location = new System.Drawing.Point(353, 229);
            this.labelControl58.Name = "labelControl58";
            this.labelControl58.Size = new System.Drawing.Size(12, 14);
            this.labelControl58.TabIndex = 57;
            this.labelControl58.Text = "县";
            // 
            // labelControl59
            // 
            this.labelControl59.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl59.Location = new System.Drawing.Point(149, 256);
            this.labelControl59.Name = "labelControl59";
            this.labelControl59.Size = new System.Drawing.Size(72, 14);
            this.labelControl59.TabIndex = 66;
            this.labelControl59.Text = "省（区、市）";
            // 
            // labelControl60
            // 
            this.labelControl60.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl60.Location = new System.Drawing.Point(289, 256);
            this.labelControl60.Name = "labelControl60";
            this.labelControl60.Size = new System.Drawing.Size(12, 14);
            this.labelControl60.TabIndex = 68;
            this.labelControl60.Text = "市";
            // 
            // labelControl61
            // 
            this.labelControl61.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl61.Location = new System.Drawing.Point(377, 256);
            this.labelControl61.Name = "labelControl61";
            this.labelControl61.Size = new System.Drawing.Size(12, 14);
            this.labelControl61.TabIndex = 70;
            this.labelControl61.Text = "县";
            // 
            // txtHKDZ_Post
            // 
            this.txtHKDZ_Post.EditValue = "";
            this.txtHKDZ_Post.EnterMoveNextControl = true;
            this.txtHKDZ_Post.Location = new System.Drawing.Point(623, 254);
            this.txtHKDZ_Post.Name = "txtHKDZ_Post";
            this.txtHKDZ_Post.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtHKDZ_Post.Properties.MaxLength = 6;
            this.txtHKDZ_Post.Size = new System.Drawing.Size(61, 19);
            this.txtHKDZ_Post.TabIndex = 33;
            this.txtHKDZ_Post.Enter += new System.EventHandler(this.txt_Enter);
            //this.txtHKDZ_Post.Leave += new System.EventHandler(this.txtHKDZ_Post_Leave);
            // 
            // labelControl62
            // 
            this.labelControl62.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl62.Location = new System.Drawing.Point(565, 256);
            this.labelControl62.Name = "labelControl62";
            this.labelControl62.Size = new System.Drawing.Size(60, 14);
            this.labelControl62.TabIndex = 72;
            this.labelControl62.Text = "邮政编码：";
            // 
            // txtOfficeTEL
            // 
            this.txtOfficeTEL.EditValue = "";
            this.txtOfficeTEL.EnterMoveNextControl = true;
            this.txtOfficeTEL.Location = new System.Drawing.Point(386, 276);
            this.txtOfficeTEL.Name = "txtOfficeTEL";
            this.txtOfficeTEL.Properties.AppearanceReadOnly.BackColor = System.Drawing.Color.White;
            this.txtOfficeTEL.Properties.AppearanceReadOnly.BackColor2 = System.Drawing.Color.White;
            this.txtOfficeTEL.Properties.AppearanceReadOnly.Options.UseBackColor = true;
            this.txtOfficeTEL.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtOfficeTEL.Properties.MaxLength = 15;
            this.txtOfficeTEL.Size = new System.Drawing.Size(79, 19);
            this.txtOfficeTEL.TabIndex = 35;
            this.txtOfficeTEL.Enter += new System.EventHandler(this.txt_Enter);
            // 
            // labelControl63
            // 
            this.labelControl63.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl63.Location = new System.Drawing.Point(325, 279);
            this.labelControl63.Name = "labelControl63";
            this.labelControl63.Size = new System.Drawing.Size(60, 14);
            this.labelControl63.TabIndex = 76;
            this.labelControl63.Text = "单位电话：";
            // 
            // txtOfficePost
            // 
            this.txtOfficePost.EditValue = "";
            this.txtOfficePost.EnterMoveNextControl = true;
            this.txtOfficePost.Location = new System.Drawing.Point(623, 277);
            this.txtOfficePost.Name = "txtOfficePost";
            this.txtOfficePost.Properties.AppearanceReadOnly.BackColor = System.Drawing.Color.White;
            this.txtOfficePost.Properties.AppearanceReadOnly.BackColor2 = System.Drawing.Color.White;
            this.txtOfficePost.Properties.AppearanceReadOnly.Options.UseBackColor = true;
            this.txtOfficePost.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtOfficePost.Properties.MaxLength = 6;
            this.txtOfficePost.Size = new System.Drawing.Size(61, 19);
            this.txtOfficePost.TabIndex = 36;
            this.txtOfficePost.Enter += new System.EventHandler(this.txt_Enter);
            //this.txtOfficePost.Leave += new System.EventHandler(this.txtOfficePost_Leave);
            // 
            // labelControl64
            // 
            this.labelControl64.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl64.Location = new System.Drawing.Point(565, 279);
            this.labelControl64.Name = "labelControl64";
            this.labelControl64.Size = new System.Drawing.Size(60, 14);
            this.labelControl64.TabIndex = 78;
            this.labelControl64.Text = "邮政编码：";
            // 
            // labelControl65
            // 
            this.labelControl65.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl65.Location = new System.Drawing.Point(23, 330);
            this.labelControl65.Name = "labelControl65";
            this.labelControl65.Size = new System.Drawing.Size(60, 14);
            this.labelControl65.TabIndex = 88;
            this.labelControl65.Text = "入院途径：";
            // 
            // chkInHosType1
            // 
            this.chkInHosType1.Location = new System.Drawing.Point(83, 328);
            this.chkInHosType1.Name = "chkInHosType1";
            this.chkInHosType1.Properties.Caption = "1.急诊";
            this.chkInHosType1.Properties.RadioGroupIndex = 0;
            this.chkInHosType1.Size = new System.Drawing.Size(60, 19);
            this.chkInHosType1.TabIndex = 41;
            this.chkInHosType1.TabStop = false;
            this.chkInHosType1.Click += new System.EventHandler(this.chkInHosType2_CheckedChanged);
            // 
            // chkInHosType2
            // 
            this.chkInHosType2.Location = new System.Drawing.Point(143, 328);
            this.chkInHosType2.Name = "chkInHosType2";
            this.chkInHosType2.Properties.Caption = "2.门诊";
            this.chkInHosType2.Properties.RadioGroupIndex = 0;
            this.chkInHosType2.Size = new System.Drawing.Size(60, 19);
            this.chkInHosType2.TabIndex = 42;
            this.chkInHosType2.TabStop = false;
            this.chkInHosType2.Click += new System.EventHandler(this.chkInHosType2_CheckedChanged);
            // 
            // chkInHosType3
            // 
            this.chkInHosType3.Location = new System.Drawing.Point(203, 328);
            this.chkInHosType3.Name = "chkInHosType3";
            this.chkInHosType3.Properties.Caption = "3.其他医疗机构转入";
            this.chkInHosType3.Properties.RadioGroupIndex = 0;
            this.chkInHosType3.Size = new System.Drawing.Size(131, 19);
            this.chkInHosType3.TabIndex = 43;
            this.chkInHosType3.TabStop = false;
            this.chkInHosType3.Click += new System.EventHandler(this.chkInHosType2_CheckedChanged);
            // 
            // chkInHosType4
            // 
            this.chkInHosType4.Location = new System.Drawing.Point(334, 328);
            this.chkInHosType4.Name = "chkInHosType4";
            this.chkInHosType4.Properties.Caption = "9.其他";
            this.chkInHosType4.Properties.RadioGroupIndex = 0;
            this.chkInHosType4.Size = new System.Drawing.Size(60, 19);
            this.chkInHosType4.TabIndex = 44;
            this.chkInHosType4.TabStop = false;
            this.chkInHosType4.Click += new System.EventHandler(this.chkInHosType2_CheckedChanged);
            // 
            // textEdit3
            // 
            this.textEdit3.EditValue = "";
            this.textEdit3.Location = new System.Drawing.Point(623, 254);
            this.textEdit3.Name = "textEdit3";
            this.textEdit3.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.textEdit3.Size = new System.Drawing.Size(61, 19);
            this.textEdit3.TabIndex = 18;
            // 
            // labelControl23
            // 
            this.labelControl23.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl23.Location = new System.Drawing.Point(419, 330);
            this.labelControl23.Name = "labelControl23";
            this.labelControl23.Size = new System.Drawing.Size(60, 14);
            this.labelControl23.TabIndex = 93;
            this.labelControl23.Text = "入院病情：";
            this.labelControl23.Visible = false;
            // 
            // chkAdmitInfo1
            // 
            this.chkAdmitInfo1.Location = new System.Drawing.Point(480, 328);
            this.chkAdmitInfo1.Name = "chkAdmitInfo1";
            this.chkAdmitInfo1.Properties.Caption = "1.危";
            this.chkAdmitInfo1.Properties.RadioGroupIndex = 2;
            this.chkAdmitInfo1.Size = new System.Drawing.Size(45, 19);
            this.chkAdmitInfo1.TabIndex = 45;
            this.chkAdmitInfo1.TabStop = false;
            this.chkAdmitInfo1.Visible = false;
            this.chkAdmitInfo1.Click += new System.EventHandler(this.chkInHosType2_CheckedChanged);
            // 
            // chkAdmitInfo2
            // 
            this.chkAdmitInfo2.Location = new System.Drawing.Point(529, 328);
            this.chkAdmitInfo2.Name = "chkAdmitInfo2";
            this.chkAdmitInfo2.Properties.Caption = "2.重";
            this.chkAdmitInfo2.Properties.RadioGroupIndex = 2;
            this.chkAdmitInfo2.Size = new System.Drawing.Size(45, 19);
            this.chkAdmitInfo2.TabIndex = 46;
            this.chkAdmitInfo2.TabStop = false;
            this.chkAdmitInfo2.Visible = false;
            this.chkAdmitInfo2.Click += new System.EventHandler(this.chkInHosType2_CheckedChanged);
            // 
            // chkAdmitInfo3
            // 
            this.chkAdmitInfo3.Location = new System.Drawing.Point(578, 328);
            this.chkAdmitInfo3.Name = "chkAdmitInfo3";
            this.chkAdmitInfo3.Properties.Caption = "3.一般";
            this.chkAdmitInfo3.Properties.RadioGroupIndex = 2;
            this.chkAdmitInfo3.Size = new System.Drawing.Size(60, 19);
            this.chkAdmitInfo3.TabIndex = 47;
            this.chkAdmitInfo3.TabStop = false;
            this.chkAdmitInfo3.Visible = false;
            this.chkAdmitInfo3.Click += new System.EventHandler(this.chkInHosType2_CheckedChanged);
            // 
            // chkAdmitInfo4
            // 
            this.chkAdmitInfo4.Location = new System.Drawing.Point(639, 328);
            this.chkAdmitInfo4.Name = "chkAdmitInfo4";
            this.chkAdmitInfo4.Properties.Caption = "4.急";
            this.chkAdmitInfo4.Properties.RadioGroupIndex = 2;
            this.chkAdmitInfo4.Size = new System.Drawing.Size(45, 19);
            this.chkAdmitInfo4.TabIndex = 48;
            this.chkAdmitInfo4.TabStop = false;
            this.chkAdmitInfo4.Visible = false;
            this.chkAdmitInfo4.Click += new System.EventHandler(this.chkInHosType2_CheckedChanged);
            // 
            // txtXZZAddress
            // 
            this.txtXZZAddress.EditValue = "";
            this.txtXZZAddress.EnterMoveNextControl = true;
            this.txtXZZAddress.Location = new System.Drawing.Point(69, 228);
            this.txtXZZAddress.Name = "txtXZZAddress";
            this.txtXZZAddress.Properties.AppearanceReadOnly.BackColor = System.Drawing.Color.White;
            this.txtXZZAddress.Properties.AppearanceReadOnly.BackColor2 = System.Drawing.Color.White;
            this.txtXZZAddress.Properties.AppearanceReadOnly.Options.UseBackColor = true;
            this.txtXZZAddress.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtXZZAddress.Size = new System.Drawing.Size(369, 19);
            this.txtXZZAddress.TabIndex = 26;
            this.txtXZZAddress.Enter += new System.EventHandler(this.txt_Enter);
            // 
            // txtHKZZAddress
            // 
            this.txtHKZZAddress.EditValue = "";
            this.txtHKZZAddress.EnterMoveNextControl = true;
            this.txtHKZZAddress.Location = new System.Drawing.Point(80, 254);
            this.txtHKZZAddress.Name = "txtHKZZAddress";
            this.txtHKZZAddress.Properties.AppearanceReadOnly.BackColor = System.Drawing.Color.White;
            this.txtHKZZAddress.Properties.AppearanceReadOnly.BackColor2 = System.Drawing.Color.White;
            this.txtHKZZAddress.Properties.AppearanceReadOnly.Options.UseBackColor = true;
            this.txtHKZZAddress.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtHKZZAddress.Size = new System.Drawing.Size(468, 19);
            this.txtHKZZAddress.TabIndex = 32;
            this.txtHKZZAddress.Enter += new System.EventHandler(this.txt_Enter);
            // 
            // chkFandB3
            // 
            this.chkFandB3.Location = new System.Drawing.Point(439, 454);
            this.chkFandB3.Name = "chkFandB3";
            this.chkFandB3.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.chkFandB3.Properties.Appearance.Options.UseForeColor = true;
            this.chkFandB3.Properties.Caption = "3.不肯定";
            this.chkFandB3.Properties.RadioGroupIndex = 10;
            this.chkFandB3.Size = new System.Drawing.Size(72, 19);
            this.chkFandB3.TabIndex = 82;
            this.chkFandB3.TabStop = false;
            this.chkFandB3.Tag = "不肯定";
            this.chkFandB3.Visible = false;
            this.chkFandB3.Click += new System.EventHandler(this.chkInHosType2_CheckedChanged);
            // 
            // chkFandB2
            // 
            this.chkFandB2.Location = new System.Drawing.Point(382, 454);
            this.chkFandB2.Name = "chkFandB2";
            this.chkFandB2.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.chkFandB2.Properties.Appearance.Options.UseForeColor = true;
            this.chkFandB2.Properties.Caption = "2.误诊";
            this.chkFandB2.Properties.RadioGroupIndex = 10;
            this.chkFandB2.Size = new System.Drawing.Size(58, 19);
            this.chkFandB2.TabIndex = 81;
            this.chkFandB2.TabStop = false;
            this.chkFandB2.Tag = "误诊";
            this.chkFandB2.Visible = false;
            this.chkFandB2.Click += new System.EventHandler(this.chkInHosType2_CheckedChanged);
            // 
            // chkFandB1
            // 
            this.chkFandB1.Location = new System.Drawing.Point(320, 454);
            this.chkFandB1.Name = "chkFandB1";
            this.chkFandB1.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.chkFandB1.Properties.Appearance.Options.UseForeColor = true;
            this.chkFandB1.Properties.Caption = "1.确诊";
            this.chkFandB1.Properties.RadioGroupIndex = 10;
            this.chkFandB1.Size = new System.Drawing.Size(64, 19);
            this.chkFandB1.TabIndex = 80;
            this.chkFandB1.TabStop = false;
            this.chkFandB1.Tag = "确诊";
            this.chkFandB1.Visible = false;
            this.chkFandB1.Click += new System.EventHandler(this.chkInHosType2_CheckedChanged);
            // 
            // chkFandB0
            // 
            this.chkFandB0.Location = new System.Drawing.Point(264, 454);
            this.chkFandB0.Name = "chkFandB0";
            this.chkFandB0.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.chkFandB0.Properties.Appearance.Options.UseForeColor = true;
            this.chkFandB0.Properties.Caption = "0.未作";
            this.chkFandB0.Properties.RadioGroupIndex = 10;
            this.chkFandB0.Size = new System.Drawing.Size(57, 19);
            this.chkFandB0.TabIndex = 79;
            this.chkFandB0.TabStop = false;
            this.chkFandB0.Tag = "未作";
            this.chkFandB0.Visible = false;
            this.chkFandB0.Click += new System.EventHandler(this.chkInHosType2_CheckedChanged);
            // 
            // labelControl24
            // 
            this.labelControl24.Appearance.ForeColor = System.Drawing.Color.Black;
            this.labelControl24.Location = new System.Drawing.Point(255, 454);
            this.labelControl24.Name = "labelControl24";
            this.labelControl24.Size = new System.Drawing.Size(0, 14);
            this.labelControl24.TabIndex = 143;
            this.labelControl24.Visible = false;
            // 
            // chkRThree3
            // 
            this.chkRThree3.Location = new System.Drawing.Point(187, 452);
            this.chkRThree3.Name = "chkRThree3";
            this.chkRThree3.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.chkRThree3.Properties.Appearance.Options.UseForeColor = true;
            this.chkRThree3.Properties.Caption = "3.不肯定";
            this.chkRThree3.Properties.RadioGroupIndex = 9;
            this.chkRThree3.Size = new System.Drawing.Size(72, 19);
            this.chkRThree3.TabIndex = 78;
            this.chkRThree3.TabStop = false;
            this.chkRThree3.Tag = "不肯定";
            this.chkRThree3.Visible = false;
            this.chkRThree3.Click += new System.EventHandler(this.chkInHosType2_CheckedChanged);
            // 
            // chkRThree2
            // 
            this.chkRThree2.Location = new System.Drawing.Point(130, 452);
            this.chkRThree2.Name = "chkRThree2";
            this.chkRThree2.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.chkRThree2.Properties.Appearance.Options.UseForeColor = true;
            this.chkRThree2.Properties.Caption = "2.误诊";
            this.chkRThree2.Properties.RadioGroupIndex = 9;
            this.chkRThree2.Size = new System.Drawing.Size(58, 19);
            this.chkRThree2.TabIndex = 77;
            this.chkRThree2.TabStop = false;
            this.chkRThree2.Tag = "误诊";
            this.chkRThree2.Visible = false;
            this.chkRThree2.Click += new System.EventHandler(this.chkInHosType2_CheckedChanged);
            // 
            // chkRThree1
            // 
            this.chkRThree1.Location = new System.Drawing.Point(67, 452);
            this.chkRThree1.Name = "chkRThree1";
            this.chkRThree1.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.chkRThree1.Properties.Appearance.Options.UseForeColor = true;
            this.chkRThree1.Properties.Caption = "1.确诊";
            this.chkRThree1.Properties.RadioGroupIndex = 9;
            this.chkRThree1.Size = new System.Drawing.Size(64, 19);
            this.chkRThree1.TabIndex = 76;
            this.chkRThree1.TabStop = false;
            this.chkRThree1.Tag = "确诊";
            this.chkRThree1.Visible = false;
            this.chkRThree1.Click += new System.EventHandler(this.chkInHosType2_CheckedChanged);
            // 
            // chkRThree0
            // 
            this.chkRThree0.Location = new System.Drawing.Point(10, 452);
            this.chkRThree0.Name = "chkRThree0";
            this.chkRThree0.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.chkRThree0.Properties.Appearance.Options.UseForeColor = true;
            this.chkRThree0.Properties.Caption = "0.未作";
            this.chkRThree0.Properties.RadioGroupIndex = 9;
            this.chkRThree0.Size = new System.Drawing.Size(57, 19);
            this.chkRThree0.TabIndex = 75;
            this.chkRThree0.TabStop = false;
            this.chkRThree0.Tag = "未作";
            this.chkRThree0.Visible = false;
            this.chkRThree0.Click += new System.EventHandler(this.chkInHosType2_CheckedChanged);
            // 
            // labelControl32
            // 
            this.labelControl32.Appearance.ForeColor = System.Drawing.Color.Black;
            this.labelControl32.Location = new System.Drawing.Point(28, 456);
            this.labelControl32.Name = "labelControl32";
            this.labelControl32.Size = new System.Drawing.Size(0, 14);
            this.labelControl32.TabIndex = 139;
            this.labelControl32.Visible = false;
            // 
            // chkLandB3
            // 
            this.chkLandB3.Location = new System.Drawing.Point(439, 428);
            this.chkLandB3.Name = "chkLandB3";
            this.chkLandB3.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.chkLandB3.Properties.Appearance.Options.UseForeColor = true;
            this.chkLandB3.Properties.Caption = "3.不肯定";
            this.chkLandB3.Properties.RadioGroupIndex = 8;
            this.chkLandB3.Size = new System.Drawing.Size(72, 19);
            this.chkLandB3.TabIndex = 74;
            this.chkLandB3.TabStop = false;
            this.chkLandB3.Tag = "不肯定";
            this.chkLandB3.Visible = false;
            this.chkLandB3.Click += new System.EventHandler(this.chkInHosType2_CheckedChanged);
            // 
            // chkLandB2
            // 
            this.chkLandB2.Location = new System.Drawing.Point(382, 428);
            this.chkLandB2.Name = "chkLandB2";
            this.chkLandB2.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.chkLandB2.Properties.Appearance.Options.UseForeColor = true;
            this.chkLandB2.Properties.Caption = "2.误诊";
            this.chkLandB2.Properties.RadioGroupIndex = 8;
            this.chkLandB2.Size = new System.Drawing.Size(58, 19);
            this.chkLandB2.TabIndex = 73;
            this.chkLandB2.TabStop = false;
            this.chkLandB2.Tag = "误诊";
            this.chkLandB2.Visible = false;
            this.chkLandB2.Click += new System.EventHandler(this.chkInHosType2_CheckedChanged);
            // 
            // chkLandB1
            // 
            this.chkLandB1.Location = new System.Drawing.Point(320, 428);
            this.chkLandB1.Name = "chkLandB1";
            this.chkLandB1.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.chkLandB1.Properties.Appearance.Options.UseForeColor = true;
            this.chkLandB1.Properties.Caption = "1.确诊";
            this.chkLandB1.Properties.RadioGroupIndex = 8;
            this.chkLandB1.Size = new System.Drawing.Size(64, 19);
            this.chkLandB1.TabIndex = 72;
            this.chkLandB1.TabStop = false;
            this.chkLandB1.Tag = "确诊";
            this.chkLandB1.Visible = false;
            this.chkLandB1.Click += new System.EventHandler(this.chkInHosType2_CheckedChanged);
            // 
            // chkLandB0
            // 
            this.chkLandB0.Location = new System.Drawing.Point(264, 428);
            this.chkLandB0.Name = "chkLandB0";
            this.chkLandB0.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.chkLandB0.Properties.Appearance.Options.UseForeColor = true;
            this.chkLandB0.Properties.Caption = "0.未作";
            this.chkLandB0.Properties.RadioGroupIndex = 8;
            this.chkLandB0.Size = new System.Drawing.Size(57, 19);
            this.chkLandB0.TabIndex = 71;
            this.chkLandB0.TabStop = false;
            this.chkLandB0.Tag = "未作";
            this.chkLandB0.Visible = false;
            this.chkLandB0.Click += new System.EventHandler(this.chkInHosType2_CheckedChanged);
            // 
            // labelControl33
            // 
            this.labelControl33.Appearance.ForeColor = System.Drawing.Color.Black;
            this.labelControl33.Location = new System.Drawing.Point(255, 426);
            this.labelControl33.Name = "labelControl33";
            this.labelControl33.Size = new System.Drawing.Size(0, 14);
            this.labelControl33.TabIndex = 133;
            this.labelControl33.Visible = false;
            // 
            // chkSqAndSh3
            // 
            this.chkSqAndSh3.Location = new System.Drawing.Point(187, 426);
            this.chkSqAndSh3.Name = "chkSqAndSh3";
            this.chkSqAndSh3.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.chkSqAndSh3.Properties.Appearance.Options.UseForeColor = true;
            this.chkSqAndSh3.Properties.Caption = "3.不肯定";
            this.chkSqAndSh3.Properties.RadioGroupIndex = 7;
            this.chkSqAndSh3.Size = new System.Drawing.Size(72, 19);
            this.chkSqAndSh3.TabIndex = 70;
            this.chkSqAndSh3.TabStop = false;
            this.chkSqAndSh3.Tag = "不肯定";
            this.chkSqAndSh3.Visible = false;
            this.chkSqAndSh3.Click += new System.EventHandler(this.chkInHosType2_CheckedChanged);
            // 
            // chkSqAndSh2
            // 
            this.chkSqAndSh2.Location = new System.Drawing.Point(130, 426);
            this.chkSqAndSh2.Name = "chkSqAndSh2";
            this.chkSqAndSh2.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.chkSqAndSh2.Properties.Appearance.Options.UseForeColor = true;
            this.chkSqAndSh2.Properties.Caption = "2.误诊";
            this.chkSqAndSh2.Properties.RadioGroupIndex = 7;
            this.chkSqAndSh2.Size = new System.Drawing.Size(58, 19);
            this.chkSqAndSh2.TabIndex = 69;
            this.chkSqAndSh2.TabStop = false;
            this.chkSqAndSh2.Tag = "误诊";
            this.chkSqAndSh2.Visible = false;
            this.chkSqAndSh2.Click += new System.EventHandler(this.chkInHosType2_CheckedChanged);
            // 
            // chkSqAndSh1
            // 
            this.chkSqAndSh1.Location = new System.Drawing.Point(67, 426);
            this.chkSqAndSh1.Name = "chkSqAndSh1";
            this.chkSqAndSh1.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.chkSqAndSh1.Properties.Appearance.Options.UseForeColor = true;
            this.chkSqAndSh1.Properties.Caption = "1.确诊";
            this.chkSqAndSh1.Properties.RadioGroupIndex = 7;
            this.chkSqAndSh1.Size = new System.Drawing.Size(64, 19);
            this.chkSqAndSh1.TabIndex = 68;
            this.chkSqAndSh1.TabStop = false;
            this.chkSqAndSh1.Tag = "确诊";
            this.chkSqAndSh1.Visible = false;
            this.chkSqAndSh1.Click += new System.EventHandler(this.chkInHosType2_CheckedChanged);
            // 
            // chkSqAndSh0
            // 
            this.chkSqAndSh0.Location = new System.Drawing.Point(10, 426);
            this.chkSqAndSh0.Name = "chkSqAndSh0";
            this.chkSqAndSh0.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.chkSqAndSh0.Properties.Appearance.Options.UseForeColor = true;
            this.chkSqAndSh0.Properties.Caption = "0.未作";
            this.chkSqAndSh0.Properties.RadioGroupIndex = 7;
            this.chkSqAndSh0.Size = new System.Drawing.Size(57, 19);
            this.chkSqAndSh0.TabIndex = 67;
            this.chkSqAndSh0.TabStop = false;
            this.chkSqAndSh0.Tag = "未作";
            this.chkSqAndSh0.Visible = false;
            this.chkSqAndSh0.Click += new System.EventHandler(this.chkInHosType2_CheckedChanged);
            // 
            // labelControl34
            // 
            this.labelControl34.Appearance.ForeColor = System.Drawing.Color.Black;
            this.labelControl34.Location = new System.Drawing.Point(28, 428);
            this.labelControl34.Name = "labelControl34";
            this.labelControl34.Size = new System.Drawing.Size(0, 14);
            this.labelControl34.TabIndex = 128;
            this.labelControl34.Visible = false;
            // 
            // chkRandC3
            // 
            this.chkRandC3.Location = new System.Drawing.Point(439, 403);
            this.chkRandC3.Name = "chkRandC3";
            this.chkRandC3.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.chkRandC3.Properties.Appearance.Options.UseForeColor = true;
            this.chkRandC3.Properties.Caption = "3.不肯定";
            this.chkRandC3.Properties.RadioGroupIndex = 6;
            this.chkRandC3.Size = new System.Drawing.Size(72, 19);
            this.chkRandC3.TabIndex = 66;
            this.chkRandC3.TabStop = false;
            this.chkRandC3.Tag = "不肯定";
            this.chkRandC3.Visible = false;
            this.chkRandC3.Click += new System.EventHandler(this.chkInHosType2_CheckedChanged);
            // 
            // chkRandC2
            // 
            this.chkRandC2.Location = new System.Drawing.Point(382, 403);
            this.chkRandC2.Name = "chkRandC2";
            this.chkRandC2.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.chkRandC2.Properties.Appearance.Options.UseForeColor = true;
            this.chkRandC2.Properties.Caption = "2.误诊";
            this.chkRandC2.Properties.RadioGroupIndex = 6;
            this.chkRandC2.Size = new System.Drawing.Size(58, 19);
            this.chkRandC2.TabIndex = 65;
            this.chkRandC2.TabStop = false;
            this.chkRandC2.Tag = "误诊";
            this.chkRandC2.Visible = false;
            this.chkRandC2.Click += new System.EventHandler(this.chkInHosType2_CheckedChanged);
            // 
            // chkRandC1
            // 
            this.chkRandC1.Location = new System.Drawing.Point(320, 403);
            this.chkRandC1.Name = "chkRandC1";
            this.chkRandC1.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.chkRandC1.Properties.Appearance.Options.UseForeColor = true;
            this.chkRandC1.Properties.Caption = "1.确诊";
            this.chkRandC1.Properties.RadioGroupIndex = 6;
            this.chkRandC1.Size = new System.Drawing.Size(64, 19);
            this.chkRandC1.TabIndex = 64;
            this.chkRandC1.TabStop = false;
            this.chkRandC1.Tag = "确诊";
            this.chkRandC1.Visible = false;
            this.chkRandC1.Click += new System.EventHandler(this.chkInHosType2_CheckedChanged);
            // 
            // chkRandC0
            // 
            this.chkRandC0.Location = new System.Drawing.Point(264, 403);
            this.chkRandC0.Name = "chkRandC0";
            this.chkRandC0.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.chkRandC0.Properties.Appearance.Options.UseForeColor = true;
            this.chkRandC0.Properties.Caption = "0.未作";
            this.chkRandC0.Properties.RadioGroupIndex = 6;
            this.chkRandC0.Size = new System.Drawing.Size(57, 19);
            this.chkRandC0.TabIndex = 63;
            this.chkRandC0.TabStop = false;
            this.chkRandC0.Tag = "未作";
            this.chkRandC0.Visible = false;
            this.chkRandC0.Click += new System.EventHandler(this.chkInHosType2_CheckedChanged);
            // 
            // labelControl36
            // 
            this.labelControl36.Appearance.ForeColor = System.Drawing.Color.Black;
            this.labelControl36.Location = new System.Drawing.Point(255, 401);
            this.labelControl36.Name = "labelControl36";
            this.labelControl36.Size = new System.Drawing.Size(0, 14);
            this.labelControl36.TabIndex = 122;
            this.labelControl36.Visible = false;
            // 
            // chkMandZ3
            // 
            this.chkMandZ3.Location = new System.Drawing.Point(187, 401);
            this.chkMandZ3.Name = "chkMandZ3";
            this.chkMandZ3.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.chkMandZ3.Properties.Appearance.Options.UseForeColor = true;
            this.chkMandZ3.Properties.Caption = "3.不肯定";
            this.chkMandZ3.Properties.RadioGroupIndex = 5;
            this.chkMandZ3.Size = new System.Drawing.Size(72, 19);
            this.chkMandZ3.TabIndex = 62;
            this.chkMandZ3.TabStop = false;
            this.chkMandZ3.Tag = "不肯定";
            this.chkMandZ3.Visible = false;
            this.chkMandZ3.Click += new System.EventHandler(this.chkInHosType2_CheckedChanged);
            // 
            // chkMandZ2
            // 
            this.chkMandZ2.Location = new System.Drawing.Point(130, 401);
            this.chkMandZ2.Name = "chkMandZ2";
            this.chkMandZ2.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.chkMandZ2.Properties.Appearance.Options.UseForeColor = true;
            this.chkMandZ2.Properties.Caption = "2.误诊";
            this.chkMandZ2.Properties.RadioGroupIndex = 5;
            this.chkMandZ2.Size = new System.Drawing.Size(58, 19);
            this.chkMandZ2.TabIndex = 61;
            this.chkMandZ2.TabStop = false;
            this.chkMandZ2.Tag = "误诊";
            this.chkMandZ2.Visible = false;
            this.chkMandZ2.Click += new System.EventHandler(this.chkInHosType2_CheckedChanged);
            // 
            // chkMandZ1
            // 
            this.chkMandZ1.Location = new System.Drawing.Point(67, 401);
            this.chkMandZ1.Name = "chkMandZ1";
            this.chkMandZ1.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.chkMandZ1.Properties.Appearance.Options.UseForeColor = true;
            this.chkMandZ1.Properties.Caption = "1.确诊";
            this.chkMandZ1.Properties.RadioGroupIndex = 5;
            this.chkMandZ1.Size = new System.Drawing.Size(64, 19);
            this.chkMandZ1.TabIndex = 60;
            this.chkMandZ1.TabStop = false;
            this.chkMandZ1.Tag = "确诊";
            this.chkMandZ1.Visible = false;
            this.chkMandZ1.Click += new System.EventHandler(this.chkInHosType2_CheckedChanged);
            // 
            // chkMandZ0
            // 
            this.chkMandZ0.Location = new System.Drawing.Point(10, 401);
            this.chkMandZ0.Name = "chkMandZ0";
            this.chkMandZ0.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.chkMandZ0.Properties.Appearance.Options.UseForeColor = true;
            this.chkMandZ0.Properties.Caption = "0.未作";
            this.chkMandZ0.Properties.RadioGroupIndex = 5;
            this.chkMandZ0.Size = new System.Drawing.Size(57, 19);
            this.chkMandZ0.TabIndex = 59;
            this.chkMandZ0.TabStop = false;
            this.chkMandZ0.Tag = "未作";
            this.chkMandZ0.Visible = false;
            this.chkMandZ0.Click += new System.EventHandler(this.chkInHosType2_CheckedChanged);
            // 
            // labelControl37
            // 
            this.labelControl37.Appearance.ForeColor = System.Drawing.Color.Black;
            this.labelControl37.Location = new System.Drawing.Point(28, 403);
            this.labelControl37.Name = "labelControl37";
            this.labelControl37.Size = new System.Drawing.Size(0, 14);
            this.labelControl37.TabIndex = 118;
            this.labelControl37.Visible = false;
            // 
            // txtAge
            // 
            this.txtAge.EnterMoveNextControl = true;
            this.txtAge.Location = new System.Drawing.Point(463, 127);
            this.txtAge.Name = "txtAge";
            this.txtAge.Properties.AppearanceDisabled.BackColor = System.Drawing.Color.White;
            this.txtAge.Properties.AppearanceDisabled.BackColor2 = System.Drawing.Color.White;
            this.txtAge.Properties.AppearanceDisabled.Options.UseBackColor = true;
            this.txtAge.Properties.AppearanceReadOnly.BackColor = System.Drawing.Color.White;
            this.txtAge.Properties.AppearanceReadOnly.BackColor2 = System.Drawing.Color.White;
            this.txtAge.Properties.AppearanceReadOnly.Options.UseBackColor = true;
            this.txtAge.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtAge.Size = new System.Drawing.Size(58, 19);
            this.txtAge.TabIndex = 7;
            this.txtAge.Enter += new System.EventHandler(this.txt_Enter);
            // 
            // textEditOrganizationCode
            // 
            this.textEditOrganizationCode.Enabled = false;
            this.textEditOrganizationCode.EnterMoveNextControl = true;
            this.textEditOrganizationCode.Location = new System.Drawing.Point(541, 36);
            this.textEditOrganizationCode.Name = "textEditOrganizationCode";
            this.textEditOrganizationCode.Properties.Appearance.BackColor = System.Drawing.SystemColors.Control;
            this.textEditOrganizationCode.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textEditOrganizationCode.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.textEditOrganizationCode.Properties.Appearance.Options.UseBackColor = true;
            this.textEditOrganizationCode.Properties.Appearance.Options.UseFont = true;
            this.textEditOrganizationCode.Properties.Appearance.Options.UseForeColor = true;
            this.textEditOrganizationCode.Properties.AppearanceDisabled.BackColor = System.Drawing.Color.White;
            this.textEditOrganizationCode.Properties.AppearanceDisabled.BackColor2 = System.Drawing.Color.White;
            this.textEditOrganizationCode.Properties.AppearanceDisabled.Options.UseBackColor = true;
            this.textEditOrganizationCode.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.textEditOrganizationCode.Size = new System.Drawing.Size(121, 21);
            this.textEditOrganizationCode.TabIndex = 155;
            // 
            // errorProvider
            // 
            this.errorProvider.ContainerControl = this;
            // 
            // lbl_title
            // 
            this.lbl_title.Appearance.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_title.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.lbl_title.Location = new System.Drawing.Point(264, 12);
            this.lbl_title.Name = "lbl_title";
            this.lbl_title.Size = new System.Drawing.Size(180, 19);
            this.lbl_title.TabIndex = 150;
            this.lbl_title.Text = "湖北省住院病案首页";
            // 
            // lbl_hostName
            // 
            this.lbl_hostName.Appearance.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_hostName.Appearance.ForeColor = System.Drawing.Color.Black;
            this.lbl_hostName.Location = new System.Drawing.Point(140, 41);
            this.lbl_hostName.Name = "lbl_hostName";
            this.lbl_hostName.Size = new System.Drawing.Size(70, 14);
            this.lbl_hostName.TabIndex = 152;
            this.lbl_hostName.Text = "医疗机构：";
            // 
            // txtCSDAddress
            // 
            this.txtCSDAddress.EditValue = "";
            this.txtCSDAddress.EnterMoveNextControl = true;
            this.txtCSDAddress.Location = new System.Drawing.Point(69, 174);
            this.txtCSDAddress.Name = "txtCSDAddress";
            this.txtCSDAddress.Properties.AppearanceReadOnly.BackColor = System.Drawing.Color.White;
            this.txtCSDAddress.Properties.AppearanceReadOnly.BackColor2 = System.Drawing.Color.White;
            this.txtCSDAddress.Properties.AppearanceReadOnly.Options.UseBackColor = true;
            this.txtCSDAddress.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtCSDAddress.Size = new System.Drawing.Size(303, 19);
            this.txtCSDAddress.TabIndex = 15;
            this.txtCSDAddress.Enter += new System.EventHandler(this.txt_Enter);
            // 
            // txtJGAddress
            // 
            this.txtJGAddress.EditValue = "";
            this.txtJGAddress.EnterMoveNextControl = true;
            this.txtJGAddress.Location = new System.Drawing.Point(419, 176);
            this.txtJGAddress.Name = "txtJGAddress";
            this.txtJGAddress.Properties.AppearanceReadOnly.BackColor = System.Drawing.Color.White;
            this.txtJGAddress.Properties.AppearanceReadOnly.BackColor2 = System.Drawing.Color.White;
            this.txtJGAddress.Properties.AppearanceReadOnly.Options.UseBackColor = true;
            this.txtJGAddress.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtJGAddress.Size = new System.Drawing.Size(215, 19);
            this.txtJGAddress.TabIndex = 18;
            this.txtJGAddress.Enter += new System.EventHandler(this.txt_Enter);
            // 
            // btn_Close
            // 
            this.btn_Close.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_Close.Image = ((System.Drawing.Image)(resources.GetObject("btn_Close.Image")));
            this.btn_Close.Location = new System.Drawing.Point(609, 465);
            this.btn_Close.Name = "btn_Close";
            this.btn_Close.Size = new System.Drawing.Size(75, 27);
            this.btn_Close.TabIndex = 84;
            this.btn_Close.Text = "关闭(&T)";
            this.btn_Close.Click += new System.EventHandler(this.btn_Close_Click);
            // 
            // btn_OK
            // 
            this.btn_OK.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_OK.Image = ((System.Drawing.Image)(resources.GetObject("btn_OK.Image")));
            this.btn_OK.Location = new System.Drawing.Point(528, 465);
            this.btn_OK.Name = "btn_OK";
            this.btn_OK.Size = new System.Drawing.Size(75, 27);
            this.btn_OK.TabIndex = 83;
            this.btn_OK.Text = "确定(&Y)";
            this.btn_OK.Click += new System.EventHandler(this.btn_OK_Click);
            // 
            // txt_newXZZAddress
            // 
            this.txt_newXZZAddress.EditValue = "";
            this.txt_newXZZAddress.EnterMoveNextControl = true;
            this.txt_newXZZAddress.Location = new System.Drawing.Point(371, 227);
            this.txt_newXZZAddress.Name = "txt_newXZZAddress";
            this.txt_newXZZAddress.Properties.AppearanceReadOnly.BackColor = System.Drawing.Color.White;
            this.txt_newXZZAddress.Properties.AppearanceReadOnly.BackColor2 = System.Drawing.Color.White;
            this.txt_newXZZAddress.Properties.AppearanceReadOnly.Options.UseBackColor = true;
            this.txt_newXZZAddress.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txt_newXZZAddress.Size = new System.Drawing.Size(69, 19);
            this.txt_newXZZAddress.TabIndex = 58;
            // 
            // txt_newHKDZAddress
            // 
            this.txt_newHKDZAddress.EditValue = "";
            this.txt_newHKDZAddress.EnterMoveNextControl = true;
            this.txt_newHKDZAddress.Location = new System.Drawing.Point(397, 253);
            this.txt_newHKDZAddress.Name = "txt_newHKDZAddress";
            this.txt_newHKDZAddress.Properties.AppearanceReadOnly.BackColor = System.Drawing.Color.White;
            this.txt_newHKDZAddress.Properties.AppearanceReadOnly.BackColor2 = System.Drawing.Color.White;
            this.txt_newHKDZAddress.Properties.AppearanceReadOnly.Options.UseBackColor = true;
            this.txt_newHKDZAddress.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txt_newHKDZAddress.Size = new System.Drawing.Size(151, 19);
            this.txt_newHKDZAddress.TabIndex = 71;
            // 
            // labelControl43
            // 
            this.labelControl43.Appearance.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl43.Location = new System.Drawing.Point(443, 40);
            this.labelControl43.Name = "labelControl43";
            this.labelControl43.Size = new System.Drawing.Size(98, 14);
            this.labelControl43.TabIndex = 154;
            this.labelControl43.Text = "组织机构代码：";
            // 
            // lueOutHosWard
            // 
            this.lueOutHosWard.EnterMoveNextControl = true;
            this.lueOutHosWard.Kind = DrectSoft.Wordbook.WordbookKind.Sql;
            this.lueOutHosWard.ListWindow = null;
            this.lueOutHosWard.Location = new System.Drawing.Point(415, 379);
            this.lueOutHosWard.Name = "lueOutHosWard";
            this.lueOutHosWard.ShowSButton = true;
            this.lueOutHosWard.Size = new System.Drawing.Size(74, 20);
            this.lueOutHosWard.TabIndex = 57;
            // 
            // lueOutHosDept
            // 
            this.lueOutHosDept.EnterMoveNextControl = true;
            this.lueOutHosDept.Kind = DrectSoft.Wordbook.WordbookKind.Sql;
            this.lueOutHosDept.ListWindow = null;
            this.lueOutHosDept.Location = new System.Drawing.Point(285, 379);
            this.lueOutHosDept.Name = "lueOutHosDept";
            this.lueOutHosDept.ShowSButton = true;
            this.lueOutHosDept.Size = new System.Drawing.Size(73, 20);
            this.lueOutHosDept.TabIndex = 56;
            this.lueOutHosDept.CodeValueChanged += new System.EventHandler(this.lueOutHosDept_CodeValueChanged);
            // 
            // lueTransAdmitDept
            // 
            this.lueTransAdmitDept.EnterMoveNextControl = true;
            this.lueTransAdmitDept.Kind = DrectSoft.Wordbook.WordbookKind.Sql;
            this.lueTransAdmitDept.ListWindow = null;
            this.lueTransAdmitDept.Location = new System.Drawing.Point(572, 353);
            this.lueTransAdmitDept.Name = "lueTransAdmitDept";
            this.lueTransAdmitDept.ShowSButton = true;
            this.lueTransAdmitDept.Size = new System.Drawing.Size(77, 20);
            this.lueTransAdmitDept.TabIndex = 53;
            // 
            // lueAdmitWard
            // 
            this.lueAdmitWard.EnterMoveNextControl = true;
            this.lueAdmitWard.Kind = DrectSoft.Wordbook.WordbookKind.Sql;
            this.lueAdmitWard.ListWindow = null;
            this.lueAdmitWard.Location = new System.Drawing.Point(415, 353);
            this.lueAdmitWard.Name = "lueAdmitWard";
            this.lueAdmitWard.ShowSButton = true;
            this.lueAdmitWard.Size = new System.Drawing.Size(74, 20);
            this.lueAdmitWard.TabIndex = 52;
            // 
            // lueAdmitDept
            // 
            this.lueAdmitDept.EnterMoveNextControl = true;
            this.lueAdmitDept.Kind = DrectSoft.Wordbook.WordbookKind.Sql;
            this.lueAdmitDept.ListWindow = null;
            this.lueAdmitDept.Location = new System.Drawing.Point(285, 353);
            this.lueAdmitDept.Name = "lueAdmitDept";
            this.lueAdmitDept.ShowSButton = true;
            this.lueAdmitDept.Size = new System.Drawing.Size(73, 20);
            this.lueAdmitDept.TabIndex = 51;
            this.lueAdmitDept.CodeValueChanged += new System.EventHandler(this.lueAdmitDept_CodeValueChanged);
            // 
            // lueRelationship
            // 
            this.lueRelationship.EnterMoveNextControl = true;
            this.lueRelationship.Kind = DrectSoft.Wordbook.WordbookKind.Sql;
            this.lueRelationship.ListWindow = null;
            this.lueRelationship.Location = new System.Drawing.Point(240, 301);
            this.lueRelationship.Name = "lueRelationship";
            this.lueRelationship.ShowSButton = true;
            this.lueRelationship.Size = new System.Drawing.Size(82, 20);
            this.lueRelationship.TabIndex = 38;
            // 
            // lueNationality
            // 
            this.lueNationality.EnterMoveNextControl = true;
            this.lueNationality.Kind = DrectSoft.Wordbook.WordbookKind.Sql;
            this.lueNationality.ListWindow = null;
            this.lueNationality.Location = new System.Drawing.Point(582, 128);
            this.lueNationality.Name = "lueNationality";
            this.lueNationality.ShowSButton = true;
            this.lueNationality.Size = new System.Drawing.Size(61, 20);
            this.lueNationality.TabIndex = 8;
            // 
            // lueNation
            // 
            this.lueNation.EnterMoveNextControl = true;
            this.lueNation.Kind = DrectSoft.Wordbook.WordbookKind.Sql;
            this.lueNation.ListWindow = null;
            this.lueNation.Location = new System.Drawing.Point(558, 200);
            this.lueNation.Name = "lueNation";
            this.lueNation.ShowSButton = true;
            this.lueNation.Size = new System.Drawing.Size(61, 20);
            this.lueNation.TabIndex = 22;
            // 
            // lueCSD_ProvinceID
            // 
            this.lueCSD_ProvinceID.EnterMoveNextControl = true;
            this.lueCSD_ProvinceID.Kind = DrectSoft.Wordbook.WordbookKind.Sql;
            this.lueCSD_ProvinceID.ListWindow = null;
            this.lueCSD_ProvinceID.Location = new System.Drawing.Point(71, 174);
            this.lueCSD_ProvinceID.Name = "lueCSD_ProvinceID";
            this.lueCSD_ProvinceID.ShowSButton = true;
            this.lueCSD_ProvinceID.Size = new System.Drawing.Size(60, 20);
            this.lueCSD_ProvinceID.TabIndex = 12;
            this.lueCSD_ProvinceID.CodeValueChanged += new System.EventHandler(this.lueProvice_CodeValueChanged);
            // 
            // luePayId
            // 
            this.luePayId.EnterMoveNextControl = true;
            this.luePayId.Kind = DrectSoft.Wordbook.WordbookKind.Sql;
            this.luePayId.ListWindow = null;
            this.luePayId.Location = new System.Drawing.Point(108, 65);
            this.luePayId.Name = "luePayId";
            this.luePayId.ShowSButton = true;
            this.luePayId.Size = new System.Drawing.Size(71, 20);
            this.luePayId.TabIndex = 0;
            // 
            // lueMarital
            // 
            this.lueMarital.EnterMoveNextControl = true;
            this.lueMarital.Kind = DrectSoft.Wordbook.WordbookKind.Sql;
            this.lueMarital.ListWindow = this.lookUpWindowMarital;
            this.lueMarital.Location = new System.Drawing.Point(444, 200);
            this.lueMarital.Name = "lueMarital";
            this.lueMarital.ShowSButton = true;
            this.lueMarital.Size = new System.Drawing.Size(55, 20);
            this.lueMarital.TabIndex = 21;
            // 
            // lookUpWindowMarital
            // 
            this.lookUpWindowMarital.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lookUpWindowMarital.GenShortCode = null;
            this.lookUpWindowMarital.MatchType = DrectSoft.Common.Library.ShowListMatchType.Any;
            this.lookUpWindowMarital.Owner = null;
            this.lookUpWindowMarital.SqlHelper = null;
            // 
            // lueJob
            // 
            this.lueJob.EnterMoveNextControl = true;
            this.lueJob.Kind = DrectSoft.Wordbook.WordbookKind.Sql;
            this.lueJob.ListWindow = null;
            this.lueJob.Location = new System.Drawing.Point(305, 200);
            this.lueJob.Name = "lueJob";
            this.lueJob.ShowSButton = true;
            this.lueJob.Size = new System.Drawing.Size(82, 20);
            this.lueJob.TabIndex = 20;
            // 
            // lueSex
            // 
            this.lueSex.EnterMoveNextControl = true;
            this.lueSex.Kind = DrectSoft.Wordbook.WordbookKind.Sql;
            this.lueSex.ListWindow = null;
            this.lueSex.Location = new System.Drawing.Point(166, 126);
            this.lueSex.Name = "lueSex";
            this.lueSex.ShowSButton = true;
            this.lueSex.Size = new System.Drawing.Size(59, 20);
            this.lueSex.TabIndex = 5;
            // 
            // lueCSD_CityID
            // 
            this.lueCSD_CityID.EnterMoveNextControl = true;
            this.lueCSD_CityID.Kind = DrectSoft.Wordbook.WordbookKind.Sql;
            this.lueCSD_CityID.ListWindow = null;
            this.lueCSD_CityID.Location = new System.Drawing.Point(210, 174);
            this.lueCSD_CityID.Name = "lueCSD_CityID";
            this.lueCSD_CityID.ShowSButton = true;
            this.lueCSD_CityID.Size = new System.Drawing.Size(60, 20);
            this.lueCSD_CityID.TabIndex = 13;
            this.lueCSD_CityID.CodeValueChanged += new System.EventHandler(this.lueProvice_CodeValueChanged);
            // 
            // lueCSD_DistrictID
            // 
            this.lueCSD_DistrictID.EnterMoveNextControl = true;
            this.lueCSD_DistrictID.Kind = DrectSoft.Wordbook.WordbookKind.Sql;
            this.lueCSD_DistrictID.ListWindow = null;
            this.lueCSD_DistrictID.Location = new System.Drawing.Point(294, 174);
            this.lueCSD_DistrictID.Name = "lueCSD_DistrictID";
            this.lueCSD_DistrictID.ShowSButton = true;
            this.lueCSD_DistrictID.Size = new System.Drawing.Size(60, 20);
            this.lueCSD_DistrictID.TabIndex = 14;
            this.lueCSD_DistrictID.CodeValueChanged += new System.EventHandler(this.lueProvice_CodeValueChanged);
            // 
            // lueJG_ProvinceID
            // 
            this.lueJG_ProvinceID.EnterMoveNextControl = true;
            this.lueJG_ProvinceID.Kind = DrectSoft.Wordbook.WordbookKind.Sql;
            this.lueJG_ProvinceID.ListWindow = null;
            this.lueJG_ProvinceID.Location = new System.Drawing.Point(420, 174);
            this.lueJG_ProvinceID.Name = "lueJG_ProvinceID";
            this.lueJG_ProvinceID.ShowSButton = true;
            this.lueJG_ProvinceID.Size = new System.Drawing.Size(60, 20);
            this.lueJG_ProvinceID.TabIndex = 16;
            this.lueJG_ProvinceID.CodeValueChanged += new System.EventHandler(this.lueProvice_CodeValueChanged);
            // 
            // lueJG_CityID
            // 
            this.lueJG_CityID.EnterMoveNextControl = true;
            this.lueJG_CityID.Kind = DrectSoft.Wordbook.WordbookKind.Sql;
            this.lueJG_CityID.ListWindow = null;
            this.lueJG_CityID.Location = new System.Drawing.Point(557, 174);
            this.lueJG_CityID.Name = "lueJG_CityID";
            this.lueJG_CityID.ShowSButton = true;
            this.lueJG_CityID.Size = new System.Drawing.Size(60, 20);
            this.lueJG_CityID.TabIndex = 17;
            // 
            // lueXZZ_ProvinceID
            // 
            this.lueXZZ_ProvinceID.EnterMoveNextControl = true;
            this.lueXZZ_ProvinceID.Kind = DrectSoft.Wordbook.WordbookKind.Sql;
            this.lueXZZ_ProvinceID.ListWindow = null;
            this.lueXZZ_ProvinceID.Location = new System.Drawing.Point(71, 226);
            this.lueXZZ_ProvinceID.Name = "lueXZZ_ProvinceID";
            this.lueXZZ_ProvinceID.ShowSButton = true;
            this.lueXZZ_ProvinceID.Size = new System.Drawing.Size(60, 20);
            this.lueXZZ_ProvinceID.TabIndex = 23;
            this.lueXZZ_ProvinceID.CodeValueChanged += new System.EventHandler(this.lueProvice_CodeValueChanged);
            // 
            // lueXZZ_CityID
            // 
            this.lueXZZ_CityID.EnterMoveNextControl = true;
            this.lueXZZ_CityID.Kind = DrectSoft.Wordbook.WordbookKind.Sql;
            this.lueXZZ_CityID.ListWindow = null;
            this.lueXZZ_CityID.Location = new System.Drawing.Point(205, 226);
            this.lueXZZ_CityID.Name = "lueXZZ_CityID";
            this.lueXZZ_CityID.ShowSButton = true;
            this.lueXZZ_CityID.Size = new System.Drawing.Size(60, 20);
            this.lueXZZ_CityID.TabIndex = 24;
            this.lueXZZ_CityID.CodeValueChanged += new System.EventHandler(this.lueProvice_CodeValueChanged);
            // 
            // lueXZZ_DistrictID
            // 
            this.lueXZZ_DistrictID.EnterMoveNextControl = true;
            this.lueXZZ_DistrictID.Kind = DrectSoft.Wordbook.WordbookKind.Sql;
            this.lueXZZ_DistrictID.ListWindow = null;
            this.lueXZZ_DistrictID.Location = new System.Drawing.Point(288, 226);
            this.lueXZZ_DistrictID.Name = "lueXZZ_DistrictID";
            this.lueXZZ_DistrictID.ShowSButton = true;
            this.lueXZZ_DistrictID.Size = new System.Drawing.Size(60, 20);
            this.lueXZZ_DistrictID.TabIndex = 25;
            this.lueXZZ_DistrictID.CodeValueChanged += new System.EventHandler(this.lueProvice_CodeValueChanged);
            // 
            // lueHKDZ_ProvinceID
            // 
            this.lueHKDZ_ProvinceID.EnterMoveNextControl = true;
            this.lueHKDZ_ProvinceID.Kind = DrectSoft.Wordbook.WordbookKind.Sql;
            this.lueHKDZ_ProvinceID.ListWindow = null;
            this.lueHKDZ_ProvinceID.Location = new System.Drawing.Point(83, 253);
            this.lueHKDZ_ProvinceID.Name = "lueHKDZ_ProvinceID";
            this.lueHKDZ_ProvinceID.ShowSButton = true;
            this.lueHKDZ_ProvinceID.Size = new System.Drawing.Size(60, 20);
            this.lueHKDZ_ProvinceID.TabIndex = 29;
            this.lueHKDZ_ProvinceID.CodeValueChanged += new System.EventHandler(this.lueProvice_CodeValueChanged);
            // 
            // lueHKDZ_CityID
            // 
            this.lueHKDZ_CityID.EnterMoveNextControl = true;
            this.lueHKDZ_CityID.Kind = DrectSoft.Wordbook.WordbookKind.Sql;
            this.lueHKDZ_CityID.ListWindow = null;
            this.lueHKDZ_CityID.Location = new System.Drawing.Point(222, 253);
            this.lueHKDZ_CityID.Name = "lueHKDZ_CityID";
            this.lueHKDZ_CityID.ShowSButton = true;
            this.lueHKDZ_CityID.Size = new System.Drawing.Size(60, 20);
            this.lueHKDZ_CityID.TabIndex = 30;
            this.lueHKDZ_CityID.CodeValueChanged += new System.EventHandler(this.lueProvice_CodeValueChanged);
            // 
            // lueHKDZ_DistrictID
            // 
            this.lueHKDZ_DistrictID.EnterMoveNextControl = true;
            this.lueHKDZ_DistrictID.Kind = DrectSoft.Wordbook.WordbookKind.Sql;
            this.lueHKDZ_DistrictID.ListWindow = null;
            this.lueHKDZ_DistrictID.Location = new System.Drawing.Point(311, 253);
            this.lueHKDZ_DistrictID.Name = "lueHKDZ_DistrictID";
            this.lueHKDZ_DistrictID.ShowSButton = true;
            this.lueHKDZ_DistrictID.Size = new System.Drawing.Size(60, 20);
            this.lueHKDZ_DistrictID.TabIndex = 31;
            this.lueHKDZ_DistrictID.CodeValueChanged += new System.EventHandler(this.lueProvice_CodeValueChanged);
            // 
            // hLineEx1
            // 
            this.hLineEx1.BackColor = System.Drawing.Color.White;
            this.hLineEx1.IsBold = true;
            this.hLineEx1.Location = new System.Drawing.Point(7, 115);
            this.hLineEx1.Name = "hLineEx1";
            this.hLineEx1.Size = new System.Drawing.Size(690, 2);
            this.hLineEx1.TabIndex = 7;
            this.hLineEx1.TabStop = false;
            this.hLineEx1.Text = "hLineEx1";
            // 
            // UCIemBasInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Controls.Add(this.labelControl43);
            this.Controls.Add(this.txt_newHKDZAddress);
            this.Controls.Add(this.txtXZZAddress);
            this.Controls.Add(this.textEditOrganizationCode);
            this.Controls.Add(this.txtJGAddress);
            this.Controls.Add(this.txtCSDAddress);
            this.Controls.Add(this.lbl_hostName);
            this.Controls.Add(this.lbl_title);
            this.Controls.Add(this.btn_Close);
            this.Controls.Add(this.btn_OK);
            this.Controls.Add(this.txtHKZZAddress);
            this.Controls.Add(this.chkAdmitInfo3);
            this.Controls.Add(this.chkAdmitInfo4);
            this.Controls.Add(this.chkAdmitInfo1);
            this.Controls.Add(this.chkAdmitInfo2);
            this.Controls.Add(this.labelControl23);
            this.Controls.Add(this.labelControl38);
            this.Controls.Add(this.labelControl39);
            this.Controls.Add(this.lueOutHosWard);
            this.Controls.Add(this.labelControl40);
            this.Controls.Add(this.lueOutHosDept);
            this.Controls.Add(this.labelControl41);
            this.Controls.Add(this.teOutWardDate);
            this.Controls.Add(this.deOutWardDate);
            this.Controls.Add(this.labelControl42);
            this.Controls.Add(this.lueTransAdmitDept);
            this.Controls.Add(this.labelControl35);
            this.Controls.Add(this.lueAdmitWard);
            this.Controls.Add(this.labelControl31);
            this.Controls.Add(this.lueAdmitDept);
            this.Controls.Add(this.labelControl30);
            this.Controls.Add(this.teAdmitDate);
            this.Controls.Add(this.deAdmitDate);
            this.Controls.Add(this.labelControl29);
            this.Controls.Add(this.txtContactTEL);
            this.Controls.Add(this.labelControl28);
            this.Controls.Add(this.txtContactAddress);
            this.Controls.Add(this.labelControl27);
            this.Controls.Add(this.lueRelationship);
            this.Controls.Add(this.labelControl26);
            this.Controls.Add(this.txtContactPerson);
            this.Controls.Add(this.labelControl25);
            this.Controls.Add(this.labelControl22);
            this.Controls.Add(this.txtXZZ_Post);
            this.Controls.Add(this.labelControl21);
            this.Controls.Add(this.txtXZZ_TEL);
            this.Controls.Add(this.labelControl20);
            this.Controls.Add(this.txtOfficePlace);
            this.Controls.Add(this.labelControl19);
            this.Controls.Add(this.txtIDNO);
            this.Controls.Add(this.labelControl18);
            this.Controls.Add(this.lueNationality);
            this.Controls.Add(this.labelControl17);
            this.Controls.Add(this.lueNation);
            this.Controls.Add(this.labelControl16);
            this.Controls.Add(this.lueCSD_ProvinceID);
            this.Controls.Add(this.labelControl12);
            this.Controls.Add(this.labelControl11);
            this.Controls.Add(this.labelControl10);
            this.Controls.Add(this.labelControl9);
            this.Controls.Add(this.labelControl8);
            this.Controls.Add(this.labelControl7);
            this.Controls.Add(this.txtSocialCare);
            this.Controls.Add(this.labelControl6);
            this.Controls.Add(this.labelControl4);
            this.Controls.Add(this.labelControl3);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.labelControl2);
            this.Controls.Add(this.txtPatNoOfHis);
            this.Controls.Add(this.labelControl1);
            this.Controls.Add(this.luePayId);
            this.Controls.Add(this.seInCount);
            this.Controls.Add(this.lueMarital);
            this.Controls.Add(this.lueJob);
            this.Controls.Add(this.lueSex);
            this.Controls.Add(this.seActualDays);
            this.Controls.Add(this.deBirth);
            this.Controls.Add(this.txtAge);
            this.Controls.Add(this.hLineEx1);
            this.Controls.Add(this.labelLogoName);
            this.Controls.Add(this.txt_hospitalName);
            this.Controls.Add(this.simpleButton1);
            this.Controls.Add(this.labelControl5);
            this.Controls.Add(this.txtCardNumber);
            this.Controls.Add(this.labelControl13);
            this.Controls.Add(this.labelControl14);
            this.Controls.Add(this.txtMonthAge);
            this.Controls.Add(this.labelControl15);
            this.Controls.Add(this.labelControl45);
            this.Controls.Add(this.txtWeight);
            this.Controls.Add(this.labelControl46);
            this.Controls.Add(this.labelControl47);
            this.Controls.Add(this.labelControl48);
            this.Controls.Add(this.txtInWeight);
            this.Controls.Add(this.labelControl49);
            this.Controls.Add(this.lueCSD_CityID);
            this.Controls.Add(this.labelControl50);
            this.Controls.Add(this.lueCSD_DistrictID);
            this.Controls.Add(this.labelControl51);
            this.Controls.Add(this.lueJG_ProvinceID);
            this.Controls.Add(this.lueJG_CityID);
            this.Controls.Add(this.labelControl52);
            this.Controls.Add(this.labelControl53);
            this.Controls.Add(this.labelControl54);
            this.Controls.Add(this.lueXZZ_ProvinceID);
            this.Controls.Add(this.lueXZZ_CityID);
            this.Controls.Add(this.lueXZZ_DistrictID);
            this.Controls.Add(this.labelControl55);
            this.Controls.Add(this.labelControl56);
            this.Controls.Add(this.labelControl57);
            this.Controls.Add(this.labelControl58);
            this.Controls.Add(this.lueHKDZ_ProvinceID);
            this.Controls.Add(this.lueHKDZ_CityID);
            this.Controls.Add(this.lueHKDZ_DistrictID);
            this.Controls.Add(this.labelControl59);
            this.Controls.Add(this.labelControl60);
            this.Controls.Add(this.labelControl61);
            this.Controls.Add(this.txtHKDZ_Post);
            this.Controls.Add(this.labelControl62);
            this.Controls.Add(this.txtOfficeTEL);
            this.Controls.Add(this.labelControl63);
            this.Controls.Add(this.txtOfficePost);
            this.Controls.Add(this.labelControl64);
            this.Controls.Add(this.labelControl65);
            this.Controls.Add(this.chkInHosType1);
            this.Controls.Add(this.chkInHosType2);
            this.Controls.Add(this.chkInHosType3);
            this.Controls.Add(this.chkInHosType4);
            this.Controls.Add(this.textEdit3);
            this.Controls.Add(this.labelControl37);
            this.Controls.Add(this.labelControl36);
            this.Controls.Add(this.labelControl34);
            this.Controls.Add(this.labelControl33);
            this.Controls.Add(this.labelControl32);
            this.Controls.Add(this.labelControl24);
            this.Controls.Add(this.chkMandZ0);
            this.Controls.Add(this.chkMandZ1);
            this.Controls.Add(this.chkMandZ2);
            this.Controls.Add(this.chkMandZ3);
            this.Controls.Add(this.chkRandC0);
            this.Controls.Add(this.chkRandC1);
            this.Controls.Add(this.chkRandC2);
            this.Controls.Add(this.chkRandC3);
            this.Controls.Add(this.chkSqAndSh0);
            this.Controls.Add(this.chkSqAndSh1);
            this.Controls.Add(this.chkSqAndSh2);
            this.Controls.Add(this.chkSqAndSh3);
            this.Controls.Add(this.chkLandB0);
            this.Controls.Add(this.chkLandB1);
            this.Controls.Add(this.chkLandB2);
            this.Controls.Add(this.chkLandB3);
            this.Controls.Add(this.chkRThree0);
            this.Controls.Add(this.chkRThree1);
            this.Controls.Add(this.chkRThree2);
            this.Controls.Add(this.chkRThree3);
            this.Controls.Add(this.chkFandB0);
            this.Controls.Add(this.chkFandB1);
            this.Controls.Add(this.chkFandB2);
            this.Controls.Add(this.chkFandB3);
            this.Controls.Add(this.txt_newXZZAddress);
            this.Name = "UCIemBasInfo";
            this.Size = new System.Drawing.Size(704, 511);
            this.Load += new System.EventHandler(this.UCIemBasInfo_Load);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.UCIemBasInfo_Paint);
            ((System.ComponentModel.ISupportInitialize)(this.deBirth.Properties.VistaTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.deBirth.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.seActualDays.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.seInCount.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.teOutWardDate.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.deOutWardDate.Properties.VistaTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.deOutWardDate.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.teAdmitDate.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.deAdmitDate.Properties.VistaTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.deAdmitDate.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtContactTEL.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtContactAddress.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtContactPerson.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtXZZ_Post.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtXZZ_TEL.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtOfficePlace.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtIDNO.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSocialCare.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtName.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPatNoOfHis.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCardNumber.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMonthAge.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtWeight.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtInWeight.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtHKDZ_Post.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtOfficeTEL.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtOfficePost.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkInHosType1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkInHosType2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkInHosType3.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkInHosType4.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit3.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkAdmitInfo1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkAdmitInfo2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkAdmitInfo3.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkAdmitInfo4.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtXZZAddress.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtHKZZAddress.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkFandB3.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkFandB2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkFandB1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkFandB0.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkRThree3.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkRThree2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkRThree1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkRThree0.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkLandB3.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkLandB2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkLandB1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkLandB0.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkSqAndSh3.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkSqAndSh2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkSqAndSh1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkSqAndSh0.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkRandC3.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkRandC2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkRandC1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkRandC0.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkMandZ3.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkMandZ2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkMandZ1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkMandZ0.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtAge.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEditOrganizationCode.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCSDAddress.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtJGAddress.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_newXZZAddress.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_newHKDZAddress.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueOutHosWard)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueOutHosDept)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueTransAdmitDept)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueAdmitWard)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueAdmitDept)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueRelationship)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueNationality)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueNation)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueCSD_ProvinceID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.luePayId)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueMarital)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookUpWindowMarital)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueJob)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueSex)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueCSD_CityID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueCSD_DistrictID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueJG_ProvinceID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueJG_CityID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueXZZ_ProvinceID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueXZZ_CityID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueXZZ_DistrictID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueHKDZ_ProvinceID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueHKDZ_CityID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueHKDZ_DistrictID)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevExpress.XtraEditors.LabelControl labelControl38;
        private DevExpress.XtraEditors.LabelControl labelControl39;
        private DrectSoft.Common.Library.LookUpEditor lueOutHosWard;
        private DevExpress.XtraEditors.LabelControl labelControl40;
        private DrectSoft.Common.Library.LookUpEditor lueOutHosDept;
        private DevExpress.XtraEditors.LabelControl labelControl41;
        private DevExpress.XtraEditors.TimeEdit teOutWardDate;
        private DevExpress.XtraEditors.DateEdit deOutWardDate;
        private DevExpress.XtraEditors.LabelControl labelControl42;
        private DrectSoft.Common.Library.LookUpEditor lueTransAdmitDept;
        private DevExpress.XtraEditors.LabelControl labelControl35;
        private DrectSoft.Common.Library.LookUpEditor lueAdmitWard;
        private DevExpress.XtraEditors.LabelControl labelControl31;
        private DrectSoft.Common.Library.LookUpEditor lueAdmitDept;
        private DevExpress.XtraEditors.LabelControl labelControl30;
        private DevExpress.XtraEditors.TimeEdit teAdmitDate;
        private DevExpress.XtraEditors.DateEdit deAdmitDate;
        private DevExpress.XtraEditors.LabelControl labelControl29;
        private DevExpress.XtraEditors.TextEdit txtContactTEL;
        private DevExpress.XtraEditors.LabelControl labelControl28;
        private DevExpress.XtraEditors.TextEdit txtContactAddress;
        private DevExpress.XtraEditors.LabelControl labelControl27;
        private DrectSoft.Common.Library.LookUpEditor lueRelationship;
        private DevExpress.XtraEditors.LabelControl labelControl26;
        private DevExpress.XtraEditors.TextEdit txtContactPerson;
        private DevExpress.XtraEditors.LabelControl labelControl25;
        private DevExpress.XtraEditors.LabelControl labelControl22;
        private DevExpress.XtraEditors.TextEdit txtXZZ_Post;
        private DevExpress.XtraEditors.LabelControl labelControl21;
        private DevExpress.XtraEditors.TextEdit txtXZZ_TEL;
        private DevExpress.XtraEditors.LabelControl labelControl20;
        private DevExpress.XtraEditors.TextEdit txtOfficePlace;
        private DevExpress.XtraEditors.LabelControl labelControl19;
        private DevExpress.XtraEditors.TextEdit txtIDNO;
        private DevExpress.XtraEditors.LabelControl labelControl18;
        private DrectSoft.Common.Library.LookUpEditor lueNationality;
        private DevExpress.XtraEditors.LabelControl labelControl17;
        private DrectSoft.Common.Library.LookUpEditor lueNation;
        private DevExpress.XtraEditors.LabelControl labelControl16;
        private DrectSoft.Common.Library.LookUpEditor lueCSD_ProvinceID;
        private DevExpress.XtraEditors.LabelControl labelControl12;
        private DevExpress.XtraEditors.LabelControl labelControl11;
        private DevExpress.XtraEditors.LabelControl labelControl10;
        private DevExpress.XtraEditors.LabelControl labelControl9;
        private DevExpress.XtraEditors.LabelControl labelControl8;
        private DevExpress.XtraEditors.LabelControl labelControl7;
        private DevExpress.XtraEditors.TextEdit txtSocialCare;
        private DevExpress.XtraEditors.LabelControl labelControl6;
        private DevExpress.XtraEditors.LabelControl labelControl4;
        private DevExpress.XtraEditors.LabelControl labelControl3;
        private DevExpress.XtraEditors.TextEdit txtName;
        private DevExpress.XtraEditors.LabelControl labelControl2;
        private DevExpress.XtraEditors.TextEdit txtPatNoOfHis;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private DrectSoft.Common.Library.LookUpEditor luePayId;
        private DevExpress.XtraEditors.SpinEdit seInCount;
        private DrectSoft.Common.Library.LookUpEditor lueMarital;
        private DrectSoft.Common.Library.LookUpEditor lueJob;
        private DrectSoft.Common.Library.LookUpEditor lueSex;
        private DevExpress.XtraEditors.SpinEdit seActualDays;
        private DevExpress.XtraEditors.DateEdit deBirth;
        private HLineEx hLineEx1;
        private DevExpress.XtraEditors.LabelControl labelLogoName;
        private DevExpress.XtraEditors.LabelControl txt_hospitalName;
        private DevExpress.XtraEditors.SimpleButton simpleButton1;
        private DevExpress.XtraEditors.LabelControl labelControl5;
        private DevExpress.XtraEditors.TextEdit txtCardNumber;
        private DevExpress.XtraEditors.LabelControl labelControl13;
        private DevExpress.XtraEditors.LabelControl labelControl14;
        private DevExpress.XtraEditors.TextEdit txtMonthAge;
        private DevExpress.XtraEditors.LabelControl labelControl15;
        private DevExpress.XtraEditors.LabelControl labelControl45;
        private DevExpress.XtraEditors.TextEdit txtWeight;
        private DevExpress.XtraEditors.LabelControl labelControl46;
        private DevExpress.XtraEditors.LabelControl labelControl47;
        private DevExpress.XtraEditors.LabelControl labelControl48;
        private DevExpress.XtraEditors.TextEdit txtInWeight;
        private DevExpress.XtraEditors.LabelControl labelControl49;
        private Common.Library.LookUpEditor lueCSD_CityID;
        private DevExpress.XtraEditors.LabelControl labelControl50;
        private Common.Library.LookUpEditor lueCSD_DistrictID;
        private DevExpress.XtraEditors.LabelControl labelControl51;
        private Common.Library.LookUpEditor lueJG_ProvinceID;
        private Common.Library.LookUpEditor lueJG_CityID;
        private DevExpress.XtraEditors.LabelControl labelControl52;
        private DevExpress.XtraEditors.LabelControl labelControl53;
        private DevExpress.XtraEditors.LabelControl labelControl54;
        private Common.Library.LookUpEditor lueXZZ_ProvinceID;
        private Common.Library.LookUpEditor lueXZZ_CityID;
        private Common.Library.LookUpEditor lueXZZ_DistrictID;
        private DevExpress.XtraEditors.LabelControl labelControl55;
        private DevExpress.XtraEditors.LabelControl labelControl56;
        private DevExpress.XtraEditors.LabelControl labelControl57;
        private DevExpress.XtraEditors.LabelControl labelControl58;
        private Common.Library.LookUpEditor lueHKDZ_ProvinceID;
        private Common.Library.LookUpEditor lueHKDZ_CityID;
        private Common.Library.LookUpEditor lueHKDZ_DistrictID;
        private DevExpress.XtraEditors.LabelControl labelControl59;
        private DevExpress.XtraEditors.LabelControl labelControl60;
        private DevExpress.XtraEditors.LabelControl labelControl61;
        private DevExpress.XtraEditors.TextEdit txtHKDZ_Post;
        private DevExpress.XtraEditors.LabelControl labelControl62;
        private DevExpress.XtraEditors.TextEdit txtOfficeTEL;
        private DevExpress.XtraEditors.LabelControl labelControl63;
        private DevExpress.XtraEditors.TextEdit txtOfficePost;
        private DevExpress.XtraEditors.LabelControl labelControl64;
        private DevExpress.XtraEditors.LabelControl labelControl65;
        private DevExpress.XtraEditors.CheckEdit chkInHosType1;
        private DevExpress.XtraEditors.CheckEdit chkInHosType2;
        private DevExpress.XtraEditors.CheckEdit chkInHosType3;
        private DevExpress.XtraEditors.CheckEdit chkInHosType4;
        private DevExpress.XtraEditors.TextEdit textEdit3;
        private DevExpress.XtraEditors.LabelControl labelControl23;
        private DevExpress.XtraEditors.CheckEdit chkAdmitInfo1;
        private DevExpress.XtraEditors.CheckEdit chkAdmitInfo2;
        private DevExpress.XtraEditors.CheckEdit chkAdmitInfo3;
        private DevExpress.XtraEditors.CheckEdit chkAdmitInfo4;
        private DevExpress.XtraEditors.TextEdit txtXZZAddress;
        private DevExpress.XtraEditors.TextEdit txtHKZZAddress;
        private DevExpress.XtraEditors.CheckEdit chkFandB3;
        private DevExpress.XtraEditors.CheckEdit chkFandB2;
        private DevExpress.XtraEditors.CheckEdit chkFandB1;
        private DevExpress.XtraEditors.CheckEdit chkFandB0;
        private DevExpress.XtraEditors.LabelControl labelControl24;
        private DevExpress.XtraEditors.CheckEdit chkRThree3;
        private DevExpress.XtraEditors.CheckEdit chkRThree2;
        private DevExpress.XtraEditors.CheckEdit chkRThree1;
        private DevExpress.XtraEditors.CheckEdit chkRThree0;
        private DevExpress.XtraEditors.LabelControl labelControl32;
        private DevExpress.XtraEditors.CheckEdit chkLandB3;
        private DevExpress.XtraEditors.CheckEdit chkLandB2;
        private DevExpress.XtraEditors.CheckEdit chkLandB1;
        private DevExpress.XtraEditors.CheckEdit chkLandB0;
        private DevExpress.XtraEditors.LabelControl labelControl33;
        private DevExpress.XtraEditors.CheckEdit chkSqAndSh3;
        private DevExpress.XtraEditors.CheckEdit chkSqAndSh2;
        private DevExpress.XtraEditors.CheckEdit chkSqAndSh1;
        private DevExpress.XtraEditors.CheckEdit chkSqAndSh0;
        private DevExpress.XtraEditors.LabelControl labelControl34;
        private DevExpress.XtraEditors.CheckEdit chkRandC3;
        private DevExpress.XtraEditors.CheckEdit chkRandC2;
        private DevExpress.XtraEditors.CheckEdit chkRandC1;
        private DevExpress.XtraEditors.CheckEdit chkRandC0;
        private DevExpress.XtraEditors.LabelControl labelControl36;
        private DevExpress.XtraEditors.CheckEdit chkMandZ3;
        private DevExpress.XtraEditors.CheckEdit chkMandZ2;
        private DevExpress.XtraEditors.CheckEdit chkMandZ1;
        private DevExpress.XtraEditors.CheckEdit chkMandZ0;
        private DevExpress.XtraEditors.LabelControl labelControl37;
        private DevExpress.XtraEditors.TextEdit txtAge;
        private DevExpress.XtraEditors.TextEdit textEditOrganizationCode;
        private System.Windows.Forms.ErrorProvider errorProvider;
        private DrectSoft.Common.Ctrs.OTHER.DevButtonClose btn_Close;
        private DrectSoft.Common.Ctrs.OTHER.DevButtonOK btn_OK;
        private DevExpress.XtraEditors.LabelControl lbl_hostName;
        private DevExpress.XtraEditors.LabelControl lbl_title;
        private DevExpress.XtraEditors.TextEdit txtCSDAddress;
        private DevExpress.XtraEditors.TextEdit txtJGAddress;
        private Common.Library.LookUpWindow lookUpWindowMarital;
        private DevExpress.XtraEditors.TextEdit txt_newHKDZAddress;
        private DevExpress.XtraEditors.TextEdit txt_newXZZAddress;
        private DevExpress.XtraEditors.LabelControl labelControl43;
    }
}
