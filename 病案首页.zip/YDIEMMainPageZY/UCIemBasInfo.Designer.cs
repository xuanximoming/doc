﻿namespace DrectSoft.Core.IEMMainPageZY
{
    partial class UCIemBasInfo
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UCIemBasInfo));
            this.labelControl38 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl39 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl40 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl41 = new DevExpress.XtraEditors.LabelControl();
            this.teOutWardDate = new DevExpress.XtraEditors.TimeEdit();
            this.labelControl42 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl35 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl31 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl30 = new DevExpress.XtraEditors.LabelControl();
            this.teAdmitDate = new DevExpress.XtraEditors.TimeEdit();
            this.labelControl29 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl28 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl27 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl26 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl25 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl22 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl21 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl20 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl19 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl18 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl17 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl16 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl12 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl11 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl10 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl9 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl8 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl7 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl6 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl4 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl3 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.labelLogoName = new DevExpress.XtraEditors.LabelControl();
            this.labelHospitalName = new DevExpress.XtraEditors.LabelControl();
            this.simpleButton1 = new DevExpress.XtraEditors.SimpleButton();
            this.labelControl5 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl13 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl14 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl15 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl45 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl46 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl47 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl48 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl49 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl50 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl51 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl52 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl53 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl54 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl55 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl56 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl57 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl58 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl59 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl60 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl61 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl62 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl63 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl64 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl65 = new DevExpress.XtraEditors.LabelControl();
            this.chkInHosType1 = new DrectSoft.Common.Ctrs.OTHER.DSCheckEdit();
            this.chkInHosType2 = new DrectSoft.Common.Ctrs.OTHER.DSCheckEdit();
            this.chkInHosType3 = new DrectSoft.Common.Ctrs.OTHER.DSCheckEdit();
            this.chkInHosType4 = new DrectSoft.Common.Ctrs.OTHER.DSCheckEdit();
            this.chkCURE_TYPE4 = new DrectSoft.Common.Ctrs.OTHER.DSCheckEdit();
            this.chkCURE_TYPE3 = new DrectSoft.Common.Ctrs.OTHER.DSCheckEdit();
            this.chkCURE_TYPE2 = new DrectSoft.Common.Ctrs.OTHER.DSCheckEdit();
            this.chkCURE_TYPE1 = new DrectSoft.Common.Ctrs.OTHER.DSCheckEdit();
            this.labelControl23 = new DevExpress.XtraEditors.LabelControl();
            this.chkCURE_TYPE5 = new DrectSoft.Common.Ctrs.OTHER.DSCheckEdit();
            this.labelControl24 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl32 = new DevExpress.XtraEditors.LabelControl();
            this.chkSSLCLJ2 = new DrectSoft.Common.Ctrs.OTHER.DSCheckEdit();
            this.chkSSLCLJ1 = new DrectSoft.Common.Ctrs.OTHER.DSCheckEdit();
            this.chkSSLCLJ3 = new DrectSoft.Common.Ctrs.OTHER.DSCheckEdit();
            this.labelControl33 = new DevExpress.XtraEditors.LabelControl();
            this.chkZYZJ1 = new DrectSoft.Common.Ctrs.OTHER.DSCheckEdit();
            this.chkZYZJ2 = new DrectSoft.Common.Ctrs.OTHER.DSCheckEdit();
            this.labelControl34 = new DevExpress.XtraEditors.LabelControl();
            this.chkZYZLSB1 = new DrectSoft.Common.Ctrs.OTHER.DSCheckEdit();
            this.chkZYZLSB2 = new DrectSoft.Common.Ctrs.OTHER.DSCheckEdit();
            this.chkZYZLJS1 = new DrectSoft.Common.Ctrs.OTHER.DSCheckEdit();
            this.chkZYZLJS2 = new DrectSoft.Common.Ctrs.OTHER.DSCheckEdit();
            this.labelControl36 = new DevExpress.XtraEditors.LabelControl();
            this.chkBZSH1 = new DrectSoft.Common.Ctrs.OTHER.DSCheckEdit();
            this.chkBZSH2 = new DrectSoft.Common.Ctrs.OTHER.DSCheckEdit();
            this.labelControl37 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl43 = new DevExpress.XtraEditors.LabelControl();
            this.lueMZXYZD_CODE1 = new DrectSoft.Common.Library.LookUpEditor();
            this.lueOutHosWard = new DrectSoft.Common.Library.LookUpEditor();
            this.lueOutHosDept = new DrectSoft.Common.Library.LookUpEditor();
            this.lueTransAdmitDept = new DrectSoft.Common.Library.LookUpEditor();
            this.lueAdmitWard = new DrectSoft.Common.Library.LookUpEditor();
            this.lueAdmitDept = new DrectSoft.Common.Library.LookUpEditor();
            this.lueMZZYZD_CODE1 = new DrectSoft.Common.Library.LookUpEditor();
            this.lueRelationship = new DrectSoft.Common.Library.LookUpEditor();
            this.lueNationality = new DrectSoft.Common.Library.LookUpEditor();
            this.lueNation = new DrectSoft.Common.Library.LookUpEditor();
            this.lueCSD_ProvinceID = new DrectSoft.Common.Library.LookUpEditor();
            this.luePayId = new DrectSoft.Common.Library.LookUpEditor();
            this.lueMarital = new DrectSoft.Common.Library.LookUpEditor();
            this.lueJob = new DrectSoft.Common.Library.LookUpEditor();
            this.lueSex = new DrectSoft.Common.Library.LookUpEditor();
            this.lueCSD_CityID = new DrectSoft.Common.Library.LookUpEditor();
            this.lueCSD_DistrictID = new DrectSoft.Common.Library.LookUpEditor();
            this.lueJG_ProvinceID = new DrectSoft.Common.Library.LookUpEditor();
            this.lueJG_CityID = new DrectSoft.Common.Library.LookUpEditor();
            this.lueXZZ_ProvinceID = new DrectSoft.Common.Library.LookUpEditor();
            this.lueXZZ_CityID = new DrectSoft.Common.Library.LookUpEditor();
            this.lueXZZ_DistrictID = new DrectSoft.Common.Library.LookUpEditor();
            this.lueHKDZ_ProvinceID = new DrectSoft.Common.Library.LookUpEditor();
            this.lueHKDZ_CityID = new DrectSoft.Common.Library.LookUpEditor();
            this.lueHKDZ_DistrictID = new DrectSoft.Common.Library.LookUpEditor();
            this.seActualDays = new DrectSoft.Common.Ctrs.OTHER.DSSpinEdit();
            this.deBirth = new DrectSoft.Common.Ctrs.OTHER.DSDateEdit();
            this.seInCount = new DrectSoft.Common.Ctrs.OTHER.DSSpinEdit();
            this.DevButtonSave1 = new DrectSoft.Common.Ctrs.OTHER.DevButtonSave();
            this.btnClose = new DrectSoft.Common.Ctrs.OTHER.DevButtonClose();
            this.lueMZXYZD_CODE = new DevTextBoxAndButton.Bwj();
            this.lueMZZYZD_CODE = new DevTextBoxAndButton.Bwj();
            this.deOutWardDate = new DrectSoft.Common.Ctrs.OTHER.DSDateEdit();
            this.deAdmitDate = new DrectSoft.Common.Ctrs.OTHER.DSDateEdit();
            this.txtContactAddress = new DrectSoft.Common.Ctrs.OTHER.DSTextBox();
            this.txtContactPerson = new DrectSoft.Common.Ctrs.OTHER.DSTextBox();
            this.txtOfficePlace = new DrectSoft.Common.Ctrs.OTHER.DSTextBox();
            this.txtIDNO = new DrectSoft.Common.Ctrs.OTHER.DSTextBox();
            this.txtSocialCare = new DrectSoft.Common.Ctrs.OTHER.DSTextBox();
            this.txtName = new DrectSoft.Common.Ctrs.OTHER.DSTextBox();
            this.txtPatNoOfHis = new DrectSoft.Common.Ctrs.OTHER.DSTextBox();
            this.txtAge = new DrectSoft.Common.Ctrs.OTHER.DSTextBox();
            this.txtCardNumber = new DrectSoft.Common.Ctrs.OTHER.DSTextBox();
            this.txtMonthAge = new DrectSoft.Common.Ctrs.OTHER.DSTextBox();
            this.txtWeight = new DrectSoft.Common.Ctrs.OTHER.DSTextBox();
            this.txtInWeight = new DrectSoft.Common.Ctrs.OTHER.DSTextBox();
            this.textEdit3 = new DrectSoft.Common.Ctrs.OTHER.DSTextBox();
            this.txtOfficeTEL = new DrectSoft.Common.Ctrs.OTHER.DevTextEditTel();
            this.txtXZZ_TEL = new DrectSoft.Common.Ctrs.OTHER.DevTextEditTel();
            this.txtContactTEL = new DrectSoft.Common.Ctrs.OTHER.DevTextEditTel();
            this.txtXZZ_Post = new DrectSoft.Common.Ctrs.OTHER.DevTextEditPost();
            this.txtHKDZ_Post = new DrectSoft.Common.Ctrs.OTHER.DevTextEditPost();
            this.txtOfficePost = new DrectSoft.Common.Ctrs.OTHER.DevTextEditPost();
            this.hLineEx1 = new DrectSoft.Core.IEMMainPageZY.HLineEx();
            ((System.ComponentModel.ISupportInitialize)(this.teOutWardDate.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.teAdmitDate.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkInHosType1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkInHosType2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkInHosType3.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkInHosType4.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCURE_TYPE4.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCURE_TYPE3.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCURE_TYPE2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCURE_TYPE1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCURE_TYPE5.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkSSLCLJ2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkSSLCLJ1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkSSLCLJ3.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkZYZJ1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkZYZJ2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkZYZLSB1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkZYZLSB2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkZYZLJS1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkZYZLJS2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkBZSH1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkBZSH2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueMZXYZD_CODE1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueOutHosWard)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueOutHosDept)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueTransAdmitDept)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueAdmitWard)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueAdmitDept)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueMZZYZD_CODE1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueRelationship)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueNationality)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueNation)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueCSD_ProvinceID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.luePayId)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueMarital)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueJob)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueSex)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueCSD_CityID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueCSD_DistrictID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueJG_ProvinceID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueJG_CityID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueXZZ_ProvinceID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueXZZ_CityID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueXZZ_DistrictID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueHKDZ_ProvinceID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueHKDZ_CityID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueHKDZ_DistrictID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.seActualDays.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.deBirth.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.deBirth.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.seInCount.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.deOutWardDate.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.deOutWardDate.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.deAdmitDate.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.deAdmitDate.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtContactAddress.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtContactPerson.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtOfficePlace.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtIDNO.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSocialCare.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtName.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPatNoOfHis.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtAge.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCardNumber.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMonthAge.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtWeight.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtInWeight.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit3.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtOfficeTEL.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtXZZ_TEL.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtContactTEL.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtXZZ_Post.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtHKDZ_Post.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtOfficePost.Properties)).BeginInit();
            this.SuspendLayout();
            // 
            // labelControl38
            // 
            this.labelControl38.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl38.Location = new System.Drawing.Point(722, 454);
            this.labelControl38.Name = "labelControl38";
            this.labelControl38.Size = new System.Drawing.Size(12, 14);
            this.labelControl38.TabIndex = 80;
            this.labelControl38.Text = "天";
            // 
            // labelControl39
            // 
            this.labelControl39.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl39.Location = new System.Drawing.Point(577, 454);
            this.labelControl39.Name = "labelControl39";
            this.labelControl39.Size = new System.Drawing.Size(48, 14);
            this.labelControl39.TabIndex = 78;
            this.labelControl39.Text = "实际住院";
            // 
            // labelControl40
            // 
            this.labelControl40.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl40.Location = new System.Drawing.Point(434, 454);
            this.labelControl40.Name = "labelControl40";
            this.labelControl40.Size = new System.Drawing.Size(24, 14);
            this.labelControl40.TabIndex = 76;
            this.labelControl40.Text = "病区";
            // 
            // labelControl41
            // 
            this.labelControl41.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl41.Location = new System.Drawing.Point(252, 454);
            this.labelControl41.Name = "labelControl41";
            this.labelControl41.Size = new System.Drawing.Size(48, 14);
            this.labelControl41.TabIndex = 74;
            this.labelControl41.Text = "出院科别";
            // 
            // teOutWardDate
            // 
            this.teOutWardDate.EditValue = new System.DateTime(2011, 3, 5, 0, 0, 0, 0);
            this.teOutWardDate.EnterMoveNextControl = true;
            this.teOutWardDate.Location = new System.Drawing.Point(181, 452);
            this.teOutWardDate.Name = "teOutWardDate";
            this.teOutWardDate.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.teOutWardDate.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.teOutWardDate.Properties.Mask.EditMask = "HH:mm";
            this.teOutWardDate.Size = new System.Drawing.Size(57, 18);
            this.teOutWardDate.TabIndex = 52;
            // 
            // labelControl42
            // 
            this.labelControl42.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl42.Location = new System.Drawing.Point(16, 454);
            this.labelControl42.Name = "labelControl42";
            this.labelControl42.Size = new System.Drawing.Size(48, 14);
            this.labelControl42.TabIndex = 72;
            this.labelControl42.Text = "出院日期";
            // 
            // labelControl35
            // 
            this.labelControl35.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl35.Location = new System.Drawing.Point(577, 421);
            this.labelControl35.Name = "labelControl35";
            this.labelControl35.Size = new System.Drawing.Size(48, 14);
            this.labelControl35.TabIndex = 66;
            this.labelControl35.Text = "转入科别";
            // 
            // labelControl31
            // 
            this.labelControl31.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl31.Location = new System.Drawing.Point(434, 421);
            this.labelControl31.Name = "labelControl31";
            this.labelControl31.Size = new System.Drawing.Size(24, 14);
            this.labelControl31.TabIndex = 59;
            this.labelControl31.Text = "病区";
            // 
            // labelControl30
            // 
            this.labelControl30.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl30.Location = new System.Drawing.Point(252, 421);
            this.labelControl30.Name = "labelControl30";
            this.labelControl30.Size = new System.Drawing.Size(48, 14);
            this.labelControl30.TabIndex = 57;
            this.labelControl30.Text = "入院科别";
            // 
            // teAdmitDate
            // 
            this.teAdmitDate.EditValue = new System.DateTime(2011, 3, 5, 0, 0, 0, 0);
            this.teAdmitDate.EnterMoveNextControl = true;
            this.teAdmitDate.Location = new System.Drawing.Point(181, 419);
            this.teAdmitDate.Name = "teAdmitDate";
            this.teAdmitDate.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.teAdmitDate.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.teAdmitDate.Properties.Mask.EditMask = "HH:mm";
            this.teAdmitDate.Size = new System.Drawing.Size(57, 18);
            this.teAdmitDate.TabIndex = 47;
            // 
            // labelControl29
            // 
            this.labelControl29.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl29.Location = new System.Drawing.Point(16, 421);
            this.labelControl29.Name = "labelControl29";
            this.labelControl29.Size = new System.Drawing.Size(48, 14);
            this.labelControl29.TabIndex = 53;
            this.labelControl29.Text = "入院日期";
            // 
            // labelControl28
            // 
            this.labelControl28.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl28.Location = new System.Drawing.Point(590, 329);
            this.labelControl28.Name = "labelControl28";
            this.labelControl28.Size = new System.Drawing.Size(24, 14);
            this.labelControl28.TabIndex = 51;
            this.labelControl28.Text = "电话";
            // 
            // labelControl27
            // 
            this.labelControl27.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl27.Location = new System.Drawing.Point(337, 329);
            this.labelControl27.Name = "labelControl27";
            this.labelControl27.Size = new System.Drawing.Size(24, 14);
            this.labelControl27.TabIndex = 49;
            this.labelControl27.Text = "地址";
            // 
            // labelControl26
            // 
            this.labelControl26.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl26.Location = new System.Drawing.Point(192, 329);
            this.labelControl26.Name = "labelControl26";
            this.labelControl26.Size = new System.Drawing.Size(24, 14);
            this.labelControl26.TabIndex = 47;
            this.labelControl26.Text = "关系";
            // 
            // labelControl25
            // 
            this.labelControl25.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl25.Location = new System.Drawing.Point(16, 329);
            this.labelControl25.Name = "labelControl25";
            this.labelControl25.Size = new System.Drawing.Size(60, 14);
            this.labelControl25.TabIndex = 117;
            this.labelControl25.Text = "联系人姓名";
            // 
            // labelControl22
            // 
            this.labelControl22.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl22.Location = new System.Drawing.Point(16, 267);
            this.labelControl22.Name = "labelControl22";
            this.labelControl22.Size = new System.Drawing.Size(48, 14);
            this.labelControl22.TabIndex = 118;
            this.labelControl22.Text = "户口地址";
            // 
            // labelControl21
            // 
            this.labelControl21.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl21.Location = new System.Drawing.Point(610, 238);
            this.labelControl21.Name = "labelControl21";
            this.labelControl21.Size = new System.Drawing.Size(48, 14);
            this.labelControl21.TabIndex = 119;
            this.labelControl21.Text = "邮政编码";
            // 
            // labelControl20
            // 
            this.labelControl20.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl20.Location = new System.Drawing.Point(475, 238);
            this.labelControl20.Name = "labelControl20";
            this.labelControl20.Size = new System.Drawing.Size(24, 14);
            this.labelControl20.TabIndex = 35;
            this.labelControl20.Text = "电话";
            // 
            // labelControl19
            // 
            this.labelControl19.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl19.Location = new System.Drawing.Point(16, 299);
            this.labelControl19.Name = "labelControl19";
            this.labelControl19.Size = new System.Drawing.Size(84, 14);
            this.labelControl19.TabIndex = 33;
            this.labelControl19.Text = "工作单位及地址";
            // 
            // labelControl18
            // 
            this.labelControl18.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl18.Location = new System.Drawing.Point(16, 209);
            this.labelControl18.Name = "labelControl18";
            this.labelControl18.Size = new System.Drawing.Size(48, 14);
            this.labelControl18.TabIndex = 120;
            this.labelControl18.Text = "身份证号";
            // 
            // labelControl17
            // 
            this.labelControl17.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl17.Location = new System.Drawing.Point(610, 128);
            this.labelControl17.Name = "labelControl17";
            this.labelControl17.Size = new System.Drawing.Size(24, 14);
            this.labelControl17.TabIndex = 121;
            this.labelControl17.Text = "国籍";
            // 
            // labelControl16
            // 
            this.labelControl16.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl16.Location = new System.Drawing.Point(601, 207);
            this.labelControl16.Name = "labelControl16";
            this.labelControl16.Size = new System.Drawing.Size(24, 14);
            this.labelControl16.TabIndex = 27;
            this.labelControl16.Text = "民族";
            // 
            // labelControl12
            // 
            this.labelControl12.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl12.Location = new System.Drawing.Point(16, 180);
            this.labelControl12.Name = "labelControl12";
            this.labelControl12.Size = new System.Drawing.Size(36, 14);
            this.labelControl12.TabIndex = 20;
            this.labelControl12.Text = "出生地";
            // 
            // labelControl11
            // 
            this.labelControl11.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl11.Location = new System.Drawing.Point(311, 209);
            this.labelControl11.Name = "labelControl11";
            this.labelControl11.Size = new System.Drawing.Size(24, 14);
            this.labelControl11.TabIndex = 122;
            this.labelControl11.Text = "职业";
            // 
            // labelControl10
            // 
            this.labelControl10.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl10.Location = new System.Drawing.Point(469, 207);
            this.labelControl10.Name = "labelControl10";
            this.labelControl10.Size = new System.Drawing.Size(24, 14);
            this.labelControl10.TabIndex = 112;
            this.labelControl10.Text = "婚姻";
            // 
            // labelControl9
            // 
            this.labelControl9.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl9.Location = new System.Drawing.Point(482, 129);
            this.labelControl9.Name = "labelControl9";
            this.labelControl9.Size = new System.Drawing.Size(24, 14);
            this.labelControl9.TabIndex = 14;
            this.labelControl9.Text = "年龄";
            // 
            // labelControl8
            // 
            this.labelControl8.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl8.Location = new System.Drawing.Point(279, 128);
            this.labelControl8.Name = "labelControl8";
            this.labelControl8.Size = new System.Drawing.Size(48, 14);
            this.labelControl8.TabIndex = 12;
            this.labelControl8.Text = "出生日期";
            // 
            // labelControl7
            // 
            this.labelControl7.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl7.Location = new System.Drawing.Point(163, 129);
            this.labelControl7.Name = "labelControl7";
            this.labelControl7.Size = new System.Drawing.Size(24, 14);
            this.labelControl7.TabIndex = 10;
            this.labelControl7.Text = "性别";
            // 
            // labelControl6
            // 
            this.labelControl6.Appearance.ForeColor = System.Drawing.Color.Red;
            this.labelControl6.Location = new System.Drawing.Point(27, 71);
            this.labelControl6.Name = "labelControl6";
            this.labelControl6.Size = new System.Drawing.Size(84, 14);
            this.labelControl6.TabIndex = 7;
            this.labelControl6.Text = "医疗付款方式：";
            // 
            // labelControl4
            // 
            this.labelControl4.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl4.Location = new System.Drawing.Point(446, 91);
            this.labelControl4.Name = "labelControl4";
            this.labelControl4.Size = new System.Drawing.Size(36, 14);
            this.labelControl4.TabIndex = 6;
            this.labelControl4.Text = "次入院";
            // 
            // labelControl3
            // 
            this.labelControl3.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl3.Location = new System.Drawing.Point(368, 91);
            this.labelControl3.Name = "labelControl3";
            this.labelControl3.Size = new System.Drawing.Size(12, 14);
            this.labelControl3.TabIndex = 4;
            this.labelControl3.Text = "第";
            // 
            // labelControl2
            // 
            this.labelControl2.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl2.Location = new System.Drawing.Point(16, 127);
            this.labelControl2.Name = "labelControl2";
            this.labelControl2.Size = new System.Drawing.Size(24, 14);
            this.labelControl2.TabIndex = 2;
            this.labelControl2.Text = "姓名";
            // 
            // labelControl1
            // 
            this.labelControl1.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl1.Location = new System.Drawing.Point(560, 91);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(48, 14);
            this.labelControl1.TabIndex = 0;
            this.labelControl1.Text = "病案号：";
            // 
            // labelLogoName
            // 
            this.labelLogoName.Appearance.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labelLogoName.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelLogoName.Location = new System.Drawing.Point(281, 46);
            this.labelLogoName.Name = "labelLogoName";
            this.labelLogoName.Size = new System.Drawing.Size(225, 33);
            this.labelLogoName.TabIndex = 111;
            this.labelLogoName.Text = "住 院 病 案 首 页";
            this.labelLogoName.Click += new System.EventHandler(this.labelLogoName_Click);
            // 
            // labelHospitalName
            // 
            this.labelHospitalName.Appearance.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labelHospitalName.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelHospitalName.Location = new System.Drawing.Point(337, 25);
            this.labelHospitalName.Name = "labelHospitalName";
            this.labelHospitalName.Size = new System.Drawing.Size(120, 16);
            this.labelHospitalName.TabIndex = 112;
            this.labelHospitalName.Text = "*******人民医院";
            // 
            // simpleButton1
            // 
            this.simpleButton1.ButtonStyle = DevExpress.XtraEditors.Controls.BorderStyles.Office2003;
            this.simpleButton1.Location = new System.Drawing.Point(694, 748);
            this.simpleButton1.Name = "simpleButton1";
            this.simpleButton1.Size = new System.Drawing.Size(10, 10);
            this.simpleButton1.TabIndex = 0;
            // 
            // labelControl5
            // 
            this.labelControl5.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl5.Location = new System.Drawing.Point(27, 91);
            this.labelControl5.Name = "labelControl5";
            this.labelControl5.Size = new System.Drawing.Size(60, 14);
            this.labelControl5.TabIndex = 4;
            this.labelControl5.Text = "健康卡号：";
            // 
            // labelControl13
            // 
            this.labelControl13.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl13.Location = new System.Drawing.Point(16, 154);
            this.labelControl13.Name = "labelControl13";
            this.labelControl13.Size = new System.Drawing.Size(115, 14);
            this.labelControl13.TabIndex = 2;
            this.labelControl13.Text = "（年龄不足1周岁的）";
            // 
            // labelControl14
            // 
            this.labelControl14.Appearance.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.labelControl14.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl14.Location = new System.Drawing.Point(131, 154);
            this.labelControl14.Name = "labelControl14";
            this.labelControl14.Size = new System.Drawing.Size(26, 14);
            this.labelControl14.TabIndex = 14;
            this.labelControl14.Text = "年龄";
            // 
            // labelControl15
            // 
            this.labelControl15.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl15.Location = new System.Drawing.Point(252, 154);
            this.labelControl15.Name = "labelControl15";
            this.labelControl15.Size = new System.Drawing.Size(12, 14);
            this.labelControl15.TabIndex = 14;
            this.labelControl15.Text = "月";
            // 
            // labelControl45
            // 
            this.labelControl45.Appearance.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.labelControl45.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl45.Location = new System.Drawing.Point(297, 154);
            this.labelControl45.Name = "labelControl45";
            this.labelControl45.Size = new System.Drawing.Size(91, 14);
            this.labelControl45.TabIndex = 12;
            this.labelControl45.Text = "新生儿出生体重";
            // 
            // labelControl46
            // 
            this.labelControl46.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl46.Location = new System.Drawing.Point(475, 154);
            this.labelControl46.Name = "labelControl46";
            this.labelControl46.Size = new System.Drawing.Size(12, 14);
            this.labelControl46.TabIndex = 14;
            this.labelControl46.Text = "克";
            // 
            // labelControl47
            // 
            this.labelControl47.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl47.Location = new System.Drawing.Point(722, 154);
            this.labelControl47.Name = "labelControl47";
            this.labelControl47.Size = new System.Drawing.Size(12, 14);
            this.labelControl47.TabIndex = 14;
            this.labelControl47.Text = "克";
            this.labelControl47.Click += new System.EventHandler(this.labelControl47_Click);
            // 
            // labelControl48
            // 
            this.labelControl48.Appearance.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.labelControl48.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl48.Location = new System.Drawing.Point(552, 154);
            this.labelControl48.Name = "labelControl48";
            this.labelControl48.Size = new System.Drawing.Size(91, 14);
            this.labelControl48.TabIndex = 12;
            this.labelControl48.Text = "新生儿入院体重";
            this.labelControl48.Click += new System.EventHandler(this.labelControl48_Click);
            // 
            // labelControl49
            // 
            this.labelControl49.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl49.Location = new System.Drawing.Point(158, 180);
            this.labelControl49.Name = "labelControl49";
            this.labelControl49.Size = new System.Drawing.Size(58, 14);
            this.labelControl49.TabIndex = 20;
            this.labelControl49.Text = "省(区、市)";
            // 
            // labelControl50
            // 
            this.labelControl50.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl50.Location = new System.Drawing.Point(311, 180);
            this.labelControl50.Name = "labelControl50";
            this.labelControl50.Size = new System.Drawing.Size(12, 14);
            this.labelControl50.TabIndex = 14;
            this.labelControl50.Text = "市";
            // 
            // labelControl51
            // 
            this.labelControl51.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl51.Location = new System.Drawing.Point(422, 180);
            this.labelControl51.Name = "labelControl51";
            this.labelControl51.Size = new System.Drawing.Size(12, 14);
            this.labelControl51.TabIndex = 14;
            this.labelControl51.Text = "县";
            // 
            // labelControl52
            // 
            this.labelControl52.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl52.Location = new System.Drawing.Point(440, 180);
            this.labelControl52.Name = "labelControl52";
            this.labelControl52.Size = new System.Drawing.Size(24, 14);
            this.labelControl52.TabIndex = 20;
            this.labelControl52.Text = "籍贯";
            // 
            // labelControl53
            // 
            this.labelControl53.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl53.Location = new System.Drawing.Point(571, 180);
            this.labelControl53.Name = "labelControl53";
            this.labelControl53.Size = new System.Drawing.Size(58, 14);
            this.labelControl53.TabIndex = 20;
            this.labelControl53.Text = "省(区、市)";
            // 
            // labelControl54
            // 
            this.labelControl54.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl54.Location = new System.Drawing.Point(722, 180);
            this.labelControl54.Name = "labelControl54";
            this.labelControl54.Size = new System.Drawing.Size(12, 14);
            this.labelControl54.TabIndex = 14;
            this.labelControl54.Text = "市";
            // 
            // labelControl55
            // 
            this.labelControl55.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl55.Location = new System.Drawing.Point(16, 238);
            this.labelControl55.Name = "labelControl55";
            this.labelControl55.Size = new System.Drawing.Size(36, 14);
            this.labelControl55.TabIndex = 20;
            this.labelControl55.Text = "现住址";
            // 
            // labelControl56
            // 
            this.labelControl56.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl56.Location = new System.Drawing.Point(162, 238);
            this.labelControl56.Name = "labelControl56";
            this.labelControl56.Size = new System.Drawing.Size(72, 14);
            this.labelControl56.TabIndex = 20;
            this.labelControl56.Text = "省（区、市）";
            // 
            // labelControl57
            // 
            this.labelControl57.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl57.Location = new System.Drawing.Point(333, 238);
            this.labelControl57.Name = "labelControl57";
            this.labelControl57.Size = new System.Drawing.Size(12, 14);
            this.labelControl57.TabIndex = 14;
            this.labelControl57.Text = "市";
            // 
            // labelControl58
            // 
            this.labelControl58.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl58.Location = new System.Drawing.Point(453, 238);
            this.labelControl58.Name = "labelControl58";
            this.labelControl58.Size = new System.Drawing.Size(12, 14);
            this.labelControl58.TabIndex = 14;
            this.labelControl58.Text = "县";
            // 
            // labelControl59
            // 
            this.labelControl59.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl59.Location = new System.Drawing.Point(209, 267);
            this.labelControl59.Name = "labelControl59";
            this.labelControl59.Size = new System.Drawing.Size(72, 14);
            this.labelControl59.TabIndex = 20;
            this.labelControl59.Text = "省（区、市）";
            // 
            // labelControl60
            // 
            this.labelControl60.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl60.Location = new System.Drawing.Point(402, 267);
            this.labelControl60.Name = "labelControl60";
            this.labelControl60.Size = new System.Drawing.Size(12, 14);
            this.labelControl60.TabIndex = 14;
            this.labelControl60.Text = "市";
            // 
            // labelControl61
            // 
            this.labelControl61.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl61.Location = new System.Drawing.Point(553, 267);
            this.labelControl61.Name = "labelControl61";
            this.labelControl61.Size = new System.Drawing.Size(12, 14);
            this.labelControl61.TabIndex = 14;
            this.labelControl61.Text = "县";
            // 
            // labelControl62
            // 
            this.labelControl62.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl62.Location = new System.Drawing.Point(581, 267);
            this.labelControl62.Name = "labelControl62";
            this.labelControl62.Size = new System.Drawing.Size(48, 14);
            this.labelControl62.TabIndex = 123;
            this.labelControl62.Text = "邮政编码";
            // 
            // labelControl63
            // 
            this.labelControl63.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl63.Location = new System.Drawing.Point(369, 299);
            this.labelControl63.Name = "labelControl63";
            this.labelControl63.Size = new System.Drawing.Size(48, 14);
            this.labelControl63.TabIndex = 35;
            this.labelControl63.Text = "单位电话";
            // 
            // labelControl64
            // 
            this.labelControl64.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl64.Location = new System.Drawing.Point(581, 302);
            this.labelControl64.Name = "labelControl64";
            this.labelControl64.Size = new System.Drawing.Size(48, 14);
            this.labelControl64.TabIndex = 124;
            this.labelControl64.Text = "邮政编码";
            // 
            // labelControl65
            // 
            this.labelControl65.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl65.Location = new System.Drawing.Point(16, 361);
            this.labelControl65.Name = "labelControl65";
            this.labelControl65.Size = new System.Drawing.Size(48, 14);
            this.labelControl65.TabIndex = 132;
            this.labelControl65.Text = "入院途径";
            // 
            // chkInHosType1
            // 
            this.chkInHosType1.Location = new System.Drawing.Point(78, 359);
            this.chkInHosType1.Name = "chkInHosType1";
            this.chkInHosType1.Properties.Caption = "1.急诊";
            this.chkInHosType1.Properties.RadioGroupIndex = 0;
            this.chkInHosType1.Size = new System.Drawing.Size(75, 19);
            this.chkInHosType1.TabIndex = 37;
            this.chkInHosType1.TabStop = false;
            this.chkInHosType1.Click += new System.EventHandler(this.chkBZSH2_Click);
            this.chkInHosType1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.KeyPress);
            // 
            // chkInHosType2
            // 
            this.chkInHosType2.Location = new System.Drawing.Point(179, 359);
            this.chkInHosType2.Name = "chkInHosType2";
            this.chkInHosType2.Properties.Caption = "2.门诊";
            this.chkInHosType2.Properties.RadioGroupIndex = 0;
            this.chkInHosType2.Size = new System.Drawing.Size(75, 19);
            this.chkInHosType2.TabIndex = 38;
            this.chkInHosType2.TabStop = false;
            this.chkInHosType2.Click += new System.EventHandler(this.chkBZSH2_Click);
            this.chkInHosType2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.KeyPress);
            // 
            // chkInHosType3
            // 
            this.chkInHosType3.Location = new System.Drawing.Point(277, 359);
            this.chkInHosType3.Name = "chkInHosType3";
            this.chkInHosType3.Properties.Caption = "3.其他医疗机构转入";
            this.chkInHosType3.Properties.RadioGroupIndex = 0;
            this.chkInHosType3.Size = new System.Drawing.Size(136, 19);
            this.chkInHosType3.TabIndex = 39;
            this.chkInHosType3.TabStop = false;
            this.chkInHosType3.Click += new System.EventHandler(this.chkBZSH2_Click);
            this.chkInHosType3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.KeyPress);
            // 
            // chkInHosType4
            // 
            this.chkInHosType4.Location = new System.Drawing.Point(438, 359);
            this.chkInHosType4.Name = "chkInHosType4";
            this.chkInHosType4.Properties.Caption = "9.其他";
            this.chkInHosType4.Properties.RadioGroupIndex = 0;
            this.chkInHosType4.Size = new System.Drawing.Size(85, 19);
            this.chkInHosType4.TabIndex = 40;
            this.chkInHosType4.TabStop = false;
            this.chkInHosType4.Click += new System.EventHandler(this.chkBZSH2_Click);
            this.chkInHosType4.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.KeyPress);
            // 
            // chkCURE_TYPE4
            // 
            this.chkCURE_TYPE4.Location = new System.Drawing.Point(438, 388);
            this.chkCURE_TYPE4.Name = "chkCURE_TYPE4";
            this.chkCURE_TYPE4.Properties.Caption = "2.中西医 ";
            this.chkCURE_TYPE4.Properties.RadioGroupIndex = 1;
            this.chkCURE_TYPE4.Size = new System.Drawing.Size(85, 19);
            this.chkCURE_TYPE4.TabIndex = 44;
            this.chkCURE_TYPE4.TabStop = false;
            this.chkCURE_TYPE4.Click += new System.EventHandler(this.chkBZSH2_Click);
            this.chkCURE_TYPE4.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.KeyPress);
            // 
            // chkCURE_TYPE3
            // 
            this.chkCURE_TYPE3.Location = new System.Drawing.Point(279, 388);
            this.chkCURE_TYPE3.Name = "chkCURE_TYPE3";
            this.chkCURE_TYPE3.Properties.Caption = "1.2民族医）";
            this.chkCURE_TYPE3.Properties.RadioGroupIndex = 1;
            this.chkCURE_TYPE3.Size = new System.Drawing.Size(136, 19);
            this.chkCURE_TYPE3.TabIndex = 43;
            this.chkCURE_TYPE3.TabStop = false;
            this.chkCURE_TYPE3.Click += new System.EventHandler(this.chkBZSH2_Click);
            this.chkCURE_TYPE3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.KeyPress);
            // 
            // chkCURE_TYPE2
            // 
            this.chkCURE_TYPE2.Location = new System.Drawing.Point(179, 388);
            this.chkCURE_TYPE2.Name = "chkCURE_TYPE2";
            this.chkCURE_TYPE2.Properties.Caption = "1.1 中医";
            this.chkCURE_TYPE2.Properties.RadioGroupIndex = 1;
            this.chkCURE_TYPE2.Size = new System.Drawing.Size(75, 19);
            this.chkCURE_TYPE2.TabIndex = 42;
            this.chkCURE_TYPE2.TabStop = false;
            this.chkCURE_TYPE2.Click += new System.EventHandler(this.chkBZSH2_Click);
            this.chkCURE_TYPE2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.KeyPress);
            // 
            // chkCURE_TYPE1
            // 
            this.chkCURE_TYPE1.Location = new System.Drawing.Point(78, 388);
            this.chkCURE_TYPE1.Name = "chkCURE_TYPE1";
            this.chkCURE_TYPE1.Properties.Caption = "1.中医（";
            this.chkCURE_TYPE1.Properties.RadioGroupIndex = 1;
            this.chkCURE_TYPE1.Size = new System.Drawing.Size(75, 19);
            this.chkCURE_TYPE1.TabIndex = 41;
            this.chkCURE_TYPE1.TabStop = false;
            this.chkCURE_TYPE1.Click += new System.EventHandler(this.chkBZSH2_Click);
            this.chkCURE_TYPE1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.KeyPress);
            // 
            // labelControl23
            // 
            this.labelControl23.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl23.Location = new System.Drawing.Point(16, 390);
            this.labelControl23.Name = "labelControl23";
            this.labelControl23.Size = new System.Drawing.Size(48, 14);
            this.labelControl23.TabIndex = 131;
            this.labelControl23.Text = "治疗类别";
            // 
            // chkCURE_TYPE5
            // 
            this.chkCURE_TYPE5.Location = new System.Drawing.Point(558, 388);
            this.chkCURE_TYPE5.Name = "chkCURE_TYPE5";
            this.chkCURE_TYPE5.Properties.Caption = "3.西医";
            this.chkCURE_TYPE5.Properties.RadioGroupIndex = 1;
            this.chkCURE_TYPE5.Size = new System.Drawing.Size(85, 19);
            this.chkCURE_TYPE5.TabIndex = 45;
            this.chkCURE_TYPE5.TabStop = false;
            this.chkCURE_TYPE5.Click += new System.EventHandler(this.chkBZSH2_Click);
            this.chkCURE_TYPE5.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.KeyPress);
            // 
            // labelControl24
            // 
            this.labelControl24.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl24.Location = new System.Drawing.Point(16, 486);
            this.labelControl24.Name = "labelControl24";
            this.labelControl24.Size = new System.Drawing.Size(156, 14);
            this.labelControl24.TabIndex = 125;
            this.labelControl24.Text = "门（急）诊诊断（中医诊断）";
            // 
            // labelControl32
            // 
            this.labelControl32.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl32.Location = new System.Drawing.Point(16, 553);
            this.labelControl32.Name = "labelControl32";
            this.labelControl32.Size = new System.Drawing.Size(84, 14);
            this.labelControl32.TabIndex = 130;
            this.labelControl32.Text = "实施临床路径：";
            // 
            // chkSSLCLJ2
            // 
            this.chkSSLCLJ2.Location = new System.Drawing.Point(213, 550);
            this.chkSSLCLJ2.Name = "chkSSLCLJ2";
            this.chkSSLCLJ2.Properties.Caption = "2. 西医";
            this.chkSSLCLJ2.Properties.RadioGroupIndex = 2;
            this.chkSSLCLJ2.Size = new System.Drawing.Size(66, 19);
            this.chkSSLCLJ2.TabIndex = 59;
            this.chkSSLCLJ2.TabStop = false;
            this.chkSSLCLJ2.Click += new System.EventHandler(this.chkBZSH2_Click);
            this.chkSSLCLJ2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.KeyPress);
            // 
            // chkSSLCLJ1
            // 
            this.chkSSLCLJ1.Location = new System.Drawing.Point(119, 550);
            this.chkSSLCLJ1.Name = "chkSSLCLJ1";
            this.chkSSLCLJ1.Properties.Caption = "1. 中医";
            this.chkSSLCLJ1.Properties.RadioGroupIndex = 2;
            this.chkSSLCLJ1.Size = new System.Drawing.Size(68, 19);
            this.chkSSLCLJ1.TabIndex = 58;
            this.chkSSLCLJ1.TabStop = false;
            this.chkSSLCLJ1.Click += new System.EventHandler(this.chkBZSH2_Click);
            this.chkSSLCLJ1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.KeyPress);
            // 
            // chkSSLCLJ3
            // 
            this.chkSSLCLJ3.Location = new System.Drawing.Point(309, 550);
            this.chkSSLCLJ3.Name = "chkSSLCLJ3";
            this.chkSSLCLJ3.Properties.Caption = "3 否";
            this.chkSSLCLJ3.Properties.RadioGroupIndex = 2;
            this.chkSSLCLJ3.Size = new System.Drawing.Size(51, 19);
            this.chkSSLCLJ3.TabIndex = 60;
            this.chkSSLCLJ3.TabStop = false;
            this.chkSSLCLJ3.Click += new System.EventHandler(this.chkBZSH2_Click);
            this.chkSSLCLJ3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.KeyPress);
            // 
            // labelControl33
            // 
            this.labelControl33.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl33.Location = new System.Drawing.Point(385, 553);
            this.labelControl33.Name = "labelControl33";
            this.labelControl33.Size = new System.Drawing.Size(132, 14);
            this.labelControl33.TabIndex = 126;
            this.labelControl33.Text = "使用医疗机构中药制剂：";
            // 
            // chkZYZJ1
            // 
            this.chkZYZJ1.Location = new System.Drawing.Point(548, 550);
            this.chkZYZJ1.Name = "chkZYZJ1";
            this.chkZYZJ1.Properties.Caption = "1.是";
            this.chkZYZJ1.Properties.RadioGroupIndex = 3;
            this.chkZYZJ1.Size = new System.Drawing.Size(59, 19);
            this.chkZYZJ1.TabIndex = 61;
            this.chkZYZJ1.TabStop = false;
            this.chkZYZJ1.Click += new System.EventHandler(this.chkBZSH2_Click);
            this.chkZYZJ1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.KeyPress);
            // 
            // chkZYZJ2
            // 
            this.chkZYZJ2.Location = new System.Drawing.Point(633, 550);
            this.chkZYZJ2.Name = "chkZYZJ2";
            this.chkZYZJ2.Properties.Caption = "2. 否";
            this.chkZYZJ2.Properties.RadioGroupIndex = 3;
            this.chkZYZJ2.Size = new System.Drawing.Size(66, 19);
            this.chkZYZJ2.TabIndex = 62;
            this.chkZYZJ2.TabStop = false;
            this.chkZYZJ2.Click += new System.EventHandler(this.chkBZSH2_Click);
            this.chkZYZJ2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.KeyPress);
            // 
            // labelControl34
            // 
            this.labelControl34.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl34.Location = new System.Drawing.Point(16, 585);
            this.labelControl34.Name = "labelControl34";
            this.labelControl34.Size = new System.Drawing.Size(108, 14);
            this.labelControl34.TabIndex = 129;
            this.labelControl34.Text = "使用中医诊疗设备：";
            // 
            // chkZYZLSB1
            // 
            this.chkZYZLSB1.Location = new System.Drawing.Point(148, 582);
            this.chkZYZLSB1.Name = "chkZYZLSB1";
            this.chkZYZLSB1.Properties.Caption = "1.是";
            this.chkZYZLSB1.Properties.RadioGroupIndex = 4;
            this.chkZYZLSB1.Size = new System.Drawing.Size(59, 19);
            this.chkZYZLSB1.TabIndex = 63;
            this.chkZYZLSB1.TabStop = false;
            this.chkZYZLSB1.Click += new System.EventHandler(this.chkBZSH2_Click);
            this.chkZYZLSB1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.KeyPress);
            // 
            // chkZYZLSB2
            // 
            this.chkZYZLSB2.Location = new System.Drawing.Point(234, 582);
            this.chkZYZLSB2.Name = "chkZYZLSB2";
            this.chkZYZLSB2.Properties.Caption = "2. 否";
            this.chkZYZLSB2.Properties.RadioGroupIndex = 4;
            this.chkZYZLSB2.Size = new System.Drawing.Size(66, 19);
            this.chkZYZLSB2.TabIndex = 64;
            this.chkZYZLSB2.TabStop = false;
            this.chkZYZLSB2.Click += new System.EventHandler(this.chkBZSH2_Click);
            this.chkZYZLSB2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.KeyPress);
            // 
            // chkZYZLJS1
            // 
            this.chkZYZLJS1.Location = new System.Drawing.Point(499, 582);
            this.chkZYZLJS1.Name = "chkZYZLJS1";
            this.chkZYZLJS1.Properties.Caption = "1.是";
            this.chkZYZLJS1.Properties.RadioGroupIndex = 5;
            this.chkZYZLJS1.Size = new System.Drawing.Size(59, 19);
            this.chkZYZLJS1.TabIndex = 65;
            this.chkZYZLJS1.TabStop = false;
            this.chkZYZLJS1.Click += new System.EventHandler(this.chkBZSH2_Click);
            this.chkZYZLJS1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.KeyPress);
            // 
            // chkZYZLJS2
            // 
            this.chkZYZLJS2.Location = new System.Drawing.Point(599, 582);
            this.chkZYZLJS2.Name = "chkZYZLJS2";
            this.chkZYZLJS2.Properties.Caption = "2. 否";
            this.chkZYZLJS2.Properties.RadioGroupIndex = 5;
            this.chkZYZLJS2.Size = new System.Drawing.Size(66, 19);
            this.chkZYZLJS2.TabIndex = 66;
            this.chkZYZLJS2.TabStop = false;
            this.chkZYZLJS2.Click += new System.EventHandler(this.chkBZSH2_Click);
            this.chkZYZLJS2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.KeyPress);
            // 
            // labelControl36
            // 
            this.labelControl36.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl36.Location = new System.Drawing.Point(374, 585);
            this.labelControl36.Name = "labelControl36";
            this.labelControl36.Size = new System.Drawing.Size(108, 14);
            this.labelControl36.TabIndex = 128;
            this.labelControl36.Text = "使用中医诊疗技术：";
            // 
            // chkBZSH1
            // 
            this.chkBZSH1.Location = new System.Drawing.Point(106, 612);
            this.chkBZSH1.Name = "chkBZSH1";
            this.chkBZSH1.Properties.Caption = "1.是";
            this.chkBZSH1.Properties.RadioGroupIndex = 6;
            this.chkBZSH1.Size = new System.Drawing.Size(59, 19);
            this.chkBZSH1.TabIndex = 67;
            this.chkBZSH1.TabStop = false;
            this.chkBZSH1.Click += new System.EventHandler(this.chkBZSH2_Click);
            this.chkBZSH1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.KeyPress);
            // 
            // chkBZSH2
            // 
            this.chkBZSH2.Location = new System.Drawing.Point(202, 612);
            this.chkBZSH2.Name = "chkBZSH2";
            this.chkBZSH2.Properties.Caption = "2. 否";
            this.chkBZSH2.Properties.RadioGroupIndex = 6;
            this.chkBZSH2.Size = new System.Drawing.Size(66, 19);
            this.chkBZSH2.TabIndex = 68;
            this.chkBZSH2.TabStop = false;
            this.chkBZSH2.Click += new System.EventHandler(this.chkBZSH2_Click);
            this.chkBZSH2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.KeyPress);
            // 
            // labelControl37
            // 
            this.labelControl37.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl37.Location = new System.Drawing.Point(16, 615);
            this.labelControl37.Name = "labelControl37";
            this.labelControl37.Size = new System.Drawing.Size(60, 14);
            this.labelControl37.TabIndex = 127;
            this.labelControl37.Text = "辨证施护：";
            // 
            // labelControl43
            // 
            this.labelControl43.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl43.Location = new System.Drawing.Point(16, 519);
            this.labelControl43.Name = "labelControl43";
            this.labelControl43.Size = new System.Drawing.Size(156, 14);
            this.labelControl43.TabIndex = 116;
            this.labelControl43.Text = "门（急）诊诊断（西医诊断）";
            // 
            // lueMZXYZD_CODE1
            // 
            this.lueMZXYZD_CODE1.EnterMoveNextControl = true;
            this.lueMZXYZD_CODE1.IsNeedPaint = true;
            this.lueMZXYZD_CODE1.Kind = DrectSoft.Wordbook.WordbookKind.Sql;
            this.lueMZXYZD_CODE1.ListWindow = null;
            this.lueMZXYZD_CODE1.Location = new System.Drawing.Point(635, 518);
            this.lueMZXYZD_CODE1.Name = "lueMZXYZD_CODE1";
            this.lueMZXYZD_CODE1.ShowSButton = true;
            this.lueMZXYZD_CODE1.Size = new System.Drawing.Size(99, 18);
            this.lueMZXYZD_CODE1.TabIndex = 110;
            this.lueMZXYZD_CODE1.Visible = false;
            // 
            // lueOutHosWard
            // 
            this.lueOutHosWard.EnterMoveNextControl = true;
            this.lueOutHosWard.IsNeedPaint = true;
            this.lueOutHosWard.Kind = DrectSoft.Wordbook.WordbookKind.Sql;
            this.lueOutHosWard.ListWindow = null;
            this.lueOutHosWard.Location = new System.Drawing.Point(464, 453);
            this.lueOutHosWard.Name = "lueOutHosWard";
            this.lueOutHosWard.ShowSButton = true;
            this.lueOutHosWard.Size = new System.Drawing.Size(101, 18);
            this.lueOutHosWard.TabIndex = 54;
            // 
            // lueOutHosDept
            // 
            this.lueOutHosDept.EnterMoveNextControl = true;
            this.lueOutHosDept.IsNeedPaint = true;
            this.lueOutHosDept.Kind = DrectSoft.Wordbook.WordbookKind.Sql;
            this.lueOutHosDept.ListWindow = null;
            this.lueOutHosDept.Location = new System.Drawing.Point(306, 453);
            this.lueOutHosDept.Name = "lueOutHosDept";
            this.lueOutHosDept.ShowSButton = true;
            this.lueOutHosDept.Size = new System.Drawing.Size(111, 18);
            this.lueOutHosDept.TabIndex = 53;
            this.lueOutHosDept.CodeValueChanged += new System.EventHandler(this.lueAdmitDept_CodeValueChanged);
            // 
            // lueTransAdmitDept
            // 
            this.lueTransAdmitDept.EnterMoveNextControl = true;
            this.lueTransAdmitDept.IsNeedPaint = true;
            this.lueTransAdmitDept.Kind = DrectSoft.Wordbook.WordbookKind.Sql;
            this.lueTransAdmitDept.ListWindow = null;
            this.lueTransAdmitDept.Location = new System.Drawing.Point(631, 420);
            this.lueTransAdmitDept.Name = "lueTransAdmitDept";
            this.lueTransAdmitDept.ShowSButton = true;
            this.lueTransAdmitDept.Size = new System.Drawing.Size(103, 18);
            this.lueTransAdmitDept.TabIndex = 50;
            // 
            // lueAdmitWard
            // 
            this.lueAdmitWard.EnterMoveNextControl = true;
            this.lueAdmitWard.IsNeedPaint = true;
            this.lueAdmitWard.Kind = DrectSoft.Wordbook.WordbookKind.Sql;
            this.lueAdmitWard.ListWindow = null;
            this.lueAdmitWard.Location = new System.Drawing.Point(464, 420);
            this.lueAdmitWard.Name = "lueAdmitWard";
            this.lueAdmitWard.ShowSButton = true;
            this.lueAdmitWard.Size = new System.Drawing.Size(101, 18);
            this.lueAdmitWard.TabIndex = 49;
            // 
            // lueAdmitDept
            // 
            this.lueAdmitDept.EnterMoveNextControl = true;
            this.lueAdmitDept.IsNeedPaint = true;
            this.lueAdmitDept.Kind = DrectSoft.Wordbook.WordbookKind.Sql;
            this.lueAdmitDept.ListWindow = null;
            this.lueAdmitDept.Location = new System.Drawing.Point(306, 420);
            this.lueAdmitDept.Name = "lueAdmitDept";
            this.lueAdmitDept.ShowSButton = true;
            this.lueAdmitDept.Size = new System.Drawing.Size(111, 18);
            this.lueAdmitDept.TabIndex = 48;
            this.lueAdmitDept.CodeValueChanged += new System.EventHandler(this.lueAdmitDept_CodeValueChanged);
            // 
            // lueMZZYZD_CODE1
            // 
            this.lueMZZYZD_CODE1.EnterMoveNextControl = true;
            this.lueMZZYZD_CODE1.IsNeedPaint = true;
            this.lueMZZYZD_CODE1.Kind = DrectSoft.Wordbook.WordbookKind.Sql;
            this.lueMZZYZD_CODE1.ListWindow = null;
            this.lueMZZYZD_CODE1.Location = new System.Drawing.Point(635, 485);
            this.lueMZZYZD_CODE1.Name = "lueMZZYZD_CODE1";
            this.lueMZZYZD_CODE1.ShowSButton = true;
            this.lueMZZYZD_CODE1.Size = new System.Drawing.Size(99, 18);
            this.lueMZZYZD_CODE1.TabIndex = 110;
            this.lueMZZYZD_CODE1.Visible = false;
            // 
            // lueRelationship
            // 
            this.lueRelationship.EnterMoveNextControl = true;
            this.lueRelationship.IsNeedPaint = true;
            this.lueRelationship.Kind = DrectSoft.Wordbook.WordbookKind.Sql;
            this.lueRelationship.ListWindow = null;
            this.lueRelationship.Location = new System.Drawing.Point(218, 328);
            this.lueRelationship.Name = "lueRelationship";
            this.lueRelationship.ShowSButton = true;
            this.lueRelationship.Size = new System.Drawing.Size(109, 18);
            this.lueRelationship.TabIndex = 34;
            // 
            // lueNationality
            // 
            this.lueNationality.EnterMoveNextControl = true;
            this.lueNationality.IsNeedPaint = true;
            this.lueNationality.Kind = DrectSoft.Wordbook.WordbookKind.Sql;
            this.lueNationality.ListWindow = null;
            this.lueNationality.Location = new System.Drawing.Point(640, 127);
            this.lueNationality.Name = "lueNationality";
            this.lueNationality.ShowSButton = true;
            this.lueNationality.Size = new System.Drawing.Size(97, 18);
            this.lueNationality.TabIndex = 8;
            // 
            // lueNation
            // 
            this.lueNation.EnterMoveNextControl = true;
            this.lueNation.IsNeedPaint = true;
            this.lueNation.Kind = DrectSoft.Wordbook.WordbookKind.Sql;
            this.lueNation.ListWindow = null;
            this.lueNation.Location = new System.Drawing.Point(631, 206);
            this.lueNation.Name = "lueNation";
            this.lueNation.ShowSButton = true;
            this.lueNation.Size = new System.Drawing.Size(103, 18);
            this.lueNation.TabIndex = 20;
            // 
            // lueCSD_ProvinceID
            // 
            this.lueCSD_ProvinceID.EnterMoveNextControl = true;
            this.lueCSD_ProvinceID.IsNeedPaint = true;
            this.lueCSD_ProvinceID.Kind = DrectSoft.Wordbook.WordbookKind.Sql;
            this.lueCSD_ProvinceID.ListWindow = null;
            this.lueCSD_ProvinceID.Location = new System.Drawing.Point(55, 179);
            this.lueCSD_ProvinceID.Name = "lueCSD_ProvinceID";
            this.lueCSD_ProvinceID.ShowSButton = true;
            this.lueCSD_ProvinceID.Size = new System.Drawing.Size(101, 18);
            this.lueCSD_ProvinceID.TabIndex = 12;
            this.lueCSD_ProvinceID.CodeValueChanged += new System.EventHandler(this.lueProvice_CodeValueChanged);
            // 
            // luePayId
            // 
            this.luePayId.EnterMoveNextControl = true;
            this.luePayId.IsNeedPaint = true;
            this.luePayId.Kind = DrectSoft.Wordbook.WordbookKind.Sql;
            this.luePayId.ListWindow = null;
            this.luePayId.Location = new System.Drawing.Point(120, 68);
            this.luePayId.Name = "luePayId";
            this.luePayId.ShowSButton = true;
            this.luePayId.Size = new System.Drawing.Size(128, 18);
            this.luePayId.TabIndex = 1;
            // 
            // lueMarital
            // 
            this.lueMarital.EnterMoveNextControl = true;
            this.lueMarital.IsNeedPaint = true;
            this.lueMarital.Kind = DrectSoft.Wordbook.WordbookKind.Sql;
            this.lueMarital.ListWindow = null;
            this.lueMarital.Location = new System.Drawing.Point(499, 206);
            this.lueMarital.Name = "lueMarital";
            this.lueMarital.ShowSButton = true;
            this.lueMarital.Size = new System.Drawing.Size(94, 18);
            this.lueMarital.TabIndex = 19;
            // 
            // lueJob
            // 
            this.lueJob.EnterMoveNextControl = true;
            this.lueJob.IsNeedPaint = true;
            this.lueJob.Kind = DrectSoft.Wordbook.WordbookKind.Sql;
            this.lueJob.ListWindow = null;
            this.lueJob.Location = new System.Drawing.Point(337, 206);
            this.lueJob.Name = "lueJob";
            this.lueJob.ShowSButton = true;
            this.lueJob.Size = new System.Drawing.Size(120, 18);
            this.lueJob.TabIndex = 18;
            // 
            // lueSex
            // 
            this.lueSex.EnterMoveNextControl = true;
            this.lueSex.IsNeedPaint = true;
            this.lueSex.Kind = DrectSoft.Wordbook.WordbookKind.Sql;
            this.lueSex.ListWindow = null;
            this.lueSex.Location = new System.Drawing.Point(193, 126);
            this.lueSex.Name = "lueSex";
            this.lueSex.ShowSButton = true;
            this.lueSex.Size = new System.Drawing.Size(71, 18);
            this.lueSex.TabIndex = 5;
            // 
            // lueCSD_CityID
            // 
            this.lueCSD_CityID.EnterMoveNextControl = true;
            this.lueCSD_CityID.IsNeedPaint = true;
            this.lueCSD_CityID.Kind = DrectSoft.Wordbook.WordbookKind.Sql;
            this.lueCSD_CityID.ListWindow = null;
            this.lueCSD_CityID.Location = new System.Drawing.Point(218, 179);
            this.lueCSD_CityID.Name = "lueCSD_CityID";
            this.lueCSD_CityID.ShowSButton = true;
            this.lueCSD_CityID.Size = new System.Drawing.Size(89, 18);
            this.lueCSD_CityID.TabIndex = 13;
            this.lueCSD_CityID.CodeValueChanged += new System.EventHandler(this.lueProvice_CodeValueChanged);
            // 
            // lueCSD_DistrictID
            // 
            this.lueCSD_DistrictID.EnterMoveNextControl = true;
            this.lueCSD_DistrictID.IsNeedPaint = true;
            this.lueCSD_DistrictID.Kind = DrectSoft.Wordbook.WordbookKind.Sql;
            this.lueCSD_DistrictID.ListWindow = null;
            this.lueCSD_DistrictID.Location = new System.Drawing.Point(326, 179);
            this.lueCSD_DistrictID.Name = "lueCSD_DistrictID";
            this.lueCSD_DistrictID.ShowSButton = true;
            this.lueCSD_DistrictID.Size = new System.Drawing.Size(93, 18);
            this.lueCSD_DistrictID.TabIndex = 14;
            this.lueCSD_DistrictID.CodeValueChanged += new System.EventHandler(this.lueProvice_CodeValueChanged);
            // 
            // lueJG_ProvinceID
            // 
            this.lueJG_ProvinceID.EnterMoveNextControl = true;
            this.lueJG_ProvinceID.IsNeedPaint = true;
            this.lueJG_ProvinceID.Kind = DrectSoft.Wordbook.WordbookKind.Sql;
            this.lueJG_ProvinceID.ListWindow = null;
            this.lueJG_ProvinceID.Location = new System.Drawing.Point(467, 179);
            this.lueJG_ProvinceID.Name = "lueJG_ProvinceID";
            this.lueJG_ProvinceID.ShowSButton = true;
            this.lueJG_ProvinceID.Size = new System.Drawing.Size(98, 18);
            this.lueJG_ProvinceID.TabIndex = 15;
            this.lueJG_ProvinceID.CodeValueChanged += new System.EventHandler(this.lueProvice_CodeValueChanged);
            // 
            // lueJG_CityID
            // 
            this.lueJG_CityID.EnterMoveNextControl = true;
            this.lueJG_CityID.IsNeedPaint = true;
            this.lueJG_CityID.Kind = DrectSoft.Wordbook.WordbookKind.Sql;
            this.lueJG_CityID.ListWindow = null;
            this.lueJG_CityID.Location = new System.Drawing.Point(631, 179);
            this.lueJG_CityID.Name = "lueJG_CityID";
            this.lueJG_CityID.ShowSButton = true;
            this.lueJG_CityID.Size = new System.Drawing.Size(85, 18);
            this.lueJG_CityID.TabIndex = 16;
            // 
            // lueXZZ_ProvinceID
            // 
            this.lueXZZ_ProvinceID.EnterMoveNextControl = true;
            this.lueXZZ_ProvinceID.IsNeedPaint = true;
            this.lueXZZ_ProvinceID.Kind = DrectSoft.Wordbook.WordbookKind.Sql;
            this.lueXZZ_ProvinceID.ListWindow = null;
            this.lueXZZ_ProvinceID.Location = new System.Drawing.Point(58, 237);
            this.lueXZZ_ProvinceID.Name = "lueXZZ_ProvinceID";
            this.lueXZZ_ProvinceID.ShowSButton = true;
            this.lueXZZ_ProvinceID.Size = new System.Drawing.Size(98, 18);
            this.lueXZZ_ProvinceID.TabIndex = 21;
            this.lueXZZ_ProvinceID.CodeValueChanged += new System.EventHandler(this.lueProvice_CodeValueChanged);
            // 
            // lueXZZ_CityID
            // 
            this.lueXZZ_CityID.EnterMoveNextControl = true;
            this.lueXZZ_CityID.IsNeedPaint = true;
            this.lueXZZ_CityID.Kind = DrectSoft.Wordbook.WordbookKind.Sql;
            this.lueXZZ_CityID.ListWindow = null;
            this.lueXZZ_CityID.Location = new System.Drawing.Point(233, 237);
            this.lueXZZ_CityID.Name = "lueXZZ_CityID";
            this.lueXZZ_CityID.ShowSButton = true;
            this.lueXZZ_CityID.Size = new System.Drawing.Size(97, 18);
            this.lueXZZ_CityID.TabIndex = 22;
            this.lueXZZ_CityID.CodeValueChanged += new System.EventHandler(this.lueProvice_CodeValueChanged);
            // 
            // lueXZZ_DistrictID
            // 
            this.lueXZZ_DistrictID.EnterMoveNextControl = true;
            this.lueXZZ_DistrictID.IsNeedPaint = true;
            this.lueXZZ_DistrictID.Kind = DrectSoft.Wordbook.WordbookKind.Sql;
            this.lueXZZ_DistrictID.ListWindow = null;
            this.lueXZZ_DistrictID.Location = new System.Drawing.Point(351, 237);
            this.lueXZZ_DistrictID.Name = "lueXZZ_DistrictID";
            this.lueXZZ_DistrictID.ShowSButton = true;
            this.lueXZZ_DistrictID.Size = new System.Drawing.Size(96, 18);
            this.lueXZZ_DistrictID.TabIndex = 23;
            this.lueXZZ_DistrictID.CodeValueChanged += new System.EventHandler(this.lueProvice_CodeValueChanged);
            // 
            // lueHKDZ_ProvinceID
            // 
            this.lueHKDZ_ProvinceID.EnterMoveNextControl = true;
            this.lueHKDZ_ProvinceID.IsNeedPaint = true;
            this.lueHKDZ_ProvinceID.Kind = DrectSoft.Wordbook.WordbookKind.Sql;
            this.lueHKDZ_ProvinceID.ListWindow = null;
            this.lueHKDZ_ProvinceID.Location = new System.Drawing.Point(70, 266);
            this.lueHKDZ_ProvinceID.Name = "lueHKDZ_ProvinceID";
            this.lueHKDZ_ProvinceID.ShowSButton = true;
            this.lueHKDZ_ProvinceID.Size = new System.Drawing.Size(126, 18);
            this.lueHKDZ_ProvinceID.TabIndex = 26;
            this.lueHKDZ_ProvinceID.CodeValueChanged += new System.EventHandler(this.lueProvice_CodeValueChanged);
            // 
            // lueHKDZ_CityID
            // 
            this.lueHKDZ_CityID.EnterMoveNextControl = true;
            this.lueHKDZ_CityID.IsNeedPaint = true;
            this.lueHKDZ_CityID.Kind = DrectSoft.Wordbook.WordbookKind.Sql;
            this.lueHKDZ_CityID.ListWindow = null;
            this.lueHKDZ_CityID.Location = new System.Drawing.Point(283, 266);
            this.lueHKDZ_CityID.Name = "lueHKDZ_CityID";
            this.lueHKDZ_CityID.ShowSButton = true;
            this.lueHKDZ_CityID.Size = new System.Drawing.Size(113, 18);
            this.lueHKDZ_CityID.TabIndex = 27;
            this.lueHKDZ_CityID.CodeValueChanged += new System.EventHandler(this.lueProvice_CodeValueChanged);
            // 
            // lueHKDZ_DistrictID
            // 
            this.lueHKDZ_DistrictID.EnterMoveNextControl = true;
            this.lueHKDZ_DistrictID.IsNeedPaint = true;
            this.lueHKDZ_DistrictID.Kind = DrectSoft.Wordbook.WordbookKind.Sql;
            this.lueHKDZ_DistrictID.ListWindow = null;
            this.lueHKDZ_DistrictID.Location = new System.Drawing.Point(422, 266);
            this.lueHKDZ_DistrictID.Name = "lueHKDZ_DistrictID";
            this.lueHKDZ_DistrictID.ShowSButton = true;
            this.lueHKDZ_DistrictID.Size = new System.Drawing.Size(125, 18);
            this.lueHKDZ_DistrictID.TabIndex = 28;
            this.lueHKDZ_DistrictID.CodeValueChanged += new System.EventHandler(this.lueProvice_CodeValueChanged);
            // 
            // seActualDays
            // 
            this.seActualDays.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.seActualDays.EnterMoveNextControl = true;
            this.seActualDays.Location = new System.Drawing.Point(631, 451);
            this.seActualDays.Name = "seActualDays";
            this.seActualDays.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.seActualDays.Size = new System.Drawing.Size(85, 20);
            this.seActualDays.TabIndex = 55;
            // 
            // deBirth
            // 
            this.deBirth.EditValue = null;
            this.deBirth.EnterMoveNextControl = true;
            this.deBirth.Location = new System.Drawing.Point(333, 125);
            this.deBirth.Name = "deBirth";
            this.deBirth.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.deBirth.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.deBirth.Size = new System.Drawing.Size(131, 20);
            this.deBirth.TabIndex = 6;
            // 
            // seInCount
            // 
            this.seInCount.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.seInCount.EnterMoveNextControl = true;
            this.seInCount.Location = new System.Drawing.Point(385, 89);
            this.seInCount.Name = "seInCount";
            this.seInCount.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.seInCount.Size = new System.Drawing.Size(55, 20);
            this.seInCount.TabIndex = 3;
            // 
            // DevButtonSave1
            // 
            this.DevButtonSave1.Image = ((System.Drawing.Image)(resources.GetObject("DevButtonSave1.Image")));
            this.DevButtonSave1.Location = new System.Drawing.Point(552, 634);
            this.DevButtonSave1.Name = "DevButtonSave1";
            this.DevButtonSave1.Size = new System.Drawing.Size(80, 23);
            this.DevButtonSave1.TabIndex = 69;
            this.DevButtonSave1.Text = "保存(&S)";
            this.DevButtonSave1.Click += new System.EventHandler(this.btn_OK_Click);
            // 
            // btnClose
            // 
            this.btnClose.Image = ((System.Drawing.Image)(resources.GetObject("btnClose.Image")));
            this.btnClose.Location = new System.Drawing.Point(649, 634);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(80, 23);
            this.btnClose.TabIndex = 70;
            this.btnClose.Text = "关闭(&T)";
            this.btnClose.Click += new System.EventHandler(this.btn_Close_Click);
            // 
            // lueMZXYZD_CODE
            // 
            this.lueMZXYZD_CODE.BackColor = System.Drawing.Color.White;
            this.lueMZXYZD_CODE.DiaCode = "";
            this.lueMZXYZD_CODE.DiaValue = "";
            this.lueMZXYZD_CODE.Location = new System.Drawing.Point(181, 518);
            this.lueMZXYZD_CODE.Name = "lueMZXYZD_CODE";
            this.lueMZXYZD_CODE.Size = new System.Drawing.Size(433, 21);
            this.lueMZXYZD_CODE.TabIndex = 57;
            this.lueMZXYZD_CODE.WaterText = "请按回车键检索";
            this.lueMZXYZD_CODE.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.bwj2_KeyPress);
            // 
            // lueMZZYZD_CODE
            // 
            this.lueMZZYZD_CODE.BackColor = System.Drawing.Color.White;
            this.lueMZZYZD_CODE.DiaCode = "";
            this.lueMZZYZD_CODE.DiaValue = "";
            this.lueMZZYZD_CODE.Location = new System.Drawing.Point(181, 485);
            this.lueMZZYZD_CODE.Name = "lueMZZYZD_CODE";
            this.lueMZZYZD_CODE.Size = new System.Drawing.Size(433, 21);
            this.lueMZZYZD_CODE.TabIndex = 56;
            this.lueMZZYZD_CODE.WaterText = "请按回车键检索";
            this.lueMZZYZD_CODE.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.bwj1_KeyPress);
            // 
            // deOutWardDate
            // 
            this.deOutWardDate.EditValue = null;
            this.deOutWardDate.EnterMoveNextControl = true;
            this.deOutWardDate.Location = new System.Drawing.Point(75, 452);
            this.deOutWardDate.Name = "deOutWardDate";
            this.deOutWardDate.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.deOutWardDate.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.deOutWardDate.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.deOutWardDate.Size = new System.Drawing.Size(103, 18);
            this.deOutWardDate.TabIndex = 51;
            // 
            // deAdmitDate
            // 
            this.deAdmitDate.EditValue = null;
            this.deAdmitDate.EnterMoveNextControl = true;
            this.deAdmitDate.Location = new System.Drawing.Point(75, 419);
            this.deAdmitDate.Name = "deAdmitDate";
            this.deAdmitDate.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.deAdmitDate.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.deAdmitDate.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.deAdmitDate.Size = new System.Drawing.Size(103, 18);
            this.deAdmitDate.TabIndex = 46;
            // 
            // txtContactAddress
            // 
            this.txtContactAddress.AllowHtmlTextInToolTip = DevExpress.Utils.DefaultBoolean.True;
            this.txtContactAddress.EditValue = "";
            this.txtContactAddress.EnterMoveNextControl = true;
            this.txtContactAddress.Location = new System.Drawing.Point(367, 327);
            this.txtContactAddress.Name = "txtContactAddress";
            this.txtContactAddress.Properties.AppearanceReadOnly.BackColor = System.Drawing.Color.White;
            this.txtContactAddress.Properties.AppearanceReadOnly.BackColor2 = System.Drawing.Color.White;
            this.txtContactAddress.Properties.AppearanceReadOnly.Options.UseBackColor = true;
            this.txtContactAddress.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtContactAddress.Size = new System.Drawing.Size(215, 18);
            this.txtContactAddress.TabIndex = 35;
            // 
            // txtContactPerson
            // 
            this.txtContactPerson.EditValue = "";
            this.txtContactPerson.EnterMoveNextControl = true;
            this.txtContactPerson.Location = new System.Drawing.Point(80, 327);
            this.txtContactPerson.Name = "txtContactPerson";
            this.txtContactPerson.Properties.AppearanceReadOnly.BackColor = System.Drawing.Color.White;
            this.txtContactPerson.Properties.AppearanceReadOnly.BackColor2 = System.Drawing.Color.White;
            this.txtContactPerson.Properties.AppearanceReadOnly.Options.UseBackColor = true;
            this.txtContactPerson.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtContactPerson.Size = new System.Drawing.Size(98, 18);
            this.txtContactPerson.TabIndex = 33;
            // 
            // txtOfficePlace
            // 
            this.txtOfficePlace.EditValue = "";
            this.txtOfficePlace.EnterMoveNextControl = true;
            this.txtOfficePlace.Location = new System.Drawing.Point(106, 297);
            this.txtOfficePlace.Name = "txtOfficePlace";
            this.txtOfficePlace.Properties.AppearanceReadOnly.BackColor = System.Drawing.Color.White;
            this.txtOfficePlace.Properties.AppearanceReadOnly.BackColor2 = System.Drawing.Color.White;
            this.txtOfficePlace.Properties.AppearanceReadOnly.Options.UseBackColor = true;
            this.txtOfficePlace.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtOfficePlace.Properties.MaxLength = 32;
            this.txtOfficePlace.Size = new System.Drawing.Size(248, 18);
            this.txtOfficePlace.TabIndex = 30;
            // 
            // txtIDNO
            // 
            this.txtIDNO.EditValue = "";
            this.txtIDNO.EnterMoveNextControl = true;
            this.txtIDNO.Location = new System.Drawing.Point(70, 207);
            this.txtIDNO.Name = "txtIDNO";
            this.txtIDNO.Properties.AppearanceReadOnly.BackColor = System.Drawing.Color.White;
            this.txtIDNO.Properties.AppearanceReadOnly.BackColor2 = System.Drawing.Color.White;
            this.txtIDNO.Properties.AppearanceReadOnly.Options.UseBackColor = true;
            this.txtIDNO.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtIDNO.Properties.MaxLength = 18;
            this.txtIDNO.Size = new System.Drawing.Size(229, 18);
            this.txtIDNO.TabIndex = 17;
            // 
            // txtSocialCare
            // 
            this.txtSocialCare.EditValue = "";
            this.txtSocialCare.Enabled = false;
            this.txtSocialCare.Location = new System.Drawing.Point(94, 22);
            this.txtSocialCare.Name = "txtSocialCare";
            this.txtSocialCare.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtSocialCare.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSocialCare.Properties.Appearance.Options.UseBackColor = true;
            this.txtSocialCare.Properties.Appearance.Options.UseFont = true;
            this.txtSocialCare.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtSocialCare.Size = new System.Drawing.Size(71, 18);
            this.txtSocialCare.TabIndex = 2;
            this.txtSocialCare.Visible = false;
            // 
            // txtName
            // 
            this.txtName.EnterMoveNextControl = true;
            this.txtName.Location = new System.Drawing.Point(46, 127);
            this.txtName.Name = "txtName";
            this.txtName.Properties.AppearanceDisabled.BackColor = System.Drawing.Color.White;
            this.txtName.Properties.AppearanceDisabled.BackColor2 = System.Drawing.Color.White;
            this.txtName.Properties.AppearanceDisabled.Options.UseBackColor = true;
            this.txtName.Properties.AppearanceReadOnly.BackColor = System.Drawing.Color.White;
            this.txtName.Properties.AppearanceReadOnly.BackColor2 = System.Drawing.Color.White;
            this.txtName.Properties.AppearanceReadOnly.Options.UseBackColor = true;
            this.txtName.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtName.Properties.MaxLength = 16;
            this.txtName.Size = new System.Drawing.Size(111, 18);
            this.txtName.TabIndex = 4;
            // 
            // txtPatNoOfHis
            // 
            this.txtPatNoOfHis.Enabled = false;
            this.txtPatNoOfHis.Location = new System.Drawing.Point(616, 89);
            this.txtPatNoOfHis.Name = "txtPatNoOfHis";
            this.txtPatNoOfHis.Properties.AppearanceDisabled.BackColor = System.Drawing.Color.White;
            this.txtPatNoOfHis.Properties.AppearanceDisabled.BackColor2 = System.Drawing.Color.White;
            this.txtPatNoOfHis.Properties.AppearanceDisabled.Options.UseBackColor = true;
            this.txtPatNoOfHis.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtPatNoOfHis.Size = new System.Drawing.Size(120, 18);
            this.txtPatNoOfHis.TabIndex = 4;
            this.txtPatNoOfHis.TabStop = false;
            // 
            // txtAge
            // 
            this.txtAge.EnterMoveNextControl = true;
            this.txtAge.Location = new System.Drawing.Point(511, 127);
            this.txtAge.Name = "txtAge";
            this.txtAge.Properties.AppearanceDisabled.BackColor = System.Drawing.Color.White;
            this.txtAge.Properties.AppearanceDisabled.BackColor2 = System.Drawing.Color.White;
            this.txtAge.Properties.AppearanceDisabled.Options.UseBackColor = true;
            this.txtAge.Properties.AppearanceReadOnly.BackColor = System.Drawing.Color.White;
            this.txtAge.Properties.AppearanceReadOnly.BackColor2 = System.Drawing.Color.White;
            this.txtAge.Properties.AppearanceReadOnly.Options.UseBackColor = true;
            this.txtAge.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtAge.Size = new System.Drawing.Size(92, 18);
            this.txtAge.TabIndex = 7;
            // 
            // txtCardNumber
            // 
            this.txtCardNumber.EnterMoveNextControl = true;
            this.txtCardNumber.Location = new System.Drawing.Point(94, 90);
            this.txtCardNumber.Name = "txtCardNumber";
            this.txtCardNumber.Properties.AppearanceDisabled.BackColor = System.Drawing.Color.White;
            this.txtCardNumber.Properties.AppearanceDisabled.BackColor2 = System.Drawing.Color.White;
            this.txtCardNumber.Properties.AppearanceDisabled.Options.UseBackColor = true;
            this.txtCardNumber.Properties.AppearanceReadOnly.BackColor = System.Drawing.Color.White;
            this.txtCardNumber.Properties.AppearanceReadOnly.BackColor2 = System.Drawing.Color.White;
            this.txtCardNumber.Properties.AppearanceReadOnly.Options.UseBackColor = true;
            this.txtCardNumber.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtCardNumber.Properties.MaxLength = 16;
            this.txtCardNumber.Size = new System.Drawing.Size(174, 18);
            this.txtCardNumber.TabIndex = 2;
            // 
            // txtMonthAge
            // 
            this.txtMonthAge.EnterMoveNextControl = true;
            this.txtMonthAge.Location = new System.Drawing.Point(163, 152);
            this.txtMonthAge.Name = "txtMonthAge";
            this.txtMonthAge.Properties.AppearanceDisabled.BackColor = System.Drawing.Color.White;
            this.txtMonthAge.Properties.AppearanceDisabled.BackColor2 = System.Drawing.Color.White;
            this.txtMonthAge.Properties.AppearanceDisabled.Options.UseBackColor = true;
            this.txtMonthAge.Properties.AppearanceReadOnly.BackColor = System.Drawing.Color.White;
            this.txtMonthAge.Properties.AppearanceReadOnly.BackColor2 = System.Drawing.Color.White;
            this.txtMonthAge.Properties.AppearanceReadOnly.Options.UseBackColor = true;
            this.txtMonthAge.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtMonthAge.Size = new System.Drawing.Size(76, 18);
            this.txtMonthAge.TabIndex = 9;
            // 
            // txtWeight
            // 
            this.txtWeight.EnterMoveNextControl = true;
            this.txtWeight.Location = new System.Drawing.Point(395, 152);
            this.txtWeight.Name = "txtWeight";
            this.txtWeight.Properties.AppearanceDisabled.BackColor = System.Drawing.Color.White;
            this.txtWeight.Properties.AppearanceDisabled.BackColor2 = System.Drawing.Color.White;
            this.txtWeight.Properties.AppearanceDisabled.Options.UseBackColor = true;
            this.txtWeight.Properties.AppearanceReadOnly.BackColor = System.Drawing.Color.White;
            this.txtWeight.Properties.AppearanceReadOnly.BackColor2 = System.Drawing.Color.White;
            this.txtWeight.Properties.AppearanceReadOnly.Options.UseBackColor = true;
            this.txtWeight.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtWeight.Size = new System.Drawing.Size(70, 18);
            this.txtWeight.TabIndex = 10;
            // 
            // txtInWeight
            // 
            this.txtInWeight.EnterMoveNextControl = true;
            this.txtInWeight.Location = new System.Drawing.Point(649, 152);
            this.txtInWeight.Name = "txtInWeight";
            this.txtInWeight.Properties.AppearanceDisabled.BackColor = System.Drawing.Color.White;
            this.txtInWeight.Properties.AppearanceDisabled.BackColor2 = System.Drawing.Color.White;
            this.txtInWeight.Properties.AppearanceDisabled.Options.UseBackColor = true;
            this.txtInWeight.Properties.AppearanceReadOnly.BackColor = System.Drawing.Color.White;
            this.txtInWeight.Properties.AppearanceReadOnly.BackColor2 = System.Drawing.Color.White;
            this.txtInWeight.Properties.AppearanceReadOnly.Options.UseBackColor = true;
            this.txtInWeight.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtInWeight.Size = new System.Drawing.Size(67, 18);
            this.txtInWeight.TabIndex = 11;
            this.txtInWeight.EditValueChanged += new System.EventHandler(this.txtInWeight_EditValueChanged);
            // 
            // textEdit3
            // 
            this.textEdit3.EditValue = "";
            this.textEdit3.Location = new System.Drawing.Point(635, 267);
            this.textEdit3.Name = "textEdit3";
            this.textEdit3.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.textEdit3.Size = new System.Drawing.Size(99, 18);
            this.textEdit3.TabIndex = 18;
            // 
            // txtOfficeTEL
            // 
            this.txtOfficeTEL.Location = new System.Drawing.Point(422, 297);
            this.txtOfficeTEL.Name = "txtOfficeTEL";
            this.txtOfficeTEL.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtOfficeTEL.Properties.MaxLength = 13;
            this.txtOfficeTEL.Size = new System.Drawing.Size(125, 18);
            this.txtOfficeTEL.TabIndex = 31;
            // 
            // txtXZZ_TEL
            // 
            this.txtXZZ_TEL.Location = new System.Drawing.Point(501, 236);
            this.txtXZZ_TEL.Name = "txtXZZ_TEL";
            this.txtXZZ_TEL.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtXZZ_TEL.Properties.MaxLength = 13;
            this.txtXZZ_TEL.Size = new System.Drawing.Size(100, 18);
            this.txtXZZ_TEL.TabIndex = 24;
            // 
            // txtContactTEL
            // 
            this.txtContactTEL.Location = new System.Drawing.Point(623, 327);
            this.txtContactTEL.Name = "txtContactTEL";
            this.txtContactTEL.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtContactTEL.Properties.MaxLength = 13;
            this.txtContactTEL.Size = new System.Drawing.Size(111, 18);
            this.txtContactTEL.TabIndex = 36;
            // 
            // txtXZZ_Post
            // 
            this.txtXZZ_Post.Location = new System.Drawing.Point(659, 236);
            this.txtXZZ_Post.Name = "txtXZZ_Post";
            this.txtXZZ_Post.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtXZZ_Post.Properties.MaxLength = 6;
            this.txtXZZ_Post.Size = new System.Drawing.Size(75, 18);
            this.txtXZZ_Post.TabIndex = 25;
            // 
            // txtHKDZ_Post
            // 
            this.txtHKDZ_Post.Location = new System.Drawing.Point(635, 267);
            this.txtHKDZ_Post.Name = "txtHKDZ_Post";
            this.txtHKDZ_Post.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtHKDZ_Post.Properties.MaxLength = 6;
            this.txtHKDZ_Post.Size = new System.Drawing.Size(100, 18);
            this.txtHKDZ_Post.TabIndex = 29;
            // 
            // txtOfficePost
            // 
            this.txtOfficePost.Location = new System.Drawing.Point(635, 300);
            this.txtOfficePost.Name = "txtOfficePost";
            this.txtOfficePost.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtOfficePost.Properties.MaxLength = 6;
            this.txtOfficePost.Size = new System.Drawing.Size(100, 18);
            this.txtOfficePost.TabIndex = 32;
            // 
            // hLineEx1
            // 
            this.hLineEx1.BackColor = System.Drawing.Color.White;
            this.hLineEx1.IsBold = true;
            this.hLineEx1.Location = new System.Drawing.Point(7, 115);
            this.hLineEx1.Name = "hLineEx1";
            this.hLineEx1.Size = new System.Drawing.Size(730, 2);
            this.hLineEx1.TabIndex = 110;
            this.hLineEx1.Text = "hLineEx1";
            // 
            // UCIemBasInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.txtOfficePost);
            this.Controls.Add(this.txtHKDZ_Post);
            this.Controls.Add(this.txtXZZ_Post);
            this.Controls.Add(this.txtContactTEL);
            this.Controls.Add(this.txtXZZ_TEL);
            this.Controls.Add(this.txtOfficeTEL);
            this.Controls.Add(this.seActualDays);
            this.Controls.Add(this.deBirth);
            this.Controls.Add(this.seInCount);
            this.Controls.Add(this.DevButtonSave1);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.lueMZXYZD_CODE);
            this.Controls.Add(this.lueMZZYZD_CODE);
            this.Controls.Add(this.lueMZXYZD_CODE1);
            this.Controls.Add(this.labelControl43);
            this.Controls.Add(this.labelControl38);
            this.Controls.Add(this.labelControl39);
            this.Controls.Add(this.lueOutHosWard);
            this.Controls.Add(this.labelControl40);
            this.Controls.Add(this.lueOutHosDept);
            this.Controls.Add(this.labelControl41);
            this.Controls.Add(this.teOutWardDate);
            this.Controls.Add(this.deOutWardDate);
            this.Controls.Add(this.labelControl42);
            this.Controls.Add(this.lueTransAdmitDept);
            this.Controls.Add(this.labelControl35);
            this.Controls.Add(this.lueAdmitWard);
            this.Controls.Add(this.labelControl31);
            this.Controls.Add(this.lueAdmitDept);
            this.Controls.Add(this.labelControl30);
            this.Controls.Add(this.teAdmitDate);
            this.Controls.Add(this.deAdmitDate);
            this.Controls.Add(this.labelControl29);
            this.Controls.Add(this.labelControl28);
            this.Controls.Add(this.txtContactAddress);
            this.Controls.Add(this.labelControl27);
            this.Controls.Add(this.lueMZZYZD_CODE1);
            this.Controls.Add(this.lueRelationship);
            this.Controls.Add(this.labelControl26);
            this.Controls.Add(this.txtContactPerson);
            this.Controls.Add(this.labelControl25);
            this.Controls.Add(this.labelControl22);
            this.Controls.Add(this.labelControl21);
            this.Controls.Add(this.labelControl20);
            this.Controls.Add(this.txtOfficePlace);
            this.Controls.Add(this.labelControl19);
            this.Controls.Add(this.txtIDNO);
            this.Controls.Add(this.labelControl18);
            this.Controls.Add(this.lueNationality);
            this.Controls.Add(this.labelControl17);
            this.Controls.Add(this.lueNation);
            this.Controls.Add(this.labelControl16);
            this.Controls.Add(this.lueCSD_ProvinceID);
            this.Controls.Add(this.labelControl12);
            this.Controls.Add(this.labelControl11);
            this.Controls.Add(this.labelControl10);
            this.Controls.Add(this.labelControl9);
            this.Controls.Add(this.labelControl8);
            this.Controls.Add(this.labelControl7);
            this.Controls.Add(this.txtSocialCare);
            this.Controls.Add(this.labelControl6);
            this.Controls.Add(this.labelControl4);
            this.Controls.Add(this.labelControl3);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.labelControl2);
            this.Controls.Add(this.txtPatNoOfHis);
            this.Controls.Add(this.labelControl1);
            this.Controls.Add(this.luePayId);
            this.Controls.Add(this.lueMarital);
            this.Controls.Add(this.lueJob);
            this.Controls.Add(this.lueSex);
            this.Controls.Add(this.txtAge);
            this.Controls.Add(this.hLineEx1);
            this.Controls.Add(this.labelLogoName);
            this.Controls.Add(this.labelHospitalName);
            this.Controls.Add(this.simpleButton1);
            this.Controls.Add(this.labelControl5);
            this.Controls.Add(this.txtCardNumber);
            this.Controls.Add(this.labelControl13);
            this.Controls.Add(this.labelControl14);
            this.Controls.Add(this.txtMonthAge);
            this.Controls.Add(this.labelControl15);
            this.Controls.Add(this.labelControl45);
            this.Controls.Add(this.txtWeight);
            this.Controls.Add(this.labelControl46);
            this.Controls.Add(this.labelControl47);
            this.Controls.Add(this.labelControl48);
            this.Controls.Add(this.txtInWeight);
            this.Controls.Add(this.labelControl49);
            this.Controls.Add(this.lueCSD_CityID);
            this.Controls.Add(this.labelControl50);
            this.Controls.Add(this.lueCSD_DistrictID);
            this.Controls.Add(this.labelControl51);
            this.Controls.Add(this.lueJG_ProvinceID);
            this.Controls.Add(this.lueJG_CityID);
            this.Controls.Add(this.labelControl52);
            this.Controls.Add(this.labelControl53);
            this.Controls.Add(this.labelControl54);
            this.Controls.Add(this.lueXZZ_ProvinceID);
            this.Controls.Add(this.lueXZZ_CityID);
            this.Controls.Add(this.lueXZZ_DistrictID);
            this.Controls.Add(this.labelControl55);
            this.Controls.Add(this.labelControl56);
            this.Controls.Add(this.labelControl57);
            this.Controls.Add(this.labelControl58);
            this.Controls.Add(this.lueHKDZ_ProvinceID);
            this.Controls.Add(this.lueHKDZ_CityID);
            this.Controls.Add(this.lueHKDZ_DistrictID);
            this.Controls.Add(this.labelControl59);
            this.Controls.Add(this.labelControl60);
            this.Controls.Add(this.labelControl61);
            this.Controls.Add(this.labelControl62);
            this.Controls.Add(this.labelControl63);
            this.Controls.Add(this.labelControl64);
            this.Controls.Add(this.labelControl24);
            this.Controls.Add(this.labelControl33);
            this.Controls.Add(this.labelControl37);
            this.Controls.Add(this.labelControl36);
            this.Controls.Add(this.labelControl34);
            this.Controls.Add(this.labelControl32);
            this.Controls.Add(this.labelControl23);
            this.Controls.Add(this.chkCURE_TYPE1);
            this.Controls.Add(this.labelControl65);
            this.Controls.Add(this.chkCURE_TYPE2);
            this.Controls.Add(this.chkBZSH2);
            this.Controls.Add(this.chkSSLCLJ1);
            this.Controls.Add(this.chkZYZLJS2);
            this.Controls.Add(this.chkInHosType1);
            this.Controls.Add(this.chkZYZLSB2);
            this.Controls.Add(this.chkBZSH1);
            this.Controls.Add(this.chkZYZJ2);
            this.Controls.Add(this.chkZYZLJS1);
            this.Controls.Add(this.chkSSLCLJ3);
            this.Controls.Add(this.chkZYZLSB1);
            this.Controls.Add(this.chkZYZJ1);
            this.Controls.Add(this.chkSSLCLJ2);
            this.Controls.Add(this.chkCURE_TYPE3);
            this.Controls.Add(this.chkInHosType2);
            this.Controls.Add(this.chkCURE_TYPE5);
            this.Controls.Add(this.chkCURE_TYPE4);
            this.Controls.Add(this.chkInHosType3);
            this.Controls.Add(this.chkInHosType4);
            this.Controls.Add(this.textEdit3);
            this.Name = "UCIemBasInfo";
            this.Size = new System.Drawing.Size(750, 670);
            this.Load += new System.EventHandler(this.UCIemBasInfo_Load);
            ((System.ComponentModel.ISupportInitialize)(this.teOutWardDate.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.teAdmitDate.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkInHosType1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkInHosType2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkInHosType3.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkInHosType4.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCURE_TYPE4.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCURE_TYPE3.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCURE_TYPE2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCURE_TYPE1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCURE_TYPE5.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkSSLCLJ2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkSSLCLJ1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkSSLCLJ3.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkZYZJ1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkZYZJ2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkZYZLSB1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkZYZLSB2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkZYZLJS1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkZYZLJS2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkBZSH1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkBZSH2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueMZXYZD_CODE1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueOutHosWard)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueOutHosDept)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueTransAdmitDept)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueAdmitWard)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueAdmitDept)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueMZZYZD_CODE1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueRelationship)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueNationality)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueNation)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueCSD_ProvinceID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.luePayId)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueMarital)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueJob)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueSex)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueCSD_CityID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueCSD_DistrictID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueJG_ProvinceID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueJG_CityID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueXZZ_ProvinceID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueXZZ_CityID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueXZZ_DistrictID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueHKDZ_ProvinceID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueHKDZ_CityID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueHKDZ_DistrictID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.seActualDays.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.deBirth.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.deBirth.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.seInCount.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.deOutWardDate.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.deOutWardDate.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.deAdmitDate.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.deAdmitDate.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtContactAddress.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtContactPerson.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtOfficePlace.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtIDNO.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSocialCare.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtName.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPatNoOfHis.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtAge.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCardNumber.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMonthAge.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtWeight.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtInWeight.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit3.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtOfficeTEL.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtXZZ_TEL.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtContactTEL.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtXZZ_Post.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtHKDZ_Post.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtOfficePost.Properties)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevExpress.XtraEditors.LabelControl labelControl38;
        private DevExpress.XtraEditors.LabelControl labelControl39;
        private DrectSoft.Common.Library.LookUpEditor lueOutHosWard;
        private DevExpress.XtraEditors.LabelControl labelControl40;
        private DrectSoft.Common.Library.LookUpEditor lueOutHosDept;
        private DevExpress.XtraEditors.LabelControl labelControl41;
        private DevExpress.XtraEditors.TimeEdit teOutWardDate;
        private DrectSoft.Common.Ctrs.OTHER.DSDateEdit deOutWardDate;
        private DevExpress.XtraEditors.LabelControl labelControl42;
        private DrectSoft.Common.Library.LookUpEditor lueTransAdmitDept;
        private DevExpress.XtraEditors.LabelControl labelControl35;
        private DrectSoft.Common.Library.LookUpEditor lueAdmitWard;
        private DevExpress.XtraEditors.LabelControl labelControl31;
        private DrectSoft.Common.Library.LookUpEditor lueAdmitDept;
        private DevExpress.XtraEditors.LabelControl labelControl30;
        private DevExpress.XtraEditors.TimeEdit teAdmitDate;
        private DrectSoft.Common.Ctrs.OTHER.DSDateEdit deAdmitDate;
        private DevExpress.XtraEditors.LabelControl labelControl29;
        private DevExpress.XtraEditors.LabelControl labelControl28;
        private DrectSoft.Common.Ctrs.OTHER.DSTextBox txtContactAddress;
        private DevExpress.XtraEditors.LabelControl labelControl27;
        private DrectSoft.Common.Library.LookUpEditor lueRelationship;
        private DevExpress.XtraEditors.LabelControl labelControl26;
        private DrectSoft.Common.Ctrs.OTHER.DSTextBox txtContactPerson;
        private DevExpress.XtraEditors.LabelControl labelControl25;
        private DevExpress.XtraEditors.LabelControl labelControl22;
        private DevExpress.XtraEditors.LabelControl labelControl21;
        private DevExpress.XtraEditors.LabelControl labelControl20;
        private DrectSoft.Common.Ctrs.OTHER.DSTextBox txtOfficePlace;
        private DevExpress.XtraEditors.LabelControl labelControl19;
        private DrectSoft.Common.Ctrs.OTHER.DSTextBox txtIDNO;
        private DevExpress.XtraEditors.LabelControl labelControl18;
        private DrectSoft.Common.Library.LookUpEditor lueNationality;
        private DevExpress.XtraEditors.LabelControl labelControl17;
        private DrectSoft.Common.Library.LookUpEditor lueNation;
        private DevExpress.XtraEditors.LabelControl labelControl16;
        private DrectSoft.Common.Library.LookUpEditor lueCSD_ProvinceID;
        private DevExpress.XtraEditors.LabelControl labelControl12;
        private DevExpress.XtraEditors.LabelControl labelControl11;
        private DevExpress.XtraEditors.LabelControl labelControl10;
        private DevExpress.XtraEditors.LabelControl labelControl9;
        private DevExpress.XtraEditors.LabelControl labelControl8;
        private DevExpress.XtraEditors.LabelControl labelControl7;
        private DrectSoft.Common.Ctrs.OTHER.DSTextBox txtSocialCare;
        private DevExpress.XtraEditors.LabelControl labelControl6;
        private DevExpress.XtraEditors.LabelControl labelControl4;
        private DevExpress.XtraEditors.LabelControl labelControl3;
        private DrectSoft.Common.Ctrs.OTHER.DSTextBox txtName;
        private DevExpress.XtraEditors.LabelControl labelControl2;
        private DrectSoft.Common.Ctrs.OTHER.DSTextBox txtPatNoOfHis;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private DrectSoft.Common.Library.LookUpEditor luePayId;
        private DrectSoft.Common.Library.LookUpEditor lueMarital;
        private DrectSoft.Common.Library.LookUpEditor lueJob;
        private DrectSoft.Common.Library.LookUpEditor lueSex;
        private DrectSoft.Common.Ctrs.OTHER.DSTextBox txtAge;
        private HLineEx hLineEx1;
        private DevExpress.XtraEditors.LabelControl labelLogoName;
        private DevExpress.XtraEditors.LabelControl labelHospitalName;
        private DevExpress.XtraEditors.SimpleButton simpleButton1;
        private DevExpress.XtraEditors.LabelControl labelControl5;
        private DrectSoft.Common.Ctrs.OTHER.DSTextBox txtCardNumber;
        private DevExpress.XtraEditors.LabelControl labelControl13;
        private DevExpress.XtraEditors.LabelControl labelControl14;
        private DrectSoft.Common.Ctrs.OTHER.DSTextBox txtMonthAge;
        private DevExpress.XtraEditors.LabelControl labelControl15;
        private DevExpress.XtraEditors.LabelControl labelControl45;
        private DrectSoft.Common.Ctrs.OTHER.DSTextBox txtWeight;
        private DevExpress.XtraEditors.LabelControl labelControl46;
        private DevExpress.XtraEditors.LabelControl labelControl47;
        private DevExpress.XtraEditors.LabelControl labelControl48;
        private DrectSoft.Common.Ctrs.OTHER.DSTextBox txtInWeight;
        private DevExpress.XtraEditors.LabelControl labelControl49;
        private Common.Library.LookUpEditor lueCSD_CityID;
        private DevExpress.XtraEditors.LabelControl labelControl50;
        private Common.Library.LookUpEditor lueCSD_DistrictID;
        private DevExpress.XtraEditors.LabelControl labelControl51;
        private Common.Library.LookUpEditor lueJG_ProvinceID;
        private Common.Library.LookUpEditor lueJG_CityID;
        private DevExpress.XtraEditors.LabelControl labelControl52;
        private DevExpress.XtraEditors.LabelControl labelControl53;
        private DevExpress.XtraEditors.LabelControl labelControl54;
        private Common.Library.LookUpEditor lueXZZ_ProvinceID;
        private Common.Library.LookUpEditor lueXZZ_CityID;
        private Common.Library.LookUpEditor lueXZZ_DistrictID;
        private DevExpress.XtraEditors.LabelControl labelControl55;
        private DevExpress.XtraEditors.LabelControl labelControl56;
        private DevExpress.XtraEditors.LabelControl labelControl57;
        private DevExpress.XtraEditors.LabelControl labelControl58;
        private Common.Library.LookUpEditor lueHKDZ_ProvinceID;
        private Common.Library.LookUpEditor lueHKDZ_CityID;
        private Common.Library.LookUpEditor lueHKDZ_DistrictID;
        private DevExpress.XtraEditors.LabelControl labelControl59;
        private DevExpress.XtraEditors.LabelControl labelControl60;
        private DevExpress.XtraEditors.LabelControl labelControl61;
        private DevExpress.XtraEditors.LabelControl labelControl62;
        private DevExpress.XtraEditors.LabelControl labelControl63;
        private DevExpress.XtraEditors.LabelControl labelControl64;
        private DevExpress.XtraEditors.LabelControl labelControl65;
        private DrectSoft.Common.Ctrs.OTHER.DSCheckEdit chkInHosType1;
        private DrectSoft.Common.Ctrs.OTHER.DSCheckEdit chkInHosType2;
        private DrectSoft.Common.Ctrs.OTHER.DSCheckEdit chkInHosType3;
        private DrectSoft.Common.Ctrs.OTHER.DSCheckEdit chkInHosType4;
        private DrectSoft.Common.Ctrs.OTHER.DSTextBox textEdit3;
        private DrectSoft.Common.Ctrs.OTHER.DSCheckEdit chkCURE_TYPE4;
        private DrectSoft.Common.Ctrs.OTHER.DSCheckEdit chkCURE_TYPE3;
        private DrectSoft.Common.Ctrs.OTHER.DSCheckEdit chkCURE_TYPE2;
        private DrectSoft.Common.Ctrs.OTHER.DSCheckEdit chkCURE_TYPE1;
        private DevExpress.XtraEditors.LabelControl labelControl23;
        private DrectSoft.Common.Ctrs.OTHER.DSCheckEdit chkCURE_TYPE5;
        private DevExpress.XtraEditors.LabelControl labelControl24;
        private Common.Library.LookUpEditor lueMZZYZD_CODE1;
        private DevExpress.XtraEditors.LabelControl labelControl32;
        private DrectSoft.Common.Ctrs.OTHER.DSCheckEdit chkSSLCLJ2;
        private DrectSoft.Common.Ctrs.OTHER.DSCheckEdit chkSSLCLJ1;
        private DrectSoft.Common.Ctrs.OTHER.DSCheckEdit chkSSLCLJ3;
        private DevExpress.XtraEditors.LabelControl labelControl33;
        private DrectSoft.Common.Ctrs.OTHER.DSCheckEdit chkZYZJ1;
        private DrectSoft.Common.Ctrs.OTHER.DSCheckEdit chkZYZJ2;
        private DevExpress.XtraEditors.LabelControl labelControl34;
        private DrectSoft.Common.Ctrs.OTHER.DSCheckEdit chkZYZLSB1;
        private DrectSoft.Common.Ctrs.OTHER.DSCheckEdit chkZYZLSB2;
        private DrectSoft.Common.Ctrs.OTHER.DSCheckEdit chkZYZLJS1;
        private DrectSoft.Common.Ctrs.OTHER.DSCheckEdit chkZYZLJS2;
        private DevExpress.XtraEditors.LabelControl labelControl36;
        private DrectSoft.Common.Ctrs.OTHER.DSCheckEdit chkBZSH1;
        private DrectSoft.Common.Ctrs.OTHER.DSCheckEdit chkBZSH2;
        private DevExpress.XtraEditors.LabelControl labelControl37;
        private Common.Library.LookUpEditor lueMZXYZD_CODE1;
        private DevExpress.XtraEditors.LabelControl labelControl43;
        private DevTextBoxAndButton.Bwj lueMZZYZD_CODE;
        private DevTextBoxAndButton.Bwj lueMZXYZD_CODE;
        private DrectSoft.Common.Ctrs.OTHER.DevButtonClose btnClose;
        private DrectSoft.Common.Ctrs.OTHER.DevButtonSave DevButtonSave1;
        private DrectSoft.Common.Ctrs.OTHER.DSSpinEdit seInCount;
        private DrectSoft.Common.Ctrs.OTHER.DSDateEdit deBirth;
        private DrectSoft.Common.Ctrs.OTHER.DSSpinEdit seActualDays;
        private DrectSoft.Common.Ctrs.OTHER.DevTextEditTel txtOfficeTEL;
        private DrectSoft.Common.Ctrs.OTHER.DevTextEditTel txtXZZ_TEL;
        private DrectSoft.Common.Ctrs.OTHER.DevTextEditTel txtContactTEL;
        private DrectSoft.Common.Ctrs.OTHER.DevTextEditPost txtXZZ_Post;
        private DrectSoft.Common.Ctrs.OTHER.DevTextEditPost txtHKDZ_Post;
        private DrectSoft.Common.Ctrs.OTHER.DevTextEditPost txtOfficePost;
    }
}
