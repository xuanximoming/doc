﻿namespace YidanSoft.Core.IEMMainPage
{
    partial class Print_UCIemBasInfo
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.txtAge = new DevExpress.XtraEditors.TextEdit();
            this.lueJob = new YidanSoft.Common.Library.LookUpEditor();
            this.luePayId = new YidanSoft.Common.Library.LookUpEditor();
            this.labelControl38 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl39 = new DevExpress.XtraEditors.LabelControl();
            this.lueOutHosWard = new YidanSoft.Common.Library.LookUpEditor();
            this.labelControl40 = new DevExpress.XtraEditors.LabelControl();
            this.lueOutHosDept = new YidanSoft.Common.Library.LookUpEditor();
            this.labelControl41 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl42 = new DevExpress.XtraEditors.LabelControl();
            this.lueTransAdmitDept = new YidanSoft.Common.Library.LookUpEditor();
            this.labelControl32 = new DevExpress.XtraEditors.LabelControl();
            this.lueAdmitWard = new YidanSoft.Common.Library.LookUpEditor();
            this.labelControl31 = new DevExpress.XtraEditors.LabelControl();
            this.lueAdmitDept = new YidanSoft.Common.Library.LookUpEditor();
            this.labelControl30 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl29 = new DevExpress.XtraEditors.LabelControl();
            this.txtContactTEL = new DevExpress.XtraEditors.TextEdit();
            this.labelControl28 = new DevExpress.XtraEditors.LabelControl();
            this.txtContactAddress = new DevExpress.XtraEditors.TextEdit();
            this.labelControl27 = new DevExpress.XtraEditors.LabelControl();
            this.lueRelationship = new YidanSoft.Common.Library.LookUpEditor();
            this.labelControl26 = new DevExpress.XtraEditors.LabelControl();
            this.txtContactPerson = new DevExpress.XtraEditors.TextEdit();
            this.labelControl25 = new DevExpress.XtraEditors.LabelControl();
            this.txtNativePost = new DevExpress.XtraEditors.TextEdit();
            this.labelControl23 = new DevExpress.XtraEditors.LabelControl();
            this.txtNativeTEL = new DevExpress.XtraEditors.TextEdit();
            this.labelControl24 = new DevExpress.XtraEditors.LabelControl();
            this.txtNativeAddress = new DevExpress.XtraEditors.TextEdit();
            this.labelControl22 = new DevExpress.XtraEditors.LabelControl();
            this.txtOfficePost = new DevExpress.XtraEditors.TextEdit();
            this.labelControl21 = new DevExpress.XtraEditors.LabelControl();
            this.txtOfficeTEL = new DevExpress.XtraEditors.TextEdit();
            this.labelControl20 = new DevExpress.XtraEditors.LabelControl();
            this.txtOfficePlace = new DevExpress.XtraEditors.TextEdit();
            this.labelControl19 = new DevExpress.XtraEditors.LabelControl();
            this.txtIDNO = new DevExpress.XtraEditors.TextEdit();
            this.labelControl18 = new DevExpress.XtraEditors.LabelControl();
            this.lueNationality = new YidanSoft.Common.Library.LookUpEditor();
            this.labelControl17 = new DevExpress.XtraEditors.LabelControl();
            this.lueNation = new YidanSoft.Common.Library.LookUpEditor();
            this.labelControl16 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl11 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl10 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl9 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl8 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl7 = new DevExpress.XtraEditors.LabelControl();
            this.txtSocialCare = new DevExpress.XtraEditors.TextEdit();
            this.labelControl5 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl6 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl4 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl3 = new DevExpress.XtraEditors.LabelControl();
            this.txtName = new DevExpress.XtraEditors.TextEdit();
            this.labelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.txtPatNoOfHis = new DevExpress.XtraEditors.TextEdit();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.labelLogoName = new DevExpress.XtraEditors.LabelControl();
            this.labelHospitalName = new DevExpress.XtraEditors.LabelControl();
            this.hLineEx1 = new YidanSoft.Core.IEMMainPage.HLineEx();
            this.lueSex = new DevExpress.XtraEditors.LabelControl();
            this.labelControl13 = new DevExpress.XtraEditors.LabelControl();
            this.deBirth = new DevExpress.XtraEditors.TextEdit();
            this.lueMarital = new DevExpress.XtraEditors.LabelControl();
            this.labelControl14 = new DevExpress.XtraEditors.LabelControl();
            this.txtAdmitWardDate = new DevExpress.XtraEditors.TextEdit();
            this.txtOutWardDate = new DevExpress.XtraEditors.TextEdit();
            this.seActualDays = new DevExpress.XtraEditors.TextEdit();
            this.seInCount = new DevExpress.XtraEditors.TextEdit();
            this.lueCounty = new YidanSoft.Common.Library.LookUpEditor();
            this.labelControl33 = new DevExpress.XtraEditors.LabelControl();
            ((System.ComponentModel.ISupportInitialize)(this.txtAge.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueJob)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.luePayId)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueOutHosWard)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueOutHosDept)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueTransAdmitDept)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueAdmitWard)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueAdmitDept)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtContactTEL.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtContactAddress.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueRelationship)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtContactPerson.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtNativePost.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtNativeTEL.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtNativeAddress.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtOfficePost.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtOfficeTEL.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtOfficePlace.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtIDNO.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueNationality)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueNation)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSocialCare.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtName.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPatNoOfHis.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.deBirth.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtAdmitWardDate.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtOutWardDate.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.seActualDays.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.seInCount.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueCounty)).BeginInit();
            this.SuspendLayout();
            // 
            // txtAge
            // 
            this.txtAge.Enabled = false;
            this.txtAge.Location = new System.Drawing.Point(436, 129);
            this.txtAge.Name = "txtAge";
            this.txtAge.Properties.AppearanceDisabled.BackColor = System.Drawing.Color.White;
            this.txtAge.Properties.AppearanceDisabled.BackColor2 = System.Drawing.Color.White;
            this.txtAge.Properties.AppearanceDisabled.Options.UseBackColor = true;
            this.txtAge.Properties.AppearanceReadOnly.BackColor = System.Drawing.Color.White;
            this.txtAge.Properties.AppearanceReadOnly.BackColor2 = System.Drawing.Color.White;
            this.txtAge.Properties.AppearanceReadOnly.Options.UseBackColor = true;
            this.txtAge.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtAge.Size = new System.Drawing.Size(28, 19);
            this.txtAge.TabIndex = 8;
            // 
            // lueJob
            // 
            this.lueJob.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lueJob.Kind = YidanSoft.Wordbook.WordbookKind.Sql;
            this.lueJob.ListWindow = null;
            this.lueJob.Location = new System.Drawing.Point(55, 156);
            this.lueJob.Name = "lueJob";
            this.lueJob.ShowSButton = true;
            this.lueJob.Size = new System.Drawing.Size(68, 19);
            this.lueJob.TabIndex = 10;
            // 
            // luePayId
            // 
            this.luePayId.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.luePayId.Kind = YidanSoft.Wordbook.WordbookKind.Sql;
            this.luePayId.ListWindow = null;
            this.luePayId.Location = new System.Drawing.Point(116, 88);
            this.luePayId.Name = "luePayId";
            this.luePayId.ShowSButton = true;
            this.luePayId.Size = new System.Drawing.Size(89, 19);
            this.luePayId.TabIndex = 1;
            // 
            // labelControl38
            // 
            this.labelControl38.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl38.Location = new System.Drawing.Point(632, 293);
            this.labelControl38.Name = "labelControl38";
            this.labelControl38.Size = new System.Drawing.Size(12, 14);
            this.labelControl38.TabIndex = 80;
            this.labelControl38.Text = "天";
            // 
            // labelControl39
            // 
            this.labelControl39.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl39.Location = new System.Drawing.Point(510, 293);
            this.labelControl39.Name = "labelControl39";
            this.labelControl39.Size = new System.Drawing.Size(48, 14);
            this.labelControl39.TabIndex = 78;
            this.labelControl39.Text = "实际住院";
            // 
            // lueOutHosWard
            // 
            this.lueOutHosWard.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lueOutHosWard.Kind = YidanSoft.Wordbook.WordbookKind.Sql;
            this.lueOutHosWard.ListWindow = null;
            this.lueOutHosWard.Location = new System.Drawing.Point(419, 290);
            this.lueOutHosWard.Name = "lueOutHosWard";
            this.lueOutHosWard.ShowSButton = true;
            this.lueOutHosWard.Size = new System.Drawing.Size(79, 19);
            this.lueOutHosWard.TabIndex = 39;
            // 
            // labelControl40
            // 
            this.labelControl40.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl40.Location = new System.Drawing.Point(393, 293);
            this.labelControl40.Name = "labelControl40";
            this.labelControl40.Size = new System.Drawing.Size(24, 14);
            this.labelControl40.TabIndex = 76;
            this.labelControl40.Text = "病区";
            // 
            // lueOutHosDept
            // 
            this.lueOutHosDept.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lueOutHosDept.Kind = YidanSoft.Wordbook.WordbookKind.Sql;
            this.lueOutHosDept.ListWindow = null;
            this.lueOutHosDept.Location = new System.Drawing.Point(306, 290);
            this.lueOutHosDept.Name = "lueOutHosDept";
            this.lueOutHosDept.ShowSButton = true;
            this.lueOutHosDept.Size = new System.Drawing.Size(79, 19);
            this.lueOutHosDept.TabIndex = 38;
            // 
            // labelControl41
            // 
            this.labelControl41.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl41.Location = new System.Drawing.Point(253, 293);
            this.labelControl41.Name = "labelControl41";
            this.labelControl41.Size = new System.Drawing.Size(48, 14);
            this.labelControl41.TabIndex = 74;
            this.labelControl41.Text = "出院科别";
            // 
            // labelControl42
            // 
            this.labelControl42.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl42.Location = new System.Drawing.Point(25, 293);
            this.labelControl42.Name = "labelControl42";
            this.labelControl42.Size = new System.Drawing.Size(48, 14);
            this.labelControl42.TabIndex = 72;
            this.labelControl42.Text = "出院日期";
            // 
            // lueTransAdmitDept
            // 
            this.lueTransAdmitDept.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lueTransAdmitDept.Kind = YidanSoft.Wordbook.WordbookKind.Sql;
            this.lueTransAdmitDept.ListWindow = null;
            this.lueTransAdmitDept.Location = new System.Drawing.Point(563, 260);
            this.lueTransAdmitDept.Name = "lueTransAdmitDept";
            this.lueTransAdmitDept.ShowSButton = true;
            this.lueTransAdmitDept.Size = new System.Drawing.Size(94, 19);
            this.lueTransAdmitDept.TabIndex = 33;
            // 
            // labelControl32
            // 
            this.labelControl32.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl32.Location = new System.Drawing.Point(509, 263);
            this.labelControl32.Name = "labelControl32";
            this.labelControl32.Size = new System.Drawing.Size(48, 14);
            this.labelControl32.TabIndex = 61;
            this.labelControl32.Text = "转科科别";
            // 
            // lueAdmitWard
            // 
            this.lueAdmitWard.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lueAdmitWard.Kind = YidanSoft.Wordbook.WordbookKind.Sql;
            this.lueAdmitWard.ListWindow = null;
            this.lueAdmitWard.Location = new System.Drawing.Point(419, 260);
            this.lueAdmitWard.Name = "lueAdmitWard";
            this.lueAdmitWard.ShowSButton = true;
            this.lueAdmitWard.Size = new System.Drawing.Size(79, 19);
            this.lueAdmitWard.TabIndex = 29;
            // 
            // labelControl31
            // 
            this.labelControl31.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl31.Location = new System.Drawing.Point(392, 263);
            this.labelControl31.Name = "labelControl31";
            this.labelControl31.Size = new System.Drawing.Size(24, 14);
            this.labelControl31.TabIndex = 59;
            this.labelControl31.Text = "病区";
            // 
            // lueAdmitDept
            // 
            this.lueAdmitDept.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lueAdmitDept.Kind = YidanSoft.Wordbook.WordbookKind.Sql;
            this.lueAdmitDept.ListWindow = null;
            this.lueAdmitDept.Location = new System.Drawing.Point(305, 260);
            this.lueAdmitDept.Name = "lueAdmitDept";
            this.lueAdmitDept.ShowSButton = true;
            this.lueAdmitDept.Size = new System.Drawing.Size(79, 19);
            this.lueAdmitDept.TabIndex = 28;
            // 
            // labelControl30
            // 
            this.labelControl30.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl30.Location = new System.Drawing.Point(253, 263);
            this.labelControl30.Name = "labelControl30";
            this.labelControl30.Size = new System.Drawing.Size(48, 14);
            this.labelControl30.TabIndex = 57;
            this.labelControl30.Text = "入院科别";
            // 
            // labelControl29
            // 
            this.labelControl29.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl29.Location = new System.Drawing.Point(22, 263);
            this.labelControl29.Name = "labelControl29";
            this.labelControl29.Size = new System.Drawing.Size(48, 14);
            this.labelControl29.TabIndex = 53;
            this.labelControl29.Text = "入院日期";
            // 
            // txtContactTEL
            // 
            this.txtContactTEL.EditValue = "";
            this.txtContactTEL.Location = new System.Drawing.Point(534, 235);
            this.txtContactTEL.Name = "txtContactTEL";
            this.txtContactTEL.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtContactTEL.Size = new System.Drawing.Size(123, 19);
            this.txtContactTEL.TabIndex = 25;
            // 
            // labelControl28
            // 
            this.labelControl28.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl28.Location = new System.Drawing.Point(504, 237);
            this.labelControl28.Name = "labelControl28";
            this.labelControl28.Size = new System.Drawing.Size(24, 14);
            this.labelControl28.TabIndex = 51;
            this.labelControl28.Text = "电话";
            // 
            // txtContactAddress
            // 
            this.txtContactAddress.EditValue = "";
            this.txtContactAddress.Location = new System.Drawing.Point(306, 235);
            this.txtContactAddress.Name = "txtContactAddress";
            this.txtContactAddress.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtContactAddress.Size = new System.Drawing.Size(194, 19);
            this.txtContactAddress.TabIndex = 24;
            // 
            // labelControl27
            // 
            this.labelControl27.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl27.Location = new System.Drawing.Point(269, 237);
            this.labelControl27.Name = "labelControl27";
            this.labelControl27.Size = new System.Drawing.Size(24, 14);
            this.labelControl27.TabIndex = 49;
            this.labelControl27.Text = "地址";
            // 
            // lueRelationship
            // 
            this.lueRelationship.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lueRelationship.Kind = YidanSoft.Wordbook.WordbookKind.Sql;
            this.lueRelationship.ListWindow = null;
            this.lueRelationship.Location = new System.Drawing.Point(185, 234);
            this.lueRelationship.Name = "lueRelationship";
            this.lueRelationship.ShowSButton = true;
            this.lueRelationship.Size = new System.Drawing.Size(78, 19);
            this.lueRelationship.TabIndex = 23;
            // 
            // labelControl26
            // 
            this.labelControl26.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl26.Location = new System.Drawing.Point(155, 237);
            this.labelControl26.Name = "labelControl26";
            this.labelControl26.Size = new System.Drawing.Size(24, 14);
            this.labelControl26.TabIndex = 47;
            this.labelControl26.Text = "关系";
            // 
            // txtContactPerson
            // 
            this.txtContactPerson.EditValue = "";
            this.txtContactPerson.Location = new System.Drawing.Point(88, 235);
            this.txtContactPerson.Name = "txtContactPerson";
            this.txtContactPerson.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtContactPerson.Size = new System.Drawing.Size(67, 19);
            this.txtContactPerson.TabIndex = 22;
            // 
            // labelControl25
            // 
            this.labelControl25.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl25.Location = new System.Drawing.Point(22, 237);
            this.labelControl25.Name = "labelControl25";
            this.labelControl25.Size = new System.Drawing.Size(60, 14);
            this.labelControl25.TabIndex = 45;
            this.labelControl25.Text = "联系人姓名";
            // 
            // txtNativePost
            // 
            this.txtNativePost.EditValue = "";
            this.txtNativePost.Location = new System.Drawing.Point(534, 210);
            this.txtNativePost.Name = "txtNativePost";
            this.txtNativePost.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtNativePost.Size = new System.Drawing.Size(123, 19);
            this.txtNativePost.TabIndex = 21;
            // 
            // labelControl23
            // 
            this.labelControl23.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl23.Location = new System.Drawing.Point(480, 212);
            this.labelControl23.Name = "labelControl23";
            this.labelControl23.Size = new System.Drawing.Size(48, 14);
            this.labelControl23.TabIndex = 43;
            this.labelControl23.Text = "邮政编码";
            // 
            // txtNativeTEL
            // 
            this.txtNativeTEL.EditValue = "";
            this.txtNativeTEL.Location = new System.Drawing.Point(372, 210);
            this.txtNativeTEL.Name = "txtNativeTEL";
            this.txtNativeTEL.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtNativeTEL.Size = new System.Drawing.Size(102, 19);
            this.txtNativeTEL.TabIndex = 20;
            // 
            // labelControl24
            // 
            this.labelControl24.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl24.Location = new System.Drawing.Point(342, 212);
            this.labelControl24.Name = "labelControl24";
            this.labelControl24.Size = new System.Drawing.Size(24, 14);
            this.labelControl24.TabIndex = 41;
            this.labelControl24.Text = "电话";
            // 
            // txtNativeAddress
            // 
            this.txtNativeAddress.EditValue = "";
            this.txtNativeAddress.Location = new System.Drawing.Point(76, 210);
            this.txtNativeAddress.Name = "txtNativeAddress";
            this.txtNativeAddress.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtNativeAddress.Size = new System.Drawing.Size(262, 19);
            this.txtNativeAddress.TabIndex = 19;
            // 
            // labelControl22
            // 
            this.labelControl22.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl22.Location = new System.Drawing.Point(22, 210);
            this.labelControl22.Name = "labelControl22";
            this.labelControl22.Size = new System.Drawing.Size(48, 14);
            this.labelControl22.TabIndex = 39;
            this.labelControl22.Text = "户口地址";
            // 
            // txtOfficePost
            // 
            this.txtOfficePost.EditValue = "";
            this.txtOfficePost.Location = new System.Drawing.Point(534, 185);
            this.txtOfficePost.Name = "txtOfficePost";
            this.txtOfficePost.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtOfficePost.Size = new System.Drawing.Size(123, 19);
            this.txtOfficePost.TabIndex = 18;
            // 
            // labelControl21
            // 
            this.labelControl21.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl21.Location = new System.Drawing.Point(480, 187);
            this.labelControl21.Name = "labelControl21";
            this.labelControl21.Size = new System.Drawing.Size(48, 14);
            this.labelControl21.TabIndex = 37;
            this.labelControl21.Text = "邮政编码";
            // 
            // txtOfficeTEL
            // 
            this.txtOfficeTEL.EditValue = "";
            this.txtOfficeTEL.Location = new System.Drawing.Point(372, 185);
            this.txtOfficeTEL.Name = "txtOfficeTEL";
            this.txtOfficeTEL.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtOfficeTEL.Size = new System.Drawing.Size(102, 19);
            this.txtOfficeTEL.TabIndex = 17;
            // 
            // labelControl20
            // 
            this.labelControl20.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl20.Location = new System.Drawing.Point(342, 187);
            this.labelControl20.Name = "labelControl20";
            this.labelControl20.Size = new System.Drawing.Size(24, 14);
            this.labelControl20.TabIndex = 35;
            this.labelControl20.Text = "电话";
            // 
            // txtOfficePlace
            // 
            this.txtOfficePlace.EditValue = "";
            this.txtOfficePlace.Location = new System.Drawing.Point(116, 185);
            this.txtOfficePlace.Name = "txtOfficePlace";
            this.txtOfficePlace.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtOfficePlace.Size = new System.Drawing.Size(222, 19);
            this.txtOfficePlace.TabIndex = 16;
            // 
            // labelControl19
            // 
            this.labelControl19.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl19.Location = new System.Drawing.Point(22, 183);
            this.labelControl19.Name = "labelControl19";
            this.labelControl19.Size = new System.Drawing.Size(84, 14);
            this.labelControl19.TabIndex = 33;
            this.labelControl19.Text = "工作单位及地址";
            // 
            // txtIDNO
            // 
            this.txtIDNO.EditValue = "";
            this.txtIDNO.Location = new System.Drawing.Point(534, 156);
            this.txtIDNO.Name = "txtIDNO";
            this.txtIDNO.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtIDNO.Size = new System.Drawing.Size(123, 19);
            this.txtIDNO.TabIndex = 15;
            // 
            // labelControl18
            // 
            this.labelControl18.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl18.Location = new System.Drawing.Point(480, 158);
            this.labelControl18.Name = "labelControl18";
            this.labelControl18.Size = new System.Drawing.Size(48, 14);
            this.labelControl18.TabIndex = 31;
            this.labelControl18.Text = "身份证号";
            // 
            // lueNationality
            // 
            this.lueNationality.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lueNationality.Kind = YidanSoft.Wordbook.WordbookKind.Sql;
            this.lueNationality.ListWindow = null;
            this.lueNationality.Location = new System.Drawing.Point(436, 156);
            this.lueNationality.Name = "lueNationality";
            this.lueNationality.ShowSButton = true;
            this.lueNationality.Size = new System.Drawing.Size(41, 19);
            this.lueNationality.TabIndex = 14;
            // 
            // labelControl17
            // 
            this.labelControl17.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl17.Location = new System.Drawing.Point(406, 158);
            this.labelControl17.Name = "labelControl17";
            this.labelControl17.Size = new System.Drawing.Size(24, 14);
            this.labelControl17.TabIndex = 29;
            this.labelControl17.Text = "国籍";
            // 
            // lueNation
            // 
            this.lueNation.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lueNation.Kind = YidanSoft.Wordbook.WordbookKind.Sql;
            this.lueNation.ListWindow = null;
            this.lueNation.Location = new System.Drawing.Point(316, 156);
            this.lueNation.Name = "lueNation";
            this.lueNation.ShowSButton = true;
            this.lueNation.Size = new System.Drawing.Size(84, 19);
            this.lueNation.TabIndex = 13;
            // 
            // labelControl16
            // 
            this.labelControl16.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl16.Location = new System.Drawing.Point(291, 158);
            this.labelControl16.Name = "labelControl16";
            this.labelControl16.Size = new System.Drawing.Size(24, 14);
            this.labelControl16.TabIndex = 27;
            this.labelControl16.Text = "民族";
            // 
            // labelControl11
            // 
            this.labelControl11.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl11.Location = new System.Drawing.Point(22, 158);
            this.labelControl11.Name = "labelControl11";
            this.labelControl11.Size = new System.Drawing.Size(24, 14);
            this.labelControl11.TabIndex = 18;
            this.labelControl11.Text = "职业";
            // 
            // labelControl10
            // 
            this.labelControl10.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl10.Location = new System.Drawing.Point(470, 131);
            this.labelControl10.Name = "labelControl10";
            this.labelControl10.Size = new System.Drawing.Size(24, 14);
            this.labelControl10.TabIndex = 16;
            this.labelControl10.Text = "婚姻";
            // 
            // labelControl9
            // 
            this.labelControl9.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl9.Location = new System.Drawing.Point(406, 131);
            this.labelControl9.Name = "labelControl9";
            this.labelControl9.Size = new System.Drawing.Size(24, 14);
            this.labelControl9.TabIndex = 14;
            this.labelControl9.Text = "年龄";
            // 
            // labelControl8
            // 
            this.labelControl8.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl8.Location = new System.Drawing.Point(237, 131);
            this.labelControl8.Name = "labelControl8";
            this.labelControl8.Size = new System.Drawing.Size(24, 14);
            this.labelControl8.TabIndex = 12;
            this.labelControl8.Text = "出生";
            // 
            // labelControl7
            // 
            this.labelControl7.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl7.Location = new System.Drawing.Point(129, 131);
            this.labelControl7.Name = "labelControl7";
            this.labelControl7.Size = new System.Drawing.Size(24, 14);
            this.labelControl7.TabIndex = 10;
            this.labelControl7.Text = "性别";
            // 
            // txtSocialCare
            // 
            this.txtSocialCare.EditValue = "";
            this.txtSocialCare.Enabled = false;
            this.txtSocialCare.Location = new System.Drawing.Point(116, 63);
            this.txtSocialCare.Name = "txtSocialCare";
            this.txtSocialCare.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtSocialCare.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSocialCare.Properties.Appearance.Options.UseBackColor = true;
            this.txtSocialCare.Properties.Appearance.Options.UseFont = true;
            this.txtSocialCare.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtSocialCare.Size = new System.Drawing.Size(71, 19);
            this.txtSocialCare.TabIndex = 2;
            this.txtSocialCare.Visible = false;
            // 
            // labelControl5
            // 
            this.labelControl5.Appearance.ForeColor = System.Drawing.Color.Red;
            this.labelControl5.Location = new System.Drawing.Point(21, 65);
            this.labelControl5.Name = "labelControl5";
            this.labelControl5.Size = new System.Drawing.Size(94, 14);
            this.labelControl5.TabIndex = 9;
            this.labelControl5.Text = "医疗保险(公费)号";
            this.labelControl5.Visible = false;
            // 
            // labelControl6
            // 
            this.labelControl6.Appearance.ForeColor = System.Drawing.Color.Red;
            this.labelControl6.Location = new System.Drawing.Point(25, 91);
            this.labelControl6.Name = "labelControl6";
            this.labelControl6.Size = new System.Drawing.Size(72, 14);
            this.labelControl6.TabIndex = 7;
            this.labelControl6.Text = "医疗付款方式";
            // 
            // labelControl4
            // 
            this.labelControl4.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl4.Location = new System.Drawing.Point(356, 91);
            this.labelControl4.Name = "labelControl4";
            this.labelControl4.Size = new System.Drawing.Size(36, 14);
            this.labelControl4.TabIndex = 6;
            this.labelControl4.Text = "次入院";
            // 
            // labelControl3
            // 
            this.labelControl3.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl3.Location = new System.Drawing.Point(275, 91);
            this.labelControl3.Name = "labelControl3";
            this.labelControl3.Size = new System.Drawing.Size(12, 14);
            this.labelControl3.TabIndex = 4;
            this.labelControl3.Text = "第";
            // 
            // txtName
            // 
            this.txtName.Enabled = false;
            this.txtName.Location = new System.Drawing.Point(55, 129);
            this.txtName.Name = "txtName";
            this.txtName.Properties.AppearanceDisabled.BackColor = System.Drawing.Color.White;
            this.txtName.Properties.AppearanceDisabled.BackColor2 = System.Drawing.Color.White;
            this.txtName.Properties.AppearanceDisabled.Options.UseBackColor = true;
            this.txtName.Properties.AppearanceReadOnly.BackColor = System.Drawing.Color.White;
            this.txtName.Properties.AppearanceReadOnly.BackColor2 = System.Drawing.Color.White;
            this.txtName.Properties.AppearanceReadOnly.Options.UseBackColor = true;
            this.txtName.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtName.Size = new System.Drawing.Size(66, 19);
            this.txtName.TabIndex = 5;
            // 
            // labelControl2
            // 
            this.labelControl2.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl2.Location = new System.Drawing.Point(22, 131);
            this.labelControl2.Name = "labelControl2";
            this.labelControl2.Size = new System.Drawing.Size(24, 14);
            this.labelControl2.TabIndex = 2;
            this.labelControl2.Text = "姓名";
            // 
            // txtPatNoOfHis
            // 
            this.txtPatNoOfHis.Enabled = false;
            this.txtPatNoOfHis.Location = new System.Drawing.Point(516, 89);
            this.txtPatNoOfHis.Name = "txtPatNoOfHis";
            this.txtPatNoOfHis.Properties.AppearanceDisabled.BackColor = System.Drawing.Color.White;
            this.txtPatNoOfHis.Properties.AppearanceDisabled.BackColor2 = System.Drawing.Color.White;
            this.txtPatNoOfHis.Properties.AppearanceDisabled.Options.UseBackColor = true;
            this.txtPatNoOfHis.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtPatNoOfHis.Size = new System.Drawing.Size(147, 19);
            this.txtPatNoOfHis.TabIndex = 4;
            // 
            // labelControl1
            // 
            this.labelControl1.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl1.Location = new System.Drawing.Point(470, 91);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(40, 14);
            this.labelControl1.TabIndex = 0;
            this.labelControl1.Text = "病案号:";
            // 
            // labelLogoName
            // 
            this.labelLogoName.Appearance.Font = new System.Drawing.Font("华文楷体", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labelLogoName.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelLogoName.Location = new System.Drawing.Point(231, 46);
            this.labelLogoName.Name = "labelLogoName";
            this.labelLogoName.Size = new System.Drawing.Size(220, 33);
            this.labelLogoName.TabIndex = 111;
            this.labelLogoName.Text = "住 院 病 案 首 页";
            // 
            // labelHospitalName
            // 
            this.labelHospitalName.Appearance.Font = new System.Drawing.Font("宋体", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labelHospitalName.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelHospitalName.Location = new System.Drawing.Point(253, 19);
            this.labelHospitalName.Name = "labelHospitalName";
            this.labelHospitalName.Size = new System.Drawing.Size(161, 21);
            this.labelHospitalName.TabIndex = 112;
            this.labelHospitalName.Text = "*******人民医院";
            // 
            // hLineEx1
            // 
            this.hLineEx1.BackColor = System.Drawing.Color.White;
            this.hLineEx1.IsBold = true;
            this.hLineEx1.Location = new System.Drawing.Point(5, 115);
            this.hLineEx1.Name = "hLineEx1";
            this.hLineEx1.Size = new System.Drawing.Size(658, 2);
            this.hLineEx1.TabIndex = 110;
            this.hLineEx1.Text = "hLineEx1";
            // 
            // lueSex
            // 
            this.lueSex.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Office2003;
            this.lueSex.Location = new System.Drawing.Point(159, 130);
            this.lueSex.Name = "lueSex";
            this.lueSex.Size = new System.Drawing.Size(14, 16);
            this.lueSex.TabIndex = 114;
            this.lueSex.Text = "   ";
            // 
            // labelControl13
            // 
            this.labelControl13.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl13.Location = new System.Drawing.Point(179, 131);
            this.labelControl13.Name = "labelControl13";
            this.labelControl13.Size = new System.Drawing.Size(50, 14);
            this.labelControl13.TabIndex = 12;
            this.labelControl13.Text = "1.男 2.女";
            // 
            // deBirth
            // 
            this.deBirth.Enabled = false;
            this.deBirth.Location = new System.Drawing.Point(266, 129);
            this.deBirth.Name = "deBirth";
            this.deBirth.Properties.AppearanceDisabled.BackColor = System.Drawing.Color.White;
            this.deBirth.Properties.AppearanceDisabled.BackColor2 = System.Drawing.Color.White;
            this.deBirth.Properties.AppearanceDisabled.Options.UseBackColor = true;
            this.deBirth.Properties.AppearanceReadOnly.BackColor = System.Drawing.Color.White;
            this.deBirth.Properties.AppearanceReadOnly.BackColor2 = System.Drawing.Color.White;
            this.deBirth.Properties.AppearanceReadOnly.Options.UseBackColor = true;
            this.deBirth.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.deBirth.Size = new System.Drawing.Size(134, 19);
            this.deBirth.TabIndex = 8;
            // 
            // lueMarital
            // 
            this.lueMarital.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Office2003;
            this.lueMarital.Location = new System.Drawing.Point(499, 130);
            this.lueMarital.Name = "lueMarital";
            this.lueMarital.Size = new System.Drawing.Size(14, 16);
            this.lueMarital.TabIndex = 114;
            this.lueMarital.Text = "   ";
            // 
            // labelControl14
            // 
            this.labelControl14.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl14.Location = new System.Drawing.Point(514, 131);
            this.labelControl14.Name = "labelControl14";
            this.labelControl14.Size = new System.Drawing.Size(143, 14);
            this.labelControl14.TabIndex = 16;
            this.labelControl14.Text = "1.未 2.已 3.离 4.丧 5.其他";
            // 
            // txtAdmitWardDate
            // 
            this.txtAdmitWardDate.Enabled = false;
            this.txtAdmitWardDate.Location = new System.Drawing.Point(81, 261);
            this.txtAdmitWardDate.Name = "txtAdmitWardDate";
            this.txtAdmitWardDate.Properties.AppearanceDisabled.BackColor = System.Drawing.Color.White;
            this.txtAdmitWardDate.Properties.AppearanceDisabled.BackColor2 = System.Drawing.Color.White;
            this.txtAdmitWardDate.Properties.AppearanceDisabled.Options.UseBackColor = true;
            this.txtAdmitWardDate.Properties.AppearanceReadOnly.BackColor = System.Drawing.Color.White;
            this.txtAdmitWardDate.Properties.AppearanceReadOnly.BackColor2 = System.Drawing.Color.White;
            this.txtAdmitWardDate.Properties.AppearanceReadOnly.Options.UseBackColor = true;
            this.txtAdmitWardDate.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtAdmitWardDate.Size = new System.Drawing.Size(166, 19);
            this.txtAdmitWardDate.TabIndex = 8;
            // 
            // txtOutWardDate
            // 
            this.txtOutWardDate.Enabled = false;
            this.txtOutWardDate.Location = new System.Drawing.Point(81, 291);
            this.txtOutWardDate.Name = "txtOutWardDate";
            this.txtOutWardDate.Properties.AppearanceDisabled.BackColor = System.Drawing.Color.White;
            this.txtOutWardDate.Properties.AppearanceDisabled.BackColor2 = System.Drawing.Color.White;
            this.txtOutWardDate.Properties.AppearanceDisabled.Options.UseBackColor = true;
            this.txtOutWardDate.Properties.AppearanceReadOnly.BackColor = System.Drawing.Color.White;
            this.txtOutWardDate.Properties.AppearanceReadOnly.BackColor2 = System.Drawing.Color.White;
            this.txtOutWardDate.Properties.AppearanceReadOnly.Options.UseBackColor = true;
            this.txtOutWardDate.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtOutWardDate.Size = new System.Drawing.Size(166, 19);
            this.txtOutWardDate.TabIndex = 8;
            // 
            // seActualDays
            // 
            this.seActualDays.EditValue = "";
            this.seActualDays.Location = new System.Drawing.Point(563, 291);
            this.seActualDays.Name = "seActualDays";
            this.seActualDays.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.seActualDays.Size = new System.Drawing.Size(63, 19);
            this.seActualDays.TabIndex = 25;
            // 
            // seInCount
            // 
            this.seInCount.Enabled = false;
            this.seInCount.Location = new System.Drawing.Point(291, 89);
            this.seInCount.Name = "seInCount";
            this.seInCount.Properties.AppearanceDisabled.BackColor = System.Drawing.Color.White;
            this.seInCount.Properties.AppearanceDisabled.BackColor2 = System.Drawing.Color.White;
            this.seInCount.Properties.AppearanceDisabled.Options.UseBackColor = true;
            this.seInCount.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.seInCount.Size = new System.Drawing.Size(62, 19);
            this.seInCount.TabIndex = 4;
            // 
            // lueCounty
            // 
            this.lueCounty.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lueCounty.Kind = YidanSoft.Wordbook.WordbookKind.Sql;
            this.lueCounty.ListWindow = null;
            this.lueCounty.Location = new System.Drawing.Point(171, 156);
            this.lueCounty.Name = "lueCounty";
            this.lueCounty.ShowSButton = true;
            this.lueCounty.Size = new System.Drawing.Size(109, 19);
            this.lueCounty.TabIndex = 116;
            // 
            // labelControl33
            // 
            this.labelControl33.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl33.Location = new System.Drawing.Point(129, 158);
            this.labelControl33.Name = "labelControl33";
            this.labelControl33.Size = new System.Drawing.Size(36, 14);
            this.labelControl33.TabIndex = 117;
            this.labelControl33.Text = "出生地";
            // 
            // Print_UCIemBasInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.Controls.Add(this.lueCounty);
            this.Controls.Add(this.labelControl33);
            this.Controls.Add(this.lueMarital);
            this.Controls.Add(this.lueSex);
            this.Controls.Add(this.labelHospitalName);
            this.Controls.Add(this.labelLogoName);
            this.Controls.Add(this.hLineEx1);
            this.Controls.Add(this.txtOutWardDate);
            this.Controls.Add(this.txtAdmitWardDate);
            this.Controls.Add(this.deBirth);
            this.Controls.Add(this.txtAge);
            this.Controls.Add(this.txtSocialCare);
            this.Controls.Add(this.labelControl1);
            this.Controls.Add(this.seInCount);
            this.Controls.Add(this.txtPatNoOfHis);
            this.Controls.Add(this.labelControl2);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.labelControl3);
            this.Controls.Add(this.lueJob);
            this.Controls.Add(this.labelControl4);
            this.Controls.Add(this.labelControl6);
            this.Controls.Add(this.labelControl5);
            this.Controls.Add(this.luePayId);
            this.Controls.Add(this.labelControl7);
            this.Controls.Add(this.labelControl13);
            this.Controls.Add(this.labelControl8);
            this.Controls.Add(this.labelControl9);
            this.Controls.Add(this.labelControl14);
            this.Controls.Add(this.labelControl10);
            this.Controls.Add(this.labelControl11);
            this.Controls.Add(this.labelControl16);
            this.Controls.Add(this.lueNation);
            this.Controls.Add(this.labelControl17);
            this.Controls.Add(this.lueNationality);
            this.Controls.Add(this.labelControl18);
            this.Controls.Add(this.txtIDNO);
            this.Controls.Add(this.labelControl19);
            this.Controls.Add(this.txtOfficePlace);
            this.Controls.Add(this.labelControl20);
            this.Controls.Add(this.txtOfficeTEL);
            this.Controls.Add(this.labelControl21);
            this.Controls.Add(this.txtOfficePost);
            this.Controls.Add(this.labelControl22);
            this.Controls.Add(this.txtNativeAddress);
            this.Controls.Add(this.labelControl24);
            this.Controls.Add(this.txtNativeTEL);
            this.Controls.Add(this.labelControl23);
            this.Controls.Add(this.txtNativePost);
            this.Controls.Add(this.labelControl25);
            this.Controls.Add(this.txtContactPerson);
            this.Controls.Add(this.labelControl26);
            this.Controls.Add(this.labelControl38);
            this.Controls.Add(this.lueRelationship);
            this.Controls.Add(this.labelControl39);
            this.Controls.Add(this.labelControl27);
            this.Controls.Add(this.lueOutHosWard);
            this.Controls.Add(this.txtContactAddress);
            this.Controls.Add(this.labelControl40);
            this.Controls.Add(this.labelControl28);
            this.Controls.Add(this.lueOutHosDept);
            this.Controls.Add(this.seActualDays);
            this.Controls.Add(this.txtContactTEL);
            this.Controls.Add(this.labelControl41);
            this.Controls.Add(this.labelControl29);
            this.Controls.Add(this.labelControl42);
            this.Controls.Add(this.labelControl30);
            this.Controls.Add(this.lueAdmitDept);
            this.Controls.Add(this.labelControl31);
            this.Controls.Add(this.lueAdmitWard);
            this.Controls.Add(this.labelControl32);
            this.Controls.Add(this.lueTransAdmitDept);
            this.Name = "Print_UCIemBasInfo";
            this.Size = new System.Drawing.Size(666, 318);
            this.Load += new System.EventHandler(this.Print_UCIemBasInfo_Load);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.UCIemBasInfo_Paint);
            ((System.ComponentModel.ISupportInitialize)(this.txtAge.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueJob)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.luePayId)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueOutHosWard)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueOutHosDept)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueTransAdmitDept)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueAdmitWard)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueAdmitDept)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtContactTEL.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtContactAddress.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueRelationship)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtContactPerson.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtNativePost.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtNativeTEL.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtNativeAddress.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtOfficePost.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtOfficeTEL.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtOfficePlace.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtIDNO.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueNationality)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueNation)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSocialCare.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtName.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPatNoOfHis.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.deBirth.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtAdmitWardDate.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtOutWardDate.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.seActualDays.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.seInCount.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueCounty)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevExpress.XtraEditors.LabelControl labelControl38;
        private DevExpress.XtraEditors.LabelControl labelControl39;
        private YidanSoft.Common.Library.LookUpEditor lueOutHosWard;
        private DevExpress.XtraEditors.LabelControl labelControl40;
        private YidanSoft.Common.Library.LookUpEditor lueOutHosDept;
        private DevExpress.XtraEditors.LabelControl labelControl41;
        private DevExpress.XtraEditors.LabelControl labelControl42;
        private YidanSoft.Common.Library.LookUpEditor lueTransAdmitDept;
        private DevExpress.XtraEditors.LabelControl labelControl32;
        private YidanSoft.Common.Library.LookUpEditor lueAdmitWard;
        private DevExpress.XtraEditors.LabelControl labelControl31;
        private YidanSoft.Common.Library.LookUpEditor lueAdmitDept;
        private DevExpress.XtraEditors.LabelControl labelControl30;
        private DevExpress.XtraEditors.LabelControl labelControl29;
        private DevExpress.XtraEditors.TextEdit txtContactTEL;
        private DevExpress.XtraEditors.LabelControl labelControl28;
        private DevExpress.XtraEditors.TextEdit txtContactAddress;
        private DevExpress.XtraEditors.LabelControl labelControl27;
        private YidanSoft.Common.Library.LookUpEditor lueRelationship;
        private DevExpress.XtraEditors.LabelControl labelControl26;
        private DevExpress.XtraEditors.TextEdit txtContactPerson;
        private DevExpress.XtraEditors.LabelControl labelControl25;
        private DevExpress.XtraEditors.TextEdit txtNativePost;
        private DevExpress.XtraEditors.LabelControl labelControl23;
        private DevExpress.XtraEditors.TextEdit txtNativeTEL;
        private DevExpress.XtraEditors.LabelControl labelControl24;
        private DevExpress.XtraEditors.TextEdit txtNativeAddress;
        private DevExpress.XtraEditors.LabelControl labelControl22;
        private DevExpress.XtraEditors.TextEdit txtOfficePost;
        private DevExpress.XtraEditors.LabelControl labelControl21;
        private DevExpress.XtraEditors.TextEdit txtOfficeTEL;
        private DevExpress.XtraEditors.LabelControl labelControl20;
        private DevExpress.XtraEditors.TextEdit txtOfficePlace;
        private DevExpress.XtraEditors.LabelControl labelControl19;
        private DevExpress.XtraEditors.TextEdit txtIDNO;
        private DevExpress.XtraEditors.LabelControl labelControl18;
        private YidanSoft.Common.Library.LookUpEditor lueNationality;
        private DevExpress.XtraEditors.LabelControl labelControl17;
        private YidanSoft.Common.Library.LookUpEditor lueNation;
        private DevExpress.XtraEditors.LabelControl labelControl16;
        private DevExpress.XtraEditors.LabelControl labelControl11;
        private DevExpress.XtraEditors.LabelControl labelControl10;
        private DevExpress.XtraEditors.LabelControl labelControl9;
        private DevExpress.XtraEditors.LabelControl labelControl8;
        private DevExpress.XtraEditors.LabelControl labelControl7;
        private DevExpress.XtraEditors.TextEdit txtSocialCare;
        private DevExpress.XtraEditors.LabelControl labelControl5;
        private DevExpress.XtraEditors.LabelControl labelControl6;
        private DevExpress.XtraEditors.LabelControl labelControl4;
        private DevExpress.XtraEditors.LabelControl labelControl3;
        private DevExpress.XtraEditors.TextEdit txtName;
        private DevExpress.XtraEditors.LabelControl labelControl2;
        private DevExpress.XtraEditors.TextEdit txtPatNoOfHis;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private YidanSoft.Common.Library.LookUpEditor luePayId;
        private YidanSoft.Common.Library.LookUpEditor lueJob;
        private DevExpress.XtraEditors.TextEdit txtAge;
        private HLineEx hLineEx1;
        private DevExpress.XtraEditors.LabelControl labelLogoName;
        private DevExpress.XtraEditors.LabelControl labelHospitalName;
        private DevExpress.XtraEditors.LabelControl lueSex;
        private DevExpress.XtraEditors.LabelControl labelControl13;
        private DevExpress.XtraEditors.TextEdit deBirth;
        private DevExpress.XtraEditors.LabelControl lueMarital;
        private DevExpress.XtraEditors.LabelControl labelControl14;
        private DevExpress.XtraEditors.TextEdit txtAdmitWardDate;
        private DevExpress.XtraEditors.TextEdit txtOutWardDate;
        private DevExpress.XtraEditors.TextEdit seActualDays;
        private DevExpress.XtraEditors.TextEdit seInCount;
        private Common.Library.LookUpEditor lueCounty;
        private DevExpress.XtraEditors.LabelControl labelControl33;
    }
}
