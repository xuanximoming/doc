﻿namespace YidanSoft.Core.IEMMainPage
{
    partial class Print_UCFee
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.hLineEx7 = new YidanSoft.Core.IEMMainPage.HLineEx();
            this.lblTotal = new DevExpress.XtraEditors.TextEdit();
            this.labelControl17 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl32 = new DevExpress.XtraEditors.LabelControl();
            this.lblBed = new DevExpress.XtraEditors.TextEdit();
            this.labelControl33 = new DevExpress.XtraEditors.LabelControl();
            this.lblCare = new DevExpress.XtraEditors.TextEdit();
            this.labelControl34 = new DevExpress.XtraEditors.LabelControl();
            this.lblWMedical = new DevExpress.XtraEditors.TextEdit();
            this.labelControl35 = new DevExpress.XtraEditors.LabelControl();
            this.lblCPMedical = new DevExpress.XtraEditors.TextEdit();
            this.lblCMedical = new DevExpress.XtraEditors.TextEdit();
            this.labelControl36 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl37 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl38 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl39 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl40 = new DevExpress.XtraEditors.LabelControl();
            this.lblRadiate = new DevExpress.XtraEditors.TextEdit();
            this.lblAssay = new DevExpress.XtraEditors.TextEdit();
            this.lblBlood = new DevExpress.XtraEditors.TextEdit();
            this.lblOx = new DevExpress.XtraEditors.TextEdit();
            this.lblMecical = new DevExpress.XtraEditors.TextEdit();
            this.labelControl41 = new DevExpress.XtraEditors.LabelControl();
            this.lblOperation = new DevExpress.XtraEditors.TextEdit();
            this.labelControl42 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl43 = new DevExpress.XtraEditors.LabelControl();
            this.lblAccouche = new DevExpress.XtraEditors.TextEdit();
            this.labelControl21 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl44 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl45 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl46 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl47 = new DevExpress.XtraEditors.LabelControl();
            this.lblRis = new DevExpress.XtraEditors.TextEdit();
            this.lblAnaesthesia = new DevExpress.XtraEditors.TextEdit();
            this.lblFollwBed = new DevExpress.XtraEditors.TextEdit();
            this.lblBaby = new DevExpress.XtraEditors.TextEdit();
            this.lblOthers = new DevExpress.XtraEditors.TextEdit();
            this.labelControl50 = new DevExpress.XtraEditors.LabelControl();
            this.textEdit23 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl51 = new DevExpress.XtraEditors.LabelControl();
            this.textEdit24 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl48 = new DevExpress.XtraEditors.LabelControl();
            this.labAshes_Check = new DevExpress.XtraEditors.LabelControl();
            this.labelControl52 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl53 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl54 = new DevExpress.XtraEditors.LabelControl();
            this.labchkIsFirstCase = new DevExpress.XtraEditors.LabelControl();
            this.hLineEx1 = new YidanSoft.Core.IEMMainPage.HLineEx();
            this.labelControl56 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl57 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl58 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl59 = new DevExpress.XtraEditors.LabelControl();
            this.labchkIsFollowing = new DevExpress.XtraEditors.LabelControl();
            this.labchkIsTeachingCase = new DevExpress.XtraEditors.LabelControl();
            this.hLineEx2 = new YidanSoft.Core.IEMMainPage.HLineEx();
            this.labelControl62 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl63 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl64 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl65 = new DevExpress.XtraEditors.LabelControl();
            this.labchkBlood = new DevExpress.XtraEditors.LabelControl();
            this.labchkBloodReaction = new DevExpress.XtraEditors.LabelControl();
            this.labelControl68 = new DevExpress.XtraEditors.LabelControl();
            this.labchkRh = new DevExpress.XtraEditors.LabelControl();
            this.labelControl70 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl71 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl72 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl73 = new DevExpress.XtraEditors.LabelControl();
            this.txtIsFollowingMon = new DevExpress.XtraEditors.TextEdit();
            this.txtIsFollowingDay = new DevExpress.XtraEditors.TextEdit();
            this.txtIsFollowingYear = new DevExpress.XtraEditors.TextEdit();
            this.labelControl74 = new DevExpress.XtraEditors.LabelControl();
            this.hLineEx3 = new YidanSoft.Core.IEMMainPage.HLineEx();
            this.labelControl75 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl76 = new DevExpress.XtraEditors.LabelControl();
            this.seRbc = new DevExpress.XtraEditors.TextEdit();
            this.labelControl82 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl84 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl85 = new DevExpress.XtraEditors.LabelControl();
            this.sePlt = new DevExpress.XtraEditors.TextEdit();
            this.labelControl77 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl78 = new DevExpress.XtraEditors.LabelControl();
            this.sePlasma = new DevExpress.XtraEditors.TextEdit();
            this.seWb = new DevExpress.XtraEditors.TextEdit();
            this.labelControl79 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl80 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl81 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl83 = new DevExpress.XtraEditors.LabelControl();
            this.txtOthers = new DevExpress.XtraEditors.TextEdit();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl3 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl4 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl5 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl6 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl7 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl8 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl9 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl10 = new DevExpress.XtraEditors.LabelControl();
            ((System.ComponentModel.ISupportInitialize)(this.lblTotal.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblBed.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblCare.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblWMedical.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblCPMedical.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblCMedical.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblRadiate.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblAssay.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblBlood.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblOx.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblMecical.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblOperation.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblAccouche.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblRis.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblAnaesthesia.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblFollwBed.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblBaby.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblOthers.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit23.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit24.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtIsFollowingMon.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtIsFollowingDay.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtIsFollowingYear.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.seRbc.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sePlt.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sePlasma.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.seWb.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtOthers.Properties)).BeginInit();
            this.SuspendLayout();
            // 
            // hLineEx7
            // 
            this.hLineEx7.BackColor = System.Drawing.Color.White;
            this.hLineEx7.IsBold = false;
            this.hLineEx7.Location = new System.Drawing.Point(5, 139);
            this.hLineEx7.Name = "hLineEx7";
            this.hLineEx7.Size = new System.Drawing.Size(658, 1);
            this.hLineEx7.TabIndex = 154;
            this.hLineEx7.Text = "hLineEx3";
            // 
            // lblTotal
            // 
            this.lblTotal.EditValue = "";
            this.lblTotal.Location = new System.Drawing.Point(116, 10);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.lblTotal.Size = new System.Drawing.Size(60, 19);
            this.lblTotal.TabIndex = 162;
            // 
            // labelControl17
            // 
            this.labelControl17.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl17.Location = new System.Drawing.Point(14, 12);
            this.labelControl17.Name = "labelControl17";
            this.labelControl17.Size = new System.Drawing.Size(98, 14);
            this.labelControl17.TabIndex = 157;
            this.labelControl17.Text = "住院费用总计(元):";
            // 
            // labelControl32
            // 
            this.labelControl32.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl32.Location = new System.Drawing.Point(177, 12);
            this.labelControl32.Name = "labelControl32";
            this.labelControl32.Size = new System.Drawing.Size(24, 14);
            this.labelControl32.TabIndex = 157;
            this.labelControl32.Text = "床费";
            // 
            // lblBed
            // 
            this.lblBed.EditValue = "";
            this.lblBed.Location = new System.Drawing.Point(203, 10);
            this.lblBed.Name = "lblBed";
            this.lblBed.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.lblBed.Size = new System.Drawing.Size(60, 19);
            this.lblBed.TabIndex = 162;
            // 
            // labelControl33
            // 
            this.labelControl33.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl33.Location = new System.Drawing.Point(265, 12);
            this.labelControl33.Name = "labelControl33";
            this.labelControl33.Size = new System.Drawing.Size(36, 14);
            this.labelControl33.TabIndex = 157;
            this.labelControl33.Text = "护理费";
            // 
            // lblCare
            // 
            this.lblCare.EditValue = "";
            this.lblCare.Location = new System.Drawing.Point(305, 10);
            this.lblCare.Name = "lblCare";
            this.lblCare.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.lblCare.Size = new System.Drawing.Size(60, 19);
            this.lblCare.TabIndex = 162;
            // 
            // labelControl34
            // 
            this.labelControl34.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl34.Location = new System.Drawing.Point(367, 12);
            this.labelControl34.Name = "labelControl34";
            this.labelControl34.Size = new System.Drawing.Size(24, 14);
            this.labelControl34.TabIndex = 157;
            this.labelControl34.Text = "西药";
            // 
            // lblWMedical
            // 
            this.lblWMedical.EditValue = "";
            this.lblWMedical.Location = new System.Drawing.Point(394, 10);
            this.lblWMedical.Name = "lblWMedical";
            this.lblWMedical.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.lblWMedical.Size = new System.Drawing.Size(60, 19);
            this.lblWMedical.TabIndex = 162;
            // 
            // labelControl35
            // 
            this.labelControl35.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl35.Location = new System.Drawing.Point(456, 12);
            this.labelControl35.Name = "labelControl35";
            this.labelControl35.Size = new System.Drawing.Size(36, 14);
            this.labelControl35.TabIndex = 157;
            this.labelControl35.Text = "中成药";
            // 
            // lblCPMedical
            // 
            this.lblCPMedical.EditValue = "";
            this.lblCPMedical.Location = new System.Drawing.Point(496, 10);
            this.lblCPMedical.Name = "lblCPMedical";
            this.lblCPMedical.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.lblCPMedical.Size = new System.Drawing.Size(60, 19);
            this.lblCPMedical.TabIndex = 162;
            // 
            // lblCMedical
            // 
            this.lblCMedical.EditValue = "";
            this.lblCMedical.Location = new System.Drawing.Point(598, 10);
            this.lblCMedical.Name = "lblCMedical";
            this.lblCMedical.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.lblCMedical.Size = new System.Drawing.Size(60, 19);
            this.lblCMedical.TabIndex = 169;
            // 
            // labelControl36
            // 
            this.labelControl36.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl36.Location = new System.Drawing.Point(558, 12);
            this.labelControl36.Name = "labelControl36";
            this.labelControl36.Size = new System.Drawing.Size(36, 14);
            this.labelControl36.TabIndex = 168;
            this.labelControl36.Text = "中草药";
            // 
            // labelControl37
            // 
            this.labelControl37.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl37.Location = new System.Drawing.Point(103, 47);
            this.labelControl37.Name = "labelControl37";
            this.labelControl37.Size = new System.Drawing.Size(24, 14);
            this.labelControl37.TabIndex = 157;
            this.labelControl37.Text = "化验";
            // 
            // labelControl38
            // 
            this.labelControl38.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl38.Location = new System.Drawing.Point(279, 47);
            this.labelControl38.Name = "labelControl38";
            this.labelControl38.Size = new System.Drawing.Size(24, 14);
            this.labelControl38.TabIndex = 157;
            this.labelControl38.Text = "输血";
            // 
            // labelControl39
            // 
            this.labelControl39.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl39.Location = new System.Drawing.Point(191, 47);
            this.labelControl39.Name = "labelControl39";
            this.labelControl39.Size = new System.Drawing.Size(24, 14);
            this.labelControl39.TabIndex = 157;
            this.labelControl39.Text = "输氧";
            // 
            // labelControl40
            // 
            this.labelControl40.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl40.Location = new System.Drawing.Point(368, 47);
            this.labelControl40.Name = "labelControl40";
            this.labelControl40.Size = new System.Drawing.Size(24, 14);
            this.labelControl40.TabIndex = 157;
            this.labelControl40.Text = "诊疗";
            // 
            // lblRadiate
            // 
            this.lblRadiate.EditValue = "";
            this.lblRadiate.Location = new System.Drawing.Point(42, 45);
            this.lblRadiate.Name = "lblRadiate";
            this.lblRadiate.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.lblRadiate.Size = new System.Drawing.Size(60, 19);
            this.lblRadiate.TabIndex = 162;
            // 
            // lblAssay
            // 
            this.lblAssay.EditValue = "";
            this.lblAssay.Location = new System.Drawing.Point(129, 45);
            this.lblAssay.Name = "lblAssay";
            this.lblAssay.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.lblAssay.Size = new System.Drawing.Size(60, 19);
            this.lblAssay.TabIndex = 162;
            // 
            // lblBlood
            // 
            this.lblBlood.EditValue = "";
            this.lblBlood.Location = new System.Drawing.Point(306, 45);
            this.lblBlood.Name = "lblBlood";
            this.lblBlood.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.lblBlood.Size = new System.Drawing.Size(60, 19);
            this.lblBlood.TabIndex = 162;
            // 
            // lblOx
            // 
            this.lblOx.EditValue = "";
            this.lblOx.Location = new System.Drawing.Point(217, 45);
            this.lblOx.Name = "lblOx";
            this.lblOx.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.lblOx.Size = new System.Drawing.Size(60, 19);
            this.lblOx.TabIndex = 162;
            // 
            // lblMecical
            // 
            this.lblMecical.EditValue = "";
            this.lblMecical.Location = new System.Drawing.Point(394, 45);
            this.lblMecical.Name = "lblMecical";
            this.lblMecical.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.lblMecical.Size = new System.Drawing.Size(60, 19);
            this.lblMecical.TabIndex = 162;
            // 
            // labelControl41
            // 
            this.labelControl41.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl41.Location = new System.Drawing.Point(466, 47);
            this.labelControl41.Name = "labelControl41";
            this.labelControl41.Size = new System.Drawing.Size(24, 14);
            this.labelControl41.TabIndex = 168;
            this.labelControl41.Text = "手术";
            // 
            // lblOperation
            // 
            this.lblOperation.EditValue = "";
            this.lblOperation.Location = new System.Drawing.Point(496, 45);
            this.lblOperation.Name = "lblOperation";
            this.lblOperation.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.lblOperation.Size = new System.Drawing.Size(60, 19);
            this.lblOperation.TabIndex = 169;
            // 
            // labelControl42
            // 
            this.labelControl42.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl42.Location = new System.Drawing.Point(14, 47);
            this.labelControl42.Name = "labelControl42";
            this.labelControl42.Size = new System.Drawing.Size(24, 14);
            this.labelControl42.TabIndex = 157;
            this.labelControl42.Text = "放射";
            // 
            // labelControl43
            // 
            this.labelControl43.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl43.Location = new System.Drawing.Point(568, 47);
            this.labelControl43.Name = "labelControl43";
            this.labelControl43.Size = new System.Drawing.Size(24, 14);
            this.labelControl43.TabIndex = 168;
            this.labelControl43.Text = "接生";
            // 
            // lblAccouche
            // 
            this.lblAccouche.EditValue = "";
            this.lblAccouche.Location = new System.Drawing.Point(598, 45);
            this.lblAccouche.Name = "lblAccouche";
            this.lblAccouche.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.lblAccouche.Size = new System.Drawing.Size(60, 19);
            this.lblAccouche.TabIndex = 169;
            // 
            // labelControl21
            // 
            this.labelControl21.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl21.Location = new System.Drawing.Point(103, 80);
            this.labelControl21.Name = "labelControl21";
            this.labelControl21.Size = new System.Drawing.Size(36, 14);
            this.labelControl21.TabIndex = 157;
            this.labelControl21.Text = "麻醉费";
            // 
            // labelControl44
            // 
            this.labelControl44.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl44.Location = new System.Drawing.Point(14, 80);
            this.labelControl44.Name = "labelControl44";
            this.labelControl44.Size = new System.Drawing.Size(24, 14);
            this.labelControl44.TabIndex = 157;
            this.labelControl44.Text = "检查";
            // 
            // labelControl45
            // 
            this.labelControl45.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl45.Location = new System.Drawing.Point(306, 80);
            this.labelControl45.Name = "labelControl45";
            this.labelControl45.Size = new System.Drawing.Size(36, 14);
            this.labelControl45.TabIndex = 157;
            this.labelControl45.Text = "陪床费";
            // 
            // labelControl46
            // 
            this.labelControl46.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl46.Location = new System.Drawing.Point(205, 80);
            this.labelControl46.Name = "labelControl46";
            this.labelControl46.Size = new System.Drawing.Size(36, 14);
            this.labelControl46.TabIndex = 157;
            this.labelControl46.Text = "婴儿费";
            // 
            // labelControl47
            // 
            this.labelControl47.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl47.Location = new System.Drawing.Point(408, 80);
            this.labelControl47.Name = "labelControl47";
            this.labelControl47.Size = new System.Drawing.Size(24, 14);
            this.labelControl47.TabIndex = 157;
            this.labelControl47.Text = "其他";
            // 
            // lblRis
            // 
            this.lblRis.EditValue = "";
            this.lblRis.Location = new System.Drawing.Point(42, 78);
            this.lblRis.Name = "lblRis";
            this.lblRis.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.lblRis.Size = new System.Drawing.Size(60, 19);
            this.lblRis.TabIndex = 162;
            // 
            // lblAnaesthesia
            // 
            this.lblAnaesthesia.EditValue = "";
            this.lblAnaesthesia.Location = new System.Drawing.Point(143, 78);
            this.lblAnaesthesia.Name = "lblAnaesthesia";
            this.lblAnaesthesia.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.lblAnaesthesia.Size = new System.Drawing.Size(60, 19);
            this.lblAnaesthesia.TabIndex = 162;
            // 
            // lblFollwBed
            // 
            this.lblFollwBed.EditValue = "";
            this.lblFollwBed.Location = new System.Drawing.Point(346, 78);
            this.lblFollwBed.Name = "lblFollwBed";
            this.lblFollwBed.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.lblFollwBed.Size = new System.Drawing.Size(60, 19);
            this.lblFollwBed.TabIndex = 162;
            // 
            // lblBaby
            // 
            this.lblBaby.EditValue = "";
            this.lblBaby.Location = new System.Drawing.Point(244, 78);
            this.lblBaby.Name = "lblBaby";
            this.lblBaby.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.lblBaby.Size = new System.Drawing.Size(60, 19);
            this.lblBaby.TabIndex = 162;
            // 
            // lblOthers
            // 
            this.lblOthers.EditValue = "";
            this.lblOthers.Location = new System.Drawing.Point(434, 78);
            this.lblOthers.Name = "lblOthers";
            this.lblOthers.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.lblOthers.Size = new System.Drawing.Size(60, 19);
            this.lblOthers.TabIndex = 162;
            // 
            // labelControl50
            // 
            this.labelControl50.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl50.Location = new System.Drawing.Point(581, 80);
            this.labelControl50.Name = "labelControl50";
            this.labelControl50.Size = new System.Drawing.Size(12, 14);
            this.labelControl50.TabIndex = 168;
            this.labelControl50.Text = "、";
            // 
            // textEdit23
            // 
            this.textEdit23.EditValue = "";
            this.textEdit23.Location = new System.Drawing.Point(515, 78);
            this.textEdit23.Name = "textEdit23";
            this.textEdit23.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.textEdit23.Size = new System.Drawing.Size(60, 19);
            this.textEdit23.TabIndex = 169;
            // 
            // labelControl51
            // 
            this.labelControl51.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl51.Location = new System.Drawing.Point(499, 80);
            this.labelControl51.Name = "labelControl51";
            this.labelControl51.Size = new System.Drawing.Size(12, 14);
            this.labelControl51.TabIndex = 168;
            this.labelControl51.Text = "、";
            // 
            // textEdit24
            // 
            this.textEdit24.EditValue = "";
            this.textEdit24.Location = new System.Drawing.Point(598, 78);
            this.textEdit24.Name = "textEdit24";
            this.textEdit24.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.textEdit24.Size = new System.Drawing.Size(60, 19);
            this.textEdit24.TabIndex = 169;
            // 
            // labelControl48
            // 
            this.labelControl48.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl48.Location = new System.Drawing.Point(14, 118);
            this.labelControl48.Name = "labelControl48";
            this.labelControl48.Size = new System.Drawing.Size(48, 14);
            this.labelControl48.TabIndex = 157;
            this.labelControl48.Text = "尸      检";
            // 
            // labAshes_Check
            // 
            this.labAshes_Check.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Office2003;
            this.labAshes_Check.Location = new System.Drawing.Point(103, 117);
            this.labAshes_Check.Name = "labAshes_Check";
            this.labAshes_Check.Size = new System.Drawing.Size(14, 16);
            this.labAshes_Check.TabIndex = 163;
            this.labAshes_Check.Text = "   ";
            // 
            // labelControl52
            // 
            this.labelControl52.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl52.Location = new System.Drawing.Point(143, 118);
            this.labelControl52.Name = "labelControl52";
            this.labelControl52.Size = new System.Drawing.Size(62, 14);
            this.labelControl52.TabIndex = 157;
            this.labelControl52.Text = "1.是    2.否";
            // 
            // labelControl53
            // 
            this.labelControl53.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl53.Location = new System.Drawing.Point(290, 119);
            this.labelControl53.Name = "labelControl53";
            this.labelControl53.Size = new System.Drawing.Size(204, 14);
            this.labelControl53.TabIndex = 157;
            this.labelControl53.Text = "手术、治疗、检查、诊断为本院第一例";
            // 
            // labelControl54
            // 
            this.labelControl54.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl54.Location = new System.Drawing.Point(581, 119);
            this.labelControl54.Name = "labelControl54";
            this.labelControl54.Size = new System.Drawing.Size(62, 14);
            this.labelControl54.TabIndex = 157;
            this.labelControl54.Text = "1.是    2.否";
            // 
            // labchkIsFirstCase
            // 
            this.labchkIsFirstCase.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Office2003;
            this.labchkIsFirstCase.Location = new System.Drawing.Point(538, 118);
            this.labchkIsFirstCase.Name = "labchkIsFirstCase";
            this.labchkIsFirstCase.Size = new System.Drawing.Size(14, 16);
            this.labchkIsFirstCase.TabIndex = 163;
            this.labchkIsFirstCase.Text = "   ";
            // 
            // hLineEx1
            // 
            this.hLineEx1.BackColor = System.Drawing.Color.White;
            this.hLineEx1.IsBold = false;
            this.hLineEx1.Location = new System.Drawing.Point(5, 169);
            this.hLineEx1.Name = "hLineEx1";
            this.hLineEx1.Size = new System.Drawing.Size(658, 1);
            this.hLineEx1.TabIndex = 155;
            this.hLineEx1.Text = "hLineEx3";
            // 
            // labelControl56
            // 
            this.labelControl56.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl56.Location = new System.Drawing.Point(14, 148);
            this.labelControl56.Name = "labelControl56";
            this.labelControl56.Size = new System.Drawing.Size(48, 14);
            this.labelControl56.TabIndex = 157;
            this.labelControl56.Text = "随      诊";
            // 
            // labelControl57
            // 
            this.labelControl57.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl57.Location = new System.Drawing.Point(143, 148);
            this.labelControl57.Name = "labelControl57";
            this.labelControl57.Size = new System.Drawing.Size(62, 14);
            this.labelControl57.TabIndex = 157;
            this.labelControl57.Text = "1.是    2.否";
            // 
            // labelControl58
            // 
            this.labelControl58.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl58.Location = new System.Drawing.Point(241, 148);
            this.labelControl58.Name = "labelControl58";
            this.labelControl58.Size = new System.Drawing.Size(48, 14);
            this.labelControl58.TabIndex = 157;
            this.labelControl58.Text = "随诊期限";
            // 
            // labelControl59
            // 
            this.labelControl59.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl59.Location = new System.Drawing.Point(581, 148);
            this.labelControl59.Name = "labelControl59";
            this.labelControl59.Size = new System.Drawing.Size(62, 14);
            this.labelControl59.TabIndex = 157;
            this.labelControl59.Text = "1.是    2.否";
            // 
            // labchkIsFollowing
            // 
            this.labchkIsFollowing.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Office2003;
            this.labchkIsFollowing.Location = new System.Drawing.Point(103, 147);
            this.labchkIsFollowing.Name = "labchkIsFollowing";
            this.labchkIsFollowing.Size = new System.Drawing.Size(14, 16);
            this.labchkIsFollowing.TabIndex = 163;
            this.labchkIsFollowing.Text = "   ";
            // 
            // labchkIsTeachingCase
            // 
            this.labchkIsTeachingCase.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Office2003;
            this.labchkIsTeachingCase.Location = new System.Drawing.Point(558, 147);
            this.labchkIsTeachingCase.Name = "labchkIsTeachingCase";
            this.labchkIsTeachingCase.Size = new System.Drawing.Size(14, 16);
            this.labchkIsTeachingCase.TabIndex = 163;
            this.labchkIsTeachingCase.Text = "   ";
            // 
            // hLineEx2
            // 
            this.hLineEx2.BackColor = System.Drawing.Color.White;
            this.hLineEx2.IsBold = false;
            this.hLineEx2.Location = new System.Drawing.Point(5, 199);
            this.hLineEx2.Name = "hLineEx2";
            this.hLineEx2.Size = new System.Drawing.Size(658, 1);
            this.hLineEx2.TabIndex = 155;
            this.hLineEx2.Text = "hLineEx3";
            // 
            // labelControl62
            // 
            this.labelControl62.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl62.Location = new System.Drawing.Point(14, 178);
            this.labelControl62.Name = "labelControl62";
            this.labelControl62.Size = new System.Drawing.Size(48, 14);
            this.labelControl62.TabIndex = 157;
            this.labelControl62.Text = "血      型";
            // 
            // labelControl63
            // 
            this.labelControl63.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl63.Location = new System.Drawing.Point(116, 180);
            this.labelControl63.Name = "labelControl63";
            this.labelControl63.Size = new System.Drawing.Size(150, 14);
            this.labelControl63.TabIndex = 157;
            this.labelControl63.Text = "1.A  2.B  3.AB  4.O  5.其他";
            // 
            // labelControl64
            // 
            this.labelControl64.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl64.Location = new System.Drawing.Point(305, 179);
            this.labelControl64.Name = "labelControl64";
            this.labelControl64.Size = new System.Drawing.Size(14, 14);
            this.labelControl64.TabIndex = 157;
            this.labelControl64.Text = "Rh";
            // 
            // labelControl65
            // 
            this.labelControl65.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl65.Location = new System.Drawing.Point(540, 179);
            this.labelControl65.Name = "labelControl65";
            this.labelControl65.Size = new System.Drawing.Size(105, 14);
            this.labelControl65.TabIndex = 157;
            this.labelControl65.Text = "0.未做  1.有    2.无";
            // 
            // labchkBlood
            // 
            this.labchkBlood.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Office2003;
            this.labchkBlood.Location = new System.Drawing.Point(85, 178);
            this.labchkBlood.Name = "labchkBlood";
            this.labchkBlood.Size = new System.Drawing.Size(14, 16);
            this.labchkBlood.TabIndex = 163;
            this.labchkBlood.Text = "   ";
            // 
            // labchkBloodReaction
            // 
            this.labchkBloodReaction.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Office2003;
            this.labchkBloodReaction.Location = new System.Drawing.Point(520, 179);
            this.labchkBloodReaction.Name = "labchkBloodReaction";
            this.labchkBloodReaction.Size = new System.Drawing.Size(14, 16);
            this.labchkBloodReaction.TabIndex = 163;
            this.labchkBloodReaction.Text = "   ";
            // 
            // labelControl68
            // 
            this.labelControl68.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl68.Location = new System.Drawing.Point(353, 179);
            this.labelControl68.Name = "labelControl68";
            this.labelControl68.Size = new System.Drawing.Size(97, 14);
            this.labelControl68.TabIndex = 157;
            this.labelControl68.Text = "0.未做  1.阴  2.阳";
            // 
            // labchkRh
            // 
            this.labchkRh.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Office2003;
            this.labchkRh.Location = new System.Drawing.Point(328, 178);
            this.labchkRh.Name = "labchkRh";
            this.labchkRh.Size = new System.Drawing.Size(14, 16);
            this.labchkRh.TabIndex = 163;
            this.labchkRh.Text = "   ";
            // 
            // labelControl70
            // 
            this.labelControl70.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl70.Location = new System.Drawing.Point(466, 180);
            this.labelControl70.Name = "labelControl70";
            this.labelControl70.Size = new System.Drawing.Size(48, 14);
            this.labelControl70.TabIndex = 157;
            this.labelControl70.Text = "输血反应";
            // 
            // labelControl71
            // 
            this.labelControl71.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl71.Location = new System.Drawing.Point(504, 148);
            this.labelControl71.Name = "labelControl71";
            this.labelControl71.Size = new System.Drawing.Size(48, 14);
            this.labelControl71.TabIndex = 157;
            this.labelControl71.Text = "示教病例";
            // 
            // labelControl72
            // 
            this.labelControl72.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl72.Location = new System.Drawing.Point(341, 148);
            this.labelControl72.Name = "labelControl72";
            this.labelControl72.Size = new System.Drawing.Size(12, 14);
            this.labelControl72.TabIndex = 157;
            this.labelControl72.Text = "日";
            // 
            // labelControl73
            // 
            this.labelControl73.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl73.Location = new System.Drawing.Point(394, 148);
            this.labelControl73.Name = "labelControl73";
            this.labelControl73.Size = new System.Drawing.Size(12, 14);
            this.labelControl73.TabIndex = 157;
            this.labelControl73.Text = "月";
            // 
            // txtIsFollowingMon
            // 
            this.txtIsFollowingMon.EditValue = "";
            this.txtIsFollowingMon.Location = new System.Drawing.Point(354, 146);
            this.txtIsFollowingMon.Name = "txtIsFollowingMon";
            this.txtIsFollowingMon.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtIsFollowingMon.Size = new System.Drawing.Size(38, 19);
            this.txtIsFollowingMon.TabIndex = 162;
            // 
            // txtIsFollowingDay
            // 
            this.txtIsFollowingDay.EditValue = "";
            this.txtIsFollowingDay.Location = new System.Drawing.Point(295, 146);
            this.txtIsFollowingDay.Name = "txtIsFollowingDay";
            this.txtIsFollowingDay.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtIsFollowingDay.Size = new System.Drawing.Size(40, 19);
            this.txtIsFollowingDay.TabIndex = 162;
            // 
            // txtIsFollowingYear
            // 
            this.txtIsFollowingYear.EditValue = "";
            this.txtIsFollowingYear.Location = new System.Drawing.Point(412, 146);
            this.txtIsFollowingYear.Name = "txtIsFollowingYear";
            this.txtIsFollowingYear.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtIsFollowingYear.Size = new System.Drawing.Size(36, 19);
            this.txtIsFollowingYear.TabIndex = 162;
            // 
            // labelControl74
            // 
            this.labelControl74.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl74.Location = new System.Drawing.Point(454, 148);
            this.labelControl74.Name = "labelControl74";
            this.labelControl74.Size = new System.Drawing.Size(12, 14);
            this.labelControl74.TabIndex = 157;
            this.labelControl74.Text = "年";
            // 
            // hLineEx3
            // 
            this.hLineEx3.BackColor = System.Drawing.Color.White;
            this.hLineEx3.IsBold = true;
            this.hLineEx3.Location = new System.Drawing.Point(5, 232);
            this.hLineEx3.Name = "hLineEx3";
            this.hLineEx3.Size = new System.Drawing.Size(658, 2);
            this.hLineEx3.TabIndex = 155;
            this.hLineEx3.Text = "hLineEx3";
            // 
            // labelControl75
            // 
            this.labelControl75.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl75.Location = new System.Drawing.Point(14, 209);
            this.labelControl75.Name = "labelControl75";
            this.labelControl75.Size = new System.Drawing.Size(48, 14);
            this.labelControl75.TabIndex = 157;
            this.labelControl75.Text = "输血品种";
            // 
            // labelControl76
            // 
            this.labelControl76.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl76.Location = new System.Drawing.Point(80, 209);
            this.labelControl76.Name = "labelControl76";
            this.labelControl76.Size = new System.Drawing.Size(47, 14);
            this.labelControl76.TabIndex = 157;
            this.labelControl76.Text = "1.红细胞";
            // 
            // seRbc
            // 
            this.seRbc.EditValue = "";
            this.seRbc.Location = new System.Drawing.Point(133, 207);
            this.seRbc.Name = "seRbc";
            this.seRbc.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.seRbc.Size = new System.Drawing.Size(40, 19);
            this.seRbc.TabIndex = 162;
            // 
            // labelControl82
            // 
            this.labelControl82.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl82.Location = new System.Drawing.Point(176, 209);
            this.labelControl82.Name = "labelControl82";
            this.labelControl82.Size = new System.Drawing.Size(24, 14);
            this.labelControl82.TabIndex = 157;
            this.labelControl82.Text = "单位";
            // 
            // labelControl84
            // 
            this.labelControl84.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl84.Location = new System.Drawing.Point(216, 209);
            this.labelControl84.Name = "labelControl84";
            this.labelControl84.Size = new System.Drawing.Size(47, 14);
            this.labelControl84.TabIndex = 157;
            this.labelControl84.Text = "2.血小板";
            // 
            // labelControl85
            // 
            this.labelControl85.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl85.Location = new System.Drawing.Point(312, 209);
            this.labelControl85.Name = "labelControl85";
            this.labelControl85.Size = new System.Drawing.Size(12, 14);
            this.labelControl85.TabIndex = 157;
            this.labelControl85.Text = "袋";
            // 
            // sePlt
            // 
            this.sePlt.EditValue = "";
            this.sePlt.Location = new System.Drawing.Point(269, 207);
            this.sePlt.Name = "sePlt";
            this.sePlt.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.sePlt.Size = new System.Drawing.Size(40, 19);
            this.sePlt.TabIndex = 162;
            // 
            // labelControl77
            // 
            this.labelControl77.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl77.Location = new System.Drawing.Point(342, 209);
            this.labelControl77.Name = "labelControl77";
            this.labelControl77.Size = new System.Drawing.Size(35, 14);
            this.labelControl77.TabIndex = 157;
            this.labelControl77.Text = "3.血浆";
            // 
            // labelControl78
            // 
            this.labelControl78.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl78.Location = new System.Drawing.Point(424, 209);
            this.labelControl78.Name = "labelControl78";
            this.labelControl78.Size = new System.Drawing.Size(12, 14);
            this.labelControl78.TabIndex = 157;
            this.labelControl78.Text = "ml";
            // 
            // sePlasma
            // 
            this.sePlasma.EditValue = "";
            this.sePlasma.Location = new System.Drawing.Point(381, 207);
            this.sePlasma.Name = "sePlasma";
            this.sePlasma.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.sePlasma.Size = new System.Drawing.Size(40, 19);
            this.sePlasma.TabIndex = 162;
            // 
            // seWb
            // 
            this.seWb.EditValue = "";
            this.seWb.Location = new System.Drawing.Point(492, 207);
            this.seWb.Name = "seWb";
            this.seWb.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.seWb.Size = new System.Drawing.Size(40, 19);
            this.seWb.TabIndex = 176;
            // 
            // labelControl79
            // 
            this.labelControl79.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl79.Location = new System.Drawing.Point(535, 209);
            this.labelControl79.Name = "labelControl79";
            this.labelControl79.Size = new System.Drawing.Size(12, 14);
            this.labelControl79.TabIndex = 175;
            this.labelControl79.Text = "ml";
            // 
            // labelControl80
            // 
            this.labelControl80.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl80.Location = new System.Drawing.Point(453, 209);
            this.labelControl80.Name = "labelControl80";
            this.labelControl80.Size = new System.Drawing.Size(35, 14);
            this.labelControl80.TabIndex = 174;
            this.labelControl80.Text = "4.全血";
            // 
            // labelControl81
            // 
            this.labelControl81.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl81.Location = new System.Drawing.Point(564, 208);
            this.labelControl81.Name = "labelControl81";
            this.labelControl81.Size = new System.Drawing.Size(35, 14);
            this.labelControl81.TabIndex = 174;
            this.labelControl81.Text = "5.其他";
            // 
            // labelControl83
            // 
            this.labelControl83.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl83.Location = new System.Drawing.Point(646, 205);
            this.labelControl83.Name = "labelControl83";
            this.labelControl83.Size = new System.Drawing.Size(12, 14);
            this.labelControl83.TabIndex = 175;
            this.labelControl83.Text = "ml";
            // 
            // txtOthers
            // 
            this.txtOthers.EditValue = "";
            this.txtOthers.Location = new System.Drawing.Point(603, 206);
            this.txtOthers.Name = "txtOthers";
            this.txtOthers.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtOthers.Size = new System.Drawing.Size(40, 19);
            this.txtOthers.TabIndex = 176;
            // 
            // labelControl1
            // 
            this.labelControl1.Appearance.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.labelControl1.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl1.Location = new System.Drawing.Point(14, 253);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(30, 14);
            this.labelControl1.TabIndex = 157;
            this.labelControl1.Text = "说明:";
            // 
            // labelControl2
            // 
            this.labelControl2.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl2.Location = new System.Drawing.Point(55, 253);
            this.labelControl2.Name = "labelControl2";
            this.labelControl2.Size = new System.Drawing.Size(72, 14);
            this.labelControl2.TabIndex = 157;
            this.labelControl2.Text = "医疗付款方式";
            // 
            // labelControl3
            // 
            this.labelControl3.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl3.Location = new System.Drawing.Point(148, 253);
            this.labelControl3.Name = "labelControl3";
            this.labelControl3.Size = new System.Drawing.Size(259, 14);
            this.labelControl3.TabIndex = 157;
            this.labelControl3.Text = "1、社会基本医疗保险（补充保险、特大病保险）";
            // 
            // labelControl4
            // 
            this.labelControl4.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl4.Location = new System.Drawing.Point(423, 253);
            this.labelControl4.Name = "labelControl4";
            this.labelControl4.Size = new System.Drawing.Size(67, 14);
            this.labelControl4.TabIndex = 157;
            this.labelControl4.Text = "2、商业保险";
            // 
            // labelControl5
            // 
            this.labelControl5.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl5.Location = new System.Drawing.Point(508, 253);
            this.labelControl5.Name = "labelControl5";
            this.labelControl5.Size = new System.Drawing.Size(67, 14);
            this.labelControl5.TabIndex = 157;
            this.labelControl5.Text = "3、自费医疗";
            // 
            // labelControl6
            // 
            this.labelControl6.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl6.Location = new System.Drawing.Point(591, 253);
            this.labelControl6.Name = "labelControl6";
            this.labelControl6.Size = new System.Drawing.Size(67, 14);
            this.labelControl6.TabIndex = 157;
            this.labelControl6.Text = "4、公费医疗";
            // 
            // labelControl7
            // 
            this.labelControl7.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl7.Location = new System.Drawing.Point(148, 283);
            this.labelControl7.Name = "labelControl7";
            this.labelControl7.Size = new System.Drawing.Size(43, 14);
            this.labelControl7.TabIndex = 157;
            this.labelControl7.Text = "6、其他";
            // 
            // labelControl8
            // 
            this.labelControl8.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl8.Location = new System.Drawing.Point(55, 283);
            this.labelControl8.Name = "labelControl8";
            this.labelControl8.Size = new System.Drawing.Size(67, 14);
            this.labelControl8.TabIndex = 157;
            this.labelControl8.Text = "5、大病统筹";
            // 
            // labelControl9
            // 
            this.labelControl9.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl9.Location = new System.Drawing.Point(241, 283);
            this.labelControl9.Name = "labelControl9";
            this.labelControl9.Size = new System.Drawing.Size(72, 14);
            this.labelControl9.TabIndex = 157;
            this.labelControl9.Text = "住院费用总计";
            // 
            // labelControl10
            // 
            this.labelControl10.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl10.Location = new System.Drawing.Point(331, 283);
            this.labelControl10.Name = "labelControl10";
            this.labelControl10.Size = new System.Drawing.Size(312, 14);
            this.labelControl10.TabIndex = 157;
            this.labelControl10.Text = "凡可由计算机提供住院费用的清单的，住院首页中可以不填";
            // 
            // Print_UCFee
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(239)))), ((int)(((byte)(255)))));
            this.Controls.Add(this.txtOthers);
            this.Controls.Add(this.seWb);
            this.Controls.Add(this.labelControl83);
            this.Controls.Add(this.labelControl79);
            this.Controls.Add(this.labelControl81);
            this.Controls.Add(this.labelControl80);
            this.Controls.Add(this.textEdit23);
            this.Controls.Add(this.lblOperation);
            this.Controls.Add(this.textEdit24);
            this.Controls.Add(this.lblAccouche);
            this.Controls.Add(this.lblCMedical);
            this.Controls.Add(this.labelControl51);
            this.Controls.Add(this.labelControl50);
            this.Controls.Add(this.labelControl41);
            this.Controls.Add(this.labelControl43);
            this.Controls.Add(this.labelControl36);
            this.Controls.Add(this.labchkBloodReaction);
            this.Controls.Add(this.labchkIsTeachingCase);
            this.Controls.Add(this.labchkIsFirstCase);
            this.Controls.Add(this.labchkBlood);
            this.Controls.Add(this.labchkRh);
            this.Controls.Add(this.labchkIsFollowing);
            this.Controls.Add(this.labAshes_Check);
            this.Controls.Add(this.lblOthers);
            this.Controls.Add(this.txtIsFollowingYear);
            this.Controls.Add(this.lblMecical);
            this.Controls.Add(this.lblCPMedical);
            this.Controls.Add(this.lblBaby);
            this.Controls.Add(this.sePlasma);
            this.Controls.Add(this.sePlt);
            this.Controls.Add(this.seRbc);
            this.Controls.Add(this.txtIsFollowingDay);
            this.Controls.Add(this.lblOx);
            this.Controls.Add(this.lblCare);
            this.Controls.Add(this.txtIsFollowingMon);
            this.Controls.Add(this.lblFollwBed);
            this.Controls.Add(this.lblBlood);
            this.Controls.Add(this.lblWMedical);
            this.Controls.Add(this.lblAnaesthesia);
            this.Controls.Add(this.lblAssay);
            this.Controls.Add(this.lblBed);
            this.Controls.Add(this.lblRis);
            this.Controls.Add(this.lblRadiate);
            this.Controls.Add(this.lblTotal);
            this.Controls.Add(this.labelControl74);
            this.Controls.Add(this.labelControl73);
            this.Controls.Add(this.labelControl47);
            this.Controls.Add(this.labelControl40);
            this.Controls.Add(this.labelControl65);
            this.Controls.Add(this.labelControl59);
            this.Controls.Add(this.labelControl54);
            this.Controls.Add(this.labelControl71);
            this.Controls.Add(this.labelControl70);
            this.Controls.Add(this.labelControl64);
            this.Controls.Add(this.labelControl58);
            this.Controls.Add(this.labelControl68);
            this.Controls.Add(this.labelControl78);
            this.Controls.Add(this.labelControl85);
            this.Controls.Add(this.labelControl82);
            this.Controls.Add(this.labelControl77);
            this.Controls.Add(this.labelControl84);
            this.Controls.Add(this.labelControl6);
            this.Controls.Add(this.labelControl5);
            this.Controls.Add(this.labelControl8);
            this.Controls.Add(this.labelControl10);
            this.Controls.Add(this.labelControl9);
            this.Controls.Add(this.labelControl7);
            this.Controls.Add(this.labelControl4);
            this.Controls.Add(this.labelControl3);
            this.Controls.Add(this.labelControl2);
            this.Controls.Add(this.labelControl76);
            this.Controls.Add(this.labelControl63);
            this.Controls.Add(this.labelControl57);
            this.Controls.Add(this.labelControl53);
            this.Controls.Add(this.labelControl52);
            this.Controls.Add(this.labelControl46);
            this.Controls.Add(this.labelControl39);
            this.Controls.Add(this.labelControl35);
            this.Controls.Add(this.labelControl72);
            this.Controls.Add(this.labelControl45);
            this.Controls.Add(this.labelControl38);
            this.Controls.Add(this.labelControl1);
            this.Controls.Add(this.labelControl75);
            this.Controls.Add(this.labelControl62);
            this.Controls.Add(this.labelControl56);
            this.Controls.Add(this.labelControl33);
            this.Controls.Add(this.labelControl48);
            this.Controls.Add(this.labelControl44);
            this.Controls.Add(this.labelControl21);
            this.Controls.Add(this.labelControl42);
            this.Controls.Add(this.labelControl37);
            this.Controls.Add(this.labelControl34);
            this.Controls.Add(this.labelControl32);
            this.Controls.Add(this.hLineEx3);
            this.Controls.Add(this.labelControl17);
            this.Controls.Add(this.hLineEx2);
            this.Controls.Add(this.hLineEx1);
            this.Controls.Add(this.hLineEx7);
            this.Name = "Print_UCFee";
            this.Size = new System.Drawing.Size(666, 317);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.Print_UCFee_Paint);
            ((System.ComponentModel.ISupportInitialize)(this.lblTotal.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblBed.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblCare.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblWMedical.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblCPMedical.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblCMedical.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblRadiate.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblAssay.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblBlood.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblOx.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblMecical.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblOperation.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblAccouche.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblRis.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblAnaesthesia.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblFollwBed.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblBaby.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblOthers.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit23.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit24.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtIsFollowingMon.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtIsFollowingDay.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtIsFollowingYear.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.seRbc.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sePlt.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sePlasma.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.seWb.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtOthers.Properties)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private HLineEx hLineEx7;
        private DevExpress.XtraEditors.TextEdit lblTotal;
        private DevExpress.XtraEditors.TextEdit lblOperation;
        private DevExpress.XtraEditors.TextEdit lblAccouche;
        private DevExpress.XtraEditors.TextEdit lblCMedical;
        private DevExpress.XtraEditors.LabelControl labelControl41;
        private DevExpress.XtraEditors.LabelControl labelControl43;
        private DevExpress.XtraEditors.LabelControl labelControl36;
        private DevExpress.XtraEditors.TextEdit lblMecical;
        private DevExpress.XtraEditors.TextEdit lblCPMedical;
        private DevExpress.XtraEditors.TextEdit lblOx;
        private DevExpress.XtraEditors.TextEdit lblCare;
        private DevExpress.XtraEditors.TextEdit lblBlood;
        private DevExpress.XtraEditors.TextEdit lblWMedical;
        private DevExpress.XtraEditors.TextEdit lblAssay;
        private DevExpress.XtraEditors.TextEdit lblBed;
        private DevExpress.XtraEditors.TextEdit lblRadiate;
        private DevExpress.XtraEditors.LabelControl labelControl40;
        private DevExpress.XtraEditors.LabelControl labelControl39;
        private DevExpress.XtraEditors.LabelControl labelControl35;
        private DevExpress.XtraEditors.LabelControl labelControl38;
        private DevExpress.XtraEditors.LabelControl labelControl33;
        private DevExpress.XtraEditors.LabelControl labelControl42;
        private DevExpress.XtraEditors.LabelControl labelControl37;
        private DevExpress.XtraEditors.LabelControl labelControl34;
        private DevExpress.XtraEditors.LabelControl labelControl32;
        private DevExpress.XtraEditors.LabelControl labelControl17;
        private DevExpress.XtraEditors.TextEdit textEdit23;
        private DevExpress.XtraEditors.TextEdit textEdit24;
        private DevExpress.XtraEditors.LabelControl labelControl51;
        private DevExpress.XtraEditors.LabelControl labelControl50;
        private DevExpress.XtraEditors.LabelControl labchkIsFirstCase;
        private DevExpress.XtraEditors.LabelControl labAshes_Check;
        private DevExpress.XtraEditors.TextEdit lblOthers;
        private DevExpress.XtraEditors.TextEdit lblBaby;
        private DevExpress.XtraEditors.TextEdit lblFollwBed;
        private DevExpress.XtraEditors.TextEdit lblAnaesthesia;
        private DevExpress.XtraEditors.TextEdit lblRis;
        private DevExpress.XtraEditors.LabelControl labelControl47;
        private DevExpress.XtraEditors.LabelControl labelControl54;
        private DevExpress.XtraEditors.LabelControl labelControl53;
        private DevExpress.XtraEditors.LabelControl labelControl52;
        private DevExpress.XtraEditors.LabelControl labelControl46;
        private DevExpress.XtraEditors.LabelControl labelControl45;
        private DevExpress.XtraEditors.LabelControl labelControl48;
        private DevExpress.XtraEditors.LabelControl labelControl44;
        private DevExpress.XtraEditors.LabelControl labelControl21;
        private DevExpress.XtraEditors.LabelControl labchkBloodReaction;
        private DevExpress.XtraEditors.LabelControl labchkIsTeachingCase;
        private DevExpress.XtraEditors.LabelControl labchkBlood;
        private DevExpress.XtraEditors.LabelControl labchkRh;
        private DevExpress.XtraEditors.LabelControl labchkIsFollowing;
        private DevExpress.XtraEditors.TextEdit txtIsFollowingYear;
        private DevExpress.XtraEditors.TextEdit txtIsFollowingDay;
        private DevExpress.XtraEditors.TextEdit txtIsFollowingMon;
        private DevExpress.XtraEditors.LabelControl labelControl74;
        private DevExpress.XtraEditors.LabelControl labelControl73;
        private DevExpress.XtraEditors.LabelControl labelControl65;
        private DevExpress.XtraEditors.LabelControl labelControl59;
        private DevExpress.XtraEditors.LabelControl labelControl71;
        private DevExpress.XtraEditors.LabelControl labelControl70;
        private DevExpress.XtraEditors.LabelControl labelControl64;
        private DevExpress.XtraEditors.LabelControl labelControl58;
        private DevExpress.XtraEditors.LabelControl labelControl68;
        private DevExpress.XtraEditors.LabelControl labelControl63;
        private DevExpress.XtraEditors.LabelControl labelControl57;
        private DevExpress.XtraEditors.LabelControl labelControl72;
        private DevExpress.XtraEditors.LabelControl labelControl62;
        private DevExpress.XtraEditors.LabelControl labelControl56;
        private HLineEx hLineEx2;
        private HLineEx hLineEx1;
        private DevExpress.XtraEditors.TextEdit txtOthers;
        private DevExpress.XtraEditors.TextEdit seWb;
        private DevExpress.XtraEditors.LabelControl labelControl83;
        private DevExpress.XtraEditors.LabelControl labelControl79;
        private DevExpress.XtraEditors.LabelControl labelControl81;
        private DevExpress.XtraEditors.LabelControl labelControl80;
        private DevExpress.XtraEditors.TextEdit sePlasma;
        private DevExpress.XtraEditors.TextEdit sePlt;
        private DevExpress.XtraEditors.TextEdit seRbc;
        private DevExpress.XtraEditors.LabelControl labelControl78;
        private DevExpress.XtraEditors.LabelControl labelControl85;
        private DevExpress.XtraEditors.LabelControl labelControl82;
        private DevExpress.XtraEditors.LabelControl labelControl77;
        private DevExpress.XtraEditors.LabelControl labelControl84;
        private DevExpress.XtraEditors.LabelControl labelControl76;
        private DevExpress.XtraEditors.LabelControl labelControl75;
        private HLineEx hLineEx3;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private DevExpress.XtraEditors.LabelControl labelControl2;
        private DevExpress.XtraEditors.LabelControl labelControl3;
        private DevExpress.XtraEditors.LabelControl labelControl4;
        private DevExpress.XtraEditors.LabelControl labelControl5;
        private DevExpress.XtraEditors.LabelControl labelControl6;
        private DevExpress.XtraEditors.LabelControl labelControl7;
        private DevExpress.XtraEditors.LabelControl labelControl8;
        private DevExpress.XtraEditors.LabelControl labelControl9;
        private DevExpress.XtraEditors.LabelControl labelControl10;
    }
}
