using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using DevExpress.XtraTreeList.Nodes;
using System.Data.SqlClient;
using DrectSoft.Wordbook;
using DrectSoft.Common.Library;
using DrectSoft.FrameWork.WinForm.Plugin;
using DrectSoft.Common.Ctrs.FORM;

namespace DrectSoft.Core.IEMMainPageZY
{
    public partial class IemNewDiagInfoForm :DevBaseForm
    {
        private IEmrHost m_App;

        private IemNewDiagInfo m_DataSearch;
        private Iem_Mainpage_Diagnosis m_IemDiagInfo = new Iem_Mainpage_Diagnosis();
        private string valueStr = DrectSoft.Service.DS_SqlService.GetConfigValueByKey("MainPageDiagnosisType");

        /// <summary>
        /// �����Ϣ
        /// </summary>
        public Iem_Mainpage_Diagnosis IemOperInfo
        {
            get
            {
                GetUI();
                return m_IemDiagInfo;
            }
            set
            {
                m_IemDiagInfo = value;
            }
        }

        /// <summary>
        /// ������� 1����ҽ  2����ҽ
        /// </summary>

        public string DiagnosisType;

        /// <summary>
        /// ��ҽ��Ͽ�
        /// </summary>
        private DataTable Diagnosis
        {
            get
            {
                if (m_Diagnosis == null)
                    m_Diagnosis = GetEditroData(12);
                return m_Diagnosis;
            }
            set
            {
                m_Diagnosis = value;
            }
        }
        private DataTable m_Diagnosis;

        /// <summary>
        /// ��ҽ��Ͽ�
        /// </summary>
        private DataTable DiagnosisOfChinese
        {
            get
            {
                if (m_DiagnosisOfChinese == null)
                    m_DiagnosisOfChinese = GetEditroData(19);
                return m_DiagnosisOfChinese;
            }
            set
            {
                m_DiagnosisOfChinese = value;
            }
        }
        private DataTable m_DiagnosisOfChinese;

        /// <summary>
        /// 
        /// </summary>
        public DataTable DataOper
        {
            get
            {
                if (m_DataOper == null)
                    m_DataOper = new DataTable();

                GetDataOper();
                return m_DataOper;
            }
        }
        private DataTable m_DataOper;
        private string m_OPETYPE;//������ҳ�洫���Ĳ������ͱ�ʶ  add ywk
        private string m_DIAGCODE;//������ICD����
        private string m_DIAGNAME;
        private string m_STATUSID;//��������Ժ����
        private string m_DIAGTYPE;//����������ҽ�ı�־
        public IemNewDiagInfoForm()
        {
            InitializeComponent();
            InitControl();   //add by ixh
        }
        public IemNewDiagInfoForm(IEmrHost app, string operatetype, string diagcode, string dianame, string status, string diagtype)
            : this()
        {
            try
            {
                m_App = app;
                InitLookUpEditor();
                m_OPETYPE = operatetype;
                m_DIAGCODE = diagcode;
                m_STATUSID = status;
                m_DIAGTYPE = diagtype;
                m_DIAGNAME = dianame;
                if (valueStr == "0")
                {
                    bwj1.Text = dianame;
                }
                else
                {
                    lueOutDiag.Text = dianame;
                }
                
                BridFormValue(m_OPETYPE, m_DIAGCODE, m_DIAGNAME, m_STATUSID, m_DIAGTYPE);
            }
            catch (Exception)
            {
                throw;
            }

        }
        //add by ixh �ж���ʾ�ĸ��ؼ�
        private void InitControl()
        {
            try
            {                
                if (valueStr == "0")
                {
                    bwj1.Visible = true;
                    bwj1.Visible = true;
                    lueOutDiag.Visible = false;
                    lueOutDiag.Visible = false;
                }
                else
                {
                    bwj1.Visible = false;
                    bwj1.Visible = false;
                    lueOutDiag.Visible = true;
                    lueOutDiag.Visible = true;
                    lueOutDiag.Left = 99;
                    lueOutDiag.Width = 370;
                    lueOutDiag.Left = 99;
                    lueOutDiag.Width = 370;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// ���ݴ�����ֵ������ʾ 
        /// </summary>
        /// <param name="m_OPETYPE"></param>
        /// <param name="m_DIAGCODE"></param>
        /// <param name="m_STATUSID"></param>
        /// <param name="m_DIAGTYPE"></param>
        private void BridFormValue(string m_OPETYPE, string m_DIAGCODE, string m_DIAGNAME, string m_STATUSID, string m_DIAGTYPE)
        {
            try
            {
                if (m_OPETYPE == "add")
                {
                }
                if (m_OPETYPE == "edit")
                {
                    if (m_DIAGTYPE == "xiyi")
                    {
                        chkDiagType1.Checked = true;
                    }
                    if (m_DIAGTYPE == "zhongyi")
                    {
                        chkDiagType2.Checked = true;
                        //BindLueData(lueOutDiag, DiagnosisOfChinese);
                    }
                    if (!string.IsNullOrEmpty(m_STATUSID))
                    {
                        switch (m_STATUSID)//������Ժ�����ѡ�����
                        {
                            case "1":
                                chkStatus1.Checked = true;
                                break;
                            case "2":
                                chkStatus2.Checked = true;
                                break;
                            case "3":
                                chkStatus3.Checked = true;
                                break;
                            case "4":
                                chkStatus4.Checked = true;
                                break;
                            default:
                                break;
                        }
                    }
                    //if (!string.IsNullOrEmpty(m_DIAGCODE))
                    //{
                    //lueOutDiag.CodeValue = m_DIAGCODE;
                    if (valueStr == "0")  //add by ixh �жϿؼ���ʾ�ĸ�ֵ
                    {
                        this.bwj1.DiaCode = m_DIAGCODE;
                        this.bwj1.DiaValue = m_DIAGNAME;
                    }
                    else
                    {
                        lueOutDiag.CodeValue = m_DIAGCODE;                        
                    }
                    //}
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private string DiagType = string.Empty;//�������
        private string GoType = string.Empty;//����������Type
        private string inputText = string.Empty;//��ȡ�ı����������

        private void obj_Click(object sender, EventArgs e)
        {
            try
            {
                if (m_OPETYPE == "DIAG")
                {

                    if (chkDiagType1.Checked)//��ҽ
                    {
                        DiagType = "XIYI";
                        inputText = bwj1.Text.ToString().Trim();
                        GoType = "OUTHOSDIAG";
                        IemNewDiagInfo diagInfo = new IemNewDiagInfo(m_App, dtXY, GoType, DiagType, inputText);
                        //inputText = string.Empty;
                        if (diagInfo.GetFormResult())
                        {
                            diagInfo.ShowDialog();
                            if (diagInfo.IsClosed)
                            {
                                bwj1.Text = diagInfo.inText;
                                bwj1.DiaCode = diagInfo.inCode;
                                bwj1.DiaValue = diagInfo.inText;
                            }
                        }
                        else
                        {
                            bwj1.DiaCode = diagInfo.inCode;
                            bwj1.DiaValue = diagInfo.inText;
                            bwj1.Multiline = false;
                        }
                    }
                    if (chkDiagType2.Checked)//��ҽ
                    {
                        DiagType = "ZHONGYI";
                        inputText = bwj1.Text.ToString().Trim();
                        GoType = "OUTHOSDIAG";
                        IemNewDiagInfo diagInfo = new IemNewDiagInfo(m_App, dtZY, GoType, DiagType, inputText);
                        //inputText = string.Empty;
                        if (diagInfo.GetFormResult())
                        {
                            diagInfo.ShowDialog();
                            if (diagInfo.IsClosed)
                            {
                                bwj1.Text = diagInfo.inText;
                                bwj1.DiaCode = diagInfo.inCode;
                                bwj1.DiaValue = diagInfo.inText;
                            }
                        }
                        else
                        {
                            bwj1.DiaCode = diagInfo.inCode;
                            bwj1.DiaValue = diagInfo.inText;
                            bwj1.Multiline = false;
                        }
                    }
                    //GoType = "OUTHOSDIAG";
                    //IemNewDiagInfo diagInfo = new IemNewDiagInfo(m_App, dtZY, GoType, DiagType, inputText); 
                    ////inputText = string.Empty;
                    //if (diagInfo.GetFormResult())
                    //{
                    //    diagInfo.ShowDialog();
                    //    if (diagInfo.IsClosed)
                    //    {
                    //        bwj1.Text = diagInfo.inText;
                    //        bwj1.DiaCode = diagInfo.inCode;
                    //        bwj1.DiaValue = diagInfo.inText;
                    //    }
                    //}
                    //else
                    //{
                    //    bwj1.DiaCode = diagInfo.inCode;
                    //    bwj1.DiaValue = diagInfo.inText;
                    //    bwj1.Multiline = false;
                    //}
                }
            }
            catch (Exception ex)
            {
                DrectSoft.Common.Ctrs.DLG.MyMessageBox.Show(ex.Message);
            }
        }
        


        private void IemNewDiagInfoForm_Load(object sender, EventArgs e)
        {
            GetFormLoadData();
           // this.bwj1.obj.Click += new EventHandler(obj_Click);
#if DEBUG
#else
            HideSbutton();
#endif
            bwj1.Focus();
        }

        private DataTable dtZY = new DataTable();
        private DataTable dtXY = new DataTable();
        public void GetFormLoadData()
        {
            try
            {
                string SqlAllDiagChinese = @"select  py, wb, name, id icd from diagnosisofchinese where valid='1' union select py, wb, name, icdid icd from diagnosischiothername where valid='1'";

                dtZY = m_App.SqlHelper.ExecuteDataTable(SqlAllDiagChinese, CommandType.Text);

                string SqlAllDiag = @"select py, wb, name, icd from diagnosis where valid='1' union select py, wb, name, icdid from diagnosisothername where valid='1";
                dtXY = m_App.SqlHelper.ExecuteDataTable(SqlAllDiag, CommandType.Text);
            }
            catch (Exception)
            {
                throw;
            }
        }

        private void getMZResult()
        {
            try
            {
                if (chkDiagType2.Checked)//��ҽ
                {
                    DiagnosisType = "2";
                    if (!string.IsNullOrEmpty(bwj1.Text.Trim()) == true)
                    {
                        //GetFormLoadData("ZHONGYI");
                        string filter = string.Empty;

                        string NameFilter = " NAME= '{0}'";
                        filter += string.Format(NameFilter, bwj1.Text.Trim());
                        dtZY.DefaultView.RowFilter = filter;

                        int dataResult = dtZY.DefaultView.ToTable().Rows.Count;

                        if (dataResult > 0)
                        {
                            bwj1.DiaValue = bwj1.Text.Trim();
                            bwj1.DiaCode = dtZY.DefaultView.ToTable().Rows[0][0].ToString();    //dtZY.row["icd"].ToString();

                        }
                        if (dataResult == 0)
                        {
                            bwj1.DiaValue = bwj1.Text.Trim();
                            bwj1.DiaCode = "";
                        }

                    }
                }
                if (chkDiagType1.Checked)//��ҽ
                {
                    DiagnosisType = "1";
                    if (!string.IsNullOrEmpty(bwj1.Text.Trim()) == true)
                    {
                        //GetFormLoadData("XIYI");
                        string filter = string.Empty;

                        string NameFilter = " NAME= '{0}'";
                        filter += string.Format(NameFilter, bwj1.Text.Trim());
                        dtXY.DefaultView.RowFilter = filter;

                        int dataResult = dtXY.DefaultView.ToTable().Rows.Count;

                        if (dataResult > 0)
                        {
                            bwj1.DiaValue = bwj1.Text.Trim();
                            bwj1.DiaCode = dtXY.DefaultView.ToTable().Rows[0]["icd"].ToString();
                            //lueMZXYZD_CODE.DiaCode = dtXY.DefaultView.ToTable().Rows[0][3].ToString();    //dtZY.row["icd"].ToString();

                        }
                        if (dataResult == 0)
                        {
                            bwj1.DiaValue = bwj1.Text.Trim();
                            bwj1.DiaCode = "";
                        }

                    }
                }
            }
            catch (Exception ex)
            {
                DrectSoft.Common.Ctrs.DLG.MyMessageBox.Show(ex.Message);
            }
        }


        /// <summary>
        /// �ж�����ҽ������ҽ ������Դ
        /// </summary>
        private void InitLookUpEditor()
        {
            try
            {
                if (chkDiagType1.Checked)
                {
                    BindLueData(lueOutDiag, Diagnosis);
                    DiagnosisType = "1";
                }
                else if (chkDiagType2.Checked)
                {
                    BindLueData(lueOutDiag, DiagnosisOfChinese);
                    DiagnosisType = "2";
                }
                lueOutDiag.CodeValue = "";
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        #region ��LUE
        private void BindLueData(LookUpEditor lueInfo, DataTable table)
        {
            LookUpWindow lupInfo = new LookUpWindow();
            lupInfo.SqlHelper = m_App.SqlHelper;
            DataTable dataTable = table;

            Dictionary<string, int> columnwidth = new Dictionary<String, Int32>();
            columnwidth.Add("����", lueInfo.Width);
            SqlWordbook sqlWordBook = new SqlWordbook("ID", dataTable, "ID", "Name", columnwidth, true);

            lueInfo.SqlWordbook = sqlWordBook;
            lueInfo.ListWindow = lupInfo;
        }

        /// <summary>
        /// ��ȡlue������Դ
        /// </summary>
        /// <param name="queryType"></param>
        /// <returns></returns>
        private DataTable GetEditroData(Decimal queryType)
        {
            SqlParameter paraType = new SqlParameter("@QueryType", SqlDbType.Decimal);
            paraType.Value = queryType;
            SqlParameter[] paramCollection = new SqlParameter[] { paraType };
            DataTable dataTable = AddTableColumn(m_App.SqlHelper.ExecuteDataTable("usp_GetLookUpEditorData", paramCollection, CommandType.StoredProcedure));
            return dataTable;
        }


        /// <summary>
        /// ��lue������Դ������ ���� ��λ
        /// </summary>
        /// <param name="dataTable"></param>
        /// <returns></returns>
        private DataTable AddTableColumn(DataTable dataTable)
        {
            DataTable dataTableAdd = dataTable;
            if (!dataTableAdd.Columns.Contains("����"))
                dataTableAdd.Columns.Add("����");
            foreach (DataRow row in dataTableAdd.Rows)
                row["����"] = row["Name"].ToString();
            return dataTableAdd;
        }
        #endregion

        private void GetUI()
        {

        }

        private void GetDataOper()
        {
            m_DataOper = new DataTable();
            #region
            if (!m_DataOper.Columns.Contains("Diagnosis_Code"))
                m_DataOper.Columns.Add("Diagnosis_Code");
            if (!m_DataOper.Columns.Contains("Diagnosis_Name"))
                m_DataOper.Columns.Add("Diagnosis_Name");
            if (!m_DataOper.Columns.Contains("Status_Id"))
                m_DataOper.Columns.Add("Status_Id");
            if (!m_DataOper.Columns.Contains("Status_Name"))
                m_DataOper.Columns.Add("Status_Name");
            if (!m_DataOper.Columns.Contains("Type"))
                m_DataOper.Columns.Add("Type");
            if (!m_DataOper.Columns.Contains("TypeName"))
                m_DataOper.Columns.Add("TypeName");
            #endregion
            FillUI();
            DataRow row = m_DataOper.NewRow();
            if (valueStr == "0")
            {
                row["Diagnosis_Code"] = bwj1.DiaCode; //lueOutDiag.CodeValue;
                row["Diagnosis_Name"] = bwj1.DiaValue;//lueOutDiag.DisplayValue;
            }
            else
            {
                row["Diagnosis_Code"] =lueOutDiag.CodeValue;
                row["Diagnosis_Name"] =lueOutDiag.DisplayValue;    
            }

            //״̬
            if (chkStatus1.Checked)
            {
                row["Status_Id"] = 1;
                row["Status_Name"] = chkStatus1.Tag.ToString();
            }
            else if (chkStatus2.Checked)
            {
                row["Status_Id"] = 2;
                row["Status_Name"] = chkStatus2.Tag.ToString();
            }
            else if (chkStatus3.Checked)
            {
                row["Status_Id"] = 3;
                row["Status_Name"] = chkStatus3.Tag.ToString();
            }
            else if (chkStatus4.Checked)
            {
                row["Status_Id"] = 4;
                row["Status_Name"] = chkStatus4.Tag.ToString();
            }

            if (chkDiagType1.Checked)
            {
                row["Type"] = "1";
                row["TypeName"] = "��ҽ���";
            }
            else if (chkDiagType2.Checked)
            {
                row["Type"] = "2";
                row["TypeName"] = "��ҽ���";
            }

            m_DataOper.Rows.Add(row);
            //m_DataOper.AcceptChanges();

        }

        private void FillUI()
        {
            //if (m_IemDiagInfo == null || String.IsNullOrEmpty(m_IemDiagInfo.Diagnosis_Code))
            //    return;
            //lueOutDiag.CodeValue = m_IemDiagInfo.Diagnosis_Code;

            //if (m_IemDiagInfo.Status_Id == 1)
            //    chkStatus1.Checked = true;
            //if (m_IemDiagInfo.Status_Id == 2)
            //    chkStatus2.Checked = true;
            //if (m_IemDiagInfo.Status_Id == 3)
            //    chkStatus3.Checked = true;
            //if (m_IemDiagInfo.Status_Id == 4)
            //    chkStatus4.Checked = true;
            //if (m_IemDiagInfo.Status_Id == 5)
            //    chkStatus5.Checked = true;

        }

        private void HideSbutton()
        {
            foreach (Control ctl in this.Controls)
            {
                if (ctl.GetType() == typeof(LookUpEditor))
                    ((LookUpEditor)ctl).ShowSButton = false;
                else
                {
                    foreach (Control ct in ctl.Controls)
                    {
                        if (ct.GetType() == typeof(LookUpEditor))
                            ((LookUpEditor)ct).ShowSButton = false;
                    }
                }
            }
        }

        private void btnConfirm_Click(object sender, EventArgs e)
        {
            try
            {
                getMZResult();
                //add by ywk 2013��7��8�� 14:44:18
                if (valueStr == "0")
                {
                    if (String.IsNullOrEmpty(this.bwj1.Text))
                    {
                        m_App.CustomMessageBox.MessageShow("��ѡ�������Ϣ");
                        return;
                    }
                }
                else
                {
                    if (String.IsNullOrEmpty(this.lueOutDiag.Text))
                    {
                        m_App.CustomMessageBox.MessageShow("��ѡ�������Ϣ");
                        return;
                    }
                }
                if (!String.IsNullOrEmpty(this.bwj1.DiaCode))
                {
                    bwj1.Text = "";
                    this.DialogResult = DialogResult.OK;
                }
                else
                {
                    this.bwj1.DiaValue = bwj1.Text.Trim();
                    this.bwj1.DiaCode = string.Empty;
                    this.DialogResult = DialogResult.OK;
                    return;
                    //m_App.CustomMessageBox.MessageShow("��ѡ����������");
                }
                //if (string.IsNullOrEmpty(bwj1.Text.Trim()))
                //{
                //    m_App.CustomMessageBox.MessageShow("������סԺ�����Ϣ");
                //}
            }
            catch (Exception ex)
            {
                DrectSoft.Common.Ctrs.DLG.MyMessageBox.Show(ex.Message);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }

        private void chkDiagType1_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                InitLookUpEditor();
            }
            catch (Exception ex)
            {
                DrectSoft.Common.Ctrs.DLG.MyMessageBox.Show(ex.Message);
            }
        }

        private void bwj1_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                Button btn = new Button();
                string oldstr = bwj1.Text.Trim();
                //if (bwj1.Text.Trim() == null)
                //{
                //    IemNewDiagInfo diagInfo = new IemNewDiagInfo(m_App, GoType, DiagType, inputText);
                //    if(diagInfo.
                //    //inputText = string.Empty;
                //}
                if (bwj1.Text.Trim() != null && e.KeyChar == 13)
                {
                    if (chkDiagType1.Checked)//��ҽ
                    {
                        DiagType = "XIYI";
                        inputText = bwj1.Text.Trim();
                        GoType = "OUTHOSDIAG";
                        IemNewDiagInfo diagInfo = new IemNewDiagInfo(m_App, dtXY, GoType, DiagType, inputText);
                        //inputText = string.Empty;
                        if (diagInfo.GetFormResult())
                        {
                            diagInfo.ShowDialog();
                            if (diagInfo.IsClosed)
                            {

                                bwj1.Text = diagInfo.inText;

                                //bwj1.Enabled = true;

                                bwj1.DiaCode = diagInfo.inCode;
                                bwj1.DiaValue = diagInfo.inText;
                                bwj1.Focus();
                                bwj1.Enabled = true;

                                //bwj1.Focused = true;
                            }
                        }
                        else
                        {
                            bwj1.DiaCode = diagInfo.inCode;
                            bwj1.DiaValue = diagInfo.inText;
                            //bwj1.Multiline = false;
                        }
                    }
                    if (chkDiagType2.Checked)//��ҽ
                    {
                        DiagType = "ZHONGYI";
                        inputText = bwj1.Text.Trim();
                        GoType = "OUTHOSDIAG";
                        IemNewDiagInfo diagInfo = new IemNewDiagInfo(m_App, dtZY, GoType, DiagType, inputText);
                        //inputText = string.Empty;
                        if (diagInfo.GetFormResult())
                        {
                            diagInfo.ShowDialog();
                            if (diagInfo.IsClosed)
                            {

                                bwj1.Text = diagInfo.inText;

                                //bwj1.Enabled = true;

                                bwj1.DiaCode = diagInfo.inCode;
                                bwj1.DiaValue = diagInfo.inText;
                                bwj1.Focus();
                                bwj1.Enabled = true;

                                //bwj1.Focused = true;
                            }
                        }
                        else
                        {
                            bwj1.DiaCode = diagInfo.inCode;
                            bwj1.DiaValue = diagInfo.inText;
                            //bwj1.Multiline = false;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                DrectSoft.Common.Ctrs.DLG.MyMessageBox.Show(ex.Message);
            }
        }

        public void diagInfo_FormClosed(object sender, EventArgs e)
        {
            try
            {
                IemNewDiagInfo diagInfo = (IemNewDiagInfo)sender;
                if (diagInfo.IsClosed)
                {
                    bwj1.Text = diagInfo.inText;
                    //bwj1.DiaCode = string.Empty;

                    bwj1.DiaCode = diagInfo.inCode;
                    bwj1.DiaValue = diagInfo.inText;
                    bwj1.Focus();
                }
            }
            catch (Exception ex)
            {
                DrectSoft.Common.Ctrs.DLG.MyMessageBox.Show(ex.Message);
            }
        }
    }
}
