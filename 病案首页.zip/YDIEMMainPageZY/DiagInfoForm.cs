﻿using DrectSoft.Common.Ctrs.FORM;

namespace DrectSoft.Core.IEMMainPageZY
{
    public partial class DiagInfoForm : DevBaseForm
    {
        public DiagInfoForm()
        {
            InitializeComponent();
        }
    }
}
