﻿namespace DrectSoft.Core.IEMMainPage
{
    partial class UCMainForm
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.simpleButton1 = new DevExpress.XtraEditors.SimpleButton();
            this.simpleButton6 = new DevExpress.XtraEditors.SimpleButton();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.simpleButton5 = new DevExpress.XtraEditors.SimpleButton();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.simpleButton4 = new DevExpress.XtraEditors.SimpleButton();
            this.simpleButton2 = new DevExpress.XtraEditors.SimpleButton();
            this.simpleButton3 = new DevExpress.XtraEditors.SimpleButton();
            this.simpleButtonTemp = new DevExpress.XtraEditors.SimpleButton();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // simpleButton1
            // 
            this.simpleButton1.Location = new System.Drawing.Point(84, 27);
            this.simpleButton1.Name = "simpleButton1";
            this.simpleButton1.Size = new System.Drawing.Size(39, 120);
            this.simpleButton1.TabIndex = 23;
            this.simpleButton1.Text = "编辑";
            this.simpleButton1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.simpleButton1_MouseMove);
            // 
            // simpleButton6
            // 
            this.simpleButton6.Location = new System.Drawing.Point(174, 153);
            this.simpleButton6.Name = "simpleButton6";
            this.simpleButton6.Size = new System.Drawing.Size(39, 120);
            this.simpleButton6.TabIndex = 28;
            this.simpleButton6.Text = "编辑";
            this.simpleButton6.Click += new System.EventHandler(this.simpleButton6_Click);
            this.simpleButton6.MouseEnter += new System.EventHandler(this.simpleButton6_MouseEnter);
            this.simpleButton6.MouseLeave += new System.EventHandler(this.simpleButton6_MouseLeave);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Location = new System.Drawing.Point(229, 27);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(128, 120);
            this.pictureBox1.TabIndex = 21;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            this.pictureBox1.Paint += new System.Windows.Forms.PaintEventHandler(this.pictureBox1_Paint);
            // 
            // simpleButton5
            // 
            this.simpleButton5.Location = new System.Drawing.Point(129, 153);
            this.simpleButton5.Name = "simpleButton5";
            this.simpleButton5.Size = new System.Drawing.Size(39, 120);
            this.simpleButton5.TabIndex = 27;
            this.simpleButton5.Text = "编辑";
            this.simpleButton5.Click += new System.EventHandler(this.simpleButton5_Click);
            this.simpleButton5.MouseEnter += new System.EventHandler(this.simpleButton5_MouseEnter);
            this.simpleButton5.MouseLeave += new System.EventHandler(this.simpleButton5_MouseLeave);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox2.Location = new System.Drawing.Point(229, 153);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(128, 120);
            this.pictureBox2.TabIndex = 22;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            this.pictureBox2.Paint += new System.Windows.Forms.PaintEventHandler(this.pictureBox2_Paint);
            // 
            // simpleButton4
            // 
            this.simpleButton4.Location = new System.Drawing.Point(84, 153);
            this.simpleButton4.Name = "simpleButton4";
            this.simpleButton4.Size = new System.Drawing.Size(39, 120);
            this.simpleButton4.TabIndex = 26;
            this.simpleButton4.Text = "编辑";
            this.simpleButton4.Click += new System.EventHandler(this.simpleButton4_Click);
            this.simpleButton4.MouseEnter += new System.EventHandler(this.simpleButton4_MouseEnter);
            this.simpleButton4.MouseLeave += new System.EventHandler(this.simpleButton4_MouseLeave);
            // 
            // simpleButton2
            // 
            this.simpleButton2.Location = new System.Drawing.Point(129, 27);
            this.simpleButton2.Name = "simpleButton2";
            this.simpleButton2.Size = new System.Drawing.Size(39, 120);
            this.simpleButton2.TabIndex = 24;
            this.simpleButton2.Text = "编辑";
            this.simpleButton2.Click += new System.EventHandler(this.simpleButton2_Click);
            this.simpleButton2.MouseEnter += new System.EventHandler(this.simpleButton2_MouseEnter);
            this.simpleButton2.MouseLeave += new System.EventHandler(this.simpleButton2_MouseLeave);
            // 
            // simpleButton3
            // 
            this.simpleButton3.Location = new System.Drawing.Point(174, 27);
            this.simpleButton3.Name = "simpleButton3";
            this.simpleButton3.Size = new System.Drawing.Size(39, 120);
            this.simpleButton3.TabIndex = 25;
            this.simpleButton3.Text = "编辑";
            this.simpleButton3.Click += new System.EventHandler(this.simpleButton3_Click);
            this.simpleButton3.MouseEnter += new System.EventHandler(this.simpleButton3_MouseEnter);
            this.simpleButton3.MouseLeave += new System.EventHandler(this.simpleButton3_MouseLeave);
            // 
            // simpleButtonTemp
            // 
            this.simpleButtonTemp.Location = new System.Drawing.Point(-8, -7);
            this.simpleButtonTemp.Name = "simpleButtonTemp";
            this.simpleButtonTemp.Size = new System.Drawing.Size(10, 10);
            this.simpleButtonTemp.TabIndex = 29;
            // 
            // UCMainForm
            // 
            this.Appearance.BackColor = System.Drawing.Color.White;
            this.Appearance.Options.UseBackColor = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.Controls.Add(this.simpleButtonTemp);
            this.Controls.Add(this.simpleButton1);
            this.Controls.Add(this.simpleButton3);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.simpleButton6);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.simpleButton2);
            this.Controls.Add(this.simpleButton5);
            this.Controls.Add(this.simpleButton4);
            this.Name = "UCMainForm";
            this.Size = new System.Drawing.Size(510, 533);
            this.Click += new System.EventHandler(this.UCMainForm_Click);
            this.Resize += new System.EventHandler(this.UCMainForm_Resize);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraEditors.SimpleButton simpleButton1;
        private DevExpress.XtraEditors.SimpleButton simpleButton6;
        private System.Windows.Forms.PictureBox pictureBox1;
        private DevExpress.XtraEditors.SimpleButton simpleButton5;
        private System.Windows.Forms.PictureBox pictureBox2;
        private DevExpress.XtraEditors.SimpleButton simpleButton4;
        private DevExpress.XtraEditors.SimpleButton simpleButton2;
        private DevExpress.XtraEditors.SimpleButton simpleButton3;
        private DevExpress.XtraEditors.SimpleButton simpleButtonTemp;
    }
}
