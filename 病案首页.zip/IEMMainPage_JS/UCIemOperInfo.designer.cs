﻿namespace DrectSoft.Core.IEMMainPage
{
    partial class UCIemOperInfo
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.btnAddOperation = new DevExpress.XtraEditors.SimpleButton();
            this.gridControl1 = new DevExpress.XtraGrid.GridControl();
            this.gridViewOper = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn10 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn11 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn3 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn4 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn14 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn5 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn15 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn6 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn16 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn17 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn7 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn18 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn8 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn19 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn9 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn12 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn13 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn20 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn21 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn22 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn23 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn24 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn25 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.barManager1 = new DevExpress.XtraBars.BarManager();
            this.barDockControlTop = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlBottom = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlLeft = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlRight = new DevExpress.XtraBars.BarDockControl();
            this.btn_del_Operinfo = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem1 = new DevExpress.XtraBars.BarButtonItem();
            this.btn_del_operbefore_diag = new DevExpress.XtraBars.BarButtonItem();
            this.btn_operafter_diag = new DevExpress.XtraBars.BarButtonItem();
            this.popupMenu1 = new DevExpress.XtraBars.PopupMenu();
            this.btn_Close = new DevExpress.XtraEditors.SimpleButton();
            this.btn_OK = new DevExpress.XtraEditors.SimpleButton();
            this.txtLaterHosComaMinute = new DevExpress.XtraEditors.TextEdit();
            this.txtBeforeHosComaMinute = new DevExpress.XtraEditors.TextEdit();
            this.txtLaterHosComaHour = new DevExpress.XtraEditors.TextEdit();
            this.txtBeforeHosComaHour = new DevExpress.XtraEditors.TextEdit();
            this.txtLaterHosComaDay = new DevExpress.XtraEditors.TextEdit();
            this.txtBeforeHosComaDay = new DevExpress.XtraEditors.TextEdit();
            this.txtAgainInHospitalReason = new DevExpress.XtraEditors.TextEdit();
            this.txtReceiveHosPital = new DevExpress.XtraEditors.TextEdit();
            this.labelControl24 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl23 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl38 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl32 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl36 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl30 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl34 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl27 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl25 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl22 = new DevExpress.XtraEditors.LabelControl();
            this.chkAgainInHospital2 = new DevExpress.XtraEditors.CheckEdit();
            this.chkOutHosType2 = new DevExpress.XtraEditors.CheckEdit();
            this.chkOutHosType3 = new DevExpress.XtraEditors.CheckEdit();
            this.chkOutHosType9 = new DevExpress.XtraEditors.CheckEdit();
            this.chkOutHosType5 = new DevExpress.XtraEditors.CheckEdit();
            this.chkOutHosType4 = new DevExpress.XtraEditors.CheckEdit();
            this.chkAgainInHospital1 = new DevExpress.XtraEditors.CheckEdit();
            this.chkOutHosType1 = new DevExpress.XtraEditors.CheckEdit();
            this.hLineEx1 = new DrectSoft.Core.IEMMainPage.HLineEx();
            this.chkzg_flag1 = new DevExpress.XtraEditors.CheckEdit();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.chkzg_flag2 = new DevExpress.XtraEditors.CheckEdit();
            this.chkzg_flag3 = new DevExpress.XtraEditors.CheckEdit();
            this.chkzg_flag4 = new DevExpress.XtraEditors.CheckEdit();
            this.chkzg_flag5 = new DevExpress.XtraEditors.CheckEdit();
            this.btnEditOperation = new DevExpress.XtraEditors.SimpleButton();
            this.txtReceiveHosPital2 = new DevExpress.XtraEditors.TextEdit();
            this.btn_delete = new DevExpress.XtraEditors.SimpleButton();
            ((System.ComponentModel.ISupportInitialize)(this.gridControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewOper)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.barManager1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.popupMenu1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtLaterHosComaMinute.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtBeforeHosComaMinute.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtLaterHosComaHour.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtBeforeHosComaHour.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtLaterHosComaDay.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtBeforeHosComaDay.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtAgainInHospitalReason.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtReceiveHosPital.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkAgainInHospital2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkOutHosType2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkOutHosType3.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkOutHosType9.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkOutHosType5.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkOutHosType4.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkAgainInHospital1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkOutHosType1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkzg_flag1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkzg_flag2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkzg_flag3.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkzg_flag4.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkzg_flag5.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtReceiveHosPital2.Properties)).BeginInit();
            this.SuspendLayout();
            // 
            // btnAddOperation
            // 
            this.btnAddOperation.Location = new System.Drawing.Point(5, 11);
            this.btnAddOperation.Name = "btnAddOperation";
            this.btnAddOperation.Size = new System.Drawing.Size(80, 23);
            this.btnAddOperation.TabIndex = 0;
            this.btnAddOperation.Text = "新增 (&A)";
            this.btnAddOperation.ToolTip = "新增手术信息";
            this.btnAddOperation.Click += new System.EventHandler(this.btnAddOperation_Click);
            // 
            // gridControl1
            // 
            this.gridControl1.Location = new System.Drawing.Point(5, 40);
            this.gridControl1.MainView = this.gridViewOper;
            this.gridControl1.Name = "gridControl1";
            this.gridControl1.Size = new System.Drawing.Size(610, 109);
            this.gridControl1.TabIndex = 3;
            this.gridControl1.TabStop = false;
            this.gridControl1.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridViewOper});
            this.gridControl1.Load += new System.EventHandler(this.gridControl1_Load);
            this.gridControl1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.gridControl1_MouseUp);
            // 
            // gridViewOper
            // 
            this.gridViewOper.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn1,
            this.gridColumn2,
            this.gridColumn10,
            this.gridColumn11,
            this.gridColumn3,
            this.gridColumn4,
            this.gridColumn14,
            this.gridColumn5,
            this.gridColumn15,
            this.gridColumn6,
            this.gridColumn16,
            this.gridColumn17,
            this.gridColumn7,
            this.gridColumn18,
            this.gridColumn8,
            this.gridColumn19,
            this.gridColumn9,
            this.gridColumn12,
            this.gridColumn13,
            this.gridColumn20,
            this.gridColumn21,
            this.gridColumn22,
            this.gridColumn23,
            this.gridColumn24,
            this.gridColumn25});
            this.gridViewOper.GridControl = this.gridControl1;
            this.gridViewOper.Name = "gridViewOper";
            this.gridViewOper.OptionsCustomization.AllowColumnMoving = false;
            this.gridViewOper.OptionsCustomization.AllowFilter = false;
            this.gridViewOper.OptionsCustomization.AllowGroup = false;
            this.gridViewOper.OptionsCustomization.AllowQuickHideColumns = false;
            this.gridViewOper.OptionsFilter.AllowColumnMRUFilterList = false;
            this.gridViewOper.OptionsFilter.AllowFilterEditor = false;
            this.gridViewOper.OptionsFilter.AllowMRUFilterList = false;
            this.gridViewOper.OptionsMenu.EnableColumnMenu = false;
            this.gridViewOper.OptionsMenu.EnableFooterMenu = false;
            this.gridViewOper.OptionsMenu.EnableGroupPanelMenu = false;
            this.gridViewOper.OptionsMenu.ShowAutoFilterRowItem = false;
            this.gridViewOper.OptionsMenu.ShowDateTimeGroupIntervalItems = false;
            this.gridViewOper.OptionsMenu.ShowGroupSortSummaryItems = false;
            this.gridViewOper.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.gridViewOper.OptionsView.ShowGroupPanel = false;
            this.gridViewOper.OptionsView.ShowIndicator = false;
            // 
            // gridColumn1
            // 
            this.gridColumn1.Caption = "手术操作码";
            this.gridColumn1.FieldName = "Operation_Code";
            this.gridColumn1.Name = "gridColumn1";
            this.gridColumn1.OptionsColumn.AllowEdit = false;
            this.gridColumn1.Visible = true;
            this.gridColumn1.VisibleIndex = 0;
            this.gridColumn1.Width = 67;
            // 
            // gridColumn2
            // 
            this.gridColumn2.Caption = "手术操作日期";
            this.gridColumn2.FieldName = "Operation_Date";
            this.gridColumn2.Name = "gridColumn2";
            this.gridColumn2.OptionsColumn.AllowEdit = false;
            this.gridColumn2.Visible = true;
            this.gridColumn2.VisibleIndex = 1;
            this.gridColumn2.Width = 79;
            // 
            // gridColumn10
            // 
            this.gridColumn10.Caption = "手术等级";
            this.gridColumn10.FieldName = "OPERATION_LEVEL_NAME";
            this.gridColumn10.Name = "gridColumn10";
            this.gridColumn10.OptionsColumn.AllowEdit = false;
            this.gridColumn10.Visible = true;
            this.gridColumn10.VisibleIndex = 2;
            this.gridColumn10.Width = 52;
            // 
            // gridColumn11
            // 
            this.gridColumn11.Caption = "手术等级编号";
            this.gridColumn11.FieldName = "OPERATION_LEVEL";
            this.gridColumn11.Name = "gridColumn11";
            // 
            // gridColumn3
            // 
            this.gridColumn3.Caption = "手术操作名称";
            this.gridColumn3.FieldName = "Operation_Name";
            this.gridColumn3.Name = "gridColumn3";
            this.gridColumn3.OptionsColumn.AllowEdit = false;
            this.gridColumn3.Visible = true;
            this.gridColumn3.VisibleIndex = 3;
            this.gridColumn3.Width = 52;
            // 
            // gridColumn4
            // 
            this.gridColumn4.Caption = "术者";
            this.gridColumn4.FieldName = "Execute_User1_Name";
            this.gridColumn4.Name = "gridColumn4";
            this.gridColumn4.OptionsColumn.AllowEdit = false;
            this.gridColumn4.Visible = true;
            this.gridColumn4.VisibleIndex = 4;
            this.gridColumn4.Width = 52;
            // 
            // gridColumn14
            // 
            this.gridColumn14.Caption = "术者ID";
            this.gridColumn14.FieldName = "Execute_User1";
            this.gridColumn14.Name = "gridColumn14";
            this.gridColumn14.OptionsColumn.AllowEdit = false;
            // 
            // gridColumn5
            // 
            this.gridColumn5.Caption = "I助";
            this.gridColumn5.FieldName = "Execute_User2_Name";
            this.gridColumn5.Name = "gridColumn5";
            this.gridColumn5.OptionsColumn.AllowEdit = false;
            this.gridColumn5.Visible = true;
            this.gridColumn5.VisibleIndex = 5;
            this.gridColumn5.Width = 52;
            // 
            // gridColumn15
            // 
            this.gridColumn15.Caption = "I助ID";
            this.gridColumn15.FieldName = "Execute_User2";
            this.gridColumn15.Name = "gridColumn15";
            this.gridColumn15.OptionsColumn.AllowEdit = false;
            // 
            // gridColumn6
            // 
            this.gridColumn6.Caption = "II助";
            this.gridColumn6.FieldName = "Execute_User3_Name";
            this.gridColumn6.Name = "gridColumn6";
            this.gridColumn6.OptionsColumn.AllowEdit = false;
            this.gridColumn6.Visible = true;
            this.gridColumn6.VisibleIndex = 6;
            this.gridColumn6.Width = 52;
            // 
            // gridColumn16
            // 
            this.gridColumn16.Caption = "II助ID";
            this.gridColumn16.FieldName = "Execute_User3";
            this.gridColumn16.Name = "gridColumn16";
            this.gridColumn16.OptionsColumn.AllowEdit = false;
            // 
            // gridColumn17
            // 
            this.gridColumn17.Caption = "麻醉方式";
            this.gridColumn17.FieldName = "Anaesthesia_Type_Name";
            this.gridColumn17.Name = "gridColumn17";
            this.gridColumn17.OptionsColumn.AllowEdit = false;
            this.gridColumn17.Visible = true;
            this.gridColumn17.VisibleIndex = 7;
            this.gridColumn17.Width = 52;
            // 
            // gridColumn7
            // 
            this.gridColumn7.Caption = "麻醉方式ID";
            this.gridColumn7.FieldName = "Anaesthesia_Type_Id";
            this.gridColumn7.Name = "gridColumn7";
            this.gridColumn7.OptionsColumn.AllowEdit = false;
            // 
            // gridColumn18
            // 
            this.gridColumn18.Caption = "切口愈合等级";
            this.gridColumn18.FieldName = "Close_Level_Name";
            this.gridColumn18.Name = "gridColumn18";
            this.gridColumn18.OptionsColumn.AllowEdit = false;
            this.gridColumn18.Visible = true;
            this.gridColumn18.VisibleIndex = 8;
            this.gridColumn18.Width = 52;
            // 
            // gridColumn8
            // 
            this.gridColumn8.Caption = "切口愈合等级ID";
            this.gridColumn8.FieldName = "Close_Level";
            this.gridColumn8.Name = "gridColumn8";
            this.gridColumn8.OptionsColumn.AllowEdit = false;
            // 
            // gridColumn19
            // 
            this.gridColumn19.Caption = "麻醉医师";
            this.gridColumn19.FieldName = "Anaesthesia_User_Name";
            this.gridColumn19.Name = "gridColumn19";
            this.gridColumn19.OptionsColumn.AllowEdit = false;
            this.gridColumn19.Visible = true;
            this.gridColumn19.VisibleIndex = 9;
            this.gridColumn19.Width = 98;
            // 
            // gridColumn9
            // 
            this.gridColumn9.Caption = "麻醉医师ID";
            this.gridColumn9.FieldName = "Anaesthesia_User";
            this.gridColumn9.Name = "gridColumn9";
            this.gridColumn9.OptionsColumn.AllowEdit = false;
            // 
            // gridColumn12
            // 
            this.gridColumn12.Caption = "是否择期手术";
            this.gridColumn12.FieldName = "ISCHOOSEDATENAME";
            this.gridColumn12.Name = "gridColumn12";
            this.gridColumn12.OptionsColumn.AllowEdit = false;
            this.gridColumn12.Visible = true;
            this.gridColumn12.VisibleIndex = 10;
            // 
            // gridColumn13
            // 
            this.gridColumn13.Caption = "是否无菌手术";
            this.gridColumn13.FieldName = "ISCLEAROPENAME";
            this.gridColumn13.Name = "gridColumn13";
            this.gridColumn13.OptionsColumn.AllowEdit = false;
            this.gridColumn13.Visible = true;
            this.gridColumn13.VisibleIndex = 11;
            // 
            // gridColumn20
            // 
            this.gridColumn20.Caption = "是否感染";
            this.gridColumn20.FieldName = "ISGANRANNAME";
            this.gridColumn20.Name = "gridColumn20";
            this.gridColumn20.OptionsColumn.AllowEdit = false;
            this.gridColumn20.Visible = true;
            this.gridColumn20.VisibleIndex = 12;
            // 
            // gridColumn21
            // 
            this.gridColumn21.Caption = "是否择期手术编号";
            this.gridColumn21.FieldName = "ISCHOOSEDATEID";
            this.gridColumn21.Name = "gridColumn21";
            // 
            // gridColumn22
            // 
            this.gridColumn22.Caption = "是否无菌手术编号";
            this.gridColumn22.FieldName = "ISCLEAROPEID";
            this.gridColumn22.Name = "gridColumn22";
            // 
            // gridColumn23
            // 
            this.gridColumn23.Caption = "是否感染编号";
            this.gridColumn23.FieldName = "ISGANRANID";
            this.gridColumn23.Name = "gridColumn23";
            // 
            // gridColumn24
            // 
            this.gridColumn24.Caption = "麻醉分级";
            this.gridColumn24.FieldName = "ANESTHESIA_LEVEL";
            this.gridColumn24.Name = "gridColumn24";
            // 
            // gridColumn25
            // 
            this.gridColumn25.Caption = "手术并发症";
            this.gridColumn25.FieldName = "OPERCOMPLICATION_CODE";
            this.gridColumn25.Name = "gridColumn25";
            // 
            // barManager1
            // 
            this.barManager1.DockControls.Add(this.barDockControlTop);
            this.barManager1.DockControls.Add(this.barDockControlBottom);
            this.barManager1.DockControls.Add(this.barDockControlLeft);
            this.barManager1.DockControls.Add(this.barDockControlRight);
            this.barManager1.Form = this;
            this.barManager1.Items.AddRange(new DevExpress.XtraBars.BarItem[] {
            this.btn_del_Operinfo,
            this.barButtonItem1,
            this.btn_del_operbefore_diag,
            this.btn_operafter_diag});
            this.barManager1.MaxItemId = 7;
            this.barManager1.QueryShowPopupMenu += new DevExpress.XtraBars.QueryShowPopupMenuEventHandler(this.barManager1_QueryShowPopupMenu);
            // 
            // barDockControlTop
            // 
            this.barDockControlTop.CausesValidation = false;
            this.barDockControlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.barDockControlTop.Location = new System.Drawing.Point(0, 0);
            this.barDockControlTop.Size = new System.Drawing.Size(620, 0);
            // 
            // barDockControlBottom
            // 
            this.barDockControlBottom.CausesValidation = false;
            this.barDockControlBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.barDockControlBottom.Location = new System.Drawing.Point(0, 368);
            this.barDockControlBottom.Size = new System.Drawing.Size(620, 0);
            // 
            // barDockControlLeft
            // 
            this.barDockControlLeft.CausesValidation = false;
            this.barDockControlLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.barDockControlLeft.Location = new System.Drawing.Point(0, 0);
            this.barDockControlLeft.Size = new System.Drawing.Size(0, 368);
            // 
            // barDockControlRight
            // 
            this.barDockControlRight.CausesValidation = false;
            this.barDockControlRight.Dock = System.Windows.Forms.DockStyle.Right;
            this.barDockControlRight.Location = new System.Drawing.Point(620, 0);
            this.barDockControlRight.Size = new System.Drawing.Size(0, 368);
            // 
            // btn_del_Operinfo
            // 
            this.btn_del_Operinfo.Caption = "删除";
            this.btn_del_Operinfo.Id = 1;
            this.btn_del_Operinfo.Name = "btn_del_Operinfo";
            this.btn_del_Operinfo.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btn_del_Operinfo_ItemClick);
            // 
            // barButtonItem1
            // 
            this.barButtonItem1.Caption = "barButtonItem1";
            this.barButtonItem1.Id = 2;
            this.barButtonItem1.Name = "barButtonItem1";
            // 
            // btn_del_operbefore_diag
            // 
            this.btn_del_operbefore_diag.Id = 5;
            this.btn_del_operbefore_diag.Name = "btn_del_operbefore_diag";
            // 
            // btn_operafter_diag
            // 
            this.btn_operafter_diag.Id = 6;
            this.btn_operafter_diag.Name = "btn_operafter_diag";
            // 
            // popupMenu1
            // 
            this.popupMenu1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.btn_del_Operinfo),
            new DevExpress.XtraBars.LinkPersistInfo(this.btn_del_operbefore_diag),
            new DevExpress.XtraBars.LinkPersistInfo(this.btn_operafter_diag)});
            this.popupMenu1.Manager = this.barManager1;
            this.popupMenu1.Name = "popupMenu1";
            // 
            // btn_Close
            // 
            this.btn_Close.Location = new System.Drawing.Point(539, 326);
            this.btn_Close.Name = "btn_Close";
            this.btn_Close.Size = new System.Drawing.Size(75, 27);
            this.btn_Close.TabIndex = 39;
            this.btn_Close.Text = "关闭 (&T)";
            this.btn_Close.ToolTip = "关闭";
            this.btn_Close.Click += new System.EventHandler(this.btn_Close_Click);
            // 
            // btn_OK
            // 
            this.btn_OK.Location = new System.Drawing.Point(454, 326);
            this.btn_OK.Name = "btn_OK";
            this.btn_OK.Size = new System.Drawing.Size(75, 27);
            this.btn_OK.TabIndex = 38;
            this.btn_OK.Text = "保存 (&S)";
            this.btn_OK.ToolTip = "保存";
            this.btn_OK.Click += new System.EventHandler(this.btn_OK_Click);
            // 
            // txtLaterHosComaMinute
            // 
            this.txtLaterHosComaMinute.Location = new System.Drawing.Point(541, 298);
            this.txtLaterHosComaMinute.Name = "txtLaterHosComaMinute";
            this.txtLaterHosComaMinute.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtLaterHosComaMinute.Size = new System.Drawing.Size(26, 19);
            this.txtLaterHosComaMinute.TabIndex = 36;
            this.txtLaterHosComaMinute.Click += new System.EventHandler(this.txt_Enter);
            this.txtLaterHosComaMinute.Enter += new System.EventHandler(this.txt_Enter);
            // 
            // txtBeforeHosComaMinute
            // 
            this.txtBeforeHosComaMinute.Location = new System.Drawing.Point(317, 298);
            this.txtBeforeHosComaMinute.Name = "txtBeforeHosComaMinute";
            this.txtBeforeHosComaMinute.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtBeforeHosComaMinute.Size = new System.Drawing.Size(26, 19);
            this.txtBeforeHosComaMinute.TabIndex = 29;
            this.txtBeforeHosComaMinute.Click += new System.EventHandler(this.txt_Enter);
            this.txtBeforeHosComaMinute.Enter += new System.EventHandler(this.txt_Enter);
            // 
            // txtLaterHosComaHour
            // 
            this.txtLaterHosComaHour.Location = new System.Drawing.Point(481, 298);
            this.txtLaterHosComaHour.Name = "txtLaterHosComaHour";
            this.txtLaterHosComaHour.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtLaterHosComaHour.Size = new System.Drawing.Size(26, 19);
            this.txtLaterHosComaHour.TabIndex = 34;
            this.txtLaterHosComaHour.Click += new System.EventHandler(this.txt_Enter);
            this.txtLaterHosComaHour.Enter += new System.EventHandler(this.txt_Enter);
            // 
            // txtBeforeHosComaHour
            // 
            this.txtBeforeHosComaHour.Location = new System.Drawing.Point(257, 298);
            this.txtBeforeHosComaHour.Name = "txtBeforeHosComaHour";
            this.txtBeforeHosComaHour.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtBeforeHosComaHour.Size = new System.Drawing.Size(26, 19);
            this.txtBeforeHosComaHour.TabIndex = 27;
            this.txtBeforeHosComaHour.Click += new System.EventHandler(this.txt_Enter);
            this.txtBeforeHosComaHour.Enter += new System.EventHandler(this.txt_Enter);
            // 
            // txtLaterHosComaDay
            // 
            this.txtLaterHosComaDay.Location = new System.Drawing.Point(429, 298);
            this.txtLaterHosComaDay.Name = "txtLaterHosComaDay";
            this.txtLaterHosComaDay.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtLaterHosComaDay.Size = new System.Drawing.Size(26, 19);
            this.txtLaterHosComaDay.TabIndex = 32;
            this.txtLaterHosComaDay.Click += new System.EventHandler(this.txt_Enter);
            this.txtLaterHosComaDay.Enter += new System.EventHandler(this.txt_Enter);
            // 
            // txtBeforeHosComaDay
            // 
            this.txtBeforeHosComaDay.Location = new System.Drawing.Point(205, 298);
            this.txtBeforeHosComaDay.Name = "txtBeforeHosComaDay";
            this.txtBeforeHosComaDay.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtBeforeHosComaDay.Size = new System.Drawing.Size(26, 19);
            this.txtBeforeHosComaDay.TabIndex = 25;
            this.txtBeforeHosComaDay.Click += new System.EventHandler(this.txt_Enter);
            this.txtBeforeHosComaDay.Enter += new System.EventHandler(this.txt_Enter);
            // 
            // txtAgainInHospitalReason
            // 
            this.txtAgainInHospitalReason.EditValue = "";
            this.txtAgainInHospitalReason.Location = new System.Drawing.Point(341, 274);
            this.txtAgainInHospitalReason.Name = "txtAgainInHospitalReason";
            this.txtAgainInHospitalReason.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtAgainInHospitalReason.Size = new System.Drawing.Size(234, 19);
            this.txtAgainInHospitalReason.TabIndex = 23;
            // 
            // txtReceiveHosPital
            // 
            this.txtReceiveHosPital.EditValue = "";
            this.txtReceiveHosPital.Location = new System.Drawing.Point(385, 199);
            this.txtReceiveHosPital.Name = "txtReceiveHosPital";
            this.txtReceiveHosPital.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtReceiveHosPital.Size = new System.Drawing.Size(210, 19);
            this.txtReceiveHosPital.TabIndex = 14;
            // 
            // labelControl24
            // 
            this.labelControl24.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl24.Location = new System.Drawing.Point(25, 300);
            this.labelControl24.Name = "labelControl24";
            this.labelControl24.Size = new System.Drawing.Size(172, 14);
            this.labelControl24.TabIndex = 24;
            this.labelControl24.Text = "颅脑损伤患者昏迷时间： 入院前";
            // 
            // labelControl23
            // 
            this.labelControl23.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl23.Location = new System.Drawing.Point(25, 276);
            this.labelControl23.Name = "labelControl23";
            this.labelControl23.Size = new System.Drawing.Size(170, 14);
            this.labelControl23.TabIndex = 20;
            this.labelControl23.Text = "是否有出院31天内再住院计划：";
            // 
            // labelControl38
            // 
            this.labelControl38.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl38.Location = new System.Drawing.Point(569, 300);
            this.labelControl38.Name = "labelControl38";
            this.labelControl38.Size = new System.Drawing.Size(24, 14);
            this.labelControl38.TabIndex = 37;
            this.labelControl38.Text = "分钟";
            // 
            // labelControl32
            // 
            this.labelControl32.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl32.Location = new System.Drawing.Point(383, 300);
            this.labelControl32.Name = "labelControl32";
            this.labelControl32.Size = new System.Drawing.Size(36, 14);
            this.labelControl32.TabIndex = 31;
            this.labelControl32.Text = "入院后";
            // 
            // labelControl36
            // 
            this.labelControl36.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl36.Location = new System.Drawing.Point(511, 300);
            this.labelControl36.Name = "labelControl36";
            this.labelControl36.Size = new System.Drawing.Size(24, 14);
            this.labelControl36.TabIndex = 35;
            this.labelControl36.Text = "小时";
            // 
            // labelControl30
            // 
            this.labelControl30.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl30.Location = new System.Drawing.Point(345, 300);
            this.labelControl30.Name = "labelControl30";
            this.labelControl30.Size = new System.Drawing.Size(24, 14);
            this.labelControl30.TabIndex = 30;
            this.labelControl30.Text = "分钟";
            // 
            // labelControl34
            // 
            this.labelControl34.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl34.Location = new System.Drawing.Point(463, 300);
            this.labelControl34.Name = "labelControl34";
            this.labelControl34.Size = new System.Drawing.Size(12, 14);
            this.labelControl34.TabIndex = 33;
            this.labelControl34.Text = "天";
            // 
            // labelControl27
            // 
            this.labelControl27.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl27.Location = new System.Drawing.Point(287, 300);
            this.labelControl27.Name = "labelControl27";
            this.labelControl27.Size = new System.Drawing.Size(24, 14);
            this.labelControl27.TabIndex = 28;
            this.labelControl27.Text = "小时";
            // 
            // labelControl25
            // 
            this.labelControl25.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl25.Location = new System.Drawing.Point(239, 300);
            this.labelControl25.Name = "labelControl25";
            this.labelControl25.Size = new System.Drawing.Size(12, 14);
            this.labelControl25.TabIndex = 26;
            this.labelControl25.Text = "天";
            // 
            // labelControl22
            // 
            this.labelControl22.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl22.Location = new System.Drawing.Point(19, 201);
            this.labelControl22.Name = "labelControl22";
            this.labelControl22.Size = new System.Drawing.Size(60, 14);
            this.labelControl22.TabIndex = 11;
            this.labelControl22.Text = "离院方式：";
            // 
            // chkAgainInHospital2
            // 
            this.chkAgainInHospital2.Location = new System.Drawing.Point(245, 273);
            this.chkAgainInHospital2.Name = "chkAgainInHospital2";
            this.chkAgainInHospital2.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkAgainInHospital2.Properties.Appearance.Options.UseForeColor = true;
            this.chkAgainInHospital2.Properties.Caption = "2.有，目的：";
            this.chkAgainInHospital2.Properties.RadioGroupIndex = 1;
            this.chkAgainInHospital2.Size = new System.Drawing.Size(90, 19);
            this.chkAgainInHospital2.TabIndex = 22;
            this.chkAgainInHospital2.TabStop = false;
            this.chkAgainInHospital2.Click += new System.EventHandler(this.chk_CheckedChanged);
            // 
            // chkOutHosType2
            // 
            this.chkOutHosType2.Location = new System.Drawing.Point(179, 198);
            this.chkOutHosType2.Name = "chkOutHosType2";
            this.chkOutHosType2.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkOutHosType2.Properties.Appearance.Options.UseForeColor = true;
            this.chkOutHosType2.Properties.Caption = "2.医嘱转院，拟接收医疗机构名称：";
            this.chkOutHosType2.Properties.RadioGroupIndex = 0;
            this.chkOutHosType2.Size = new System.Drawing.Size(201, 19);
            this.chkOutHosType2.TabIndex = 13;
            this.chkOutHosType2.TabStop = false;
            this.chkOutHosType2.Click += new System.EventHandler(this.chk_CheckedChanged);
            // 
            // chkOutHosType3
            // 
            this.chkOutHosType3.Location = new System.Drawing.Point(85, 224);
            this.chkOutHosType3.Name = "chkOutHosType3";
            this.chkOutHosType3.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkOutHosType3.Properties.Appearance.Options.UseForeColor = true;
            this.chkOutHosType3.Properties.Caption = "3.医嘱转社区卫生服务机构/乡镇卫生院，拟接收医疗机构名称：";
            this.chkOutHosType3.Properties.RadioGroupIndex = 0;
            this.chkOutHosType3.Size = new System.Drawing.Size(361, 19);
            this.chkOutHosType3.TabIndex = 15;
            this.chkOutHosType3.TabStop = false;
            this.chkOutHosType3.Click += new System.EventHandler(this.chk_CheckedChanged);
            // 
            // chkOutHosType9
            // 
            this.chkOutHosType9.Location = new System.Drawing.Point(260, 249);
            this.chkOutHosType9.Name = "chkOutHosType9";
            this.chkOutHosType9.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkOutHosType9.Properties.Appearance.Options.UseForeColor = true;
            this.chkOutHosType9.Properties.Caption = "9.其他";
            this.chkOutHosType9.Properties.RadioGroupIndex = 0;
            this.chkOutHosType9.Size = new System.Drawing.Size(59, 19);
            this.chkOutHosType9.TabIndex = 19;
            this.chkOutHosType9.TabStop = false;
            this.chkOutHosType9.Click += new System.EventHandler(this.chk_CheckedChanged);
            // 
            // chkOutHosType5
            // 
            this.chkOutHosType5.Location = new System.Drawing.Point(195, 249);
            this.chkOutHosType5.Name = "chkOutHosType5";
            this.chkOutHosType5.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkOutHosType5.Properties.Appearance.Options.UseForeColor = true;
            this.chkOutHosType5.Properties.Caption = "5.死亡";
            this.chkOutHosType5.Properties.RadioGroupIndex = 0;
            this.chkOutHosType5.Size = new System.Drawing.Size(59, 19);
            this.chkOutHosType5.TabIndex = 18;
            this.chkOutHosType5.TabStop = false;
            this.chkOutHosType5.Click += new System.EventHandler(this.chk_CheckedChanged);
            // 
            // chkOutHosType4
            // 
            this.chkOutHosType4.Location = new System.Drawing.Point(85, 249);
            this.chkOutHosType4.Name = "chkOutHosType4";
            this.chkOutHosType4.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkOutHosType4.Properties.Appearance.Options.UseForeColor = true;
            this.chkOutHosType4.Properties.Caption = "4.非医嘱离院";
            this.chkOutHosType4.Properties.RadioGroupIndex = 0;
            this.chkOutHosType4.Size = new System.Drawing.Size(104, 19);
            this.chkOutHosType4.TabIndex = 17;
            this.chkOutHosType4.TabStop = false;
            this.chkOutHosType4.Click += new System.EventHandler(this.chk_CheckedChanged);
            // 
            // chkAgainInHospital1
            // 
            this.chkAgainInHospital1.Location = new System.Drawing.Point(196, 273);
            this.chkAgainInHospital1.Name = "chkAgainInHospital1";
            this.chkAgainInHospital1.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkAgainInHospital1.Properties.Appearance.Options.UseForeColor = true;
            this.chkAgainInHospital1.Properties.Caption = "1.无";
            this.chkAgainInHospital1.Properties.RadioGroupIndex = 1;
            this.chkAgainInHospital1.Size = new System.Drawing.Size(46, 19);
            this.chkAgainInHospital1.TabIndex = 21;
            this.chkAgainInHospital1.TabStop = false;
            this.chkAgainInHospital1.Click += new System.EventHandler(this.chk_CheckedChanged);
            // 
            // chkOutHosType1
            // 
            this.chkOutHosType1.Location = new System.Drawing.Point(85, 198);
            this.chkOutHosType1.Name = "chkOutHosType1";
            this.chkOutHosType1.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkOutHosType1.Properties.Appearance.Options.UseForeColor = true;
            this.chkOutHosType1.Properties.Caption = "1.医嘱离院";
            this.chkOutHosType1.Properties.RadioGroupIndex = 0;
            this.chkOutHosType1.Size = new System.Drawing.Size(84, 19);
            this.chkOutHosType1.TabIndex = 12;
            this.chkOutHosType1.TabStop = false;
            this.chkOutHosType1.Click += new System.EventHandler(this.chk_CheckedChanged);
            // 
            // hLineEx1
            // 
            this.hLineEx1.BackColor = System.Drawing.Color.White;
            this.hLineEx1.IsBold = false;
            this.hLineEx1.Location = new System.Drawing.Point(0, 162);
            this.hLineEx1.Name = "hLineEx1";
            this.hLineEx1.Size = new System.Drawing.Size(618, 1);
            this.hLineEx1.TabIndex = 4;
            this.hLineEx1.TabStop = false;
            this.hLineEx1.Text = "hLineEx3";
            // 
            // chkzg_flag1
            // 
            this.chkzg_flag1.Location = new System.Drawing.Point(85, 173);
            this.chkzg_flag1.Name = "chkzg_flag1";
            this.chkzg_flag1.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkzg_flag1.Properties.Appearance.Options.UseForeColor = true;
            this.chkzg_flag1.Properties.Caption = "1.治愈";
            this.chkzg_flag1.Properties.RadioGroupIndex = 2;
            this.chkzg_flag1.Size = new System.Drawing.Size(60, 19);
            this.chkzg_flag1.TabIndex = 6;
            this.chkzg_flag1.TabStop = false;
            this.chkzg_flag1.Click += new System.EventHandler(this.chk_CheckedChanged);
            // 
            // labelControl1
            // 
            this.labelControl1.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl1.Location = new System.Drawing.Point(43, 175);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(36, 14);
            this.labelControl1.TabIndex = 5;
            this.labelControl1.Text = "转归：";
            // 
            // chkzg_flag2
            // 
            this.chkzg_flag2.Location = new System.Drawing.Point(151, 173);
            this.chkzg_flag2.Name = "chkzg_flag2";
            this.chkzg_flag2.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkzg_flag2.Properties.Appearance.Options.UseForeColor = true;
            this.chkzg_flag2.Properties.Caption = "2.好转";
            this.chkzg_flag2.Properties.RadioGroupIndex = 2;
            this.chkzg_flag2.Size = new System.Drawing.Size(60, 19);
            this.chkzg_flag2.TabIndex = 7;
            this.chkzg_flag2.TabStop = false;
            this.chkzg_flag2.Click += new System.EventHandler(this.chk_CheckedChanged);
            // 
            // chkzg_flag3
            // 
            this.chkzg_flag3.Location = new System.Drawing.Point(217, 173);
            this.chkzg_flag3.Name = "chkzg_flag3";
            this.chkzg_flag3.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkzg_flag3.Properties.Appearance.Options.UseForeColor = true;
            this.chkzg_flag3.Properties.Caption = "3.未愈";
            this.chkzg_flag3.Properties.RadioGroupIndex = 2;
            this.chkzg_flag3.Size = new System.Drawing.Size(60, 19);
            this.chkzg_flag3.TabIndex = 8;
            this.chkzg_flag3.TabStop = false;
            this.chkzg_flag3.Click += new System.EventHandler(this.chk_CheckedChanged);
            // 
            // chkzg_flag4
            // 
            this.chkzg_flag4.Location = new System.Drawing.Point(283, 173);
            this.chkzg_flag4.Name = "chkzg_flag4";
            this.chkzg_flag4.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkzg_flag4.Properties.Appearance.Options.UseForeColor = true;
            this.chkzg_flag4.Properties.Caption = "4.死亡";
            this.chkzg_flag4.Properties.RadioGroupIndex = 2;
            this.chkzg_flag4.Size = new System.Drawing.Size(60, 19);
            this.chkzg_flag4.TabIndex = 9;
            this.chkzg_flag4.TabStop = false;
            this.chkzg_flag4.Click += new System.EventHandler(this.chk_CheckedChanged);
            // 
            // chkzg_flag5
            // 
            this.chkzg_flag5.Location = new System.Drawing.Point(349, 173);
            this.chkzg_flag5.Name = "chkzg_flag5";
            this.chkzg_flag5.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkzg_flag5.Properties.Appearance.Options.UseForeColor = true;
            this.chkzg_flag5.Properties.Caption = "5.其他";
            this.chkzg_flag5.Properties.RadioGroupIndex = 2;
            this.chkzg_flag5.Size = new System.Drawing.Size(60, 19);
            this.chkzg_flag5.TabIndex = 10;
            this.chkzg_flag5.TabStop = false;
            this.chkzg_flag5.Click += new System.EventHandler(this.chk_CheckedChanged);
            // 
            // btnEditOperation
            // 
            this.btnEditOperation.Location = new System.Drawing.Point(94, 11);
            this.btnEditOperation.Name = "btnEditOperation";
            this.btnEditOperation.Size = new System.Drawing.Size(80, 23);
            this.btnEditOperation.TabIndex = 1;
            this.btnEditOperation.Text = "编辑 (&E)";
            this.btnEditOperation.ToolTip = "编辑手术信息";
            this.btnEditOperation.Click += new System.EventHandler(this.btnEditOperation_Click);
            // 
            // txtReceiveHosPital2
            // 
            this.txtReceiveHosPital2.EditValue = "";
            this.txtReceiveHosPital2.Location = new System.Drawing.Point(401, 224);
            this.txtReceiveHosPital2.Name = "txtReceiveHosPital2";
            this.txtReceiveHosPital2.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtReceiveHosPital2.Size = new System.Drawing.Size(192, 19);
            this.txtReceiveHosPital2.TabIndex = 16;
            // 
            // btn_delete
            // 
            this.btn_delete.Location = new System.Drawing.Point(183, 11);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(80, 23);
            this.btn_delete.TabIndex = 2;
            this.btn_delete.Text = "删除 (&E)";
            this.btn_delete.ToolTip = "删除手术信息";
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // UCIemOperInfo
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.btnEditOperation);
            this.Controls.Add(this.hLineEx1);
            this.Controls.Add(this.txtLaterHosComaMinute);
            this.Controls.Add(this.txtBeforeHosComaMinute);
            this.Controls.Add(this.txtLaterHosComaHour);
            this.Controls.Add(this.txtBeforeHosComaHour);
            this.Controls.Add(this.txtLaterHosComaDay);
            this.Controls.Add(this.txtBeforeHosComaDay);
            this.Controls.Add(this.txtAgainInHospitalReason);
            this.Controls.Add(this.txtReceiveHosPital2);
            this.Controls.Add(this.txtReceiveHosPital);
            this.Controls.Add(this.labelControl24);
            this.Controls.Add(this.labelControl23);
            this.Controls.Add(this.labelControl38);
            this.Controls.Add(this.labelControl32);
            this.Controls.Add(this.labelControl36);
            this.Controls.Add(this.labelControl30);
            this.Controls.Add(this.labelControl34);
            this.Controls.Add(this.labelControl27);
            this.Controls.Add(this.labelControl25);
            this.Controls.Add(this.labelControl1);
            this.Controls.Add(this.labelControl22);
            this.Controls.Add(this.chkAgainInHospital2);
            this.Controls.Add(this.chkOutHosType2);
            this.Controls.Add(this.chkOutHosType3);
            this.Controls.Add(this.chkOutHosType9);
            this.Controls.Add(this.chkOutHosType5);
            this.Controls.Add(this.chkOutHosType4);
            this.Controls.Add(this.chkzg_flag5);
            this.Controls.Add(this.chkzg_flag4);
            this.Controls.Add(this.chkzg_flag3);
            this.Controls.Add(this.chkzg_flag2);
            this.Controls.Add(this.chkzg_flag1);
            this.Controls.Add(this.chkAgainInHospital1);
            this.Controls.Add(this.chkOutHosType1);
            this.Controls.Add(this.btn_Close);
            this.Controls.Add(this.btn_OK);
            this.Controls.Add(this.btnAddOperation);
            this.Controls.Add(this.gridControl1);
            this.Controls.Add(this.barDockControlLeft);
            this.Controls.Add(this.barDockControlRight);
            this.Controls.Add(this.barDockControlBottom);
            this.Controls.Add(this.barDockControlTop);
            this.Name = "UCIemOperInfo";
            this.Size = new System.Drawing.Size(620, 368);
            this.Load += new System.EventHandler(this.UCIemOperInfo_Load);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.UCIemOperInfo_Paint);
            ((System.ComponentModel.ISupportInitialize)(this.gridControl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewOper)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.barManager1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.popupMenu1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtLaterHosComaMinute.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtBeforeHosComaMinute.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtLaterHosComaHour.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtBeforeHosComaHour.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtLaterHosComaDay.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtBeforeHosComaDay.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtAgainInHospitalReason.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtReceiveHosPital.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkAgainInHospital2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkOutHosType2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkOutHosType3.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkOutHosType9.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkOutHosType5.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkOutHosType4.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkAgainInHospital1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkOutHosType1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkzg_flag1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkzg_flag2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkzg_flag3.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkzg_flag4.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkzg_flag5.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtReceiveHosPital2.Properties)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevExpress.XtraGrid.GridControl gridControl1;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewOper;
        private DevExpress.XtraEditors.SimpleButton btnAddOperation;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn2;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn3;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn4;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn5;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn6;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn7;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn8;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn9;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn14;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn15;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn16;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn17;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn18;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn19;
        private DevExpress.XtraBars.BarManager barManager1;
        private DevExpress.XtraBars.BarDockControl barDockControlTop;
        private DevExpress.XtraBars.BarDockControl barDockControlBottom;
        private DevExpress.XtraBars.BarDockControl barDockControlLeft;
        private DevExpress.XtraBars.BarDockControl barDockControlRight;
        private DevExpress.XtraBars.BarButtonItem btn_del_Operinfo;
        private DevExpress.XtraBars.PopupMenu popupMenu1;
        private DevExpress.XtraBars.BarButtonItem barButtonItem1;
        private DevExpress.XtraBars.BarButtonItem btn_del_operbefore_diag;
        private DevExpress.XtraBars.BarButtonItem btn_operafter_diag;
        private DevExpress.XtraEditors.SimpleButton btn_Close;
        private DevExpress.XtraEditors.SimpleButton btn_OK;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn10;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn11;
        private DevExpress.XtraEditors.TextEdit txtLaterHosComaMinute;
        private DevExpress.XtraEditors.TextEdit txtBeforeHosComaMinute;
        private DevExpress.XtraEditors.TextEdit txtLaterHosComaHour;
        private DevExpress.XtraEditors.TextEdit txtBeforeHosComaHour;
        private DevExpress.XtraEditors.TextEdit txtLaterHosComaDay;
        private DevExpress.XtraEditors.TextEdit txtBeforeHosComaDay;
        private DevExpress.XtraEditors.TextEdit txtAgainInHospitalReason;
        private DevExpress.XtraEditors.TextEdit txtReceiveHosPital;
        private DevExpress.XtraEditors.LabelControl labelControl24;
        private DevExpress.XtraEditors.LabelControl labelControl23;
        private DevExpress.XtraEditors.LabelControl labelControl38;
        private DevExpress.XtraEditors.LabelControl labelControl32;
        private DevExpress.XtraEditors.LabelControl labelControl36;
        private DevExpress.XtraEditors.LabelControl labelControl30;
        private DevExpress.XtraEditors.LabelControl labelControl34;
        private DevExpress.XtraEditors.LabelControl labelControl27;
        private DevExpress.XtraEditors.LabelControl labelControl25;
        private DevExpress.XtraEditors.LabelControl labelControl22;
        private DevExpress.XtraEditors.CheckEdit chkAgainInHospital2;
        private DevExpress.XtraEditors.CheckEdit chkOutHosType2;
        private DevExpress.XtraEditors.CheckEdit chkOutHosType3;
        private DevExpress.XtraEditors.CheckEdit chkOutHosType9;
        private DevExpress.XtraEditors.CheckEdit chkOutHosType5;
        private DevExpress.XtraEditors.CheckEdit chkOutHosType4;
        private DevExpress.XtraEditors.CheckEdit chkAgainInHospital1;
        private DevExpress.XtraEditors.CheckEdit chkOutHosType1;
        private HLineEx hLineEx1;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private DevExpress.XtraEditors.CheckEdit chkzg_flag5;
        private DevExpress.XtraEditors.CheckEdit chkzg_flag4;
        private DevExpress.XtraEditors.CheckEdit chkzg_flag3;
        private DevExpress.XtraEditors.CheckEdit chkzg_flag2;
        private DevExpress.XtraEditors.CheckEdit chkzg_flag1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn12;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn13;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn20;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn21;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn22;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn23;
        private DevExpress.XtraEditors.SimpleButton btnEditOperation;
        private DevExpress.XtraEditors.TextEdit txtReceiveHosPital2;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn24;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn25;
        private DevExpress.XtraEditors.SimpleButton btn_delete;
    }
}
