﻿namespace DrectSoft.Core.IEMMainPage
{
    partial class UCObstetricsBaby
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UCObstetricsBaby));
            this.labelControl17 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl29 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl7 = new DevExpress.XtraEditors.LabelControl();
            this.chkTC1 = new DevExpress.XtraEditors.CheckEdit();
            this.chkTC2 = new DevExpress.XtraEditors.CheckEdit();
            this.chkTC3 = new DevExpress.XtraEditors.CheckEdit();
            this.labelControl8 = new DevExpress.XtraEditors.LabelControl();
            this.chkCC1 = new DevExpress.XtraEditors.CheckEdit();
            this.chkCC2 = new DevExpress.XtraEditors.CheckEdit();
            this.chkCC3 = new DevExpress.XtraEditors.CheckEdit();
            this.labelControl9 = new DevExpress.XtraEditors.LabelControl();
            this.chkCFHYPLD1 = new DevExpress.XtraEditors.CheckEdit();
            this.chkCFHYPLD2 = new DevExpress.XtraEditors.CheckEdit();
            this.chkCFHYPLD3 = new DevExpress.XtraEditors.CheckEdit();
            this.labelControl11 = new DevExpress.XtraEditors.LabelControl();
            this.chkSex1 = new DevExpress.XtraEditors.CheckEdit();
            this.chkSex2 = new DevExpress.XtraEditors.CheckEdit();
            this.labelControl15 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl23 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl27 = new DevExpress.XtraEditors.LabelControl();
            this.txtheigh = new DevExpress.XtraEditors.TextEdit();
            this.labelControl30 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl32 = new DevExpress.XtraEditors.LabelControl();
            this.txtweight = new DevExpress.XtraEditors.TextEdit();
            this.labelControl33 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl34 = new DevExpress.XtraEditors.LabelControl();
            this.chkCCQK1 = new DevExpress.XtraEditors.CheckEdit();
            this.chkCCQK2 = new DevExpress.XtraEditors.CheckEdit();
            this.chkCCQK3 = new DevExpress.XtraEditors.CheckEdit();
            this.chkCCQK4 = new DevExpress.XtraEditors.CheckEdit();
            this.labelControl35 = new DevExpress.XtraEditors.LabelControl();
            this.chkTB1 = new DevExpress.XtraEditors.CheckEdit();
            this.chkTB2 = new DevExpress.XtraEditors.CheckEdit();
            this.chkTB3 = new DevExpress.XtraEditors.CheckEdit();
            this.txtAPJPF = new DevExpress.XtraEditors.TextEdit();
            this.chkCYQK1 = new DevExpress.XtraEditors.CheckEdit();
            this.chkCYQK2 = new DevExpress.XtraEditors.CheckEdit();
            this.chkCYQK3 = new DevExpress.XtraEditors.CheckEdit();
            this.labelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.chkFMFS1 = new DevExpress.XtraEditors.CheckEdit();
            this.chkFMFS2 = new DevExpress.XtraEditors.CheckEdit();
            this.chkFMFS3 = new DevExpress.XtraEditors.CheckEdit();
            this.chkFMFS4 = new DevExpress.XtraEditors.CheckEdit();
            this.chkFMFS5 = new DevExpress.XtraEditors.CheckEdit();
            this.chkFMFS6 = new DevExpress.XtraEditors.CheckEdit();
            this.BithDayTime = new DevExpress.XtraEditors.TimeEdit();
            this.BithDayDate = new DevExpress.XtraEditors.DateEdit();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.gridControlBabyInfo = new DevExpress.XtraGrid.GridControl();
            this.gridViewBabyInfo = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn3 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn4 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn5 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn6 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn7 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn8 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn9 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemCheckEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.simpleButtonAddInfo = new DevExpress.XtraEditors.SimpleButton();
            this.panelControl1 = new DevExpress.XtraEditors.PanelControl();
            this.btnEditBaby = new DevExpress.XtraEditors.SimpleButton();
            this.lpEdiMidwifery = new DrectSoft.Common.Library.LookUpEditor();
            this.simpleButtonDeleteInfo = new DevExpress.XtraEditors.SimpleButton();
            this.errorProvider = new System.Windows.Forms.ErrorProvider(this.components);
            this.btn_OK = new DrectSoft.Common.Ctrs.OTHER.DevButtonOK(this.components);
            this.btn_Close = new DrectSoft.Common.Ctrs.OTHER.DevButtonClose(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.chkTC1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkTC2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkTC3.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCC1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCC2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCC3.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCFHYPLD1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCFHYPLD2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCFHYPLD3.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkSex1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkSex2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtheigh.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtweight.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCCQK1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCCQK2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCCQK3.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCCQK4.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkTB1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkTB2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkTB3.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtAPJPF.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCYQK1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCYQK2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCYQK3.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkFMFS1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkFMFS2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkFMFS3.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkFMFS4.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkFMFS5.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkFMFS6.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BithDayTime.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BithDayDate.Properties.VistaTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BithDayDate.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridControlBabyInfo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewBabyInfo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).BeginInit();
            this.panelControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lpEdiMidwifery)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider)).BeginInit();
            this.SuspendLayout();
            // 
            // labelControl17
            // 
            this.labelControl17.Appearance.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold);
            this.labelControl17.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl17.Location = new System.Drawing.Point(151, 15);
            this.labelControl17.Name = "labelControl17";
            this.labelControl17.Size = new System.Drawing.Size(303, 33);
            this.labelControl17.TabIndex = 157;
            this.labelControl17.Text = "产 科 产 妇 婴 儿 情 况";
            // 
            // labelControl29
            // 
            this.labelControl29.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl29.Location = new System.Drawing.Point(335, 86);
            this.labelControl29.Name = "labelControl29";
            this.labelControl29.Size = new System.Drawing.Size(60, 14);
            this.labelControl29.TabIndex = 157;
            this.labelControl29.Text = "出院情况：";
            // 
            // labelControl7
            // 
            this.labelControl7.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl7.Location = new System.Drawing.Point(25, 58);
            this.labelControl7.Name = "labelControl7";
            this.labelControl7.Size = new System.Drawing.Size(52, 14);
            this.labelControl7.TabIndex = 157;
            this.labelControl7.Text = "胎    次：";
            // 
            // chkTC1
            // 
            this.chkTC1.Location = new System.Drawing.Point(86, 57);
            this.chkTC1.Name = "chkTC1";
            this.chkTC1.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkTC1.Properties.Appearance.Options.UseForeColor = true;
            this.chkTC1.Properties.Caption = "1.单";
            this.chkTC1.Properties.RadioGroupIndex = 1;
            this.chkTC1.Size = new System.Drawing.Size(67, 19);
            this.chkTC1.TabIndex = 168;
            this.chkTC1.TabStop = false;
            this.chkTC1.Click += new System.EventHandler(this.chk_CheckedChanged);
            // 
            // chkTC2
            // 
            this.chkTC2.Location = new System.Drawing.Point(153, 57);
            this.chkTC2.Name = "chkTC2";
            this.chkTC2.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkTC2.Properties.Appearance.Options.UseForeColor = true;
            this.chkTC2.Properties.Caption = "2.双";
            this.chkTC2.Properties.RadioGroupIndex = 1;
            this.chkTC2.Size = new System.Drawing.Size(63, 19);
            this.chkTC2.TabIndex = 169;
            this.chkTC2.TabStop = false;
            this.chkTC2.Click += new System.EventHandler(this.chk_CheckedChanged);
            // 
            // chkTC3
            // 
            this.chkTC3.Location = new System.Drawing.Point(216, 57);
            this.chkTC3.Name = "chkTC3";
            this.chkTC3.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkTC3.Properties.Appearance.Options.UseForeColor = true;
            this.chkTC3.Properties.Caption = "3.多";
            this.chkTC3.Properties.RadioGroupIndex = 1;
            this.chkTC3.Size = new System.Drawing.Size(57, 19);
            this.chkTC3.TabIndex = 170;
            this.chkTC3.TabStop = false;
            this.chkTC3.Click += new System.EventHandler(this.chk_CheckedChanged);
            // 
            // labelControl8
            // 
            this.labelControl8.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl8.Location = new System.Drawing.Point(351, 59);
            this.labelControl8.Name = "labelControl8";
            this.labelControl8.Size = new System.Drawing.Size(52, 14);
            this.labelControl8.TabIndex = 157;
            this.labelControl8.Text = "产    次：";
            // 
            // chkCC1
            // 
            this.chkCC1.Location = new System.Drawing.Point(412, 57);
            this.chkCC1.Name = "chkCC1";
            this.chkCC1.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkCC1.Properties.Appearance.Options.UseForeColor = true;
            this.chkCC1.Properties.Caption = "1.单";
            this.chkCC1.Properties.RadioGroupIndex = 2;
            this.chkCC1.Size = new System.Drawing.Size(67, 19);
            this.chkCC1.TabIndex = 168;
            this.chkCC1.TabStop = false;
            this.chkCC1.Click += new System.EventHandler(this.chk_CheckedChanged);
            // 
            // chkCC2
            // 
            this.chkCC2.Location = new System.Drawing.Point(479, 57);
            this.chkCC2.Name = "chkCC2";
            this.chkCC2.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkCC2.Properties.Appearance.Options.UseForeColor = true;
            this.chkCC2.Properties.Caption = "2.双";
            this.chkCC2.Properties.RadioGroupIndex = 2;
            this.chkCC2.Size = new System.Drawing.Size(63, 19);
            this.chkCC2.TabIndex = 169;
            this.chkCC2.TabStop = false;
            this.chkCC2.Click += new System.EventHandler(this.chk_CheckedChanged);
            // 
            // chkCC3
            // 
            this.chkCC3.Location = new System.Drawing.Point(542, 57);
            this.chkCC3.Name = "chkCC3";
            this.chkCC3.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkCC3.Properties.Appearance.Options.UseForeColor = true;
            this.chkCC3.Properties.Caption = "3.多";
            this.chkCC3.Properties.RadioGroupIndex = 2;
            this.chkCC3.Size = new System.Drawing.Size(57, 19);
            this.chkCC3.TabIndex = 170;
            this.chkCC3.TabStop = false;
            this.chkCC3.Click += new System.EventHandler(this.chk_CheckedChanged);
            // 
            // labelControl9
            // 
            this.labelControl9.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl9.Location = new System.Drawing.Point(341, 79);
            this.labelControl9.Name = "labelControl9";
            this.labelControl9.Size = new System.Drawing.Size(72, 14);
            this.labelControl9.TabIndex = 157;
            this.labelControl9.Text = "会阴破裂度：";
            // 
            // chkCFHYPLD1
            // 
            this.chkCFHYPLD1.Location = new System.Drawing.Point(412, 78);
            this.chkCFHYPLD1.Name = "chkCFHYPLD1";
            this.chkCFHYPLD1.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkCFHYPLD1.Properties.Appearance.Options.UseForeColor = true;
            this.chkCFHYPLD1.Properties.Caption = "1.I";
            this.chkCFHYPLD1.Properties.RadioGroupIndex = 4;
            this.chkCFHYPLD1.Size = new System.Drawing.Size(67, 19);
            this.chkCFHYPLD1.TabIndex = 168;
            this.chkCFHYPLD1.TabStop = false;
            this.chkCFHYPLD1.Click += new System.EventHandler(this.chk_CheckedChanged);
            // 
            // chkCFHYPLD2
            // 
            this.chkCFHYPLD2.Location = new System.Drawing.Point(479, 78);
            this.chkCFHYPLD2.Name = "chkCFHYPLD2";
            this.chkCFHYPLD2.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkCFHYPLD2.Properties.Appearance.Options.UseForeColor = true;
            this.chkCFHYPLD2.Properties.Caption = "2.II";
            this.chkCFHYPLD2.Properties.RadioGroupIndex = 4;
            this.chkCFHYPLD2.Size = new System.Drawing.Size(63, 19);
            this.chkCFHYPLD2.TabIndex = 169;
            this.chkCFHYPLD2.TabStop = false;
            this.chkCFHYPLD2.Click += new System.EventHandler(this.chk_CheckedChanged);
            // 
            // chkCFHYPLD3
            // 
            this.chkCFHYPLD3.Location = new System.Drawing.Point(542, 78);
            this.chkCFHYPLD3.Name = "chkCFHYPLD3";
            this.chkCFHYPLD3.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkCFHYPLD3.Properties.Appearance.Options.UseForeColor = true;
            this.chkCFHYPLD3.Properties.Caption = "3.III";
            this.chkCFHYPLD3.Properties.RadioGroupIndex = 4;
            this.chkCFHYPLD3.Size = new System.Drawing.Size(57, 19);
            this.chkCFHYPLD3.TabIndex = 170;
            this.chkCFHYPLD3.TabStop = false;
            this.chkCFHYPLD3.Click += new System.EventHandler(this.chk_CheckedChanged);
            // 
            // labelControl11
            // 
            this.labelControl11.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl11.Location = new System.Drawing.Point(13, 14);
            this.labelControl11.Name = "labelControl11";
            this.labelControl11.Size = new System.Drawing.Size(52, 14);
            this.labelControl11.TabIndex = 157;
            this.labelControl11.Text = "性    别：";
            // 
            // chkSex1
            // 
            this.chkSex1.Location = new System.Drawing.Point(74, 11);
            this.chkSex1.Name = "chkSex1";
            this.chkSex1.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkSex1.Properties.Appearance.Options.UseForeColor = true;
            this.chkSex1.Properties.Caption = "1.男";
            this.chkSex1.Properties.RadioGroupIndex = 5;
            this.chkSex1.Size = new System.Drawing.Size(67, 19);
            this.chkSex1.TabIndex = 168;
            this.chkSex1.TabStop = false;
            this.chkSex1.Click += new System.EventHandler(this.chk_CheckedChanged);
            // 
            // chkSex2
            // 
            this.chkSex2.Location = new System.Drawing.Point(141, 11);
            this.chkSex2.Name = "chkSex2";
            this.chkSex2.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkSex2.Properties.Appearance.Options.UseForeColor = true;
            this.chkSex2.Properties.Caption = "2.女";
            this.chkSex2.Properties.RadioGroupIndex = 5;
            this.chkSex2.Size = new System.Drawing.Size(49, 19);
            this.chkSex2.TabIndex = 169;
            this.chkSex2.TabStop = false;
            this.chkSex2.Click += new System.EventHandler(this.chk_CheckedChanged);
            // 
            // labelControl15
            // 
            this.labelControl15.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl15.Location = new System.Drawing.Point(323, 13);
            this.labelControl15.Name = "labelControl15";
            this.labelControl15.Size = new System.Drawing.Size(72, 14);
            this.labelControl15.TabIndex = 157;
            this.labelControl15.Text = "阿帕加评分：";
            // 
            // labelControl23
            // 
            this.labelControl23.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl23.Location = new System.Drawing.Point(13, 38);
            this.labelControl23.Name = "labelControl23";
            this.labelControl23.Size = new System.Drawing.Size(52, 14);
            this.labelControl23.TabIndex = 157;
            this.labelControl23.Text = "身    长：";
            // 
            // labelControl27
            // 
            this.labelControl27.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl27.Location = new System.Drawing.Point(182, 38);
            this.labelControl27.Name = "labelControl27";
            this.labelControl27.Size = new System.Drawing.Size(16, 14);
            this.labelControl27.TabIndex = 157;
            this.labelControl27.Text = "CM";
            // 
            // txtheigh
            // 
            this.txtheigh.EditValue = "";
            this.txtheigh.Location = new System.Drawing.Point(76, 36);
            this.txtheigh.Name = "txtheigh";
            this.txtheigh.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtheigh.Size = new System.Drawing.Size(100, 19);
            this.txtheigh.TabIndex = 162;
            // 
            // labelControl30
            // 
            this.labelControl30.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl30.Location = new System.Drawing.Point(343, 38);
            this.labelControl30.Name = "labelControl30";
            this.labelControl30.Size = new System.Drawing.Size(52, 14);
            this.labelControl30.TabIndex = 157;
            this.labelControl30.Text = "体    重：";
            // 
            // labelControl32
            // 
            this.labelControl32.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl32.Location = new System.Drawing.Point(511, 38);
            this.labelControl32.Name = "labelControl32";
            this.labelControl32.Size = new System.Drawing.Size(8, 14);
            this.labelControl32.TabIndex = 157;
            this.labelControl32.Text = "G";
            // 
            // txtweight
            // 
            this.txtweight.EditValue = "";
            this.txtweight.Location = new System.Drawing.Point(402, 36);
            this.txtweight.Name = "txtweight";
            this.txtweight.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtweight.Size = new System.Drawing.Size(100, 19);
            this.txtweight.TabIndex = 162;
            // 
            // labelControl33
            // 
            this.labelControl33.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl33.Location = new System.Drawing.Point(13, 62);
            this.labelControl33.Name = "labelControl33";
            this.labelControl33.Size = new System.Drawing.Size(60, 14);
            this.labelControl33.TabIndex = 157;
            this.labelControl33.Text = "出生时间：";
            // 
            // labelControl34
            // 
            this.labelControl34.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl34.Location = new System.Drawing.Point(13, 87);
            this.labelControl34.Name = "labelControl34";
            this.labelControl34.Size = new System.Drawing.Size(60, 14);
            this.labelControl34.TabIndex = 157;
            this.labelControl34.Text = "产出情况：";
            // 
            // chkCCQK1
            // 
            this.chkCCQK1.Location = new System.Drawing.Point(74, 84);
            this.chkCCQK1.Name = "chkCCQK1";
            this.chkCCQK1.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkCCQK1.Properties.Appearance.Options.UseForeColor = true;
            this.chkCCQK1.Properties.Caption = "1.活产";
            this.chkCCQK1.Properties.RadioGroupIndex = 6;
            this.chkCCQK1.Size = new System.Drawing.Size(56, 19);
            this.chkCCQK1.TabIndex = 168;
            this.chkCCQK1.TabStop = false;
            this.chkCCQK1.Click += new System.EventHandler(this.chk_CheckedChanged);
            // 
            // chkCCQK2
            // 
            this.chkCCQK2.Location = new System.Drawing.Point(130, 84);
            this.chkCCQK2.Name = "chkCCQK2";
            this.chkCCQK2.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkCCQK2.Properties.Appearance.Options.UseForeColor = true;
            this.chkCCQK2.Properties.Caption = "2.死产";
            this.chkCCQK2.Properties.RadioGroupIndex = 6;
            this.chkCCQK2.Size = new System.Drawing.Size(56, 19);
            this.chkCCQK2.TabIndex = 169;
            this.chkCCQK2.TabStop = false;
            this.chkCCQK2.Click += new System.EventHandler(this.chk_CheckedChanged);
            // 
            // chkCCQK3
            // 
            this.chkCCQK3.Location = new System.Drawing.Point(186, 84);
            this.chkCCQK3.Name = "chkCCQK3";
            this.chkCCQK3.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkCCQK3.Properties.Appearance.Options.UseForeColor = true;
            this.chkCCQK3.Properties.Caption = "3.死胎";
            this.chkCCQK3.Properties.RadioGroupIndex = 6;
            this.chkCCQK3.Size = new System.Drawing.Size(56, 19);
            this.chkCCQK3.TabIndex = 170;
            this.chkCCQK3.TabStop = false;
            this.chkCCQK3.Click += new System.EventHandler(this.chk_CheckedChanged);
            // 
            // chkCCQK4
            // 
            this.chkCCQK4.Location = new System.Drawing.Point(242, 84);
            this.chkCCQK4.Name = "chkCCQK4";
            this.chkCCQK4.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkCCQK4.Properties.Appearance.Options.UseForeColor = true;
            this.chkCCQK4.Properties.Caption = "4.畸形";
            this.chkCCQK4.Properties.RadioGroupIndex = 6;
            this.chkCCQK4.Size = new System.Drawing.Size(56, 19);
            this.chkCCQK4.TabIndex = 170;
            this.chkCCQK4.TabStop = false;
            this.chkCCQK4.Click += new System.EventHandler(this.chk_CheckedChanged);
            // 
            // labelControl35
            // 
            this.labelControl35.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl35.Location = new System.Drawing.Point(25, 81);
            this.labelControl35.Name = "labelControl35";
            this.labelControl35.Size = new System.Drawing.Size(52, 14);
            this.labelControl35.TabIndex = 157;
            this.labelControl35.Text = "胎    别：";
            // 
            // chkTB1
            // 
            this.chkTB1.Location = new System.Drawing.Point(86, 78);
            this.chkTB1.Name = "chkTB1";
            this.chkTB1.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkTB1.Properties.Appearance.Options.UseForeColor = true;
            this.chkTB1.Properties.Caption = "1.单";
            this.chkTB1.Properties.RadioGroupIndex = 3;
            this.chkTB1.Size = new System.Drawing.Size(67, 19);
            this.chkTB1.TabIndex = 168;
            this.chkTB1.TabStop = false;
            this.chkTB1.Click += new System.EventHandler(this.chk_CheckedChanged);
            // 
            // chkTB2
            // 
            this.chkTB2.Location = new System.Drawing.Point(153, 78);
            this.chkTB2.Name = "chkTB2";
            this.chkTB2.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkTB2.Properties.Appearance.Options.UseForeColor = true;
            this.chkTB2.Properties.Caption = "2.双";
            this.chkTB2.Properties.RadioGroupIndex = 3;
            this.chkTB2.Size = new System.Drawing.Size(63, 19);
            this.chkTB2.TabIndex = 169;
            this.chkTB2.TabStop = false;
            this.chkTB2.Click += new System.EventHandler(this.chk_CheckedChanged);
            // 
            // chkTB3
            // 
            this.chkTB3.Location = new System.Drawing.Point(216, 78);
            this.chkTB3.Name = "chkTB3";
            this.chkTB3.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkTB3.Properties.Appearance.Options.UseForeColor = true;
            this.chkTB3.Properties.Caption = "3.多";
            this.chkTB3.Properties.RadioGroupIndex = 3;
            this.chkTB3.Size = new System.Drawing.Size(57, 19);
            this.chkTB3.TabIndex = 170;
            this.chkTB3.TabStop = false;
            this.chkTB3.Click += new System.EventHandler(this.chk_CheckedChanged);
            // 
            // txtAPJPF
            // 
            this.txtAPJPF.EditValue = "";
            this.txtAPJPF.Location = new System.Drawing.Point(402, 11);
            this.txtAPJPF.Name = "txtAPJPF";
            this.txtAPJPF.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtAPJPF.Size = new System.Drawing.Size(185, 19);
            this.txtAPJPF.TabIndex = 162;
            // 
            // chkCYQK1
            // 
            this.chkCYQK1.Location = new System.Drawing.Point(397, 84);
            this.chkCYQK1.Name = "chkCYQK1";
            this.chkCYQK1.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkCYQK1.Properties.Appearance.Options.UseForeColor = true;
            this.chkCYQK1.Properties.Caption = "1.正常";
            this.chkCYQK1.Properties.RadioGroupIndex = 7;
            this.chkCYQK1.Size = new System.Drawing.Size(61, 19);
            this.chkCYQK1.TabIndex = 168;
            this.chkCYQK1.TabStop = false;
            this.chkCYQK1.Click += new System.EventHandler(this.chk_CheckedChanged);
            // 
            // chkCYQK2
            // 
            this.chkCYQK2.Location = new System.Drawing.Point(458, 84);
            this.chkCYQK2.Name = "chkCYQK2";
            this.chkCYQK2.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkCYQK2.Properties.Appearance.Options.UseForeColor = true;
            this.chkCYQK2.Properties.Caption = "2.有病";
            this.chkCYQK2.Properties.RadioGroupIndex = 7;
            this.chkCYQK2.Size = new System.Drawing.Size(61, 19);
            this.chkCYQK2.TabIndex = 169;
            this.chkCYQK2.TabStop = false;
            this.chkCYQK2.Click += new System.EventHandler(this.chk_CheckedChanged);
            // 
            // chkCYQK3
            // 
            this.chkCYQK3.Location = new System.Drawing.Point(519, 84);
            this.chkCYQK3.Name = "chkCYQK3";
            this.chkCYQK3.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkCYQK3.Properties.Appearance.Options.UseForeColor = true;
            this.chkCYQK3.Properties.Caption = "3.交叉感染";
            this.chkCYQK3.Properties.RadioGroupIndex = 7;
            this.chkCYQK3.Size = new System.Drawing.Size(82, 19);
            this.chkCYQK3.TabIndex = 170;
            this.chkCYQK3.TabStop = false;
            this.chkCYQK3.Click += new System.EventHandler(this.chk_CheckedChanged);
            // 
            // labelControl2
            // 
            this.labelControl2.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl2.Location = new System.Drawing.Point(13, 110);
            this.labelControl2.Name = "labelControl2";
            this.labelControl2.Size = new System.Drawing.Size(60, 14);
            this.labelControl2.TabIndex = 157;
            this.labelControl2.Text = "分娩方式：";
            // 
            // chkFMFS1
            // 
            this.chkFMFS1.Location = new System.Drawing.Point(74, 107);
            this.chkFMFS1.Name = "chkFMFS1";
            this.chkFMFS1.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkFMFS1.Properties.Appearance.Options.UseForeColor = true;
            this.chkFMFS1.Properties.Caption = "1.自然";
            this.chkFMFS1.Properties.RadioGroupIndex = 8;
            this.chkFMFS1.Size = new System.Drawing.Size(67, 19);
            this.chkFMFS1.TabIndex = 168;
            this.chkFMFS1.TabStop = false;
            this.chkFMFS1.Click += new System.EventHandler(this.chk_CheckedChanged);
            // 
            // chkFMFS2
            // 
            this.chkFMFS2.Location = new System.Drawing.Point(141, 107);
            this.chkFMFS2.Name = "chkFMFS2";
            this.chkFMFS2.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkFMFS2.Properties.Appearance.Options.UseForeColor = true;
            this.chkFMFS2.Properties.Caption = "2.侧+吸";
            this.chkFMFS2.Properties.RadioGroupIndex = 8;
            this.chkFMFS2.Size = new System.Drawing.Size(72, 19);
            this.chkFMFS2.TabIndex = 169;
            this.chkFMFS2.TabStop = false;
            this.chkFMFS2.Click += new System.EventHandler(this.chk_CheckedChanged);
            // 
            // chkFMFS3
            // 
            this.chkFMFS3.Location = new System.Drawing.Point(219, 107);
            this.chkFMFS3.Name = "chkFMFS3";
            this.chkFMFS3.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkFMFS3.Properties.Appearance.Options.UseForeColor = true;
            this.chkFMFS3.Properties.Caption = "3.产钳";
            this.chkFMFS3.Properties.RadioGroupIndex = 8;
            this.chkFMFS3.Size = new System.Drawing.Size(57, 19);
            this.chkFMFS3.TabIndex = 170;
            this.chkFMFS3.TabStop = false;
            this.chkFMFS3.Click += new System.EventHandler(this.chk_CheckedChanged);
            // 
            // chkFMFS4
            // 
            this.chkFMFS4.Location = new System.Drawing.Point(282, 107);
            this.chkFMFS4.Name = "chkFMFS4";
            this.chkFMFS4.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkFMFS4.Properties.Appearance.Options.UseForeColor = true;
            this.chkFMFS4.Properties.Caption = "4.臂牵引";
            this.chkFMFS4.Properties.RadioGroupIndex = 8;
            this.chkFMFS4.Size = new System.Drawing.Size(67, 19);
            this.chkFMFS4.TabIndex = 168;
            this.chkFMFS4.TabStop = false;
            this.chkFMFS4.Click += new System.EventHandler(this.chk_CheckedChanged);
            // 
            // chkFMFS5
            // 
            this.chkFMFS5.Location = new System.Drawing.Point(361, 107);
            this.chkFMFS5.Name = "chkFMFS5";
            this.chkFMFS5.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkFMFS5.Properties.Appearance.Options.UseForeColor = true;
            this.chkFMFS5.Properties.Caption = "5.剖宫";
            this.chkFMFS5.Properties.RadioGroupIndex = 8;
            this.chkFMFS5.Size = new System.Drawing.Size(63, 19);
            this.chkFMFS5.TabIndex = 169;
            this.chkFMFS5.TabStop = false;
            this.chkFMFS5.Click += new System.EventHandler(this.chk_CheckedChanged);
            // 
            // chkFMFS6
            // 
            this.chkFMFS6.Location = new System.Drawing.Point(430, 107);
            this.chkFMFS6.Name = "chkFMFS6";
            this.chkFMFS6.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.chkFMFS6.Properties.Appearance.Options.UseForeColor = true;
            this.chkFMFS6.Properties.Caption = "6.其他";
            this.chkFMFS6.Properties.RadioGroupIndex = 8;
            this.chkFMFS6.Size = new System.Drawing.Size(57, 19);
            this.chkFMFS6.TabIndex = 170;
            this.chkFMFS6.TabStop = false;
            this.chkFMFS6.Click += new System.EventHandler(this.chk_CheckedChanged);
            // 
            // BithDayTime
            // 
            this.BithDayTime.EditValue = new System.DateTime(2011, 3, 5, 0, 0, 0, 0);
            this.BithDayTime.Location = new System.Drawing.Point(182, 60);
            this.BithDayTime.Name = "BithDayTime";
            this.BithDayTime.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.BithDayTime.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.BithDayTime.Properties.Mask.EditMask = "HH:mm";
            this.BithDayTime.Size = new System.Drawing.Size(79, 19);
            this.BithDayTime.TabIndex = 172;
            // 
            // BithDayDate
            // 
            this.BithDayDate.EditValue = null;
            this.BithDayDate.Location = new System.Drawing.Point(76, 60);
            this.BithDayDate.Name = "BithDayDate";
            this.BithDayDate.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.BithDayDate.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.BithDayDate.Properties.VistaTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.BithDayDate.Size = new System.Drawing.Size(100, 19);
            this.BithDayDate.TabIndex = 171;
            this.BithDayDate.Validating += new System.ComponentModel.CancelEventHandler(this.BithDayDate_Validating);
            // 
            // labelControl1
            // 
            this.labelControl1.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl1.Location = new System.Drawing.Point(347, 62);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(48, 14);
            this.labelControl1.TabIndex = 157;
            this.labelControl1.Text = "接产者：";
            // 
            // gridControlBabyInfo
            // 
            this.gridControlBabyInfo.Location = new System.Drawing.Point(25, 103);
            this.gridControlBabyInfo.MainView = this.gridViewBabyInfo;
            this.gridControlBabyInfo.Name = "gridControlBabyInfo";
            this.gridControlBabyInfo.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemCheckEdit1});
            this.gridControlBabyInfo.Size = new System.Drawing.Size(604, 200);
            this.gridControlBabyInfo.TabIndex = 185;
            this.gridControlBabyInfo.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridViewBabyInfo});
            this.gridControlBabyInfo.Click += new System.EventHandler(this.gridControlBabyInfo_Click);
            // 
            // gridViewBabyInfo
            // 
            this.gridViewBabyInfo.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn1,
            this.gridColumn2,
            this.gridColumn3,
            this.gridColumn4,
            this.gridColumn5,
            this.gridColumn6,
            this.gridColumn7,
            this.gridColumn8,
            this.gridColumn9});
            this.gridViewBabyInfo.GridControl = this.gridControlBabyInfo;
            this.gridViewBabyInfo.Name = "gridViewBabyInfo";
            this.gridViewBabyInfo.OptionsCustomization.AllowColumnMoving = false;
            this.gridViewBabyInfo.OptionsCustomization.AllowColumnResizing = false;
            this.gridViewBabyInfo.OptionsCustomization.AllowFilter = false;
            this.gridViewBabyInfo.OptionsCustomization.AllowGroup = false;
            this.gridViewBabyInfo.OptionsCustomization.AllowQuickHideColumns = false;
            this.gridViewBabyInfo.OptionsCustomization.AllowSort = false;
            this.gridViewBabyInfo.OptionsFilter.AllowColumnMRUFilterList = false;
            this.gridViewBabyInfo.OptionsFilter.AllowFilterEditor = false;
            this.gridViewBabyInfo.OptionsFilter.AllowMRUFilterList = false;
            this.gridViewBabyInfo.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.gridViewBabyInfo.OptionsView.ShowGroupPanel = false;
            this.gridViewBabyInfo.OptionsView.ShowIndicator = false;
            // 
            // gridColumn1
            // 
            this.gridColumn1.Caption = "性别";
            this.gridColumn1.FieldName = "SEX";
            this.gridColumn1.Name = "gridColumn1";
            this.gridColumn1.OptionsColumn.AllowEdit = false;
            this.gridColumn1.Visible = true;
            this.gridColumn1.VisibleIndex = 0;
            // 
            // gridColumn2
            // 
            this.gridColumn2.Caption = "身长";
            this.gridColumn2.FieldName = "HEIGH";
            this.gridColumn2.Name = "gridColumn2";
            this.gridColumn2.OptionsColumn.AllowEdit = false;
            this.gridColumn2.Visible = true;
            this.gridColumn2.VisibleIndex = 1;
            // 
            // gridColumn3
            // 
            this.gridColumn3.Caption = "体重";
            this.gridColumn3.FieldName = "WEIGHT";
            this.gridColumn3.Name = "gridColumn3";
            this.gridColumn3.OptionsColumn.AllowEdit = false;
            this.gridColumn3.Visible = true;
            this.gridColumn3.VisibleIndex = 2;
            // 
            // gridColumn4
            // 
            this.gridColumn4.Caption = "出生时间";
            this.gridColumn4.FieldName = "BITHDAY";
            this.gridColumn4.Name = "gridColumn4";
            this.gridColumn4.OptionsColumn.AllowEdit = false;
            this.gridColumn4.Visible = true;
            this.gridColumn4.VisibleIndex = 3;
            // 
            // gridColumn5
            // 
            this.gridColumn5.Caption = "分娩方式";
            this.gridColumn5.FieldName = "FMFS";
            this.gridColumn5.Name = "gridColumn5";
            this.gridColumn5.OptionsColumn.AllowEdit = false;
            this.gridColumn5.Visible = true;
            this.gridColumn5.VisibleIndex = 4;
            // 
            // gridColumn6
            // 
            this.gridColumn6.Caption = "产出情况";
            this.gridColumn6.FieldName = "CCQK";
            this.gridColumn6.Name = "gridColumn6";
            this.gridColumn6.OptionsColumn.AllowEdit = false;
            this.gridColumn6.Visible = true;
            this.gridColumn6.VisibleIndex = 5;
            // 
            // gridColumn7
            // 
            this.gridColumn7.Caption = "阿帕加评分";
            this.gridColumn7.FieldName = "APJ";
            this.gridColumn7.Name = "gridColumn7";
            this.gridColumn7.OptionsColumn.AllowEdit = false;
            this.gridColumn7.Visible = true;
            this.gridColumn7.VisibleIndex = 6;
            // 
            // gridColumn8
            // 
            this.gridColumn8.Caption = "接产者";
            this.gridColumn8.FieldName = "MIDWIFERY";
            this.gridColumn8.Name = "gridColumn8";
            this.gridColumn8.OptionsColumn.AllowEdit = false;
            this.gridColumn8.Visible = true;
            this.gridColumn8.VisibleIndex = 7;
            // 
            // gridColumn9
            // 
            this.gridColumn9.Caption = "出院情况";
            this.gridColumn9.FieldName = "CYQK";
            this.gridColumn9.Name = "gridColumn9";
            this.gridColumn9.OptionsColumn.AllowEdit = false;
            this.gridColumn9.Visible = true;
            this.gridColumn9.VisibleIndex = 8;
            // 
            // repositoryItemCheckEdit1
            // 
            this.repositoryItemCheckEdit1.AutoHeight = false;
            this.repositoryItemCheckEdit1.Name = "repositoryItemCheckEdit1";
            // 
            // simpleButtonAddInfo
            // 
            this.simpleButtonAddInfo.Location = new System.Drawing.Point(292, 139);
            this.simpleButtonAddInfo.Name = "simpleButtonAddInfo";
            this.simpleButtonAddInfo.Size = new System.Drawing.Size(96, 27);
            this.simpleButtonAddInfo.TabIndex = 186;
            this.simpleButtonAddInfo.Text = "添加婴儿信息";
            this.simpleButtonAddInfo.Click += new System.EventHandler(this.simpleButtonAddInfo_Click);
            // 
            // panelControl1
            // 
            this.panelControl1.Controls.Add(this.btnEditBaby);
            this.panelControl1.Controls.Add(this.lpEdiMidwifery);
            this.panelControl1.Controls.Add(this.simpleButtonDeleteInfo);
            this.panelControl1.Controls.Add(this.chkCCQK1);
            this.panelControl1.Controls.Add(this.simpleButtonAddInfo);
            this.panelControl1.Controls.Add(this.labelControl23);
            this.panelControl1.Controls.Add(this.labelControl33);
            this.panelControl1.Controls.Add(this.labelControl30);
            this.panelControl1.Controls.Add(this.labelControl27);
            this.panelControl1.Controls.Add(this.BithDayTime);
            this.panelControl1.Controls.Add(this.labelControl32);
            this.panelControl1.Controls.Add(this.BithDayDate);
            this.panelControl1.Controls.Add(this.labelControl11);
            this.panelControl1.Controls.Add(this.labelControl34);
            this.panelControl1.Controls.Add(this.chkCYQK3);
            this.panelControl1.Controls.Add(this.labelControl2);
            this.panelControl1.Controls.Add(this.labelControl29);
            this.panelControl1.Controls.Add(this.chkCCQK4);
            this.panelControl1.Controls.Add(this.labelControl15);
            this.panelControl1.Controls.Add(this.chkCCQK3);
            this.panelControl1.Controls.Add(this.labelControl1);
            this.panelControl1.Controls.Add(this.chkFMFS6);
            this.panelControl1.Controls.Add(this.txtheigh);
            this.panelControl1.Controls.Add(this.chkFMFS3);
            this.panelControl1.Controls.Add(this.txtAPJPF);
            this.panelControl1.Controls.Add(this.txtweight);
            this.panelControl1.Controls.Add(this.chkFMFS1);
            this.panelControl1.Controls.Add(this.chkSex2);
            this.panelControl1.Controls.Add(this.chkFMFS4);
            this.panelControl1.Controls.Add(this.chkCYQK2);
            this.panelControl1.Controls.Add(this.chkCYQK1);
            this.panelControl1.Controls.Add(this.chkSex1);
            this.panelControl1.Controls.Add(this.chkCCQK2);
            this.panelControl1.Controls.Add(this.chkFMFS2);
            this.panelControl1.Controls.Add(this.chkFMFS5);
            this.panelControl1.Location = new System.Drawing.Point(25, 309);
            this.panelControl1.Name = "panelControl1";
            this.panelControl1.Size = new System.Drawing.Size(604, 171);
            this.panelControl1.TabIndex = 187;
            // 
            // btnEditBaby
            // 
            this.btnEditBaby.Location = new System.Drawing.Point(398, 139);
            this.btnEditBaby.Name = "btnEditBaby";
            this.btnEditBaby.Size = new System.Drawing.Size(96, 27);
            this.btnEditBaby.TabIndex = 189;
            this.btnEditBaby.Text = "编辑婴儿信息";
            this.btnEditBaby.Click += new System.EventHandler(this.btnEditBaby_Click);
            // 
            // lpEdiMidwifery
            // 
            this.lpEdiMidwifery.ListWindow = null;
            this.lpEdiMidwifery.Location = new System.Drawing.Point(402, 61);
            this.lpEdiMidwifery.Name = "lpEdiMidwifery";
            this.lpEdiMidwifery.ShowSButton = true;
            this.lpEdiMidwifery.Size = new System.Drawing.Size(185, 20);
            this.lpEdiMidwifery.TabIndex = 188;
            // 
            // simpleButtonDeleteInfo
            // 
            this.simpleButtonDeleteInfo.Location = new System.Drawing.Point(504, 139);
            this.simpleButtonDeleteInfo.Name = "simpleButtonDeleteInfo";
            this.simpleButtonDeleteInfo.Size = new System.Drawing.Size(96, 27);
            this.simpleButtonDeleteInfo.TabIndex = 187;
            this.simpleButtonDeleteInfo.Text = "删除婴儿信息";
            this.simpleButtonDeleteInfo.Click += new System.EventHandler(this.simpleButtonDeleteInfo_Click);
            // 
            // errorProvider
            // 
            this.errorProvider.ContainerControl = this;
            // 
            // btn_OK
            // 
            this.btn_OK.Image = ((System.Drawing.Image)(resources.GetObject("btn_OK.Image")));
            this.btn_OK.Location = new System.Drawing.Point(467, 486);
            this.btn_OK.Name = "btn_OK";
            this.btn_OK.Size = new System.Drawing.Size(75, 27);
            this.btn_OK.TabIndex = 183;
            this.btn_OK.Text = "确定(&Y)";
            this.btn_OK.Click += new System.EventHandler(this.btn_OK_Click);
            // 
            // btn_Close
            // 
            this.btn_Close.Image = ((System.Drawing.Image)(resources.GetObject("btn_Close.Image")));
            this.btn_Close.Location = new System.Drawing.Point(555, 486);
            this.btn_Close.Name = "btn_Close";
            this.btn_Close.Size = new System.Drawing.Size(75, 27);
            this.btn_Close.TabIndex = 184;
            this.btn_Close.Text = "关闭(&T)";
            this.btn_Close.Click += new System.EventHandler(this.btn_Close_Click);
            // 
            // UCObstetricsBaby
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.btn_Close);
            this.Controls.Add(this.btn_OK);
            this.Controls.Add(this.panelControl1);
            this.Controls.Add(this.gridControlBabyInfo);
            this.Controls.Add(this.chkCC3);
            this.Controls.Add(this.chkCFHYPLD3);
            this.Controls.Add(this.chkTB3);
            this.Controls.Add(this.chkTC3);
            this.Controls.Add(this.chkCC2);
            this.Controls.Add(this.chkCFHYPLD2);
            this.Controls.Add(this.chkTB2);
            this.Controls.Add(this.chkTC2);
            this.Controls.Add(this.chkCC1);
            this.Controls.Add(this.chkCFHYPLD1);
            this.Controls.Add(this.chkTB1);
            this.Controls.Add(this.chkTC1);
            this.Controls.Add(this.labelControl9);
            this.Controls.Add(this.labelControl35);
            this.Controls.Add(this.labelControl8);
            this.Controls.Add(this.labelControl7);
            this.Controls.Add(this.labelControl17);
            this.Name = "UCObstetricsBaby";
            this.Size = new System.Drawing.Size(651, 523);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.UCObstetricsBaby_Paint);
            ((System.ComponentModel.ISupportInitialize)(this.chkTC1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkTC2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkTC3.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCC1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCC2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCC3.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCFHYPLD1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCFHYPLD2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCFHYPLD3.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkSex1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkSex2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtheigh.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtweight.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCCQK1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCCQK2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCCQK3.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCCQK4.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkTB1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkTB2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkTB3.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtAPJPF.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCYQK1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCYQK2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCYQK3.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkFMFS1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkFMFS2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkFMFS3.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkFMFS4.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkFMFS5.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkFMFS6.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BithDayTime.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BithDayDate.Properties.VistaTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BithDayDate.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridControlBabyInfo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewBabyInfo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).EndInit();
            this.panelControl1.ResumeLayout(false);
            this.panelControl1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lpEdiMidwifery)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevExpress.XtraEditors.LabelControl labelControl17;
        private DevExpress.XtraEditors.LabelControl labelControl29;
        private DevExpress.XtraEditors.CheckEdit chkCC3;
        private DevExpress.XtraEditors.CheckEdit chkTC3;
        private DevExpress.XtraEditors.CheckEdit chkCC2;
        private DevExpress.XtraEditors.CheckEdit chkTC2;
        private DevExpress.XtraEditors.CheckEdit chkCC1;
        private DevExpress.XtraEditors.CheckEdit chkTC1;
        private DevExpress.XtraEditors.LabelControl labelControl8;
        private DevExpress.XtraEditors.LabelControl labelControl7;
        private DevExpress.XtraEditors.CheckEdit chkCFHYPLD3;
        private DevExpress.XtraEditors.CheckEdit chkCCQK3;
        private DevExpress.XtraEditors.CheckEdit chkSex2;
        private DevExpress.XtraEditors.CheckEdit chkCFHYPLD2;
        private DevExpress.XtraEditors.CheckEdit chkCCQK2;
        private DevExpress.XtraEditors.CheckEdit chkSex1;
        private DevExpress.XtraEditors.CheckEdit chkCFHYPLD1;
        private DevExpress.XtraEditors.CheckEdit chkCCQK1;
        private DevExpress.XtraEditors.TextEdit txtweight;
        private DevExpress.XtraEditors.TextEdit txtheigh;
        private DevExpress.XtraEditors.LabelControl labelControl9;
        private DevExpress.XtraEditors.LabelControl labelControl15;
        private DevExpress.XtraEditors.LabelControl labelControl34;
        private DevExpress.XtraEditors.LabelControl labelControl11;
        private DevExpress.XtraEditors.LabelControl labelControl32;
        private DevExpress.XtraEditors.LabelControl labelControl27;
        private DevExpress.XtraEditors.LabelControl labelControl30;
        private DevExpress.XtraEditors.LabelControl labelControl33;
        private DevExpress.XtraEditors.LabelControl labelControl23;
        private DevExpress.XtraEditors.CheckEdit chkCCQK4;
        private DevExpress.XtraEditors.CheckEdit chkTB3;
        private DevExpress.XtraEditors.CheckEdit chkTB2;
        private DevExpress.XtraEditors.CheckEdit chkTB1;
        private DevExpress.XtraEditors.LabelControl labelControl35;
        private DevExpress.XtraEditors.CheckEdit chkCYQK3;
        private DevExpress.XtraEditors.CheckEdit chkCYQK2;
        private DevExpress.XtraEditors.CheckEdit chkCYQK1;
        private DevExpress.XtraEditors.TextEdit txtAPJPF;
        private DevExpress.XtraEditors.LabelControl labelControl2;
        private DevExpress.XtraEditors.CheckEdit chkFMFS6;
        private DevExpress.XtraEditors.CheckEdit chkFMFS3;
        private DevExpress.XtraEditors.CheckEdit chkFMFS5;
        private DevExpress.XtraEditors.CheckEdit chkFMFS2;
        private DevExpress.XtraEditors.CheckEdit chkFMFS4;
        private DevExpress.XtraEditors.CheckEdit chkFMFS1;
        private DevExpress.XtraEditors.TimeEdit BithDayTime;
        private DevExpress.XtraEditors.DateEdit BithDayDate;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private DevExpress.XtraGrid.GridControl gridControlBabyInfo;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewBabyInfo;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn2;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn3;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn4;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn5;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn6;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn7;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn8;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn9;
        private DevExpress.XtraEditors.SimpleButton simpleButtonAddInfo;
        private DevExpress.XtraEditors.PanelControl panelControl1;
        private DevExpress.XtraEditors.SimpleButton simpleButtonDeleteInfo;
        private System.Windows.Forms.ErrorProvider errorProvider;
        private DrectSoft.Common.Ctrs.OTHER.DevButtonClose btn_Close;
        private DrectSoft.Common.Ctrs.OTHER.DevButtonOK btn_OK;
        private Common.Library.LookUpEditor lpEdiMidwifery;
        private DevExpress.XtraEditors.SimpleButton btnEditBaby;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit1;
    }
}
